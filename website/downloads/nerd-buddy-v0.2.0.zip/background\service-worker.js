const y = "nerd_buddy_keepalive";
let n = null;
chrome.alarms.create(y, { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener((e) => {
  e.name === y && h();
});
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: !0 }).catch((e) => console.error(e));
chrome.tabs.onActivated.addListener(async (e) => {
  try {
    const t = await chrome.tabs.get(e.tabId);
    t.url && chrome.storage.local.set({
      synqto_active_url: t.url,
      nerd_buddy_active_url: t.url
    });
  } catch {
  }
});
chrome.tabs.onUpdated.addListener((e, t, r) => {
  r.active && t.url && chrome.storage.local.set({
    synqto_active_url: t.url,
    nerd_buddy_active_url: t.url
  });
});
chrome.runtime.onMessage.addListener((e, t, r) => {
  var i, l, a, _, s;
  if (e.type === "PROBLEM_DETECTED")
    (i = t.tab) != null && i.active && chrome.storage.local.set({
      synqto_active_problem: e.payload,
      synqto_active_url: e.payload.url,
      nerd_buddy_active_problem: e.payload,
      nerd_buddy_active_url: e.payload.url
    });
  else if (e.type === "LOCAL_CURSOR_MOVE" || e.type === "LOCAL_CLICK_PULSE" || e.type === "WHITEBOARD_STROKE_LOCAL" || e.type === "WHITEBOARD_CLEAR_LOCAL" || e.type === "WHITEBOARD_UNDO_LOCAL" || e.type === "WHITEBOARD_BG_LOCAL" || e.type === "WHITEBOARD_PAGE_SYNC_LOCAL" || e.type === "TIMER_STATE_SYNC" || e.type === "CODE_DELTA_LOCAL" || e.type === "CODE_CURSOR_LOCAL" || e.type === "CODE_SYNC_LOCAL" || e.type === "CODE_DELTA_REMOTE" || e.type === "CODE_CURSOR_REMOTE" || e.type === "CODE_SYNC_REMOTE")
    chrome.runtime.sendMessage(e).catch(() => {
    }), chrome.tabs.query({}, (c) => {
      c.forEach((o) => {
        var d;
        o.id && o.id !== ((d = t.tab) == null ? void 0 : d.id) && chrome.tabs.sendMessage(o.id, e).catch(() => {
        });
      });
    });
  else if (e.type === "OPEN_SIDEPANEL") {
    const c = (l = t.tab) == null ? void 0 : l.id, o = (a = t.tab) == null ? void 0 : a.windowId;
    return c && ((_ = chrome.sidePanel) != null && _.open) ? chrome.sidePanel.open({ tabId: c }).catch(() => {
      o && chrome.sidePanel.open({ windowId: o }).catch(() => {
      });
    }) : o && ((s = chrome.sidePanel) != null && s.open) && chrome.sidePanel.open({ windowId: o }).catch(() => {
    }), chrome.storage.local.set({
      synqto_sidepanel_open: !0,
      nerd_buddy_sidepanel_open: !0
    }), r({ success: !0 }), !0;
  } else if (e.type === "SEND_PAGE_CHAT_MESSAGE")
    chrome.runtime.sendMessage(e).catch(() => {
    });
  else if (e.type === "CAPTURE_ACTIVE_TAB")
    return chrome.windows.getLastFocused({ populate: !1 }, (c) => {
      const o = c == null ? void 0 : c.id;
      ((u) => {
        const f = (p) => {
          var E;
          chrome.runtime.lastError || !p ? (console.warn("[ServiceWorker] captureVisibleTab failed:", chrome.runtime.lastError), r({ success: !1, error: ((E = chrome.runtime.lastError) == null ? void 0 : E.message) || "Capture failed" })) : r({ success: !0, dataUrl: p });
        };
        u !== void 0 ? chrome.tabs.captureVisibleTab(u, { format: "png" }, f) : chrome.tabs.captureVisibleTab({ format: "png" }, f);
      })(o);
    }), !0;
  return !0;
});
chrome.storage.onChanged.addListener((e, t) => {
  var r;
  if (t === "local" && (e.synqto_fab_settings || e.nerd_buddy_fab_settings)) {
    const i = (r = e.synqto_fab_settings || e.nerd_buddy_fab_settings) == null ? void 0 : r.newValue;
    i && chrome.tabs.query({}, (l) => {
      l.forEach((a) => {
        a.id && chrome.tabs.sendMessage(a.id, {
          type: "FAB_SETTINGS_UPDATED",
          payload: i
        }).catch(() => {
        });
      });
    });
  }
});
async function h() {
  var t;
  const e = "offscreen.html";
  try {
    if (typeof ((t = chrome.runtime) == null ? void 0 : t.getContexts) == "function" && (await chrome.runtime.getContexts({
      contextTypes: ["OFFSCREEN_DOCUMENT"],
      documentUrls: [chrome.runtime.getURL(e)]
    })).length > 0)
      return;
    if (n) {
      await n;
      return;
    }
    typeof chrome.offscreen < "u" && (n = chrome.offscreen.createDocument({
      url: e,
      reasons: ["WEB_RTC"],
      justification: "Maintain P2P presence and notifications when sidepanel is closed"
    }), await n, n = null);
  } catch (r) {
    console.debug("[ServiceWorker] Offscreen doc initialization bypassed:", r), n = null;
  }
}
h();
