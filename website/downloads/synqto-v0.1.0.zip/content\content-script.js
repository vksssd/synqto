(function(){"use strict";function k(a){let t=2166136261,e=2166136261;for(let r=0;r<a.length;r++){const n=a.charCodeAt(r);t=Math.imul(t^n&255,16777619),e=Math.imul(e^n>>8,16777619)}return((t>>>0^e>>>0)>>>0).toString(16).padStart(8,"0")}function S(a,t){let e=null;return(...s)=>{e&&clearTimeout(e),e=setTimeout(()=>a(...s),t)}}function x(a,t){var e;try{const s=new URL(a),r=s.hostname.toLowerCase(),n=s.pathname;if(r.includes("leetcode.com")){const i=n.match(/\/problems\/([a-zA-Z0-9-_]+)/);if(i&&i[1]){const o=i[1],l=b(o);return{platform:"LeetCode",slug:o,title:l,url:a,canonicalUrl:`https://leetcode.com/problems/${o}/`}}}if(r.includes("neetcode.io")){const i=n.match(/\/problems\/([a-zA-Z0-9-_]+)/);if(i&&i[1]){const o=i[1],l=b(o);return{platform:"NeetCode",slug:o,title:l,url:a,canonicalUrl:`https://neetcode.io/problems/${o}`}}}if(r.includes("codeforces.com")){const i=n.match(/\/(?:contest|problemset\/problem)\/(\d+)\/([A-Z0-9]+)/i);if(i){const o=i[1],l=i[2].toUpperCase();return{platform:"Codeforces",slug:`cf-${o}-${l}`,title:`Codeforces ${o}${l}`,url:a,canonicalUrl:`https://codeforces.com/problemset/problem/${o}/${l}`}}}if(r.includes("hackerrank.com")){const i=n.match(/\/challenges\/([a-zA-Z0-9-_]+)/);if(i&&i[1]){const o=i[1];return{platform:"HackerRank",slug:o,title:b(o),url:a,canonicalUrl:`https://www.hackerrank.com/challenges/${o}/problem`}}}if(r.includes("codechef.com")){const i=n.match(/\/problems\/([a-zA-Z0-9-_]+)/);if(i&&i[1]){const o=i[1];return{platform:"CodeChef",slug:o,title:`CodeChef ${o}`,url:a,canonicalUrl:`https://www.codechef.com/problems/${o}`}}}if(r.includes("geeksforgeeks.org")){const i=n.match(/\/problems\/([a-zA-Z0-9-_]+)/);if(i&&i[1]){const o=i[1];return{platform:"GeeksforGeeks",slug:o,title:b(o),url:a,canonicalUrl:`https://www.geeksforgeeks.org/problems/${o}/1`}}}if(r.includes("youtube.com")||r.includes("youtu.be")){let i=s.searchParams.get("v");if(!i&&r.includes("youtu.be")&&(i=n.slice(1)),!i&&n.includes("/shorts/")&&(i=(e=n.split("/shorts/")[1])==null?void 0:e.split("/")[0]),i){const o=t?C(t):`YouTube Video (${i})`;return{platform:"YouTube",slug:`yt-${i}`,title:o,url:a,canonicalUrl:`https://www.youtube.com/watch?v=${i}`}}}if(r.includes("arxiv.org")){const i=n.match(/\/(?:abs|pdf)\/(\d+\.\d+(?:v\d+)?)/);if(i&&i[1]){const o=i[1];return{platform:"ArXiv",slug:`arxiv-${o.replace(/\./g,"-")}`,title:t?$(t):`ArXiv ${o}`,url:a,canonicalUrl:`https://arxiv.org/abs/${o}`}}}if(r.includes("github.com")){const i=n.match(/^\/([^\/]+)\/([^\/]+)\/(?:issues|pull)\/(\d+)/);if(i){const o=i[1],l=i[2],p=i[3];return{platform:"GitHub",slug:`gh-${o}-${l}-${p}`,title:`${o}/${l} #${p}`,url:a,canonicalUrl:`https://github.com/${o}/${l}/issues/${p}`}}}return{platform:"Web",slug:r.replace(/\./g,"-")||"general-study",title:t||r||"General Study Room",url:a,canonicalUrl:a}}catch{return null}}function b(a){return a.split(/[-_]/).map(t=>t.charAt(0).toUpperCase()+t.slice(1)).join(" ")}function C(a){return a.replace(/\s*-\s*YouTube\s*$/,"").trim()}function $(a){return a.replace(/^\[[^\]]+\]\s*/,"").replace(/\s*-\s*arXiv.*$/,"").trim()}function w(){try{return!!(typeof chrome<"u"&&chrome.runtime&&chrome.runtime.id)}catch{return!1}}class E{constructor(t){this.lastUrl="",this.lastTitle="",this.mutationObserver=null,this.pollTimer=null,this.debouncedCheck=S(()=>{if(!w()){this.destroy();return}this.checkCurrentPage()},250),this.callback=t,this.init()}init(){this.checkCurrentPage();const t=history.pushState,e=history.replaceState;history.pushState=(...r)=>{t.apply(history,r),this.debouncedCheck()},history.replaceState=(...r)=>{e.apply(history,r),this.debouncedCheck()},window.addEventListener("popstate",()=>this.debouncedCheck()),window.addEventListener("hashchange",()=>this.debouncedCheck()),window.addEventListener("yt-navigate-finish",()=>this.debouncedCheck()),this.mutationObserver=new MutationObserver(()=>{document.title!==this.lastTitle&&this.debouncedCheck()});const s=document.querySelector("title");s&&this.mutationObserver.observe(s,{subtree:!0,characterData:!0,childList:!0}),this.pollTimer=setInterval(()=>{if(!w()){this.destroy();return}window.location.href!==this.lastUrl&&this.checkCurrentPage()},350)}checkCurrentPage(){const t=window.location.href,e=document.title;if(t===this.lastUrl&&e===this.lastTitle)return;this.lastUrl=t,this.lastTitle=e;const s=x(t,e);s&&this.callback(s)}destroy(){this.mutationObserver&&(this.mutationObserver.disconnect(),this.mutationObserver=null),this.pollTimer&&(clearInterval(this.pollTimer),this.pollTimer=null)}}function y(){try{return!!(typeof chrome<"u"&&chrome.runtime&&chrome.runtime.id)}catch{return!1}}class I{constructor(){this.container=null,this.cursorElements=new Map,this.cursorTimeouts=new Map,this.myIdentity=null,this.liveStage=null,this.createContainer(),this.loadState(),this.listenToStorage(),this.listenForMessages(),this.setupLocalTrackers()}async loadState(){var t;if(typeof chrome<"u"&&((t=chrome.storage)!=null&&t.local))try{const e=await chrome.storage.local.get(["nerd_buddy_identity","synqme_identity","nerd_buddy_live_stage","synqme_live_stage"]);this.myIdentity=e.synqme_identity||e.nerd_buddy_identity||null,this.liveStage=e.synqme_live_stage||e.nerd_buddy_live_stage||null,(!this.liveStage||!this.liveStage.isActive)&&this.clearAllCursors()}catch{}}listenToStorage(){var t;typeof chrome<"u"&&((t=chrome.storage)!=null&&t.onChanged)&&chrome.storage.onChanged.addListener((e,s)=>{s==="local"&&((e.synqme_identity||e.nerd_buddy_identity)&&(this.myIdentity=(e.synqme_identity||e.nerd_buddy_identity).newValue),(e.synqme_live_stage||e.nerd_buddy_live_stage)&&(this.liveStage=(e.synqme_live_stage||e.nerd_buddy_live_stage).newValue,(!this.liveStage||!this.liveStage.isActive)&&this.clearAllCursors()))})}clearAllCursors(){this.cursorTimeouts.forEach(t=>clearTimeout(t)),this.cursorTimeouts.clear(),this.cursorElements.forEach(t=>{t.remove()}),this.cursorElements.clear(),this.container&&(this.container.innerHTML="")}isLocalUserOnStage(){var e,s;if(!this.liveStage||!this.liveStage.isActive)return!1;const t=(e=this.myIdentity)==null?void 0:e.peerId;return t?!!(((s=this.liveStage.tutorIdentity)==null?void 0:s.peerId)===t||this.liveStage.tutorPeerId===t||this.liveStage.myRole==="tutor"||Array.isArray(this.liveStage.guestSpeakers)&&this.liveStage.guestSpeakers.some(r=>r.peerId===t)):!1}createContainer(){if(document.getElementById("nerd-buddy-cursor-overlay"))return;const t=document.createElement("div");if(t.id="nerd-buddy-cursor-overlay",t.style.cssText=`
      position: fixed !important;
      top: 0 !important;
      left: 0 !important;
      width: 100vw !important;
      height: 100vh !important;
      pointer-events: none !important;
      z-index: 2147483645 !important;
      overflow: hidden !important;
      box-sizing: border-box !important;
    `,document.body.appendChild(t),this.container=t,!document.getElementById("nerd-buddy-cursor-styles")){const e=document.createElement("style");e.id="nerd-buddy-cursor-styles",e.textContent=`
        @keyframes nb-click-ripple {
          0% { transform: scale(0.15); opacity: 1; }
          40% { opacity: 0.9; }
          100% { transform: scale(2.8); opacity: 0; }
        }
      `,document.head.appendChild(e)}}listenForMessages(){var t;if(!(!y()||!((t=chrome.runtime)!=null&&t.onMessage)))try{chrome.runtime.onMessage.addListener(e=>{var s,r,n,d;if(y()){if(e.type==="NERD_BUDDY_STAGE_ENDED"||e.type==="NERD_BUDDY_STAGE_INACTIVE"){this.clearAllCursors();return}if(e.type==="NERD_BUDDY_CURSOR_UPDATE"&&e.cursor){const i=e.cursor;(i.isTutor||this.liveStage&&(((s=this.liveStage.tutorIdentity)==null?void 0:s.peerId)===i.peerId||this.liveStage.tutorPeerId===i.peerId||((r=this.liveStage.guestSpeakers)==null?void 0:r.some(l=>l.peerId===i.peerId)))||!this.liveStage)&&this.renderCursor(i)}else if(e.type==="NERD_BUDDY_CLICK_PULSE"&&e.click){const i=e.click;(i.isTutor||this.liveStage&&(((n=this.liveStage.tutorIdentity)==null?void 0:n.peerId)===i.peerId||this.liveStage.tutorPeerId===i.peerId||((d=this.liveStage.guestSpeakers)==null?void 0:d.some(l=>l.peerId===i.peerId)))||i.isTutor||!this.liveStage)&&this.renderClickPulse(i)}}})}catch{}}renderCursor(t){if(this.container||this.createContainer(),!this.container)return;let e=this.cursorElements.get(t.peerId);e||(e=document.createElement("div"),e.style.cssText=`
        position: fixed !important;
        pointer-events: none !important;
        transition: left 0.05s linear, top 0.05s linear, opacity 0.3s ease !important;
        display: flex !important;
        align-items: center !important;
        gap: 5px !important;
        opacity: 1 !important;
        z-index: 2147483646 !important;
      `,this.container.appendChild(e),this.cursorElements.set(t.peerId,e));const s=Math.max(0,Math.min(window.innerWidth-30,t.xPct/100*window.innerWidth)),r=Math.max(0,Math.min(window.innerHeight-30,t.yPct/100*window.innerHeight));e.style.left=`${s}px`,e.style.top=`${r}px`,e.style.opacity="1";const n=t.isTutor?"#8b5cf6":t.color||"#6366f1";e.innerHTML=`
      <div style="
        width: 18px;
        height: 18px;
        border-radius: 50%;
        background: ${n};
        box-shadow: 0 0 16px ${n}, 0 0 6px #ffffff;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 11px;
        color: #fff;
        border: 2px solid #ffffff;
      ">
        ${t.avatar||"👑"}
      </div>
      <div style="
        background: rgba(15, 23, 42, 0.92);
        border: 1px solid ${n};
        color: #f8fafc;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        font-size: 10px;
        font-weight: 600;
        padding: 2px 6px;
        border-radius: 4px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.6);
        white-space: nowrap;
      ">
        ${t.nickname} ${t.isTutor?"🎓 (Tutor)":"🎤 (Speaker)"}
      </div>
    `;const d=this.cursorTimeouts.get(t.peerId);d&&clearTimeout(d);const i=window.setTimeout(()=>{e&&(e.style.opacity="0")},4e3);this.cursorTimeouts.set(t.peerId,i)}renderClickPulse(t){if(this.container||this.createContainer(),!this.container)return;const e=t.xPct/100*window.innerWidth,s=t.yPct/100*window.innerHeight,r=document.createElement("div"),n=t.color||(t.isTutor?"#8b5cf6":"#6366f1");r.style.cssText=`
      position: fixed !important;
      left: ${e-22}px !important;
      top: ${s-22}px !important;
      width: 44px !important;
      height: 44px !important;
      border-radius: 50% !important;
      border: 3px solid ${n} !important;
      box-shadow: 0 0 16px ${n}, inset 0 0 8px ${n} !important;
      pointer-events: none !important;
      z-index: 2147483647 !important;
      box-sizing: border-box !important;
      animation: nb-click-ripple 0.85s cubic-bezier(0.1, 0.8, 0.3, 1) forwards !important;
    `,this.container.appendChild(r),setTimeout(()=>{r.remove()},900)}setupLocalTrackers(){let t=0;window.addEventListener("mousemove",e=>{if(!y()||!this.isLocalUserOnStage())return;const s=Date.now();if(s-t<40)return;t=s;const r=e.clientX/window.innerWidth*100,n=e.clientY/window.innerHeight*100;try{chrome.runtime.sendMessage({type:"LOCAL_CURSOR_MOVE",xPct:r,yPct:n}).catch(()=>{})}catch{}}),window.addEventListener("click",e=>{var n,d,i;if(!y()||!this.isLocalUserOnStage())return;const s=e.clientX/window.innerWidth*100,r=e.clientY/window.innerHeight*100;this.renderClickPulse({peerId:((n=this.myIdentity)==null?void 0:n.peerId)||"local",nickname:((d=this.myIdentity)==null?void 0:d.nickname)||"You",xPct:s,yPct:r,color:((i=this.myIdentity)==null?void 0:i.color)||"#8b5cf6",isTutor:!0,timestamp:Date.now()});try{chrome.runtime.sendMessage({type:"LOCAL_CLICK_PULSE",xPct:s,yPct:r}).catch(()=>{})}catch{}})}}const T={mode:"coding_sites",clickAction:"open_popup",customDomains:["leetcode.com","neetcode.io","codeforces.com","hackerrank.com","geeksforgeeks.org"]},f="nerd_buddy_fab_settings";function M(a,t){const e=a.toLowerCase().replace(/[^a-z0-9-_]/g,"-").slice(0,24).replace(/-+$/,""),s=k(t);return`room:${e||"lobby"}-${s}`}function P(a){switch(a.toLowerCase()){case"leetcode":return"#FFA116";case"neetcode":return"#8B5CF6";case"codeforces":return"#318CE7";case"hackerrank":return"#2EC866";case"codechef":return"#5B4638";case"geeksforgeeks":return"#2F8D46";case"youtube":return"#FF0000";case"arxiv":return"#B31B1B";case"github":return"#24292F";case"group":return"#8B5CF6";default:return"#6366F1"}}class A{constructor(){this.hostElement=null,this.shadow=null,this.isOpen=!1,this.settings=T,this.currentProblem=null,this.messages=[],this.unreadCount=0,this.currentRoomStorageKey="",this.myIdentity=null,this.liveStage=null,this.peerCount=1,this.replyingTo=null,this.revealedSpoilers={},this.init()}async init(){await this.loadIdentity(),await this.loadSettings(),this.detectCurrentPageProblem(),this.checkVisibilityAndRender(),this.listenToStorageChanges()}async loadIdentity(){var t;if(typeof chrome<"u"&&((t=chrome.storage)!=null&&t.local)){const e=await chrome.storage.local.get(["nerd_buddy_identity"]);e.nerd_buddy_identity&&(this.myIdentity=e.nerd_buddy_identity)}this.myIdentity||(this.myIdentity={peerId:"peer-"+Math.random().toString(36).slice(2,10),nickname:"Coder"+Math.floor(Math.random()*900+100),avatar:"⚡",color:"#6366f1"})}async loadSettings(){var t,e;if(typeof chrome<"u"&&((t=chrome.storage)!=null&&t.local)){const s=await chrome.storage.local.get([f,"nerd_buddy_active_problem","nerd_buddy_live_stage","nerd_buddy_sidepanel_open","nerd_buddy_peer_count"]);s[f]&&(this.settings=s[f]),s.nerd_buddy_active_problem&&(this.currentProblem=s.nerd_buddy_active_problem,this.currentRoomStorageKey=`nerd_buddy_chat_${((e=this.currentProblem)==null?void 0:e.roomId)||""}`,await this.loadMessages()),s.nerd_buddy_live_stage&&(this.liveStage=s.nerd_buddy_live_stage),typeof s.nerd_buddy_peer_count=="number"&&(this.peerCount=Math.max(1,s.nerd_buddy_peer_count))}}detectCurrentPageProblem(){const t=x(window.location.href,document.title);if(t){const e=M(t.slug,t.canonicalUrl);this.currentProblem={platform:t.platform,slug:t.slug,title:t.title,canonicalUrl:t.canonicalUrl,roomId:e},this.currentRoomStorageKey=`nerd_buddy_chat_${e}`,this.loadMessages()}}shouldShow(){if(this.settings.mode==="disabled")return!1;if(this.settings.mode==="all_sites")return!0;const t=window.location.hostname.toLowerCase();if(this.settings.mode==="custom_sites")return this.settings.customDomains.some(n=>t.includes(n.toLowerCase()));const s=["leetcode.com","neetcode.io","codeforces.com","hackerrank.com","geeksforgeeks.org","codechef.com","atcoder.jp","github.com","youtube.com","arxiv.org"].some(n=>t.includes(n)),r=!!(this.currentProblem||x(window.location.href));return s||r}checkVisibilityAndRender(){const t=this.shouldShow();t&&!this.hostElement?this.createWidgetDOM():!t&&this.hostElement&&(this.hostElement.remove(),this.hostElement=null,this.shadow=null)}createWidgetDOM(){document.getElementById("nerd-buddy-floating-root")||(this.hostElement=document.createElement("div"),this.hostElement.id="nerd-buddy-floating-root",this.hostElement.style.cssText=`
      position: fixed;
      bottom: 24px;
      right: 24px;
      z-index: 2147483645;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
    `,document.body.appendChild(this.hostElement),this.shadow=this.hostElement.attachShadow({mode:"open"}),this.render())}render(){var i;if(!this.shadow)return;const t=this.currentProblem?this.currentProblem.title:"Study Circle",e=this.currentProblem?this.currentProblem.platform:"General",s=P(e),r=!!(this.liveStage&&this.liveStage.isActive),n=r?((i=this.liveStage.tutorIdentity)==null?void 0:i.nickname)||"Tutor":"",d=r?(this.liveStage.broadcastType||"Audio").toUpperCase():"";this.shadow.innerHTML=`
      <style>
        :host {
          --bg-app: #030712;
          --bg-surface: rgba(15, 23, 42, 0.85);
          --bg-surface-elevated: rgba(30, 41, 59, 0.92);
          --bg-glass-input: rgba(3, 7, 18, 0.7);
          --border-subtle: rgba(255, 255, 255, 0.08);
          --border-medium: rgba(255, 255, 255, 0.14);
          --border-focus: rgba(99, 102, 241, 0.5);
          --primary: #6366f1;
          --primary-glow: rgba(99, 102, 241, 0.35);
          --accent-purple: #8b5cf6;
          --accent-emerald: #10b981;
          --accent-rose: #f43f5e;
          --accent-cyan: #06b6d4;
          --text-primary: #f8fafc;
          --text-secondary: #94a3b8;
          --text-muted: #64748b;
          --text-dim: #475569;
          --font-mono: 'JetBrains Mono', 'Fira Code', Consolas, Monaco, monospace;
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }

        /* Custom Scrollbar */
        ::-webkit-scrollbar { width: 5px; height: 5px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: rgba(255, 255, 255, 0.15); border-radius: 4px; }
        ::-webkit-scrollbar-thumb:hover { background: rgba(255, 255, 255, 0.25); }

        /* Floating Action Button */
        .fab-button {
          display: flex;
          align-items: center;
          gap: 8px;
          padding: 10px 16px;
          border-radius: 9999px;
          background: ${r?"linear-gradient(135deg, #ef4444, #dc2626)":"linear-gradient(135deg, #4f46e5, #7c3aed)"};
          color: #ffffff;
          border: 1px solid rgba(255, 255, 255, 0.25);
          box-shadow: ${r?"0 0 24px rgba(239, 68, 68, 0.65)":"0 10px 25px -5px rgba(79, 70, 229, 0.5), 0 8px 10px -6px rgba(0, 0, 0, 0.3)"};
          cursor: pointer;
          font-size: 13px;
          font-weight: 600;
          transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
          user-select: none;
          backdrop-filter: blur(12px);
        }

        .fab-button:hover {
          transform: translateY(-2px) scale(1.03);
          box-shadow: ${r?"0 0 32px rgba(239, 68, 68, 0.85)":"0 14px 28px -5px rgba(79, 70, 229, 0.65)"};
        }

        .live-dot {
          width: 8px;
          height: 8px;
          border-radius: 50%;
          background: #ffffff;
          box-shadow: 0 0 8px #ffffff;
          animation: pulse 1.2s infinite;
        }

        @keyframes pulse {
          0%, 100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.4; transform: scale(0.85); }
        }

        .fab-badge {
          background: #f59e0b;
          color: #ffffff;
          font-size: 10px;
          font-weight: 700;
          padding: 2px 6px;
          border-radius: 9999px;
        }

        /* In-Page Popup Card (Identical to Sidepanel Chat View) */
        .popup-card {
          display: ${this.isOpen?"flex":"none"};
          flex-direction: column;
          position: absolute;
          bottom: 56px;
          right: 0;
          width: 380px;
          height: 520px;
          max-height: 82vh;
          background: rgba(15, 23, 42, 0.96);
          border: 1px solid ${r?"rgba(239, 68, 68, 0.45)":"rgba(99, 102, 241, 0.35)"};
          border-radius: 16px;
          box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.85), 0 0 24px ${r?"rgba(239, 68, 68, 0.25)":"rgba(99, 102, 241, 0.2)"};
          backdrop-filter: blur(20px);
          -webkit-backdrop-filter: blur(20px);
          overflow: hidden;
          animation: slideIn 0.2s cubic-bezier(0.16, 1, 0.3, 1);
          color: var(--text-primary);
        }

        @keyframes slideIn {
          from { opacity: 0; transform: translateY(12px) scale(0.96); }
          to { opacity: 1; transform: translateY(0) scale(1); }
        }

        /* Room Header (Matches RoomCard) */
        .room-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 10px 12px;
          background: linear-gradient(135deg, rgba(30, 41, 59, 0.95), rgba(15, 23, 42, 0.95));
          border-bottom: 1px solid var(--border-subtle);
        }

        .room-info {
          display: flex;
          align-items: center;
          gap: 10px;
          overflow: hidden;
        }

        .platform-icon-box {
          width: 34px;
          height: 34px;
          border-radius: 10px;
          background: rgba(99, 102, 241, 0.15);
          border: 1px solid rgba(255, 255, 255, 0.1);
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 18px;
          flex-shrink: 0;
        }

        .problem-title {
          font-size: 13px;
          font-weight: 700;
          color: var(--text-primary);
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
          max-width: 170px;
        }

        .badges-row {
          display: flex;
          align-items: center;
          gap: 6px;
          margin-top: 2px;
        }

        .platform-pill {
          font-size: 9px;
          font-weight: 700;
          padding: 1px 6px;
          border-radius: 4px;
          background: ${s}20;
          border: 1px solid ${s}50;
          color: ${s};
          text-transform: uppercase;
        }

        .peer-count-pill {
          font-size: 10px;
          color: var(--text-secondary);
          display: flex;
          align-items: center;
          gap: 4px;
        }

        .header-actions {
          display: flex;
          align-items: center;
          gap: 4px;
        }

        .icon-btn {
          background: transparent;
          border: none;
          color: var(--text-secondary);
          cursor: pointer;
          padding: 5px;
          border-radius: 6px;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: all 0.15s;
        }

        .icon-btn:hover {
          background: rgba(255, 255, 255, 0.1);
          color: #ffffff;
        }

        /* Live Broadcast Alert Bar */
        .live-stage-banner {
          background: linear-gradient(135deg, rgba(239, 68, 68, 0.25), rgba(139, 92, 246, 0.2));
          border-bottom: 1px solid rgba(239, 68, 68, 0.35);
          padding: 6px 12px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          font-size: 11px;
          color: #fca5a5;
        }

        /* Messages List (Matches ChatCard.tsx exactly) */
        .message-list {
          flex: 1;
          overflow-y: auto;
          padding: 12px;
          display: flex;
          flex-direction: column;
          gap: 10px;
        }

        .chat-bubble {
          display: flex;
          flex-direction: column;
          max-width: 86%;
          padding: 8px 12px;
          border-radius: 14px;
          font-size: 12px;
          position: relative;
          word-break: break-word;
          line-height: 1.45;
        }

        .chat-bubble.self {
          align-self: flex-end;
          background: linear-gradient(135deg, rgba(99, 102, 241, 0.28), rgba(139, 92, 246, 0.22));
          border: 1px solid rgba(99, 102, 241, 0.35);
          border-bottom-right-radius: 4px;
          color: #ffffff;
        }

        .chat-bubble.other {
          align-self: flex-start;
          background: var(--bg-surface-elevated);
          border: 1px solid var(--border-subtle);
          border-bottom-left-radius: 4px;
          color: #f1f5f9;
        }

        .chat-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 8px;
          margin-bottom: 4px;
          font-size: 11px;
        }

        .chat-author {
          font-weight: 600;
          display: flex;
          align-items: center;
          gap: 4px;
        }

        .chat-timestamp {
          color: var(--text-dim);
          font-size: 10px;
        }

        .reply-quote-preview {
          border-left: 2px solid var(--primary);
          padding-left: 6px;
          margin-bottom: 4px;
          font-size: 10px;
          color: var(--text-muted);
          font-style: italic;
        }

        .chat-footer {
          display: flex;
          align-items: center;
          justify-content: flex-end;
          gap: 4px;
          margin-top: 4px;
          font-size: 10px;
          color: var(--text-dim);
        }

        .ack-read {
          color: var(--accent-cyan);
          font-weight: bold;
        }

        /* Reply Banner */
        .replying-banner {
          display: flex;
          align-items: center;
          justify-content: space-between;
          background: rgba(99, 102, 241, 0.15);
          border: 1px solid rgba(99, 102, 241, 0.3);
          border-radius: 6px;
          padding: 4px 8px;
          font-size: 11px;
          color: var(--text-secondary);
          margin: 0 10px;
        }

        /* Quick Strategy Prompt Pills (Matches ChatInput.tsx) */
        .prompt-pills-row {
          display: flex;
          gap: 5px;
          padding: 6px 10px;
          overflow-x: auto;
          background: rgba(15, 23, 42, 0.4);
          border-top: 1px solid var(--border-subtle);
        }

        .prompt-pill {
          white-space: nowrap;
          background: rgba(255, 255, 255, 0.05);
          border: 1px solid var(--border-subtle);
          border-radius: 9999px;
          padding: 3px 8px;
          font-size: 10px;
          color: var(--text-secondary);
          cursor: pointer;
          transition: all 0.15s ease;
        }

        .prompt-pill:hover {
          background: rgba(99, 102, 241, 0.2);
          border-color: rgba(99, 102, 241, 0.4);
          color: #ffffff;
        }

        /* Composer Toolbar (Matches ChatInput.tsx) */
        .composer-box {
          display: flex;
          align-items: center;
          gap: 6px;
          padding: 8px 10px;
          background: rgba(30, 41, 59, 0.92);
          border-top: 1px solid var(--border-subtle);
        }

        .input-glass {
          flex: 1;
          background: var(--bg-glass-input);
          border: 1px solid var(--border-medium);
          border-radius: 8px;
          color: #ffffff;
          font-size: 12px;
          padding: 7px 10px;
          outline: none;
          font-family: inherit;
        }

        .input-glass:focus {
          border-color: var(--border-focus);
          box-shadow: 0 0 10px var(--primary-glow);
        }

        .btn-send {
          background: linear-gradient(135deg, var(--primary), var(--accent-purple));
          border: 1px solid rgba(255, 255, 255, 0.15);
          color: #ffffff;
          padding: 7px 12px;
          border-radius: 8px;
          cursor: pointer;
          font-size: 12px;
          font-weight: 600;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: all 0.15s ease;
        }

        .btn-send:hover {
          filter: brightness(1.1);
        }
      </style>

      <!-- In-Page Chat Popup -->
      <div class="popup-card" id="nb-popup">
        <!-- Room Header -->
        <div class="room-header">
          <div class="room-info">
            <div class="platform-icon-box">⚡</div>
            <div>
              <div class="problem-title">${t}</div>
              <div class="badges-row">
                <span class="platform-pill">${e}</span>
                <span class="peer-count-pill">
                  <span style="display:inline-block;width:6px;height:6px;border-radius:50%;background:#10b981;"></span>
                  <span>${this.peerCount} Online</span>
                </span>
              </div>
            </div>
          </div>

          <div class="header-actions">
            <button class="icon-btn" id="nb-open-sidepanel" title="Open complete extension in side panel">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M15 3h6v6M10 14L21 3M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6"/>
              </svg>
            </button>
            <button class="icon-btn" id="nb-close-popup" title="Minimize">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M18 6L6 18M6 6l12 12"/>
              </svg>
            </button>
          </div>
        </div>

        <!-- Live Broadcaster Banner if Active -->
        ${r?`
          <div class="live-stage-banner">
            <div style="display:flex;align-items:center;gap:6px;">
              <span class="live-dot"></span>
              <span><strong>${n}</strong> is broadcasting ${d}</span>
            </div>
            <button id="nb-live-tunein" style="background:#ef4444;color:#fff;border:none;padding:3px 8px;border-radius:4px;font-size:10px;font-weight:600;cursor:pointer;">
              Watch Stream 📺
            </button>
          </div>
        `:""}

        <!-- Message List -->
        <div class="message-list" id="nb-messages">
          ${this.messages.length===0?`
            <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:100%;color:var(--text-muted);gap:8px;padding:30px 10px;text-align:center;">
              <div style="font-size:28px;">💬</div>
              <div style="font-size:13px;font-weight:600;color:var(--text-secondary);">No messages yet</div>
              <div style="font-size:11px;max-width:220px;">Say hello or ask for a hint! Messages are synchronized P2P across all peers.</div>
            </div>
          `:this.messages.map((o,l)=>{var p,g,u,c;return`
            <div class="chat-bubble ${o.isSelf?"self":"other"}">
              ${o.replyPreview?`<div class="reply-quote-preview">${this.escapeHtml(o.replyPreview)}</div>`:""}
              
              <div class="chat-header">
                <div class="chat-author">
                  <span>${((p=o.from)==null?void 0:p.avatar)||"👤"}</span>
                  <span style="color:${o.isSelf?"#ffffff":((g=o.from)==null?void 0:g.color)||"#a5b4fc"}">
                    ${o.isSelf?"You":((u=o.from)==null?void 0:u.nickname)||"Buddy"}
                  </span>
                </div>
                <div style="display:flex;align-items:center;gap:4px;">
                  <span class="chat-timestamp">${this.formatTimestamp(o.timestamp)}</span>
                  <button class="icon-btn nb-reply-trigger" data-id="${o.id}" data-text="${this.escapeHtml(o.text.slice(0,35))}" data-nick="${this.escapeHtml(((c=o.from)==null?void 0:c.nickname)||"Buddy")}" style="padding:0;width:18px;height:18px;" title="Reply">
                    <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                      <path d="M9 14L4 9l5-5"/>
                      <path d="M4 9h10.5a5.5 5.5 0 0 1 5.5 5.5v5.5"/>
                    </svg>
                  </button>
                </div>
              </div>

              <div class="chat-body">${this.renderFormattedText(o.text,l)}</div>

              ${o.isSelf?`
                <div class="chat-footer">
                  ${o.status==="pending"?"<span>⏳</span>":""}
                  ${o.status==="sent"?'<span style="color:var(--text-dim);">✓</span>':""}
                  ${o.status==="delivered"?'<span style="color:var(--text-secondary);">✓✓</span>':""}
                  ${o.status==="read"?'<span class="ack-read">✓✓</span>':""}
                </div>
              `:""}
            </div>
          `}).join("")}
        </div>

        <!-- Replying Banner -->
        ${this.replyingTo?`
          <div class="replying-banner">
            <span>Replying to <strong>${this.replyingTo.from.nickname}</strong>: ${this.escapeHtml(this.replyingTo.text.slice(0,30))}...</span>
            <button class="icon-btn" id="nb-cancel-reply" style="padding:0;width:18px;height:18px;">✕</button>
          </div>
        `:""}

        <!-- Quick Strategy Prompt Pills -->
        <div class="prompt-pills-row">
          <button class="prompt-pill" data-text="⚡ O(N) Time">⚡ O(N) Time</button>
          <button class="prompt-pill" data-text="💾 O(1) Space">💾 O(1) Space</button>
          <button class="prompt-pill" data-text="👉 Two Pointers">👉 Two Pointers</button>
          <button class="prompt-pill" data-text="🔍 Binary Search">🔍 Binary Search</button>
          <button class="prompt-pill" data-text="🧠 DP / Memo">🧠 DP / Memo</button>
          <button class="prompt-pill" data-text="💡 Sliding Window">💡 Sliding Window</button>
          <button class="prompt-pill" data-text="⏳ Anyone stuck?">⏳ Anyone stuck?</button>
        </div>

        <!-- Input Box & Composer -->
        <form class="composer-box" id="nb-composer">
          <button type="button" class="icon-btn" id="nb-spoiler-insert" title="Insert Spoiler Blur ||text||" style="width:28px;height:28px;flex-shrink:0;">
            👁️‍🗨️
          </button>
          <input type="text" class="input-glass" id="nb-input" placeholder="Type a hint, code snippet, or ||spoiler||..." />
          <button type="submit" class="btn-send">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <line x1="22" y1="2" x2="11" y2="13"></line>
              <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
            </svg>
          </button>
        </form>
      </div>

      <!-- Floating Action Button (FAB) -->
      <button class="fab-button" id="nb-fab-trigger">
        ${r?'<span class="live-dot"></span>':"<span>⚡</span>"}
        <span>${r?`LIVE (${n})`:"Nerd Buddy"}</span>
        ${this.unreadCount>0?`<span class="fab-badge">${this.unreadCount}</span>`:""}
      </button>
    `,this.attachEventListeners()}attachEventListeners(){if(!this.shadow)return;const t=this.shadow.getElementById("nb-fab-trigger");t==null||t.addEventListener("click",()=>{var c;if(this.settings.clickAction==="open_extension"){typeof chrome<"u"&&((c=chrome.runtime)!=null&&c.sendMessage)&&chrome.runtime.sendMessage({type:"OPEN_SIDEPANEL"}).catch(()=>{});return}this.isOpen=!this.isOpen,this.unreadCount=0,this.render(),this.isOpen&&this.scrollToBottom()});const e=this.shadow.getElementById("nb-close-popup");e==null||e.addEventListener("click",()=>{this.isOpen=!1,this.render()});const s=this.shadow.getElementById("nb-open-sidepanel");s==null||s.addEventListener("click",()=>{var c;this.isOpen=!1,this.render(),typeof chrome<"u"&&((c=chrome.runtime)!=null&&c.sendMessage)&&chrome.runtime.sendMessage({type:"OPEN_SIDEPANEL"}).catch(()=>{})});const r=this.shadow.getElementById("nb-live-tunein");r==null||r.addEventListener("click",()=>{var c;this.isOpen=!1,this.render(),typeof chrome<"u"&&((c=chrome.runtime)!=null&&c.sendMessage)&&chrome.runtime.sendMessage({type:"OPEN_SIDEPANEL"}).catch(()=>{})});const n=this.shadow.getElementById("nb-cancel-reply");n==null||n.addEventListener("click",()=>{this.replyingTo=null,this.render()}),this.shadow.querySelectorAll(".nb-reply-trigger").forEach(c=>{c.addEventListener("click",h=>{var _;const m=h.currentTarget,B=m.getAttribute("data-id")||"",L=m.getAttribute("data-text")||"",R=m.getAttribute("data-nick")||"";this.replyingTo={id:B,text:L,from:{nickname:R,avatar:"👤",color:"#a5b4fc",peerId:""},timestamp:Date.now()},this.render();const v=(_=this.shadow)==null?void 0:_.getElementById("nb-input");v==null||v.focus()})}),this.shadow.querySelectorAll(".prompt-pill").forEach(c=>{c.addEventListener("click",h=>{const m=h.target.getAttribute("data-text");m&&this.sendMessage(m)})});const o=this.shadow.getElementById("nb-spoiler-insert"),l=this.shadow.getElementById("nb-input");o==null||o.addEventListener("click",()=>{l&&(l.value=`${l.value}||hint solution||`,l.focus())}),this.shadow.querySelectorAll(".nb-spoiler-tag").forEach(c=>{c.addEventListener("click",h=>{const m=h.currentTarget.getAttribute("data-skey")||"";this.revealedSpoilers[m]=!this.revealedSpoilers[m],this.render()})}),this.shadow.querySelectorAll(".nb-copy-code").forEach(c=>{c.addEventListener("click",h=>{const m=h.currentTarget.getAttribute("data-code")||"";m&&(navigator.clipboard.writeText(m),h.currentTarget.innerText="✓ Copied",setTimeout(()=>{h.currentTarget.innerText="📋 Copy"},1500))})});const u=this.shadow.getElementById("nb-composer");u==null||u.addEventListener("submit",c=>{c.preventDefault();const h=l==null?void 0:l.value.trim();h&&(this.sendMessage(h,this.replyingTo?{id:this.replyingTo.id,preview:`${this.replyingTo.from.nickname}: ${this.replyingTo.text.slice(0,30)}`}:void 0),l&&(l.value=""),this.replyingTo=null)})}escapeHtml(t){return t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}formatTimestamp(t){return new Date(t).toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"})}renderFormattedText(t,e){return t.split(`
`).map((r,n)=>{if(r.startsWith("```")&&r.endsWith("```")&&r.length>6){const d=r.slice(3,-3);return`
          <div style="background:rgba(0,0,0,0.45);padding:6px 8px;border-radius:6px;margin:4px 0;font-family:var(--font-mono);font-size:11px;position:relative;">
            <pre style="margin:0;white-space:pre-wrap;word-break:break-all;">${this.escapeHtml(d)}</pre>
            <button class="nb-copy-code" data-code="${this.escapeHtml(d)}" style="position:absolute;top:4px;right:4px;background:rgba(255,255,255,0.1);border:none;color:#fff;border-radius:4px;padding:2px 6px;font-size:10px;cursor:pointer;">
              📋 Copy
            </button>
          </div>
        `}return r.includes("||")?`<p style="margin:2px 0;">${r.split(/(\|\|.*?\|\|)/g).map((o,l)=>{if(o.startsWith("||")&&o.endsWith("||")&&o.length>4){const p=o.slice(2,-2),g=`${e}-${n}-${l}`,u=!!this.revealedSpoilers[g];return`
              <span class="nb-spoiler-tag" data-skey="${g}" style="display:inline-block;padding:1px 6px;border-radius:4px;background:${u?"rgba(99, 102, 241, 0.25)":"rgba(255, 255, 255, 0.15)"};border:1px solid rgba(255, 255, 255, 0.1);filter:${u?"none":"blur(4px)"};cursor:pointer;user-select:${u?"text":"none"};color:${u?"var(--text-primary)":"transparent"};">
                ${this.escapeHtml(p)}
              </span>
            `}return this.escapeHtml(o)}).join("")}</p>`:`<p style="margin:2px 0;">${this.escapeHtml(r)}</p>`}).join("")}deduplicateMessages(t){var r,n;const e=new Set,s=[];for(const d of t)!d||!d.id||e.has(d.id)||(e.add(d.id),s.push({...d,isSelf:((r=d.from)==null?void 0:r.peerId)===((n=this.myIdentity)==null?void 0:n.peerId)||d.isSelf}));return s}async sendMessage(t,e){var d,i,o,l;if(!t.trim())return;!this.currentRoomStorageKey&&((d=this.currentProblem)!=null&&d.roomId)&&(this.currentRoomStorageKey=`nerd_buddy_chat_${this.currentProblem.roomId}`);const s=t.trim(),r="msg-"+Math.random().toString(36).slice(2,10)+Date.now(),n={id:r,from:this.myIdentity||{nickname:"You",avatar:"⚡",color:"#6366f1",peerId:"self"},text:s,timestamp:Date.now(),replyTo:e==null?void 0:e.id,replyPreview:e==null?void 0:e.preview,status:"sent",isSelf:!0};if(this.messages.push(n),this.messages=this.deduplicateMessages(this.messages),this.render(),this.scrollToBottom(),this.currentRoomStorageKey&&typeof chrome<"u"&&((i=chrome.storage)!=null&&i.local))try{const p=await chrome.storage.local.get([this.currentRoomStorageKey]),g=p[this.currentRoomStorageKey]&&Array.isArray(p[this.currentRoomStorageKey])?p[this.currentRoomStorageKey]:[],u=this.deduplicateMessages([...g,n]).slice(-150);await chrome.storage.local.set({[this.currentRoomStorageKey]:u})}catch{}typeof chrome<"u"&&((o=chrome.runtime)!=null&&o.sendMessage)&&chrome.runtime.sendMessage({type:"SEND_PAGE_CHAT_MESSAGE",messageId:r,text:n.text,replyTo:n.replyTo,replyPreview:n.replyPreview,roomId:(l=this.currentProblem)==null?void 0:l.roomId}).catch(()=>{})}async loadMessages(){var t;if(this.currentRoomStorageKey&&typeof chrome<"u"&&(t=chrome.storage)!=null&&t.local){const e=await chrome.storage.local.get([this.currentRoomStorageKey]);e[this.currentRoomStorageKey]&&Array.isArray(e[this.currentRoomStorageKey])&&(this.messages=this.deduplicateMessages(e[this.currentRoomStorageKey]),this.isOpen&&(this.render(),this.scrollToBottom()))}}scrollToBottom(){setTimeout(()=>{var e;const t=(e=this.shadow)==null?void 0:e.getElementById("nb-messages");t&&(t.scrollTop=t.scrollHeight)},40)}listenToStorageChanges(){var t;typeof chrome<"u"&&((t=chrome.storage)!=null&&t.onChanged)&&chrome.storage.onChanged.addListener((e,s)=>{var r,n,d;if(s==="local"&&(e.nerd_buddy_sidepanel_open&&e.nerd_buddy_sidepanel_open.newValue===!0&&this.isOpen&&(this.isOpen=!1,this.render()),e.nerd_buddy_live_stage&&(this.liveStage=e.nerd_buddy_live_stage.newValue,this.render()),e.nerd_buddy_identity&&(this.myIdentity=e.nerd_buddy_identity.newValue),e[f]&&(this.settings=e[f].newValue,this.checkVisibilityAndRender()),e.nerd_buddy_active_problem&&(this.currentProblem=e.nerd_buddy_active_problem.newValue,this.currentRoomStorageKey=`nerd_buddy_chat_${((r=this.currentProblem)==null?void 0:r.roomId)||""}`,this.loadMessages(),this.checkVisibilityAndRender()),e.nerd_buddy_peer_count&&(this.peerCount=Math.max(1,e.nerd_buddy_peer_count.newValue||1),this.render()),this.currentRoomStorageKey&&e[this.currentRoomStorageKey])){const i=e[this.currentRoomStorageKey].newValue||[];this.messages=this.deduplicateMessages(i),!this.isOpen&&((n=e[this.currentRoomStorageKey].newValue)==null?void 0:n.length)>(((d=e[this.currentRoomStorageKey].oldValue)==null?void 0:d.length)||0)&&this.unreadCount++,this.render(),this.isOpen&&this.scrollToBottom()}})}}console.log("[Nerd Buddy] Content script initialized on:",window.location.href),new E(a=>{var t;try{typeof chrome<"u"&&((t=chrome.runtime)!=null&&t.sendMessage)&&chrome.runtime.sendMessage({type:"PROBLEM_DETECTED",payload:a})}catch{}}),new I,new A})();
