const o = "nerd_buddy_keepalive";
let n = null;
chrome.alarms.create(o, { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener((e) => {
  e.name === o && i();
});
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: !0 }).catch((e) => console.error(e));
chrome.tabs.onActivated.addListener(async (e) => {
  try {
    const t = await chrome.tabs.get(e.tabId);
    t.url && chrome.storage.local.set({ nerd_buddy_active_url: t.url });
  } catch {
  }
});
chrome.tabs.onUpdated.addListener((e, t, r) => {
  r.active && t.url && chrome.storage.local.set({ nerd_buddy_active_url: t.url });
});
chrome.runtime.onMessage.addListener((e, t, r) => {
  var a, c;
  return e.type === "PROBLEM_DETECTED" ? (a = t.tab) != null && a.active && chrome.storage.local.set({
    nerd_buddy_active_problem: e.payload,
    nerd_buddy_active_url: e.payload.url
  }) : e.type === "LOCAL_CURSOR_MOVE" || e.type === "LOCAL_CLICK_PULSE" ? chrome.runtime.sendMessage(e).catch(() => {
  }) : e.type === "OPEN_SIDEPANEL" ? (c = t.tab) != null && c.windowId && chrome.sidePanel.open({ windowId: t.tab.windowId }).catch(() => {
  }) : e.type === "SEND_PAGE_CHAT_MESSAGE" && chrome.runtime.sendMessage(e).catch(() => {
  }), !0;
});
async function i() {
  const e = "offscreen.html";
  if (!((await chrome.runtime.getContexts({
    contextTypes: ["OFFSCREEN_DOCUMENT"],
    documentUrls: [chrome.runtime.getURL(e)]
  })).length > 0)) {
    if (n) {
      await n;
      return;
    }
    n = chrome.offscreen.createDocument({
      url: e,
      reasons: ["WEB_RTC"],
      justification: "Maintain P2P presence and notifications when sidepanel is closed"
    }), await n, n = null;
  }
}
i();
