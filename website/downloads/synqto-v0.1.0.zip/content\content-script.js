(function(){"use strict";function E(u){let e=2166136261,i=2166136261;for(let t=0;t<u.length;t++){const l=u.charCodeAt(t);e=Math.imul(e^l&255,16777619),i=Math.imul(i^l>>8,16777619)}return((e>>>0^i>>>0)>>>0).toString(16).padStart(8,"0")}function P(u,e){let i=null;return(...s)=>{i&&clearTimeout(i),i=setTimeout(()=>u(...s),e)}}function _(u,e){var i;try{const s=new URL(u),t=s.hostname.toLowerCase(),l=s.pathname;if(t.includes("leetcode.com")){const o=l.match(/\/problems\/([a-zA-Z0-9-_]+)/);if(o&&o[1]){const a=o[1],c=v(a);return{platform:"LeetCode",slug:a,title:c,url:u,canonicalUrl:`https://leetcode.com/problems/${a}/`}}}if(t.includes("neetcode.io")){const o=l.match(/\/problems\/([a-zA-Z0-9-_]+)/);if(o&&o[1]){const a=o[1],c=v(a);return{platform:"NeetCode",slug:a,title:c,url:u,canonicalUrl:`https://neetcode.io/problems/${a}`}}}if(t.includes("codeforces.com")){const o=l.match(/\/(?:contest|problemset\/problem)\/(\d+)\/([A-Z0-9]+)/i);if(o){const a=o[1],c=o[2].toUpperCase();return{platform:"Codeforces",slug:`cf-${a}-${c}`,title:`Codeforces ${a}${c}`,url:u,canonicalUrl:`https://codeforces.com/problemset/problem/${a}/${c}`}}}if(t.includes("hackerrank.com")){const o=l.match(/\/challenges\/([a-zA-Z0-9-_]+)/);if(o&&o[1]){const a=o[1];return{platform:"HackerRank",slug:a,title:v(a),url:u,canonicalUrl:`https://www.hackerrank.com/challenges/${a}/problem`}}}if(t.includes("codechef.com")){const o=l.match(/\/problems\/([a-zA-Z0-9-_]+)/);if(o&&o[1]){const a=o[1];return{platform:"CodeChef",slug:a,title:`CodeChef ${a}`,url:u,canonicalUrl:`https://www.codechef.com/problems/${a}`}}}if(t.includes("geeksforgeeks.org")){const o=l.match(/\/problems\/([a-zA-Z0-9-_]+)/);if(o&&o[1]){const a=o[1];return{platform:"GeeksforGeeks",slug:a,title:v(a),url:u,canonicalUrl:`https://www.geeksforgeeks.org/problems/${a}/1`}}}if(t.includes("youtube.com")||t.includes("youtu.be")){let o=s.searchParams.get("v");if(!o&&t.includes("youtu.be")&&(o=l.slice(1)),!o&&l.includes("/shorts/")&&(o=(i=l.split("/shorts/")[1])==null?void 0:i.split("/")[0]),o){const a=e?M(e):`YouTube Video (${o})`;return{platform:"YouTube",slug:`yt-${o}`,title:a,url:u,canonicalUrl:`https://www.youtube.com/watch?v=${o}`}}}if(t.includes("arxiv.org")){const o=l.match(/\/(?:abs|pdf)\/(\d+\.\d+(?:v\d+)?)/);if(o&&o[1]){const a=o[1];return{platform:"ArXiv",slug:`arxiv-${a.replace(/\./g,"-")}`,title:e?$(e):`ArXiv ${a}`,url:u,canonicalUrl:`https://arxiv.org/abs/${a}`}}}if(t.includes("github.com")){const o=l.match(/^\/([^\/]+)\/([^\/]+)\/(?:issues|pull)\/(\d+)/);if(o){const a=o[1],c=o[2],p=o[3];return{platform:"GitHub",slug:`gh-${a}-${c}-${p}`,title:`${a}/${c} #${p}`,url:u,canonicalUrl:`https://github.com/${a}/${c}/issues/${p}`}}}return{platform:"Web",slug:t.replace(/\./g,"-")||"general-study",title:e||t||"General Study Room",url:u,canonicalUrl:u}}catch{return null}}function v(u){return u.split(/[-_]/).map(e=>e.charAt(0).toUpperCase()+e.slice(1)).join(" ")}function M(u){return u.replace(/\s*-\s*YouTube\s*$/,"").trim()}function $(u){return u.replace(/^\[[^\]]+\]\s*/,"").replace(/\s*-\s*arXiv.*$/,"").trim()}function S(){try{return!!(typeof chrome<"u"&&chrome.runtime&&chrome.runtime.id)}catch{return!1}}class I{constructor(e){this.lastUrl="",this.lastTitle="",this.mutationObserver=null,this.pollTimer=null,this.debouncedCheck=P(()=>{if(!S()){this.destroy();return}this.checkCurrentPage()},250),this.callback=e,this.init()}init(){this.checkCurrentPage();const e=history.pushState,i=history.replaceState;history.pushState=(...t)=>{e.apply(history,t),this.debouncedCheck()},history.replaceState=(...t)=>{i.apply(history,t),this.debouncedCheck()},window.addEventListener("popstate",()=>this.debouncedCheck()),window.addEventListener("hashchange",()=>this.debouncedCheck()),window.addEventListener("yt-navigate-finish",()=>this.debouncedCheck()),this.mutationObserver=new MutationObserver(()=>{document.title!==this.lastTitle&&this.debouncedCheck()});const s=document.querySelector("title");s&&this.mutationObserver.observe(s,{subtree:!0,characterData:!0,childList:!0}),this.pollTimer=setInterval(()=>{if(!S()){this.destroy();return}window.location.href!==this.lastUrl&&this.checkCurrentPage()},350)}checkCurrentPage(){const e=window.location.href,i=document.title;if(e===this.lastUrl&&i===this.lastTitle)return;this.lastUrl=e,this.lastTitle=i;const s=_(e,i);s&&this.callback(s)}destroy(){this.mutationObserver&&(this.mutationObserver.disconnect(),this.mutationObserver=null),this.pollTimer&&(clearInterval(this.pollTimer),this.pollTimer=null)}}function x(){try{return!!(typeof chrome<"u"&&chrome.runtime&&chrome.runtime.id)}catch{return!1}}class L{constructor(){this.container=null,this.cursorElements=new Map,this.cursorTimeouts=new Map,this.myIdentity=null,this.liveStage=null,this.createContainer(),this.loadState(),this.listenToStorage(),this.listenForMessages(),this.setupLocalTrackers()}async loadState(){var e;if(typeof chrome<"u"&&((e=chrome.storage)!=null&&e.local))try{const i=await chrome.storage.local.get(["nerd_buddy_identity","synqme_identity","nerd_buddy_live_stage","synqme_live_stage"]);this.myIdentity=i.synqme_identity||i.nerd_buddy_identity||null,this.liveStage=i.synqme_live_stage||i.nerd_buddy_live_stage||null,(!this.liveStage||!this.liveStage.isActive)&&this.clearAllCursors()}catch{}}listenToStorage(){var e;typeof chrome<"u"&&((e=chrome.storage)!=null&&e.onChanged)&&chrome.storage.onChanged.addListener((i,s)=>{s==="local"&&((i.synqme_identity||i.nerd_buddy_identity)&&(this.myIdentity=(i.synqme_identity||i.nerd_buddy_identity).newValue),(i.synqme_live_stage||i.nerd_buddy_live_stage)&&(this.liveStage=(i.synqme_live_stage||i.nerd_buddy_live_stage).newValue,(!this.liveStage||!this.liveStage.isActive)&&this.clearAllCursors()))})}clearAllCursors(){this.cursorTimeouts.forEach(e=>clearTimeout(e)),this.cursorTimeouts.clear(),this.cursorElements.forEach(e=>{e.remove()}),this.cursorElements.clear(),this.container&&(this.container.innerHTML="")}isLocalUserOnStage(){var i,s;if(!this.liveStage||!this.liveStage.isActive)return!1;const e=(i=this.myIdentity)==null?void 0:i.peerId;return e?!!(((s=this.liveStage.tutorIdentity)==null?void 0:s.peerId)===e||this.liveStage.tutorPeerId===e||this.liveStage.myRole==="tutor"||Array.isArray(this.liveStage.guestSpeakers)&&this.liveStage.guestSpeakers.some(t=>t.peerId===e)):!1}createContainer(){if(document.getElementById("nerd-buddy-cursor-overlay"))return;const e=document.createElement("div");if(e.id="nerd-buddy-cursor-overlay",e.style.cssText=`
      position: fixed !important;
      top: 0 !important;
      left: 0 !important;
      width: 100vw !important;
      height: 100vh !important;
      pointer-events: none !important;
      z-index: 2147483645 !important;
      overflow: hidden !important;
      box-sizing: border-box !important;
    `,document.body.appendChild(e),this.container=e,!document.getElementById("nerd-buddy-cursor-styles")){const i=document.createElement("style");i.id="nerd-buddy-cursor-styles",i.textContent=`
        @keyframes nb-click-ripple {
          0% { transform: scale(0.15); opacity: 1; }
          40% { opacity: 0.9; }
          100% { transform: scale(2.8); opacity: 0; }
        }
      `,document.head.appendChild(i)}}listenForMessages(){var e;if(!(!x()||!((e=chrome.runtime)!=null&&e.onMessage)))try{chrome.runtime.onMessage.addListener(i=>{var s,t,l,n;if(x()){if(i.type==="NERD_BUDDY_STAGE_ENDED"||i.type==="NERD_BUDDY_STAGE_INACTIVE"){this.clearAllCursors();return}if(i.type==="NERD_BUDDY_CURSOR_UPDATE"&&i.cursor){const o=i.cursor;(o.isTutor||this.liveStage&&(((s=this.liveStage.tutorIdentity)==null?void 0:s.peerId)===o.peerId||this.liveStage.tutorPeerId===o.peerId||((t=this.liveStage.guestSpeakers)==null?void 0:t.some(c=>c.peerId===o.peerId)))||!this.liveStage)&&this.renderCursor(o)}else if(i.type==="NERD_BUDDY_CLICK_PULSE"&&i.click){const o=i.click;(o.isTutor||this.liveStage&&(((l=this.liveStage.tutorIdentity)==null?void 0:l.peerId)===o.peerId||this.liveStage.tutorPeerId===o.peerId||((n=this.liveStage.guestSpeakers)==null?void 0:n.some(c=>c.peerId===o.peerId)))||o.isTutor||!this.liveStage)&&this.renderClickPulse(o)}}})}catch{}}renderCursor(e){if(this.container||this.createContainer(),!this.container)return;let i=this.cursorElements.get(e.peerId);i||(i=document.createElement("div"),i.style.cssText=`
        position: fixed !important;
        pointer-events: none !important;
        transition: left 0.05s linear, top 0.05s linear, opacity 0.3s ease !important;
        display: flex !important;
        align-items: center !important;
        gap: 5px !important;
        opacity: 1 !important;
        z-index: 2147483646 !important;
      `,this.container.appendChild(i),this.cursorElements.set(e.peerId,i));const s=Math.max(0,Math.min(window.innerWidth-30,e.xPct/100*window.innerWidth)),t=Math.max(0,Math.min(window.innerHeight-30,e.yPct/100*window.innerHeight));i.style.left=`${s}px`,i.style.top=`${t}px`,i.style.opacity="1";const l=e.isTutor?"#8b5cf6":e.color||"#6366f1";i.innerHTML=`
      <div style="
        width: 18px;
        height: 18px;
        border-radius: 50%;
        background: ${l};
        box-shadow: 0 0 16px ${l}, 0 0 6px #ffffff;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 11px;
        color: #fff;
        border: 2px solid #ffffff;
      ">
        ${e.avatar||"👑"}
      </div>
      <div style="
        background: rgba(15, 23, 42, 0.92);
        border: 1px solid ${l};
        color: #f8fafc;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        font-size: 10px;
        font-weight: 600;
        padding: 2px 6px;
        border-radius: 4px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.6);
        white-space: nowrap;
      ">
        ${e.nickname} ${e.isTutor?"🎓 (Tutor)":"🎤 (Speaker)"}
      </div>
    `;const n=this.cursorTimeouts.get(e.peerId);n&&clearTimeout(n);const o=window.setTimeout(()=>{i&&(i.style.opacity="0")},4e3);this.cursorTimeouts.set(e.peerId,o)}renderClickPulse(e){if(this.container||this.createContainer(),!this.container)return;const i=e.xPct/100*window.innerWidth,s=e.yPct/100*window.innerHeight,t=document.createElement("div"),l=e.color||(e.isTutor?"#8b5cf6":"#6366f1");t.style.cssText=`
      position: fixed !important;
      left: ${i-22}px !important;
      top: ${s-22}px !important;
      width: 44px !important;
      height: 44px !important;
      border-radius: 50% !important;
      border: 3px solid ${l} !important;
      box-shadow: 0 0 16px ${l}, inset 0 0 8px ${l} !important;
      pointer-events: none !important;
      z-index: 2147483647 !important;
      box-sizing: border-box !important;
      animation: nb-click-ripple 0.85s cubic-bezier(0.1, 0.8, 0.3, 1) forwards !important;
    `,this.container.appendChild(t),setTimeout(()=>{t.remove()},900)}setupLocalTrackers(){let e=0;window.addEventListener("mousemove",i=>{if(!x()||!this.isLocalUserOnStage())return;const s=Date.now();if(s-e<40)return;e=s;const t=i.clientX/window.innerWidth*100,l=i.clientY/window.innerHeight*100;try{chrome.runtime.sendMessage({type:"LOCAL_CURSOR_MOVE",xPct:t,yPct:l}).catch(()=>{})}catch{}}),window.addEventListener("click",i=>{var l,n,o;if(!x()||!this.isLocalUserOnStage())return;const s=i.clientX/window.innerWidth*100,t=i.clientY/window.innerHeight*100;this.renderClickPulse({peerId:((l=this.myIdentity)==null?void 0:l.peerId)||"local",nickname:((n=this.myIdentity)==null?void 0:n.nickname)||"You",xPct:s,yPct:t,color:((o=this.myIdentity)==null?void 0:o.color)||"#8b5cf6",isTutor:!0,timestamp:Date.now()});try{chrome.runtime.sendMessage({type:"LOCAL_CLICK_PULSE",xPct:s,yPct:t}).catch(()=>{})}catch{}})}}const B={mode:"coding_sites",clickAction:"open_popup",customDomains:["leetcode.com","neetcode.io","codeforces.com","hackerrank.com","geeksforgeeks.org"],enableWhiteboard:!1,positionMode:"permanent",savedPosition:{right:24,bottom:24}},w="nerd_buddy_fab_settings";function R(u,e){const i=u.toLowerCase().replace(/[^a-z0-9-_]/g,"-").slice(0,24).replace(/-+$/,""),s=E(e);return`room:${i||"lobby"}-${s}`}function A(u){switch(u.toLowerCase()){case"leetcode":return"#FFA116";case"neetcode":return"#8B5CF6";case"codeforces":return"#318CE7";case"hackerrank":return"#2EC866";case"codechef":return"#5B4638";case"geeksforgeeks":return"#2F8D46";case"youtube":return"#FF0000";case"arxiv":return"#B31B1B";case"github":return"#24292F";case"group":return"#8B5CF6";default:return"#6366F1"}}class D{constructor(){this.hostElement=null,this.shadow=null,this.isOpen=!1,this.settings=B,this.currentProblem=null,this.messages=[],this.unreadCount=0,this.currentRoomStorageKey="",this.myIdentity=null,this.liveStage=null,this.peerCount=1,this.replyingTo=null,this.revealedSpoilers={},this.currentPosition={right:24,bottom:24},this.isDragging=!1,this.dragMoved=!1,this.activeTab="chat",this.wbTool="pen",this.wbColor="#6366f1",this.wbWidth=4,this.wbTheme="dark_grid",this.wbStrokes=[],this.wbRedoStack=[],this.isWbDrawing=!1,this.wbCurrentPoints=[],this.wbStartPoint=null,this.init()}async init(){await this.loadIdentity(),await this.loadSettings(),this.detectCurrentPageProblem(),this.checkVisibilityAndRender(),this.listenToStorageChanges(),this.listenForRuntimeMessages()}async loadIdentity(){var e;if(typeof chrome<"u"&&((e=chrome.storage)!=null&&e.local)){const i=await chrome.storage.local.get(["synqto_identity","nerd_buddy_identity"]);(i.synqto_identity||i.nerd_buddy_identity)&&(this.myIdentity=i.synqto_identity||i.nerd_buddy_identity)}this.myIdentity||(this.myIdentity={peerId:"peer-"+Math.random().toString(36).slice(2,10),nickname:"Coder"+Math.floor(Math.random()*900+100),avatar:"⚡",color:"#6366f1"})}async loadSettings(){var e,i;if(typeof chrome<"u"&&((e=chrome.storage)!=null&&e.local)){const s=await chrome.storage.local.get([w,"synqto_active_problem","nerd_buddy_active_problem","synqto_live_stage","nerd_buddy_live_stage","nerd_buddy_sidepanel_open","nerd_buddy_peer_count"]);s[w]&&(this.settings=s[w]),this.settings.positionMode==="permanent"&&this.settings.savedPosition?this.currentPosition={...this.settings.savedPosition}:this.currentPosition={right:24,bottom:24};const t=s.synqto_active_problem||s.nerd_buddy_active_problem;t&&(this.currentProblem=t,this.currentRoomStorageKey=`synqto_chat_${((i=this.currentProblem)==null?void 0:i.roomId)||""}`,await this.loadMessages()),(s.synqto_live_stage||s.nerd_buddy_live_stage)&&(this.liveStage=s.synqto_live_stage||s.nerd_buddy_live_stage),typeof s.nerd_buddy_peer_count=="number"&&(this.peerCount=Math.max(1,s.nerd_buddy_peer_count))}}detectCurrentPageProblem(){const e=_(window.location.href,document.title);if(e){const i=R(e.slug,e.canonicalUrl);this.currentProblem={platform:e.platform,slug:e.slug,title:e.title,canonicalUrl:e.canonicalUrl,roomId:i},this.currentRoomStorageKey=`synqto_chat_${i}`,this.loadMessages()}}shouldShow(){if(this.settings.mode==="disabled")return!1;if(this.settings.mode==="all_sites")return!0;const e=window.location.hostname.toLowerCase();if(this.settings.mode==="custom_sites")return this.settings.customDomains.some(l=>e.includes(l.toLowerCase()));const s=["leetcode.com","neetcode.io","codeforces.com","hackerrank.com","geeksforgeeks.org","codechef.com","atcoder.jp","github.com","youtube.com","arxiv.org"].some(l=>e.includes(l)),t=!!(this.currentProblem||_(window.location.href));return s||t}checkVisibilityAndRender(){const e=this.shouldShow();e&&!this.hostElement?this.createWidgetDOM():!e&&this.hostElement&&(this.hostElement.remove(),this.hostElement=null,this.shadow=null)}createWidgetDOM(){if(document.getElementById("synqto-floating-host"))return;const e=document.createElement("div");e.id="synqto-floating-host",e.style.cssText=`
      position: fixed;
      bottom: ${this.currentPosition.bottom}px;
      right: ${this.currentPosition.right}px;
      z-index: 2147483640;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
      touch-action: none;
    `,document.body.appendChild(e),this.hostElement=e,this.shadow=e.attachShadow({mode:"open"}),this.render()}applyHostPosition(){if(!this.hostElement)return;const e=Math.max(10,Math.min(window.innerWidth-130,this.currentPosition.right)),i=Math.max(10,Math.min(window.innerHeight-55,this.currentPosition.bottom));this.hostElement.style.right=`${e}px`,this.hostElement.style.bottom=`${i}px`}render(){var c,p,h,d;if(!this.shadow)return;this.applyHostPosition();const e=!!(this.liveStage&&this.liveStage.isActive),i=((p=(c=this.liveStage)==null?void 0:c.tutorIdentity)==null?void 0:p.nickname)||"Tutor",s=((h=this.currentProblem)==null?void 0:h.title)||"Global Problem Lobby",t=((d=this.currentProblem)==null?void 0:d.platform)||"LeetCode",l=A(t),n=this.settings.enableWhiteboard&&this.activeTab==="whiteboard",o=this.currentPosition.bottom>window.innerHeight-540,a=this.currentPosition.right>window.innerWidth-420;this.shadow.innerHTML=`
      <style>
        :host {
          --primary: #6366f1;
          --primary-hover: #4f46e5;
          --bg-card: rgba(15, 23, 42, 0.96);
          --bg-surface-elevated: rgba(30, 41, 59, 0.85);
          --border-subtle: rgba(255, 255, 255, 0.1);
          --text-primary: #f8fafc;
          --text-secondary: #94a3b8;
          --text-muted: #64748b;
          --text-dim: #475569;
          --font-mono: 'JetBrains Mono', 'Fira Code', monospace;
        }

        * {
          box-sizing: border-box;
          margin: 0;
          padding: 0;
        }

        /* Floating Action Button (FAB) */
        .fab-button {
          position: relative;
          display: flex;
          align-items: center;
          gap: 7px;
          padding: 10px 14px;
          border-radius: 9999px;
          background: linear-gradient(135deg, #4f46e5, #7c3aed);
          border: 1px solid rgba(255, 255, 255, 0.2);
          box-shadow: 0 10px 25px -5px rgba(99, 102, 241, 0.5), 0 0 15px rgba(124, 58, 237, 0.3);
          color: #ffffff;
          font-size: 12px;
          font-weight: 700;
          cursor: grab;
          transition: transform 0.15s cubic-bezier(0.16, 1, 0.3, 1), box-shadow 0.15s;
          user-select: none;
        }

        .fab-button:active {
          cursor: grabbing;
        }

        .fab-button:hover {
          transform: translateY(-2px) scale(1.02);
          box-shadow: 0 14px 28px -5px rgba(99, 102, 241, 0.65), 0 0 20px rgba(124, 58, 237, 0.4);
        }

        .drag-grip {
          opacity: 0.5;
          font-size: 11px;
          cursor: grab;
        }

        .live-dot {
          width: 8px;
          height: 8px;
          border-radius: 50%;
          background: #ef4444;
          box-shadow: 0 0 10px #ef4444;
          animation: livePulse 1.5s infinite;
        }

        @keyframes livePulse {
          0%, 100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.4; transform: scale(1.2); }
        }

        .fab-badge {
          position: absolute;
          top: -4px;
          right: -4px;
          background: #f59e0b;
          color: #ffffff;
          font-size: 10px;
          font-weight: 700;
          padding: 2px 6px;
          border-radius: 9999px;
        }

        /* In-Page Popup Card */
        .popup-card {
          display: ${this.isOpen?"flex":"none"};
          flex-direction: column;
          position: absolute;
          ${o?"top: 52px; bottom: auto;":"bottom: 52px; top: auto;"}
          ${a?"left: 0; right: auto;":"right: 0; left: auto;"}
          width: 400px;
          height: 540px;
          max-height: 84vh;
          background: rgba(15, 23, 42, 0.96);
          border: 1px solid ${e?"rgba(239, 68, 68, 0.45)":"rgba(99, 102, 241, 0.35)"};
          border-radius: 16px;
          box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.85), 0 0 24px ${e?"rgba(239, 68, 68, 0.25)":"rgba(99, 102, 241, 0.2)"};
          backdrop-filter: blur(20px);
          -webkit-backdrop-filter: blur(20px);
          overflow: hidden;
          animation: slideIn 0.2s cubic-bezier(0.16, 1, 0.3, 1);
          color: var(--text-primary);
        }

        @keyframes slideIn {
          from { opacity: 0; transform: translateY(12px) scale(0.96); }
          to { opacity: 1; transform: translateY(0) scale(1); }
        }

        /* Room Header */
        .room-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 10px 12px;
          background: linear-gradient(135deg, rgba(30, 41, 59, 0.95), rgba(15, 23, 42, 0.95));
          border-bottom: 1px solid var(--border-subtle);
        }

        .room-info {
          display: flex;
          align-items: center;
          gap: 10px;
          overflow: hidden;
        }

        .platform-icon-box {
          width: 32px;
          height: 32px;
          border-radius: 8px;
          background: rgba(99, 102, 241, 0.15);
          border: 1px solid rgba(255, 255, 255, 0.1);
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 16px;
          flex-shrink: 0;
        }

        .problem-title {
          font-size: 13px;
          font-weight: 700;
          color: var(--text-primary);
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
          max-width: 170px;
        }

        .badges-row {
          display: flex;
          align-items: center;
          gap: 6px;
          margin-top: 2px;
        }

        .platform-pill {
          font-size: 9px;
          font-weight: 700;
          padding: 1px 6px;
          border-radius: 4px;
          background: ${l}20;
          border: 1px solid ${l}50;
          color: ${l};
          text-transform: uppercase;
        }

        .peer-count-pill {
          font-size: 10px;
          color: var(--text-secondary);
          display: flex;
          align-items: center;
          gap: 4px;
        }

        .header-actions {
          display: flex;
          align-items: center;
          gap: 4px;
        }

        .icon-btn {
          background: transparent;
          border: none;
          color: var(--text-secondary);
          cursor: pointer;
          padding: 5px;
          border-radius: 6px;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: all 0.15s;
        }

        .icon-btn:hover {
          background: rgba(255, 255, 255, 0.1);
          color: #ffffff;
        }

        /* Segmented View Switcher */
        .tab-switcher {
          display: flex;
          background: rgba(15, 23, 42, 0.9);
          padding: 3px 6px;
          border-bottom: 1px solid var(--border-subtle);
          gap: 4px;
        }

        .tab-btn {
          flex: 1;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 6px;
          padding: 5px 8px;
          font-size: 11px;
          font-weight: 600;
          border-radius: 6px;
          border: none;
          cursor: pointer;
          transition: all 0.15s;
          background: transparent;
          color: var(--text-muted);
        }

        .tab-btn.active {
          background: var(--primary);
          color: #ffffff;
        }

        /* Messages List */
        .message-list {
          flex: 1;
          overflow-y: auto;
          padding: 12px;
          display: flex;
          flex-direction: column;
          gap: 10px;
        }

        .chat-bubble {
          display: flex;
          flex-direction: column;
          max-width: 86%;
          padding: 8px 12px;
          border-radius: 14px;
          font-size: 12px;
          position: relative;
          word-break: break-word;
          line-height: 1.45;
        }

        .chat-bubble.self {
          align-self: flex-end;
          background: linear-gradient(135deg, rgba(99, 102, 241, 0.28), rgba(139, 92, 246, 0.22));
          border: 1px solid rgba(99, 102, 241, 0.35);
          border-bottom-right-radius: 4px;
          color: #ffffff;
        }

        .chat-bubble.other {
          align-self: flex-start;
          background: var(--bg-surface-elevated);
          border: 1px solid var(--border-subtle);
          border-bottom-left-radius: 4px;
          color: #f1f5f9;
        }

        .chat-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 8px;
          margin-bottom: 4px;
          font-size: 11px;
        }

        .chat-author {
          font-weight: 600;
          display: flex;
          align-items: center;
          gap: 4px;
        }

        .chat-timestamp {
          color: var(--text-dim);
          font-size: 10px;
        }

        .chat-footer {
          margin-top: 3px;
          display: flex;
          align-items: center;
          justify-content: flex-end;
          font-size: 10px;
        }

        .ack-read {
          color: #38bdf8;
          font-weight: 700;
        }

        /* Whiteboard Toolbar & Canvas */
        .whiteboard-container {
          flex: 1;
          display: flex;
          flex-direction: column;
          background: #090d16;
          overflow: hidden;
          position: relative;
        }

        .wb-toolbar {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 6px 8px;
          background: rgba(15, 23, 42, 0.95);
          border-bottom: 1px solid var(--border-subtle);
          flex-wrap: wrap;
          gap: 4px;
        }

        .wb-tool-group {
          display: flex;
          gap: 3px;
          align-items: center;
        }

        .wb-tool-btn {
          padding: 4px 6px;
          border-radius: 4px;
          border: 1px solid transparent;
          background: transparent;
          color: var(--text-muted);
          cursor: pointer;
          font-size: 11px;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .wb-tool-btn.active {
          border-color: var(--primary);
          background: rgba(99, 102, 241, 0.25);
          color: #c7d2fe;
        }

        .wb-palette-bar {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 3px 8px;
          background: rgba(0, 0, 0, 0.3);
          border-bottom: 1px solid var(--border-subtle);
        }

        .color-dot {
          width: 13px;
          height: 13px;
          border-radius: 50%;
          border: 1px solid rgba(255, 255, 255, 0.2);
          cursor: pointer;
        }

        .color-dot.active {
          border: 2px solid #ffffff;
          box-shadow: 0 0 6px rgba(255, 255, 255, 0.5);
        }

        .size-pill {
          font-size: 9px;
          font-weight: 700;
          padding: 1px 4px;
          border-radius: 3px;
          background: rgba(255, 255, 255, 0.05);
          border: 1px solid transparent;
          color: var(--text-dim);
          cursor: pointer;
        }

        .size-pill.active {
          background: rgba(99, 102, 241, 0.3);
          border-color: var(--primary);
          color: #ffffff;
        }

        #nb-whiteboard-canvas {
          flex-grow: 1;
          width: 100%;
          height: 100%;
          cursor: crosshair;
          touch-action: none;
        }

        /* Input Composer */
        .composer-box {
          display: flex;
          align-items: center;
          gap: 6px;
          padding: 8px 10px;
          background: rgba(15, 23, 42, 0.95);
          border-top: 1px solid var(--border-subtle);
        }

        .input-glass {
          flex: 1;
          background: rgba(0, 0, 0, 0.4);
          border: 1px solid var(--border-subtle);
          border-radius: 8px;
          padding: 7px 10px;
          color: #ffffff;
          font-size: 11px;
          outline: none;
        }

        .input-glass:focus {
          border-color: var(--primary);
        }

        .btn-send {
          background: var(--primary);
          border: none;
          color: #ffffff;
          padding: 6px 10px;
          border-radius: 8px;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .prompt-pills-row {
          display: flex;
          gap: 4px;
          padding: 4px 8px;
          overflow-x: auto;
          background: rgba(0, 0, 0, 0.3);
          border-top: 1px solid var(--border-subtle);
        }

        .prompt-pill {
          background: rgba(255, 255, 255, 0.06);
          border: 1px solid var(--border-subtle);
          color: var(--text-secondary);
          font-size: 9px;
          font-weight: 600;
          padding: 2px 6px;
          border-radius: 4px;
          cursor: pointer;
          white-space: nowrap;
        }

        .prompt-pill:hover {
          background: rgba(99, 102, 241, 0.2);
          color: #ffffff;
        }
      </style>

      <!-- In-Page Popup Card Window -->
      <div class="popup-card" id="nb-popup-card">
        <!-- Room Header Bar -->
        <div class="room-header">
          <div class="room-info">
            <div class="platform-icon-box">⚡</div>
            <div>
              <div class="problem-title">${this.escapeHtml(s)}</div>
              <div class="badges-row">
                <span class="platform-pill">${t}</span>
                <span class="peer-count-pill">
                  <span style="display:inline-block;width:6px;height:6px;border-radius:50%;background:#10b981;"></span>
                  <span>${this.peerCount} Online</span>
                </span>
              </div>
            </div>
          </div>

          <div class="header-actions">
            <button class="icon-btn" id="nb-open-sidepanel" title="Open complete extension in side panel">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M15 3h6v6M10 14L21 3M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6"/>
              </svg>
            </button>
            <button class="icon-btn" id="nb-close-popup" title="Minimize">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M18 6L6 18M6 6l12 12"/>
              </svg>
            </button>
          </div>
        </div>

        <!-- Segmented Switcher when Whiteboard is Enabled in Settings -->
        ${this.settings.enableWhiteboard?`
          <div class="tab-switcher">
            <button class="tab-btn ${this.activeTab==="chat"?"active":""}" id="nb-tab-chat">
              <span>💬 Live Chat</span>
            </button>
            <button class="tab-btn ${this.activeTab==="whiteboard"?"active":""}" id="nb-tab-whiteboard">
              <span>🎨 Whiteboard</span>
            </button>
          </div>
        `:""}

        <!-- Multi-Broadcaster Live Streams List -->
        ${e?`
          <div style="background:linear-gradient(135deg, rgba(239, 68, 68, 0.22), rgba(139, 92, 246, 0.18));border-bottom:1px solid rgba(239, 68, 68, 0.35);padding:6px 10px;display:flex;flex-direction:column;gap:5px;">
            <div style="display:flex;align-items:center;justify-content:space-between;font-size:10px;color:#fca5a5;">
              <div style="display:flex;align-items:center;gap:5px;font-weight:700;">
                <span class="live-dot"></span>
                <span>LIVE STREAMS (${this.liveStage.activeStreams&&this.liveStage.activeStreams.length||1}):</span>
              </div>
              <button id="nb-live-tunein" style="background:#ef4444;color:#fff;border:none;padding:2px 8px;border-radius:4px;font-size:9px;font-weight:700;cursor:pointer;">
                Open Side Panel 📺
              </button>
            </div>

            <div style="display:flex;gap:4px;overflow-x:auto;padding-bottom:2px;">
              ${(this.liveStage.activeStreams&&this.liveStage.activeStreams.length>0?this.liveStage.activeStreams:[{broadcasterIdentity:this.liveStage.tutorIdentity||{nickname:i,avatar:"👑"},title:`${i}'s Walkthrough`,broadcastType:this.liveStage.broadcastType||"screen"}]).map(r=>{var b,f;return`
                <div style="display:flex;align-items:center;gap:4px;padding:3px 6px;border-radius:4px;background:rgba(0,0,0,0.4);border:1px solid rgba(255,255,255,0.1);font-size:10px;color:#f8fafc;white-space:nowrap;">
                  <span>${((b=r.broadcasterIdentity)==null?void 0:b.avatar)||"👤"}</span>
                  <span style="font-weight:600;">${((f=r.broadcasterIdentity)==null?void 0:f.nickname)||"Streamer"}:</span>
                  <span style="color:#c7d2fe;max-width:110px;overflow:hidden;text-overflow:ellipsis;">${this.escapeHtml(r.title||"Live Stream")}</span>
                  <span style="font-size:8px;padding:1px 4px;border-radius:3px;background:rgba(239,68,68,0.3);color:#fca5a5;text-transform:uppercase;">${r.broadcastType||"live"}</span>
                </div>
              `}).join("")}
            </div>
          </div>
        `:""}

        <!-- Main Body: Chat or Whiteboard -->
        ${n?`
          <!-- Whiteboard View -->
          <div class="whiteboard-container">
            <div class="wb-toolbar">
              <div class="wb-tool-group">
                <button class="wb-tool-btn ${this.wbTool==="pen"?"active":""}" data-wbtool="pen" title="Pen">✏️</button>
                <button class="wb-tool-btn ${this.wbTool==="highlighter"?"active":""}" data-wbtool="highlighter" title="Highlighter">🖍️</button>
                <button class="wb-tool-btn ${this.wbTool==="eraser"?"active":""}" data-wbtool="eraser" title="Eraser">🧹</button>
                <button class="wb-tool-btn ${this.wbTool==="line"?"active":""}" data-wbtool="line" title="Line">📏</button>
                <button class="wb-tool-btn ${this.wbTool==="arrow"?"active":""}" data-wbtool="arrow" title="Arrow">➡️</button>
                <button class="wb-tool-btn ${this.wbTool==="rect"?"active":""}" data-wbtool="rect" title="Box">🔲</button>
                <button class="wb-tool-btn ${this.wbTool==="circle"?"active":""}" data-wbtool="circle" title="Node">⭕</button>
                <button class="wb-tool-btn ${this.wbTool==="tree_node"?"active":""}" data-wbtool="tree_node" title="Tree Node">🌳</button>
              </div>

              <div class="wb-tool-group">
                <button class="wb-tool-btn" id="nb-wb-undo" title="Undo">↩️</button>
                <button class="wb-tool-btn" id="nb-wb-redo" title="Redo">↪️</button>
                <button class="wb-tool-btn" id="nb-wb-clear" title="Clear Canvas" style="color:#f87171;">🗑️</button>
                <button class="wb-tool-btn" id="nb-wb-save" title="Export PNG">💾</button>
              </div>
            </div>

            <!-- Color Palette, Widths & Board Theme Choice -->
            <div class="wb-palette-bar">
              <div style="display:flex;gap:3px;align-items:center;">
                <button class="size-pill ${this.wbTheme==="dark_grid"?"active":""}" data-wbtheme="dark_grid" title="Dark Grid">⬛</button>
                <button class="size-pill ${this.wbTheme==="clean_white"?"active":""}" data-wbtheme="clean_white" title="White Board">⬜</button>
                <button class="size-pill ${this.wbTheme==="dot_matrix"?"active":""}" data-wbtheme="dot_matrix" title="Dot Grid">🟦</button>
                <button class="size-pill ${this.wbTheme==="isometric"?"active":""}" data-wbtheme="isometric" title="Matrix Grid">📐</button>
              </div>

              <div style="display:flex;gap:4px;align-items:center;">
                ${["#6366f1","#06b6d4","#10b981","#f59e0b","#f43f5e","#ffffff"].map(r=>`
                  <div class="color-dot ${this.wbColor===r?"active":""}" data-color="${r}" style="background:${r};"></div>
                `).join("")}
              </div>

              <div style="display:flex;gap:2px;align-items:center;">
                <button class="size-pill ${this.wbWidth===2?"active":""}" data-size="2">S</button>
                <button class="size-pill ${this.wbWidth===4?"active":""}" data-size="4">M</button>
                <button class="size-pill ${this.wbWidth===8?"active":""}" data-size="8">L</button>
              </div>
            </div>

            <!-- HTML5 Interactive Canvas -->
            <canvas id="nb-whiteboard-canvas"></canvas>
          </div>
        `:`
          <!-- Chat Messages View -->
          <div class="message-list" id="nb-messages">
            ${this.messages.length===0?`
              <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:100%;color:var(--text-muted);gap:8px;padding:30px 10px;text-align:center;">
                <div style="font-size:28px;">💬</div>
                <div style="font-size:13px;font-weight:600;color:var(--text-secondary);">No messages yet</div>
                <div style="font-size:11px;max-width:220px;">Say hello or ask for a hint! Messages are synchronized P2P across all peers.</div>
              </div>
            `:this.messages.map((r,b)=>{var f,g,y,m;return`
              <div class="chat-bubble ${r.isSelf?"self":"other"}">
                ${r.replyPreview?`<div style="border-left:2px solid var(--primary);padding-left:6px;margin-bottom:4px;font-size:10px;color:var(--text-muted);">${this.escapeHtml(r.replyPreview)}</div>`:""}
                
                <div class="chat-header">
                  <div class="chat-author">
                    <span>${((f=r.from)==null?void 0:f.avatar)||"👤"}</span>
                    <span style="color:${r.isSelf?"#ffffff":((g=r.from)==null?void 0:g.color)||"#a5b4fc"}">
                      ${r.isSelf?"You":((y=r.from)==null?void 0:y.nickname)||"Buddy"}
                    </span>
                  </div>
                  <div style="display:flex;align-items:center;gap:4px;">
                    <span class="chat-timestamp">${this.formatTimestamp(r.timestamp)}</span>
                    <button class="icon-btn nb-reply-trigger" data-id="${r.id}" data-text="${this.escapeHtml(r.text.slice(0,35))}" data-nick="${this.escapeHtml(((m=r.from)==null?void 0:m.nickname)||"Buddy")}" style="padding:0;width:18px;height:18px;" title="Reply">
                      ↩
                    </button>
                  </div>
                </div>

                <div class="chat-body">${this.renderFormattedText(r.text,b)}</div>

                ${r.isSelf?`
                  <div class="chat-footer">
                    ${r.status==="pending"?"<span>⏳</span>":""}
                    ${r.status==="sent"?'<span style="color:var(--text-dim);">✓</span>':""}
                    ${r.status==="delivered"?'<span style="color:var(--text-secondary);">✓✓</span>':""}
                    ${r.status==="read"?'<span class="ack-read">✓✓</span>':""}
                  </div>
                `:""}
              </div>
            `}).join("")}
          </div>

          <!-- Quick Strategy Prompt Pills -->
          <div class="prompt-pills-row">
            <button class="prompt-pill" data-text="⚡ O(N) Time">⚡ O(N) Time</button>
            <button class="prompt-pill" data-text="💾 O(1) Space">💾 O(1) Space</button>
            <button class="prompt-pill" data-text="👉 Two Pointers">👉 Two Pointers</button>
            <button class="prompt-pill" data-text="🔍 Binary Search">🔍 Binary Search</button>
            <button class="prompt-pill" data-text="🧠 DP / Memo">🧠 DP / Memo</button>
            <button class="prompt-pill" data-text="💡 Sliding Window">💡 Sliding Window</button>
          </div>

          <!-- Input Box & Composer -->
          <form class="composer-box" id="nb-composer">
            <button type="button" class="icon-btn" id="nb-spoiler-insert" title="Insert Spoiler Blur ||text||" style="width:28px;height:28px;flex-shrink:0;">
              👁️
            </button>
            <input type="text" class="input-glass" id="nb-input" placeholder="Type a hint, code snippet, or ||spoiler||..." />
            <button type="submit" class="btn-send">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <line x1="22" y1="2" x2="11" y2="13"></line>
                <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
              </svg>
            </button>
          </form>
        `}
      </div>

      <!-- Draggable Floating Action Button (FAB) -->
      <button class="fab-button" id="nb-fab-trigger" title="Drag anywhere or click to open">
        <span class="drag-grip">⠿</span>
        ${e?'<span class="live-dot"></span>':"<span>⚡</span>"}
        <span>${e?`LIVE (${i})`:"Synqto"}</span>
        ${this.unreadCount>0?`<span class="fab-badge">${this.unreadCount}</span>`:""}
      </button>
    `,this.attachEventListeners(),n&&this.initWhiteboardCanvas()}attachEventListeners(){if(!this.shadow)return;const e=this.shadow.getElementById("nb-fab-trigger");if(e){let h=0,d=0,r=24,b=24;const f=m=>{if(!this.isDragging)return;const k="touches"in m?m.touches[0].clientX:m.clientX,W="touches"in m?m.touches[0].clientY:m.clientY,T=k-h,C=W-d;if(Math.hypot(T,C)>4){this.dragMoved=!0;const z=r-T,O=b-C;this.currentPosition={right:Math.max(10,Math.min(window.innerWidth-130,z)),bottom:Math.max(10,Math.min(window.innerHeight-55,O))},this.applyHostPosition()}},g=()=>{var m;if(this.isDragging&&(this.isDragging=!1,window.removeEventListener("mousemove",f),window.removeEventListener("mouseup",g),window.removeEventListener("touchmove",f),window.removeEventListener("touchend",g),this.dragMoved)){if(this.settings.positionMode==="permanent"){const k={...this.settings,savedPosition:{...this.currentPosition}};this.settings=k,typeof chrome<"u"&&((m=chrome.storage)!=null&&m.local)&&chrome.storage.local.set({[w]:k})}setTimeout(()=>{this.dragMoved=!1},60)}},y=m=>{this.isDragging=!0,this.dragMoved=!1,h="touches"in m?m.touches[0].clientX:m.clientX,d="touches"in m?m.touches[0].clientY:m.clientY,r=this.currentPosition.right,b=this.currentPosition.bottom,window.addEventListener("mousemove",f,{passive:!0}),window.addEventListener("mouseup",g),window.addEventListener("touchmove",f,{passive:!0}),window.addEventListener("touchend",g)};e.addEventListener("mousedown",y),e.addEventListener("touchstart",y,{passive:!0}),e.addEventListener("click",()=>{var m;if(!this.dragMoved){if(this.settings.clickAction==="open_extension"){typeof chrome<"u"&&((m=chrome.runtime)!=null&&m.sendMessage)&&chrome.runtime.sendMessage({type:"OPEN_SIDEPANEL"}).catch(()=>{});return}this.isOpen=!this.isOpen,this.unreadCount=0,this.render(),this.isOpen&&this.activeTab==="chat"&&this.scrollToBottom()}})}const i=this.shadow.getElementById("nb-close-popup");i==null||i.addEventListener("click",()=>{this.isOpen=!1,this.render()});const s=this.shadow.getElementById("nb-open-sidepanel");s==null||s.addEventListener("click",()=>{var h;this.isOpen=!1,this.render(),typeof chrome<"u"&&((h=chrome.runtime)!=null&&h.sendMessage)&&chrome.runtime.sendMessage({type:"OPEN_SIDEPANEL"}).catch(()=>{})});const t=this.shadow.getElementById("nb-tab-chat");t==null||t.addEventListener("click",()=>{this.activeTab="chat",this.render(),this.scrollToBottom()});const l=this.shadow.getElementById("nb-tab-whiteboard");l==null||l.addEventListener("click",()=>{this.activeTab="whiteboard",this.render()});const n=this.shadow.getElementById("nb-live-tunein");n==null||n.addEventListener("click",()=>{var h;this.isOpen=!1,this.render(),typeof chrome<"u"&&((h=chrome.runtime)!=null&&h.sendMessage)&&chrome.runtime.sendMessage({type:"OPEN_SIDEPANEL"}).catch(()=>{})}),this.shadow.querySelectorAll(".prompt-pill").forEach(h=>{h.addEventListener("click",d=>{const r=d.target.getAttribute("data-text");r&&this.sendMessage(r)})});const a=this.shadow.getElementById("nb-spoiler-insert"),c=this.shadow.getElementById("nb-input");a==null||a.addEventListener("click",()=>{c&&(c.value=`${c.value}||hint solution||`,c.focus())});const p=this.shadow.getElementById("nb-composer");p==null||p.addEventListener("submit",h=>{h.preventDefault();const d=c==null?void 0:c.value.trim();d&&(this.sendMessage(d,this.replyingTo?{id:this.replyingTo.id,preview:`${this.replyingTo.from.nickname}: ${this.replyingTo.text.slice(0,30)}`}:void 0),c&&(c.value=""),this.replyingTo=null)})}initWhiteboardCanvas(){var a,c,p,h;if(!this.shadow)return;const e=this.shadow.getElementById("nb-whiteboard-canvas");if(!e)return;this.shadow.querySelectorAll(".wb-tool-btn[data-wbtool]").forEach(d=>{d.addEventListener("click",r=>{const b=r.currentTarget.getAttribute("data-wbtool");b&&(this.wbTool=b,this.render())})}),this.shadow.querySelectorAll(".size-pill[data-wbtheme]").forEach(d=>{d.addEventListener("click",r=>{const b=r.currentTarget.getAttribute("data-wbtheme");b&&(this.wbTheme=b,b==="clean_white"&&this.wbColor==="#ffffff"&&(this.wbColor="#0f172a"),this.render())})}),this.shadow.querySelectorAll(".color-dot").forEach(d=>{d.addEventListener("click",r=>{const b=r.currentTarget.getAttribute("data-color");b&&(this.wbColor=b,this.render())})}),this.shadow.querySelectorAll(".size-pill[data-size]").forEach(d=>{d.addEventListener("click",r=>{const b=Number(r.currentTarget.getAttribute("data-size"));b&&(this.wbWidth=b,this.render())})}),(a=this.shadow.getElementById("nb-wb-undo"))==null||a.addEventListener("click",()=>{var d;if(this.wbStrokes.length>0){const r=this.wbStrokes.pop();r&&(this.wbRedoStack.push(r),this.drawWbCanvas(),typeof chrome<"u"&&((d=chrome.runtime)!=null&&d.sendMessage)&&chrome.runtime.sendMessage({type:"WHITEBOARD_UNDO_LOCAL",strokeId:r.id}).catch(()=>{}))}}),(c=this.shadow.getElementById("nb-wb-redo"))==null||c.addEventListener("click",()=>{var d;if(this.wbRedoStack.length>0){const r=this.wbRedoStack.pop();r&&(this.wbStrokes.push(r),this.drawWbCanvas(),typeof chrome<"u"&&((d=chrome.runtime)!=null&&d.sendMessage)&&chrome.runtime.sendMessage({type:"WHITEBOARD_STROKE_LOCAL",stroke:r}).catch(()=>{}))}}),(p=this.shadow.getElementById("nb-wb-clear"))==null||p.addEventListener("click",()=>{var d;confirm("Clear collaborative whiteboard canvas?")&&(this.wbStrokes=[],this.wbRedoStack=[],this.drawWbCanvas(),typeof chrome<"u"&&((d=chrome.runtime)!=null&&d.sendMessage)&&chrome.runtime.sendMessage({type:"WHITEBOARD_CLEAR_LOCAL"}).catch(()=>{}))}),(h=this.shadow.getElementById("nb-wb-save"))==null||h.addEventListener("click",()=>{const d=e.toDataURL("image/png"),r=document.createElement("a");r.download=`synqto-whiteboard-${Date.now()}.png`,r.href=d,r.click()}),setTimeout(()=>{const d=e.getBoundingClientRect(),r=window.devicePixelRatio||1;e.width=(d.width||380)*r,e.height=(d.height||360)*r;const b=e.getContext("2d");b&&b.scale(r,r),this.drawWbCanvas()},30);const n=d=>{const r=e.getBoundingClientRect();let b=0,f=0;return"touches"in d&&d.touches.length>0?(b=d.touches[0].clientX,f=d.touches[0].clientY):"clientX"in d&&(b=d.clientX,f=d.clientY),{x:b-r.left,y:f-r.top}};e.addEventListener("mousedown",d=>{const r=n(d);this.isWbDrawing=!0,this.wbStartPoint=r,this.wbCurrentPoints=[r]}),e.addEventListener("mousemove",d=>{if(!this.isWbDrawing)return;const r=n(d);["line","arrow","rect","circle","tree_node"].includes(this.wbTool)&&this.wbStartPoint?this.drawWbCanvas(void 0,{x1:this.wbStartPoint.x,y1:this.wbStartPoint.y,x2:r.x,y2:r.y,label:this.wbTool==="tree_node"?"val":void 0}):(this.wbCurrentPoints.push(r),this.drawWbCanvas(this.wbCurrentPoints))});const o=d=>{var y;if(!this.isWbDrawing)return;this.isWbDrawing=!1;const r=n(d),b=["line","arrow","rect","circle","tree_node"].includes(this.wbTool),f=this.wbTool==="highlighter"?14:this.wbWidth,g={id:"stroke-"+Math.random().toString(36).slice(2,10),tool:this.wbTool,color:this.wbColor,width:f,opacity:this.wbTool==="highlighter"?.35:1,points:b?[]:[...this.wbCurrentPoints],geometry:b&&this.wbStartPoint?{x1:this.wbStartPoint.x,y1:this.wbStartPoint.y,x2:r.x,y2:r.y,label:this.wbTool==="tree_node"?String(Math.floor(Math.random()*50)+1):void 0}:void 0};this.wbStrokes.push(g),this.wbRedoStack=[],this.wbCurrentPoints=[],this.wbStartPoint=null,this.drawWbCanvas(),typeof chrome<"u"&&((y=chrome.runtime)!=null&&y.sendMessage)&&chrome.runtime.sendMessage({type:"WHITEBOARD_STROKE_LOCAL",stroke:g}).catch(()=>{})};e.addEventListener("mouseup",o),e.addEventListener("mouseleave",o)}drawWbCanvas(e,i){if(!this.shadow)return;const s=this.shadow.getElementById("nb-whiteboard-canvas");if(!s)return;const t=s.getContext("2d");if(!t)return;if(t.clearRect(0,0,s.width,s.height),t.save(),this.wbTheme==="clean_white"){t.fillStyle="#f8fafc",t.fillRect(0,0,s.width,s.height),t.strokeStyle="rgba(0, 0, 0, 0.06)",t.lineWidth=1;const n=20;for(let o=0;o<s.width;o+=n)t.beginPath(),t.moveTo(o,0),t.lineTo(o,s.height),t.stroke();for(let o=0;o<s.height;o+=n)t.beginPath(),t.moveTo(0,o),t.lineTo(s.width,o),t.stroke()}else if(this.wbTheme==="dot_matrix"){t.fillStyle="#090d16",t.fillRect(0,0,s.width,s.height),t.fillStyle="rgba(255, 255, 255, 0.15)";for(let n=10;n<s.width;n+=18)for(let o=10;o<s.height;o+=18)t.beginPath(),t.arc(n,o,1,0,Math.PI*2),t.fill()}else if(this.wbTheme==="isometric"){t.fillStyle="#090d16",t.fillRect(0,0,s.width,s.height),t.strokeStyle="rgba(99, 102, 241, 0.08)",t.lineWidth=1;const n=22;for(let o=0;o<s.width;o+=n)t.beginPath(),t.moveTo(o,0),t.lineTo(o,s.height),t.stroke();for(let o=0;o<s.height;o+=n)t.beginPath(),t.moveTo(0,o),t.lineTo(s.width,o),t.stroke()}else{t.fillStyle="#090d16",t.fillRect(0,0,s.width,s.height),t.strokeStyle="rgba(255, 255, 255, 0.04)",t.lineWidth=1;const n=20;for(let o=0;o<s.width;o+=n)t.beginPath(),t.moveTo(o,0),t.lineTo(o,s.height),t.stroke();for(let o=0;o<s.height;o+=n)t.beginPath(),t.moveTo(0,o),t.lineTo(s.width,o),t.stroke()}t.restore();const l=n=>{t.save();let o=n.color;if(this.wbTheme==="clean_white"&&(o==="#ffffff"||o==="#fff")&&(o="#0f172a"),t.strokeStyle=o,t.fillStyle=o,t.lineWidth=n.width,t.lineCap="round",t.lineJoin="round",t.globalAlpha=n.opacity,n.tool==="eraser"&&(t.globalCompositeOperation="destination-out",t.lineWidth=n.width*3),n.geometry){const{x1:a,y1:c,x2:p,y2:h}=n.geometry;if(n.tool==="line")t.beginPath(),t.moveTo(a,c),t.lineTo(p,h),t.stroke();else if(n.tool==="arrow"){t.beginPath(),t.moveTo(a,c),t.lineTo(p,h),t.stroke();const d=Math.atan2(h-c,p-a),r=Math.max(10,n.width*3);t.beginPath(),t.moveTo(p,h),t.lineTo(p-r*Math.cos(d-Math.PI/6),h-r*Math.sin(d-Math.PI/6)),t.moveTo(p,h),t.lineTo(p-r*Math.cos(d+Math.PI/6),h-r*Math.sin(d+Math.PI/6)),t.stroke()}else if(n.tool==="rect")t.strokeRect(Math.min(a,p),Math.min(c,h),Math.abs(p-a),Math.abs(h-c));else if(n.tool==="circle"){const d=Math.abs(p-a)/2,r=Math.abs(h-c)/2;t.beginPath(),t.ellipse(Math.min(a,p)+d,Math.min(c,h)+r,d,r,0,0,Math.PI*2),t.stroke()}else if(n.tool==="tree_node"){const d=Math.max(16,n.width*3.5);t.beginPath(),t.arc(a,c,d,0,Math.PI*2),t.fillStyle="rgba(15, 23, 42, 0.9)",t.fill(),t.stroke(),t.fillStyle="#ffffff",t.font="bold 11px monospace",t.textAlign="center",t.textBaseline="middle",t.fillText(n.geometry.label||"N",a,c)}}else if(n.points&&n.points.length>1){t.beginPath(),t.moveTo(n.points[0].x,n.points[0].y);for(let a=1;a<n.points.length;a++)t.lineTo(n.points[a].x,n.points[a].y);t.stroke()}t.restore()};this.wbStrokes.forEach(l),i?l({tool:this.wbTool,color:this.wbColor,width:this.wbTool==="highlighter"?14:this.wbWidth,opacity:this.wbTool==="highlighter"?.35:1,points:[],geometry:i}):e&&e.length>1&&l({tool:this.wbTool,color:this.wbColor,width:this.wbTool==="highlighter"?14:this.wbWidth,opacity:this.wbTool==="highlighter"?.35:1,points:e})}listenForRuntimeMessages(){var e;typeof chrome<"u"&&((e=chrome.runtime)!=null&&e.onMessage)&&chrome.runtime.onMessage.addListener(i=>{i.type==="WHITEBOARD_STROKE_LOCAL"&&i.stroke?this.wbStrokes.some(s=>s.id===i.stroke.id)||(this.wbStrokes.push(i.stroke),this.activeTab==="whiteboard"&&this.drawWbCanvas()):i.type==="WHITEBOARD_CLEAR_LOCAL"?(this.wbStrokes=[],this.wbRedoStack=[],this.activeTab==="whiteboard"&&this.drawWbCanvas()):i.type==="WHITEBOARD_UNDO_LOCAL"&&i.strokeId&&(this.wbStrokes=this.wbStrokes.filter(s=>s.id!==i.strokeId),this.activeTab==="whiteboard"&&this.drawWbCanvas())})}escapeHtml(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}formatTimestamp(e){return new Date(e).toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"})}renderFormattedText(e,i){return e.split(`
`).map((t,l)=>{if(t.startsWith("```")&&t.endsWith("```")&&t.length>6){const n=t.slice(3,-3);return`
          <div style="background:rgba(0,0,0,0.45);padding:6px 8px;border-radius:6px;margin:4px 0;font-family:var(--font-mono);font-size:11px;position:relative;">
            <pre style="margin:0;white-space:pre-wrap;word-break:break-all;">${this.escapeHtml(n)}</pre>
          </div>
        `}return t.includes("||")?`<p style="margin:2px 0;">${t.split(/(\|\|.*?\|\|)/g).map((a,c)=>{if(a.startsWith("||")&&a.endsWith("||")&&a.length>4){const p=a.slice(2,-2),h=`${i}-${l}-${c}`,d=!!this.revealedSpoilers[h];return`
              <span style="display:inline-block;padding:1px 6px;border-radius:4px;background:${d?"rgba(99, 102, 241, 0.25)":"rgba(255, 255, 255, 0.15)"};filter:${d?"none":"blur(4px)"};cursor:pointer;">
                ${this.escapeHtml(p)}
              </span>
            `}return this.escapeHtml(a)}).join("")}</p>`:`<p style="margin:2px 0;">${this.escapeHtml(t)}</p>`}).join("")}deduplicateMessages(e){var t,l;const i=new Set,s=[];for(const n of e)!n||!n.id||i.has(n.id)||(i.add(n.id),s.push({...n,isSelf:((t=n.from)==null?void 0:t.peerId)===((l=this.myIdentity)==null?void 0:l.peerId)||n.isSelf}));return s}async sendMessage(e,i){var n,o,a,c;if(!e.trim())return;!this.currentRoomStorageKey&&((n=this.currentProblem)!=null&&n.roomId)&&(this.currentRoomStorageKey=`synqto_chat_${this.currentProblem.roomId}`);const s=e.trim(),t="msg-"+Math.random().toString(36).slice(2,10)+Date.now(),l={id:t,from:this.myIdentity||{nickname:"You",avatar:"⚡",color:"#6366f1",peerId:"self"},text:s,timestamp:Date.now(),replyTo:i==null?void 0:i.id,replyPreview:i==null?void 0:i.preview,status:"sent",isSelf:!0};if(this.messages.push(l),this.messages=this.deduplicateMessages(this.messages),this.render(),this.scrollToBottom(),this.currentRoomStorageKey&&typeof chrome<"u"&&((o=chrome.storage)!=null&&o.local))try{const p=await chrome.storage.local.get([this.currentRoomStorageKey]),h=p[this.currentRoomStorageKey]&&Array.isArray(p[this.currentRoomStorageKey])?p[this.currentRoomStorageKey]:[],d=this.deduplicateMessages([...h,l]).slice(-150);await chrome.storage.local.set({[this.currentRoomStorageKey]:d})}catch{}typeof chrome<"u"&&((a=chrome.runtime)!=null&&a.sendMessage)&&chrome.runtime.sendMessage({type:"SEND_PAGE_CHAT_MESSAGE",messageId:t,text:l.text,replyTo:l.replyTo,replyPreview:l.replyPreview,roomId:(c=this.currentProblem)==null?void 0:c.roomId}).catch(()=>{})}async loadMessages(){var e;if(this.currentRoomStorageKey&&typeof chrome<"u"&&(e=chrome.storage)!=null&&e.local){const i=await chrome.storage.local.get([this.currentRoomStorageKey]);i[this.currentRoomStorageKey]&&Array.isArray(i[this.currentRoomStorageKey])&&(this.messages=this.deduplicateMessages(i[this.currentRoomStorageKey]),this.isOpen&&this.activeTab==="chat"&&(this.render(),this.scrollToBottom()))}}scrollToBottom(){setTimeout(()=>{var i;const e=(i=this.shadow)==null?void 0:i.getElementById("nb-messages");e&&(e.scrollTop=e.scrollHeight)},40)}listenToStorageChanges(){var e;typeof chrome<"u"&&((e=chrome.storage)!=null&&e.onChanged)&&chrome.storage.onChanged.addListener((i,s)=>{var t,l,n;if(s==="local"&&(i.nerd_buddy_sidepanel_open&&i.nerd_buddy_sidepanel_open.newValue===!0&&this.isOpen&&(this.isOpen=!1,this.render()),(i.synqto_live_stage||i.nerd_buddy_live_stage)&&(this.liveStage=(i.synqto_live_stage||i.nerd_buddy_live_stage).newValue,this.render()),(i.synqto_identity||i.nerd_buddy_identity)&&(this.myIdentity=(i.synqto_identity||i.nerd_buddy_identity).newValue),i[w]&&(this.settings=i[w].newValue,this.settings.positionMode==="permanent"&&this.settings.savedPosition&&(this.currentPosition={...this.settings.savedPosition}),this.checkVisibilityAndRender()),(i.synqto_active_problem||i.nerd_buddy_active_problem)&&(this.currentProblem=(i.synqto_active_problem||i.nerd_buddy_active_problem).newValue,this.currentRoomStorageKey=`synqto_chat_${((t=this.currentProblem)==null?void 0:t.roomId)||""}`,this.loadMessages(),this.checkVisibilityAndRender()),i.nerd_buddy_peer_count&&(this.peerCount=Math.max(1,i.nerd_buddy_peer_count.newValue||1),this.render()),this.currentRoomStorageKey&&i[this.currentRoomStorageKey])){const o=i[this.currentRoomStorageKey].newValue||[];this.messages=this.deduplicateMessages(o),!this.isOpen&&((l=i[this.currentRoomStorageKey].newValue)==null?void 0:l.length)>(((n=i[this.currentRoomStorageKey].oldValue)==null?void 0:n.length)||0)&&this.unreadCount++,this.render(),this.isOpen&&this.activeTab==="chat"&&this.scrollToBottom()}})}}console.log("[Nerd Buddy] Content script initialized on:",window.location.href),new I(u=>{var e;try{typeof chrome<"u"&&((e=chrome.runtime)!=null&&e.sendMessage)&&chrome.runtime.sendMessage({type:"PROBLEM_DETECTED",payload:u})}catch{}}),new L,new D})();
