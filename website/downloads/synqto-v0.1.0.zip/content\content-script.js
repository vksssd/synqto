(function(){"use strict";function P(u){let e=2166136261,i=2166136261;for(let t=0;t<u.length;t++){const l=u.charCodeAt(t);e=Math.imul(e^l&255,16777619),i=Math.imul(i^l>>8,16777619)}return((e>>>0^i>>>0)>>>0).toString(16).padStart(8,"0")}function E(u,e){let i=null;return(...s)=>{i&&clearTimeout(i),i=setTimeout(()=>u(...s),e)}}function S(u,e){var i;try{const s=new URL(u),t=s.hostname.toLowerCase(),l=s.pathname;if(t.includes("leetcode.com")){const o=l.match(/\/problems\/([a-zA-Z0-9-_]+)/);if(o&&o[1]){const r=o[1],d=v(r);return{platform:"LeetCode",slug:r,title:d,url:u,canonicalUrl:`https://leetcode.com/problems/${r}/`}}}if(t.includes("neetcode.io")){const o=l.match(/\/problems\/([a-zA-Z0-9-_]+)/);if(o&&o[1]){const r=o[1],d=v(r);return{platform:"NeetCode",slug:r,title:d,url:u,canonicalUrl:`https://neetcode.io/problems/${r}`}}}if(t.includes("codeforces.com")){const o=l.match(/\/(?:contest|problemset\/problem)\/(\d+)\/([A-Z0-9]+)/i);if(o){const r=o[1],d=o[2].toUpperCase();return{platform:"Codeforces",slug:`cf-${r}-${d}`,title:`Codeforces ${r}${d}`,url:u,canonicalUrl:`https://codeforces.com/problemset/problem/${r}/${d}`}}}if(t.includes("hackerrank.com")){const o=l.match(/\/challenges\/([a-zA-Z0-9-_]+)/);if(o&&o[1]){const r=o[1];return{platform:"HackerRank",slug:r,title:v(r),url:u,canonicalUrl:`https://www.hackerrank.com/challenges/${r}/problem`}}}if(t.includes("codechef.com")){const o=l.match(/\/problems\/([a-zA-Z0-9-_]+)/);if(o&&o[1]){const r=o[1];return{platform:"CodeChef",slug:r,title:`CodeChef ${r}`,url:u,canonicalUrl:`https://www.codechef.com/problems/${r}`}}}if(t.includes("geeksforgeeks.org")){const o=l.match(/\/problems\/([a-zA-Z0-9-_]+)/);if(o&&o[1]){const r=o[1];return{platform:"GeeksforGeeks",slug:r,title:v(r),url:u,canonicalUrl:`https://www.geeksforgeeks.org/problems/${r}/1`}}}if(t.includes("youtube.com")||t.includes("youtu.be")){let o=s.searchParams.get("v");if(!o&&t.includes("youtu.be")&&(o=l.slice(1)),!o&&l.includes("/shorts/")&&(o=(i=l.split("/shorts/")[1])==null?void 0:i.split("/")[0]),o){const r=e?$(e):`YouTube Video (${o})`;return{platform:"YouTube",slug:`yt-${o}`,title:r,url:u,canonicalUrl:`https://www.youtube.com/watch?v=${o}`}}}if(t.includes("arxiv.org")){const o=l.match(/\/(?:abs|pdf)\/(\d+\.\d+(?:v\d+)?)/);if(o&&o[1]){const r=o[1];return{platform:"ArXiv",slug:`arxiv-${r.replace(/\./g,"-")}`,title:e?M(e):`ArXiv ${r}`,url:u,canonicalUrl:`https://arxiv.org/abs/${r}`}}}if(t.includes("github.com")){const o=l.match(/^\/([^\/]+)\/([^\/]+)\/(?:issues|pull)\/(\d+)/);if(o){const r=o[1],d=o[2],b=o[3];return{platform:"GitHub",slug:`gh-${r}-${d}-${b}`,title:`${r}/${d} #${b}`,url:u,canonicalUrl:`https://github.com/${r}/${d}/issues/${b}`}}}return{platform:"Web",slug:t.replace(/\./g,"-")||"general-study",title:e||t||"General Study Room",url:u,canonicalUrl:u}}catch{return null}}function v(u){return u.split(/[-_]/).map(e=>e.charAt(0).toUpperCase()+e.slice(1)).join(" ")}function $(u){return u.replace(/\s*-\s*YouTube\s*$/,"").trim()}function M(u){return u.replace(/^\[[^\]]+\]\s*/,"").replace(/\s*-\s*arXiv.*$/,"").trim()}function _(){try{return!!(typeof chrome<"u"&&chrome.runtime&&chrome.runtime.id)}catch{return!1}}class I{constructor(e){this.lastUrl="",this.lastTitle="",this.mutationObserver=null,this.pollTimer=null,this.debouncedCheck=E(()=>{if(!_()){this.destroy();return}this.checkCurrentPage()},250),this.callback=e,this.init()}init(){this.checkCurrentPage();const e=history.pushState,i=history.replaceState;history.pushState=(...t)=>{e.apply(history,t),this.debouncedCheck()},history.replaceState=(...t)=>{i.apply(history,t),this.debouncedCheck()},window.addEventListener("popstate",()=>this.debouncedCheck()),window.addEventListener("hashchange",()=>this.debouncedCheck()),window.addEventListener("yt-navigate-finish",()=>this.debouncedCheck()),this.mutationObserver=new MutationObserver(()=>{document.title!==this.lastTitle&&this.debouncedCheck()});const s=document.querySelector("title");s&&this.mutationObserver.observe(s,{subtree:!0,characterData:!0,childList:!0}),this.pollTimer=setInterval(()=>{if(!_()){this.destroy();return}window.location.href!==this.lastUrl&&this.checkCurrentPage()},350)}checkCurrentPage(){const e=window.location.href,i=document.title;if(e===this.lastUrl&&i===this.lastTitle)return;this.lastUrl=e,this.lastTitle=i;const s=S(e,i);s&&this.callback(s)}destroy(){this.mutationObserver&&(this.mutationObserver.disconnect(),this.mutationObserver=null),this.pollTimer&&(clearInterval(this.pollTimer),this.pollTimer=null)}}function x(){try{return!!(typeof chrome<"u"&&chrome.runtime&&chrome.runtime.id)}catch{return!1}}class L{constructor(){this.container=null,this.cursorElements=new Map,this.cursorTimeouts=new Map,this.myIdentity=null,this.liveStage=null,this.createContainer(),this.loadState(),this.listenToStorage(),this.listenForMessages(),this.setupLocalTrackers()}async loadState(){var e;if(typeof chrome<"u"&&((e=chrome.storage)!=null&&e.local))try{const i=await chrome.storage.local.get(["nerd_buddy_identity","synqme_identity","nerd_buddy_live_stage","synqme_live_stage"]);this.myIdentity=i.synqme_identity||i.nerd_buddy_identity||null,this.liveStage=i.synqme_live_stage||i.nerd_buddy_live_stage||null,(!this.liveStage||!this.liveStage.isActive)&&this.clearAllCursors()}catch{}}listenToStorage(){var e;typeof chrome<"u"&&((e=chrome.storage)!=null&&e.onChanged)&&chrome.storage.onChanged.addListener((i,s)=>{s==="local"&&((i.synqme_identity||i.nerd_buddy_identity)&&(this.myIdentity=(i.synqme_identity||i.nerd_buddy_identity).newValue),(i.synqme_live_stage||i.nerd_buddy_live_stage)&&(this.liveStage=(i.synqme_live_stage||i.nerd_buddy_live_stage).newValue,(!this.liveStage||!this.liveStage.isActive)&&this.clearAllCursors()))})}clearAllCursors(){this.cursorTimeouts.forEach(e=>clearTimeout(e)),this.cursorTimeouts.clear(),this.cursorElements.forEach(e=>{e.remove()}),this.cursorElements.clear(),this.container&&(this.container.innerHTML="")}isLocalUserOnStage(){var i,s;if(!this.liveStage||!this.liveStage.isActive)return!1;const e=(i=this.myIdentity)==null?void 0:i.peerId;return e?!!(((s=this.liveStage.tutorIdentity)==null?void 0:s.peerId)===e||this.liveStage.tutorPeerId===e||this.liveStage.myRole==="tutor"||Array.isArray(this.liveStage.guestSpeakers)&&this.liveStage.guestSpeakers.some(t=>t.peerId===e)):!1}createContainer(){if(document.getElementById("nerd-buddy-cursor-overlay"))return;const e=document.createElement("div");if(e.id="nerd-buddy-cursor-overlay",e.style.cssText=`
      position: fixed !important;
      top: 0 !important;
      left: 0 !important;
      width: 100vw !important;
      height: 100vh !important;
      pointer-events: none !important;
      z-index: 2147483645 !important;
      overflow: hidden !important;
      box-sizing: border-box !important;
    `,document.body.appendChild(e),this.container=e,!document.getElementById("nerd-buddy-cursor-styles")){const i=document.createElement("style");i.id="nerd-buddy-cursor-styles",i.textContent=`
        @keyframes nb-click-ripple {
          0% { transform: scale(0.15); opacity: 1; }
          40% { opacity: 0.9; }
          100% { transform: scale(2.8); opacity: 0; }
        }
      `,document.head.appendChild(i)}}listenForMessages(){var e;if(!(!x()||!((e=chrome.runtime)!=null&&e.onMessage)))try{chrome.runtime.onMessage.addListener(i=>{var s,t,l,c;if(x()){if(i.type==="NERD_BUDDY_STAGE_ENDED"||i.type==="NERD_BUDDY_STAGE_INACTIVE"){this.clearAllCursors();return}if(i.type==="NERD_BUDDY_CURSOR_UPDATE"&&i.cursor){const o=i.cursor;(o.isTutor||this.liveStage&&(((s=this.liveStage.tutorIdentity)==null?void 0:s.peerId)===o.peerId||this.liveStage.tutorPeerId===o.peerId||((t=this.liveStage.guestSpeakers)==null?void 0:t.some(d=>d.peerId===o.peerId)))||!this.liveStage)&&this.renderCursor(o)}else if(i.type==="NERD_BUDDY_CLICK_PULSE"&&i.click){const o=i.click;(o.isTutor||this.liveStage&&(((l=this.liveStage.tutorIdentity)==null?void 0:l.peerId)===o.peerId||this.liveStage.tutorPeerId===o.peerId||((c=this.liveStage.guestSpeakers)==null?void 0:c.some(d=>d.peerId===o.peerId)))||o.isTutor||!this.liveStage)&&this.renderClickPulse(o)}}})}catch{}}renderCursor(e){if(this.container||this.createContainer(),!this.container)return;let i=this.cursorElements.get(e.peerId);i||(i=document.createElement("div"),i.style.cssText=`
        position: fixed !important;
        pointer-events: none !important;
        transition: left 0.05s linear, top 0.05s linear, opacity 0.3s ease !important;
        display: flex !important;
        align-items: center !important;
        gap: 5px !important;
        opacity: 1 !important;
        z-index: 2147483646 !important;
      `,this.container.appendChild(i),this.cursorElements.set(e.peerId,i));const s=Math.max(0,Math.min(window.innerWidth-30,e.xPct/100*window.innerWidth)),t=Math.max(0,Math.min(window.innerHeight-30,e.yPct/100*window.innerHeight));i.style.left=`${s}px`,i.style.top=`${t}px`,i.style.opacity="1";const l=e.isTutor?"#8b5cf6":e.color||"#6366f1";i.innerHTML=`
      <div style="
        width: 18px;
        height: 18px;
        border-radius: 50%;
        background: ${l};
        box-shadow: 0 0 16px ${l}, 0 0 6px #ffffff;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 11px;
        color: #fff;
        border: 2px solid #ffffff;
      ">
        ${e.avatar||"👑"}
      </div>
      <div style="
        background: rgba(15, 23, 42, 0.92);
        border: 1px solid ${l};
        color: #f8fafc;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        font-size: 10px;
        font-weight: 600;
        padding: 2px 6px;
        border-radius: 4px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.6);
        white-space: nowrap;
      ">
        ${e.nickname} ${e.isTutor?"🎓 (Tutor)":"🎤 (Speaker)"}
      </div>
    `;const c=this.cursorTimeouts.get(e.peerId);c&&clearTimeout(c);const o=window.setTimeout(()=>{i&&(i.style.opacity="0")},4e3);this.cursorTimeouts.set(e.peerId,o)}renderClickPulse(e){if(this.container||this.createContainer(),!this.container)return;const i=e.xPct/100*window.innerWidth,s=e.yPct/100*window.innerHeight,t=document.createElement("div"),l=e.color||(e.isTutor?"#8b5cf6":"#6366f1");t.style.cssText=`
      position: fixed !important;
      left: ${i-22}px !important;
      top: ${s-22}px !important;
      width: 44px !important;
      height: 44px !important;
      border-radius: 50% !important;
      border: 3px solid ${l} !important;
      box-shadow: 0 0 16px ${l}, inset 0 0 8px ${l} !important;
      pointer-events: none !important;
      z-index: 2147483647 !important;
      box-sizing: border-box !important;
      animation: nb-click-ripple 0.85s cubic-bezier(0.1, 0.8, 0.3, 1) forwards !important;
    `,this.container.appendChild(t),setTimeout(()=>{t.remove()},900)}setupLocalTrackers(){let e=0;window.addEventListener("mousemove",i=>{if(!x()||!this.isLocalUserOnStage())return;const s=Date.now();if(s-e<40)return;e=s;const t=i.clientX/window.innerWidth*100,l=i.clientY/window.innerHeight*100;try{chrome.runtime.sendMessage({type:"LOCAL_CURSOR_MOVE",xPct:t,yPct:l}).catch(()=>{})}catch{}}),window.addEventListener("click",i=>{var l,c,o;if(!x()||!this.isLocalUserOnStage())return;const s=i.clientX/window.innerWidth*100,t=i.clientY/window.innerHeight*100;this.renderClickPulse({peerId:((l=this.myIdentity)==null?void 0:l.peerId)||"local",nickname:((c=this.myIdentity)==null?void 0:c.nickname)||"You",xPct:s,yPct:t,color:((o=this.myIdentity)==null?void 0:o.color)||"#8b5cf6",isTutor:!0,timestamp:Date.now()});try{chrome.runtime.sendMessage({type:"LOCAL_CLICK_PULSE",xPct:s,yPct:t}).catch(()=>{})}catch{}})}}const B={mode:"coding_sites",clickAction:"open_popup",customDomains:["leetcode.com","neetcode.io","codeforces.com","hackerrank.com","geeksforgeeks.org"],enableWhiteboard:!1,positionMode:"permanent",savedPosition:{right:24,bottom:24}},w="nerd_buddy_fab_settings";function A(u,e){const i=u.toLowerCase().replace(/[^a-z0-9-_]/g,"-").slice(0,24).replace(/-+$/,""),s=P(e);return`room:${i||"lobby"}-${s}`}function R(u){switch(u.toLowerCase()){case"leetcode":return"#FFA116";case"neetcode":return"#8B5CF6";case"codeforces":return"#318CE7";case"hackerrank":return"#2EC866";case"codechef":return"#5B4638";case"geeksforgeeks":return"#2F8D46";case"youtube":return"#FF0000";case"arxiv":return"#B31B1B";case"github":return"#24292F";case"group":return"#8B5CF6";default:return"#6366F1"}}class W{constructor(){this.hostElement=null,this.shadow=null,this.isOpen=!1,this.settings=B,this.currentProblem=null,this.messages=[],this.unreadCount=0,this.currentRoomStorageKey="",this.myIdentity=null,this.liveStage=null,this.peerCount=1,this.replyingTo=null,this.revealedSpoilers={},this.currentPosition={right:24,bottom:24},this.isDragging=!1,this.dragMoved=!1,this.activeTab="chat",this.wbTool="pen",this.wbColor="#6366f1",this.wbWidth=4,this.wbTheme="grid",this.wbStrokes=[],this.wbRedoStack=[],this.isWbDrawing=!1,this.wbCurrentPoints=[],this.wbStartPoint=null,this.init()}async init(){await this.loadIdentity(),await this.loadSettings(),this.detectCurrentPageProblem(),this.checkVisibilityAndRender(),this.listenToStorageChanges(),this.listenForRuntimeMessages()}async loadIdentity(){var e;if(typeof chrome<"u"&&((e=chrome.storage)!=null&&e.local)){const i=await chrome.storage.local.get(["synqto_identity","nerd_buddy_identity"]);(i.synqto_identity||i.nerd_buddy_identity)&&(this.myIdentity=i.synqto_identity||i.nerd_buddy_identity)}this.myIdentity||(this.myIdentity={peerId:"peer-"+Math.random().toString(36).slice(2,10),nickname:"Coder"+Math.floor(Math.random()*900+100),avatar:"⚡",color:"#6366f1"})}async loadSettings(){var e,i;if(typeof chrome<"u"&&((e=chrome.storage)!=null&&e.local)){const s=await chrome.storage.local.get([w,"synqto_active_problem","nerd_buddy_active_problem","synqto_live_stage","nerd_buddy_live_stage","nerd_buddy_sidepanel_open","nerd_buddy_peer_count"]);s[w]&&(this.settings=s[w]),this.settings.positionMode==="permanent"&&this.settings.savedPosition?this.currentPosition={...this.settings.savedPosition}:this.currentPosition={right:24,bottom:24};const t=s.synqto_active_problem||s.nerd_buddy_active_problem;t&&(this.currentProblem=t,this.currentRoomStorageKey=`synqto_chat_${((i=this.currentProblem)==null?void 0:i.roomId)||""}`,await this.loadMessages()),(s.synqto_live_stage||s.nerd_buddy_live_stage)&&(this.liveStage=s.synqto_live_stage||s.nerd_buddy_live_stage),typeof s.nerd_buddy_peer_count=="number"&&(this.peerCount=Math.max(1,s.nerd_buddy_peer_count))}}detectCurrentPageProblem(){const e=S(window.location.href,document.title);if(e){const i=A(e.slug,e.canonicalUrl);this.currentProblem={platform:e.platform,slug:e.slug,title:e.title,canonicalUrl:e.canonicalUrl,roomId:i},this.currentRoomStorageKey=`synqto_chat_${i}`,this.loadMessages()}}shouldShow(){if(this.settings.mode==="disabled")return!1;if(this.settings.mode==="all_sites")return!0;const e=window.location.hostname.toLowerCase();if(this.settings.mode==="custom_sites")return this.settings.customDomains.some(l=>e.includes(l.toLowerCase()));const s=["leetcode.com","neetcode.io","codeforces.com","hackerrank.com","geeksforgeeks.org","codechef.com","atcoder.jp","github.com","youtube.com","arxiv.org"].some(l=>e.includes(l)),t=!!(this.currentProblem||S(window.location.href));return s||t}checkVisibilityAndRender(){const e=this.shouldShow();e&&!this.hostElement?this.createWidgetDOM():!e&&this.hostElement&&(this.hostElement.remove(),this.hostElement=null,this.shadow=null)}createWidgetDOM(){if(document.getElementById("synqto-floating-host"))return;const e=document.createElement("div");e.id="synqto-floating-host",e.style.cssText=`
      position: fixed;
      bottom: ${this.currentPosition.bottom}px;
      right: ${this.currentPosition.right}px;
      z-index: 2147483640;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
      touch-action: none;
    `,document.body.appendChild(e),this.hostElement=e,this.shadow=e.attachShadow({mode:"open"}),this.render()}applyHostPosition(){if(!this.hostElement)return;const e=Math.max(10,Math.min(window.innerWidth-130,this.currentPosition.right)),i=Math.max(10,Math.min(window.innerHeight-55,this.currentPosition.bottom));this.hostElement.style.right=`${e}px`,this.hostElement.style.bottom=`${i}px`}render(){var d,b,p,a;if(!this.shadow)return;this.applyHostPosition();const e=!!(this.liveStage&&this.liveStage.isActive),i=((b=(d=this.liveStage)==null?void 0:d.tutorIdentity)==null?void 0:b.nickname)||"Tutor",s=((p=this.currentProblem)==null?void 0:p.title)||"Global Problem Lobby",t=((a=this.currentProblem)==null?void 0:a.platform)||"LeetCode",l=R(t),c=this.settings.enableWhiteboard&&this.activeTab==="whiteboard",o=this.currentPosition.bottom>window.innerHeight-540,r=this.currentPosition.right>window.innerWidth-420;this.shadow.innerHTML=`
      <style>
        :host {
          --primary: #6366f1;
          --primary-hover: #4f46e5;
          --bg-card: rgba(15, 23, 42, 0.96);
          --bg-surface-elevated: rgba(30, 41, 59, 0.85);
          --border-subtle: rgba(255, 255, 255, 0.1);
          --text-primary: #f8fafc;
          --text-secondary: #94a3b8;
          --text-muted: #64748b;
          --text-dim: #475569;
          --font-mono: 'JetBrains Mono', 'Fira Code', monospace;
        }

        * {
          box-sizing: border-box;
          margin: 0;
          padding: 0;
        }

        /* Floating Action Button (FAB) */
        .fab-button {
          position: relative;
          display: flex;
          align-items: center;
          gap: 7px;
          padding: 10px 14px;
          border-radius: 9999px;
          background: linear-gradient(135deg, #4f46e5, #7c3aed);
          border: 1px solid rgba(255, 255, 255, 0.2);
          box-shadow: 0 10px 25px -5px rgba(99, 102, 241, 0.5), 0 0 15px rgba(124, 58, 237, 0.3);
          color: #ffffff;
          font-size: 12px;
          font-weight: 700;
          cursor: grab;
          transition: transform 0.15s cubic-bezier(0.16, 1, 0.3, 1), box-shadow 0.15s;
          user-select: none;
        }

        .fab-button:active {
          cursor: grabbing;
        }

        .fab-button:hover {
          transform: translateY(-2px) scale(1.02);
          box-shadow: 0 14px 28px -5px rgba(99, 102, 241, 0.65), 0 0 20px rgba(124, 58, 237, 0.4);
        }

        .drag-grip {
          opacity: 0.5;
          font-size: 11px;
          cursor: grab;
        }

        .live-dot {
          width: 8px;
          height: 8px;
          border-radius: 50%;
          background: #ef4444;
          box-shadow: 0 0 10px #ef4444;
          animation: livePulse 1.5s infinite;
        }

        @keyframes livePulse {
          0%, 100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.4; transform: scale(1.2); }
        }

        .fab-badge {
          position: absolute;
          top: -4px;
          right: -4px;
          background: #f59e0b;
          color: #ffffff;
          font-size: 10px;
          font-weight: 700;
          padding: 2px 6px;
          border-radius: 9999px;
        }

        /* In-Page Popup Card */
        .popup-card {
          display: ${this.isOpen?"flex":"none"};
          flex-direction: column;
          position: absolute;
          ${o?"top: 52px; bottom: auto;":"bottom: 52px; top: auto;"}
          ${r?"left: 0; right: auto;":"right: 0; left: auto;"}
          width: 400px;
          height: 540px;
          max-height: 84vh;
          background: rgba(15, 23, 42, 0.96);
          border: 1px solid ${e?"rgba(239, 68, 68, 0.45)":"rgba(99, 102, 241, 0.35)"};
          border-radius: 16px;
          box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.85), 0 0 24px ${e?"rgba(239, 68, 68, 0.25)":"rgba(99, 102, 241, 0.2)"};
          backdrop-filter: blur(20px);
          -webkit-backdrop-filter: blur(20px);
          overflow: hidden;
          animation: slideIn 0.2s cubic-bezier(0.16, 1, 0.3, 1);
          color: var(--text-primary);
        }

        @keyframes slideIn {
          from { opacity: 0; transform: translateY(12px) scale(0.96); }
          to { opacity: 1; transform: translateY(0) scale(1); }
        }

        /* Room Header */
        .room-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 10px 12px;
          background: linear-gradient(135deg, rgba(30, 41, 59, 0.95), rgba(15, 23, 42, 0.95));
          border-bottom: 1px solid var(--border-subtle);
        }

        .room-info {
          display: flex;
          align-items: center;
          gap: 10px;
          overflow: hidden;
        }

        .platform-icon-box {
          width: 32px;
          height: 32px;
          border-radius: 8px;
          background: rgba(99, 102, 241, 0.15);
          border: 1px solid rgba(255, 255, 255, 0.1);
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 16px;
          flex-shrink: 0;
        }

        .problem-title {
          font-size: 13px;
          font-weight: 700;
          color: var(--text-primary);
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
          max-width: 170px;
        }

        .badges-row {
          display: flex;
          align-items: center;
          gap: 6px;
          margin-top: 2px;
        }

        .platform-pill {
          font-size: 9px;
          font-weight: 700;
          padding: 1px 6px;
          border-radius: 4px;
          background: ${l}20;
          border: 1px solid ${l}50;
          color: ${l};
          text-transform: uppercase;
        }

        .peer-count-pill {
          font-size: 10px;
          color: var(--text-secondary);
          display: flex;
          align-items: center;
          gap: 4px;
        }

        .header-actions {
          display: flex;
          align-items: center;
          gap: 4px;
        }

        .icon-btn {
          background: transparent;
          border: none;
          color: var(--text-secondary);
          cursor: pointer;
          padding: 5px;
          border-radius: 6px;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: all 0.15s;
        }

        .icon-btn:hover {
          background: rgba(255, 255, 255, 0.1);
          color: #ffffff;
        }

        /* Segmented View Switcher */
        .tab-switcher {
          display: flex;
          background: rgba(15, 23, 42, 0.9);
          padding: 3px 6px;
          border-bottom: 1px solid var(--border-subtle);
          gap: 4px;
        }

        .tab-btn {
          flex: 1;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 6px;
          padding: 5px 8px;
          font-size: 11px;
          font-weight: 600;
          border-radius: 6px;
          border: none;
          cursor: pointer;
          transition: all 0.15s;
          background: transparent;
          color: var(--text-muted);
        }

        .tab-btn.active {
          background: var(--primary);
          color: #ffffff;
        }

        /* Messages List */
        .message-list {
          flex: 1;
          overflow-y: auto;
          padding: 12px;
          display: flex;
          flex-direction: column;
          gap: 10px;
        }

        .chat-bubble {
          display: flex;
          flex-direction: column;
          max-width: 86%;
          padding: 8px 12px;
          border-radius: 14px;
          font-size: 12px;
          position: relative;
          word-break: break-word;
          line-height: 1.45;
        }

        .chat-bubble.self {
          align-self: flex-end;
          background: linear-gradient(135deg, rgba(99, 102, 241, 0.28), rgba(139, 92, 246, 0.22));
          border: 1px solid rgba(99, 102, 241, 0.35);
          border-bottom-right-radius: 4px;
          color: #ffffff;
        }

        .chat-bubble.other {
          align-self: flex-start;
          background: var(--bg-surface-elevated);
          border: 1px solid var(--border-subtle);
          border-bottom-left-radius: 4px;
          color: #f1f5f9;
        }

        .chat-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 8px;
          margin-bottom: 4px;
          font-size: 11px;
        }

        .chat-author {
          font-weight: 600;
          display: flex;
          align-items: center;
          gap: 4px;
        }

        .chat-timestamp {
          color: var(--text-dim);
          font-size: 10px;
        }

        .chat-footer {
          margin-top: 3px;
          display: flex;
          align-items: center;
          justify-content: flex-end;
          font-size: 10px;
        }

        .ack-read {
          color: #38bdf8;
          font-weight: 700;
        }

        /* Whiteboard Toolbar & Canvas */
        .whiteboard-container {
          flex: 1;
          display: flex;
          flex-direction: column;
          background: #090d16;
          overflow: hidden;
          position: relative;
        }

        .wb-toolbar {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 6px 8px;
          background: rgba(15, 23, 42, 0.95);
          border-bottom: 1px solid var(--border-subtle);
          flex-wrap: wrap;
          gap: 4px;
        }

        .wb-tool-group {
          display: flex;
          gap: 3px;
          align-items: center;
        }

        .wb-tool-btn {
          padding: 4px 6px;
          border-radius: 4px;
          border: 1px solid transparent;
          background: transparent;
          color: var(--text-muted);
          cursor: pointer;
          font-size: 11px;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .wb-tool-btn.active {
          border-color: var(--primary);
          background: rgba(99, 102, 241, 0.25);
          color: #c7d2fe;
        }

        .wb-palette-bar {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 3px 8px;
          background: rgba(0, 0, 0, 0.3);
          border-bottom: 1px solid var(--border-subtle);
        }

        .color-dot {
          width: 13px;
          height: 13px;
          border-radius: 50%;
          border: 1px solid rgba(255, 255, 255, 0.2);
          cursor: pointer;
        }

        .color-dot.active {
          border: 2px solid #ffffff;
          box-shadow: 0 0 6px rgba(255, 255, 255, 0.5);
        }

        .size-pill {
          font-size: 9px;
          font-weight: 700;
          padding: 1px 4px;
          border-radius: 3px;
          background: rgba(255, 255, 255, 0.05);
          border: 1px solid transparent;
          color: var(--text-dim);
          cursor: pointer;
        }

        .size-pill.active {
          background: rgba(99, 102, 241, 0.3);
          border-color: var(--primary);
          color: #ffffff;
        }

        #nb-whiteboard-canvas {
          flex-grow: 1;
          width: 100%;
          height: 100%;
          cursor: crosshair;
          touch-action: none;
        }

        /* Input Composer */
        .composer-box {
          display: flex;
          align-items: center;
          gap: 6px;
          padding: 8px 10px;
          background: rgba(15, 23, 42, 0.95);
          border-top: 1px solid var(--border-subtle);
        }

        .input-glass {
          flex: 1;
          background: rgba(0, 0, 0, 0.4);
          border: 1px solid var(--border-subtle);
          border-radius: 8px;
          padding: 7px 10px;
          color: #ffffff;
          font-size: 11px;
          outline: none;
        }

        .input-glass:focus {
          border-color: var(--primary);
        }

        .btn-send {
          background: var(--primary);
          border: none;
          color: #ffffff;
          padding: 6px 10px;
          border-radius: 8px;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .prompt-pills-row {
          display: flex;
          gap: 4px;
          padding: 4px 8px;
          overflow-x: auto;
          background: rgba(0, 0, 0, 0.3);
          border-top: 1px solid var(--border-subtle);
        }

        .prompt-pill {
          background: rgba(255, 255, 255, 0.06);
          border: 1px solid var(--border-subtle);
          color: var(--text-secondary);
          font-size: 9px;
          font-weight: 600;
          padding: 2px 6px;
          border-radius: 4px;
          cursor: pointer;
          white-space: nowrap;
        }

        .prompt-pill:hover {
          background: rgba(99, 102, 241, 0.2);
          color: #ffffff;
        }
      </style>

      <!-- In-Page Popup Card Window -->
      <div class="popup-card" id="nb-popup-card">
        <!-- Room Header Bar -->
        <div class="room-header">
          <div class="room-info">
            <div class="platform-icon-box">⚡</div>
            <div>
              <div class="problem-title">${this.escapeHtml(s)}</div>
              <div class="badges-row">
                <span class="platform-pill">${t}</span>
                <span class="peer-count-pill">
                  <span style="display:inline-block;width:6px;height:6px;border-radius:50%;background:#10b981;"></span>
                  <span>${this.peerCount} Online</span>
                </span>
              </div>
            </div>
          </div>

          <div class="header-actions">
            <button class="icon-btn" id="nb-open-sidepanel" title="Open complete extension in side panel">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M15 3h6v6M10 14L21 3M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6"/>
              </svg>
            </button>
            <button class="icon-btn" id="nb-close-popup" title="Minimize">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M18 6L6 18M6 6l12 12"/>
              </svg>
            </button>
          </div>
        </div>

        <!-- Segmented Switcher when Whiteboard is Enabled in Settings -->
        ${this.settings.enableWhiteboard?`
          <div class="tab-switcher">
            <button class="tab-btn ${this.activeTab==="chat"?"active":""}" id="nb-tab-chat">
              <span>💬 Live Chat</span>
            </button>
            <button class="tab-btn ${this.activeTab==="whiteboard"?"active":""}" id="nb-tab-whiteboard">
              <span>🎨 Whiteboard</span>
            </button>
          </div>
        `:""}

        <!-- Multi-Broadcaster Live Streams List -->
        ${e?`
          <div style="background:linear-gradient(135deg, rgba(239, 68, 68, 0.22), rgba(139, 92, 246, 0.18));border-bottom:1px solid rgba(239, 68, 68, 0.35);padding:6px 10px;display:flex;flex-direction:column;gap:5px;">
            <div style="display:flex;align-items:center;justify-content:space-between;font-size:10px;color:#fca5a5;">
              <div style="display:flex;align-items:center;gap:5px;font-weight:700;">
                <span class="live-dot"></span>
                <span>LIVE STREAMS (${this.liveStage.activeStreams&&this.liveStage.activeStreams.length||1}):</span>
              </div>
              <button id="nb-live-tunein" style="background:#ef4444;color:#fff;border:none;padding:2px 8px;border-radius:4px;font-size:9px;font-weight:700;cursor:pointer;">
                Open Side Panel 📺
              </button>
            </div>

            <div style="display:flex;gap:4px;overflow-x:auto;padding-bottom:2px;">
              ${(this.liveStage.activeStreams&&this.liveStage.activeStreams.length>0?this.liveStage.activeStreams:[{broadcasterIdentity:this.liveStage.tutorIdentity||{nickname:i,avatar:"👑"},title:`${i}'s Walkthrough`,broadcastType:this.liveStage.broadcastType||"screen"}]).map(n=>{var h,g;return`
                <div style="display:flex;align-items:center;gap:4px;padding:3px 6px;border-radius:4px;background:rgba(0,0,0,0.4);border:1px solid rgba(255,255,255,0.1);font-size:10px;color:#f8fafc;white-space:nowrap;">
                  <span>${((h=n.broadcasterIdentity)==null?void 0:h.avatar)||"👤"}</span>
                  <span style="font-weight:600;">${((g=n.broadcasterIdentity)==null?void 0:g.nickname)||"Streamer"}:</span>
                  <span style="color:#c7d2fe;max-width:110px;overflow:hidden;text-overflow:ellipsis;">${this.escapeHtml(n.title||"Live Stream")}</span>
                  <span style="font-size:8px;padding:1px 4px;border-radius:3px;background:rgba(239,68,68,0.3);color:#fca5a5;text-transform:uppercase;">${n.broadcastType||"live"}</span>
                </div>
              `}).join("")}
            </div>
          </div>
        `:""}

        <!-- Main Body: Chat or Whiteboard -->
        ${c?`
          <!-- Whiteboard View -->
          <div class="whiteboard-container">
            <div class="wb-toolbar">
              <div class="wb-tool-group">
                <button class="wb-tool-btn ${this.wbTool==="pen"?"active":""}" data-wbtool="pen" title="Fine Pen">✏️</button>
                <button class="wb-tool-btn ${this.wbTool==="brush"?"active":""}" data-wbtool="brush" title="Brush Pen">✒️</button>
                <button class="wb-tool-btn ${this.wbTool==="highlighter"?"active":""}" data-wbtool="highlighter" title="Highlighter">🖍️</button>
                <button class="wb-tool-btn ${this.wbTool==="laser"?"active":""}" data-wbtool="laser" title="Laser Pointer">🔴</button>
                <button class="wb-tool-btn ${this.wbTool==="torch"?"active":""}" data-wbtool="torch" title="Spotlight Torch">🔦</button>
                <button class="wb-tool-btn ${this.wbTool==="eraser"?"active":""}" data-wbtool="eraser" title="Eraser">🧹</button>
                <button class="wb-tool-btn ${this.wbTool==="line"?"active":""}" data-wbtool="line" title="Line">📏</button>
                <button class="wb-tool-btn ${this.wbTool==="arrow"?"active":""}" data-wbtool="arrow" title="Arrow">➡️</button>
                <button class="wb-tool-btn ${this.wbTool==="rect"?"active":""}" data-wbtool="rect" title="Box">🔲</button>
                <button class="wb-tool-btn ${this.wbTool==="circle"?"active":""}" data-wbtool="circle" title="Node">⭕</button>
                <button class="wb-tool-btn ${this.wbTool==="tree_node"?"active":""}" data-wbtool="tree_node" title="Tree Node">🌳</button>
              </div>

              <div class="wb-tool-group">
                <button class="wb-tool-btn" id="nb-wb-undo" title="Undo">↩️</button>
                <button class="wb-tool-btn" id="nb-wb-redo" title="Redo">↪️</button>
                <button class="wb-tool-btn" id="nb-wb-clear" title="Clear Canvas" style="color:#f87171;">🗑️</button>
                <button class="wb-tool-btn" id="nb-wb-save" title="Export PNG">💾</button>
              </div>
            </div>

            <!-- Color Palette, Widths & Background Choices -->
            <div class="wb-palette-bar">
              <div style="display:flex;gap:2px;align-items:center;overflow-x:auto;">
                <button class="size-pill ${this.wbTheme==="grid"?"active":""}" data-wbtheme="grid" title="Square Graph Grid">⬛ Grid</button>
                <button class="size-pill ${this.wbTheme==="ruled"?"active":""}" data-wbtheme="ruled" title="Ruled Lined Paper">📏 Ruled</button>
                <button class="size-pill ${this.wbTheme==="plot"?"active":""}" data-wbtheme="plot" title="Coordinate Plot (X,Y)">📈 Plot</button>
                <button class="size-pill ${this.wbTheme==="dotted"?"active":""}" data-wbtheme="dotted" title="Dot Grid">🟦 Dots</button>
                <button class="size-pill ${this.wbTheme==="matrix"?"active":""}" data-wbtheme="matrix" title="Matrix Table">📐 Matrix</button>
                <button class="size-pill ${this.wbTheme==="white_blank"?"active":""}" data-wbtheme="white_blank" title="White Board">⬜ White</button>
              </div>

              <div style="display:flex;gap:4px;align-items:center;">
                ${["#6366f1","#06b6d4","#10b981","#f59e0b","#f43f5e","#ffffff"].map(n=>`
                  <div class="color-dot ${this.wbColor===n?"active":""}" data-color="${n}" style="background:${n};"></div>
                `).join("")}
              </div>

              <div style="display:flex;gap:2px;align-items:center;">
                <button class="size-pill ${this.wbWidth===2?"active":""}" data-size="2">S</button>
                <button class="size-pill ${this.wbWidth===4?"active":""}" data-size="4">M</button>
                <button class="size-pill ${this.wbWidth===8?"active":""}" data-size="8">L</button>
              </div>
            </div>

            <!-- HTML5 Interactive Canvas -->
            <canvas id="nb-whiteboard-canvas"></canvas>
          </div>
        `:`
          <!-- Chat Messages View -->
          <div class="message-list" id="nb-messages">
            ${this.messages.length===0?`
              <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:100%;color:var(--text-muted);gap:8px;padding:30px 10px;text-align:center;">
                <div style="font-size:28px;">💬</div>
                <div style="font-size:13px;font-weight:600;color:var(--text-secondary);">No messages yet</div>
                <div style="font-size:11px;max-width:220px;">Say hello or ask for a hint! Messages are synchronized P2P across all peers.</div>
              </div>
            `:this.messages.map((n,h)=>{var g,f,y,m;return`
              <div class="chat-bubble ${n.isSelf?"self":"other"}">
                ${n.replyPreview?`<div style="border-left:2px solid var(--primary);padding-left:6px;margin-bottom:4px;font-size:10px;color:var(--text-muted);">${this.escapeHtml(n.replyPreview)}</div>`:""}
                
                <div class="chat-header">
                  <div class="chat-author">
                    <span>${((g=n.from)==null?void 0:g.avatar)||"👤"}</span>
                    <span style="color:${n.isSelf?"#ffffff":((f=n.from)==null?void 0:f.color)||"#a5b4fc"}">
                      ${n.isSelf?"You":((y=n.from)==null?void 0:y.nickname)||"Buddy"}
                    </span>
                  </div>
                  <div style="display:flex;align-items:center;gap:4px;">
                    <span class="chat-timestamp">${this.formatTimestamp(n.timestamp)}</span>
                    <button class="icon-btn nb-reply-trigger" data-id="${n.id}" data-text="${this.escapeHtml(n.text.slice(0,35))}" data-nick="${this.escapeHtml(((m=n.from)==null?void 0:m.nickname)||"Buddy")}" style="padding:0;width:18px;height:18px;" title="Reply">
                      ↩
                    </button>
                  </div>
                </div>

                <div class="chat-body">${this.renderFormattedText(n.text,h)}</div>

                ${n.isSelf?`
                  <div class="chat-footer">
                    ${n.status==="pending"?"<span>⏳</span>":""}
                    ${n.status==="sent"?'<span style="color:var(--text-dim);">✓</span>':""}
                    ${n.status==="delivered"?'<span style="color:var(--text-secondary);">✓✓</span>':""}
                    ${n.status==="read"?'<span class="ack-read">✓✓</span>':""}
                  </div>
                `:""}
              </div>
            `}).join("")}
          </div>

          <!-- Quick Strategy Prompt Pills -->
          <div class="prompt-pills-row">
            <button class="prompt-pill" data-text="⚡ O(N) Time">⚡ O(N) Time</button>
            <button class="prompt-pill" data-text="💾 O(1) Space">💾 O(1) Space</button>
            <button class="prompt-pill" data-text="👉 Two Pointers">👉 Two Pointers</button>
            <button class="prompt-pill" data-text="🔍 Binary Search">🔍 Binary Search</button>
            <button class="prompt-pill" data-text="🧠 DP / Memo">🧠 DP / Memo</button>
            <button class="prompt-pill" data-text="💡 Sliding Window">💡 Sliding Window</button>
          </div>

          <!-- Input Box & Composer -->
          <form class="composer-box" id="nb-composer">
            <button type="button" class="icon-btn" id="nb-spoiler-insert" title="Insert Spoiler Blur ||text||" style="width:28px;height:28px;flex-shrink:0;">
              👁️
            </button>
            <input type="text" class="input-glass" id="nb-input" placeholder="Type a hint, code snippet, or ||spoiler||..." />
            <button type="submit" class="btn-send">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <line x1="22" y1="2" x2="11" y2="13"></line>
                <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
              </svg>
            </button>
          </form>
        `}
      </div>

      <!-- Draggable Floating Action Button (FAB) -->
      <button class="fab-button" id="nb-fab-trigger" title="Drag anywhere or click to open">
        <span class="drag-grip">⠿</span>
        ${e?'<span class="live-dot"></span>':"<span>⚡</span>"}
        <span>${e?`LIVE (${i})`:"Synqto"}</span>
        ${this.unreadCount>0?`<span class="fab-badge">${this.unreadCount}</span>`:""}
      </button>
    `,this.attachEventListeners(),c&&this.initWhiteboardCanvas()}attachEventListeners(){if(!this.shadow)return;const e=this.shadow.getElementById("nb-fab-trigger");if(e){let p=0,a=0,n=24,h=24;const g=m=>{if(!this.isDragging)return;const k="touches"in m?m.touches[0].clientX:m.clientX,D="touches"in m?m.touches[0].clientY:m.clientY,T=k-p,C=D-a;if(Math.hypot(T,C)>4){this.dragMoved=!0;const z=n-T,O=h-C;this.currentPosition={right:Math.max(10,Math.min(window.innerWidth-130,z)),bottom:Math.max(10,Math.min(window.innerHeight-55,O))},this.applyHostPosition()}},f=()=>{var m;if(this.isDragging&&(this.isDragging=!1,window.removeEventListener("mousemove",g),window.removeEventListener("mouseup",f),window.removeEventListener("touchmove",g),window.removeEventListener("touchend",f),this.dragMoved)){if(this.settings.positionMode==="permanent"){const k={...this.settings,savedPosition:{...this.currentPosition}};this.settings=k,typeof chrome<"u"&&((m=chrome.storage)!=null&&m.local)&&chrome.storage.local.set({[w]:k})}setTimeout(()=>{this.dragMoved=!1},60)}},y=m=>{this.isDragging=!0,this.dragMoved=!1,p="touches"in m?m.touches[0].clientX:m.clientX,a="touches"in m?m.touches[0].clientY:m.clientY,n=this.currentPosition.right,h=this.currentPosition.bottom,window.addEventListener("mousemove",g,{passive:!0}),window.addEventListener("mouseup",f),window.addEventListener("touchmove",g,{passive:!0}),window.addEventListener("touchend",f)};e.addEventListener("mousedown",y),e.addEventListener("touchstart",y,{passive:!0}),e.addEventListener("click",()=>{var m;if(!this.dragMoved){if(this.settings.clickAction==="open_extension"){typeof chrome<"u"&&((m=chrome.runtime)!=null&&m.sendMessage)&&chrome.runtime.sendMessage({type:"OPEN_SIDEPANEL"}).catch(()=>{});return}this.isOpen=!this.isOpen,this.unreadCount=0,this.render(),this.isOpen&&this.activeTab==="chat"&&this.scrollToBottom()}})}const i=this.shadow.getElementById("nb-close-popup");i==null||i.addEventListener("click",()=>{this.isOpen=!1,this.render()});const s=this.shadow.getElementById("nb-open-sidepanel");s==null||s.addEventListener("click",()=>{var p;this.isOpen=!1,this.render(),typeof chrome<"u"&&((p=chrome.runtime)!=null&&p.sendMessage)&&chrome.runtime.sendMessage({type:"OPEN_SIDEPANEL"}).catch(()=>{})});const t=this.shadow.getElementById("nb-tab-chat");t==null||t.addEventListener("click",()=>{this.activeTab="chat",this.render(),this.scrollToBottom()});const l=this.shadow.getElementById("nb-tab-whiteboard");l==null||l.addEventListener("click",()=>{this.activeTab="whiteboard",this.render()});const c=this.shadow.getElementById("nb-live-tunein");c==null||c.addEventListener("click",()=>{var p;this.isOpen=!1,this.render(),typeof chrome<"u"&&((p=chrome.runtime)!=null&&p.sendMessage)&&chrome.runtime.sendMessage({type:"OPEN_SIDEPANEL"}).catch(()=>{})}),this.shadow.querySelectorAll(".prompt-pill").forEach(p=>{p.addEventListener("click",a=>{const n=a.target.getAttribute("data-text");n&&this.sendMessage(n)})});const r=this.shadow.getElementById("nb-spoiler-insert"),d=this.shadow.getElementById("nb-input");r==null||r.addEventListener("click",()=>{d&&(d.value=`${d.value}||hint solution||`,d.focus())});const b=this.shadow.getElementById("nb-composer");b==null||b.addEventListener("submit",p=>{p.preventDefault();const a=d==null?void 0:d.value.trim();a&&(this.sendMessage(a,this.replyingTo?{id:this.replyingTo.id,preview:`${this.replyingTo.from.nickname}: ${this.replyingTo.text.slice(0,30)}`}:void 0),d&&(d.value=""),this.replyingTo=null)})}initWhiteboardCanvas(){var r,d,b,p;if(!this.shadow)return;const e=this.shadow.getElementById("nb-whiteboard-canvas");if(!e)return;this.shadow.querySelectorAll(".wb-tool-btn[data-wbtool]").forEach(a=>{a.addEventListener("click",n=>{const h=n.currentTarget.getAttribute("data-wbtool");h&&(this.wbTool=h,this.render())})}),this.shadow.querySelectorAll(".size-pill[data-wbtheme]").forEach(a=>{a.addEventListener("click",n=>{const h=n.currentTarget.getAttribute("data-wbtheme");h&&(this.wbTheme=h,h==="clean_white"&&this.wbColor==="#ffffff"&&(this.wbColor="#0f172a"),this.render())})}),this.shadow.querySelectorAll(".color-dot").forEach(a=>{a.addEventListener("click",n=>{const h=n.currentTarget.getAttribute("data-color");h&&(this.wbColor=h,this.render())})}),this.shadow.querySelectorAll(".size-pill[data-size]").forEach(a=>{a.addEventListener("click",n=>{const h=Number(n.currentTarget.getAttribute("data-size"));h&&(this.wbWidth=h,this.render())})}),(r=this.shadow.getElementById("nb-wb-undo"))==null||r.addEventListener("click",()=>{var a;if(this.wbStrokes.length>0){const n=this.wbStrokes.pop();n&&(this.wbRedoStack.push(n),this.drawWbCanvas(),typeof chrome<"u"&&((a=chrome.runtime)!=null&&a.sendMessage)&&chrome.runtime.sendMessage({type:"WHITEBOARD_UNDO_LOCAL",strokeId:n.id}).catch(()=>{}))}}),(d=this.shadow.getElementById("nb-wb-redo"))==null||d.addEventListener("click",()=>{var a;if(this.wbRedoStack.length>0){const n=this.wbRedoStack.pop();n&&(this.wbStrokes.push(n),this.drawWbCanvas(),typeof chrome<"u"&&((a=chrome.runtime)!=null&&a.sendMessage)&&chrome.runtime.sendMessage({type:"WHITEBOARD_STROKE_LOCAL",stroke:n}).catch(()=>{}))}}),(b=this.shadow.getElementById("nb-wb-clear"))==null||b.addEventListener("click",()=>{var a;confirm("Clear collaborative whiteboard canvas?")&&(this.wbStrokes=[],this.wbRedoStack=[],this.drawWbCanvas(),typeof chrome<"u"&&((a=chrome.runtime)!=null&&a.sendMessage)&&chrome.runtime.sendMessage({type:"WHITEBOARD_CLEAR_LOCAL"}).catch(()=>{}))}),(p=this.shadow.getElementById("nb-wb-save"))==null||p.addEventListener("click",()=>{const a=e.toDataURL("image/png"),n=document.createElement("a");n.download=`synqto-whiteboard-${Date.now()}.png`,n.href=a,n.click()}),setTimeout(()=>{const a=e.getBoundingClientRect(),n=window.devicePixelRatio||1;e.width=(a.width||380)*n,e.height=(a.height||360)*n;const h=e.getContext("2d");h&&h.scale(n,n),this.drawWbCanvas()},30);const c=a=>{const n=e.getBoundingClientRect();let h=0,g=0;return"touches"in a&&a.touches.length>0?(h=a.touches[0].clientX,g=a.touches[0].clientY):"clientX"in a&&(h=a.clientX,g=a.clientY),{x:h-n.left,y:g-n.top}};e.addEventListener("mousedown",a=>{const n=c(a);this.isWbDrawing=!0,this.wbStartPoint=n,this.wbCurrentPoints=[n]}),e.addEventListener("mousemove",a=>{if(!this.isWbDrawing)return;const n=c(a);["line","arrow","rect","circle","tree_node"].includes(this.wbTool)&&this.wbStartPoint?this.drawWbCanvas(void 0,{x1:this.wbStartPoint.x,y1:this.wbStartPoint.y,x2:n.x,y2:n.y,label:this.wbTool==="tree_node"?"val":void 0}):(this.wbCurrentPoints.push(n),this.drawWbCanvas(this.wbCurrentPoints))});const o=a=>{var y;if(!this.isWbDrawing)return;this.isWbDrawing=!1;const n=c(a),h=["line","arrow","rect","circle","tree_node"].includes(this.wbTool),g=this.wbTool==="highlighter"?14:this.wbWidth,f={id:"stroke-"+Math.random().toString(36).slice(2,10),tool:this.wbTool,color:this.wbColor,width:g,opacity:this.wbTool==="highlighter"?.35:1,points:h?[]:[...this.wbCurrentPoints],geometry:h&&this.wbStartPoint?{x1:this.wbStartPoint.x,y1:this.wbStartPoint.y,x2:n.x,y2:n.y,label:this.wbTool==="tree_node"?String(Math.floor(Math.random()*50)+1):void 0}:void 0};this.wbStrokes.push(f),this.wbRedoStack=[],this.wbCurrentPoints=[],this.wbStartPoint=null,this.drawWbCanvas(),typeof chrome<"u"&&((y=chrome.runtime)!=null&&y.sendMessage)&&chrome.runtime.sendMessage({type:"WHITEBOARD_STROKE_LOCAL",stroke:f}).catch(()=>{})};e.addEventListener("mouseup",o),e.addEventListener("mouseleave",o)}drawWbCanvas(e,i){if(!this.shadow)return;const s=this.shadow.getElementById("nb-whiteboard-canvas");if(!s)return;const t=s.getContext("2d");if(!t)return;t.clearRect(0,0,s.width,s.height),t.save();const l=this.wbTheme==="white_blank";if(t.fillStyle=l?"#f8fafc":"#090d16",t.fillRect(0,0,s.width,s.height),this.wbTheme==="ruled"){t.strokeStyle="rgba(99, 102, 241, 0.18)",t.lineWidth=1;for(let o=28;o<s.height;o+=24)t.beginPath(),t.moveTo(0,o),t.lineTo(s.width,o),t.stroke();t.strokeStyle="rgba(244, 63, 94, 0.4)",t.lineWidth=1.5,t.beginPath(),t.moveTo(40,0),t.lineTo(40,s.height),t.stroke()}else if(this.wbTheme==="plot"){const o=Math.floor(s.width/2),r=Math.floor(s.height/2);t.strokeStyle="#6366f1",t.lineWidth=1.5,t.beginPath(),t.moveTo(0,r),t.lineTo(s.width,r),t.moveTo(o,0),t.lineTo(o,s.height),t.stroke()}else if(this.wbTheme==="dotted"){t.fillStyle="rgba(255, 255, 255, 0.16)";for(let o=8;o<s.width;o+=18)for(let r=8;r<s.height;r+=18)t.beginPath(),t.arc(o,r,1.2,0,Math.PI*2),t.fill()}else if(this.wbTheme==="matrix"){t.strokeStyle="rgba(99, 102, 241, 0.15)",t.lineWidth=1;const o=26;for(let r=0;r<s.width;r+=o)t.beginPath(),t.moveTo(r,0),t.lineTo(r,s.height),t.stroke();for(let r=0;r<s.height;r+=o)t.beginPath(),t.moveTo(0,r),t.lineTo(s.width,r),t.stroke()}else if(this.wbTheme==="grid"){t.strokeStyle="rgba(255, 255, 255, 0.04)",t.lineWidth=1;const o=20;for(let r=0;r<s.width;r+=o)t.beginPath(),t.moveTo(r,0),t.lineTo(r,s.height),t.stroke();for(let r=0;r<s.height;r+=o)t.beginPath(),t.moveTo(0,r),t.lineTo(s.width,r),t.stroke()}t.restore();const c=o=>{t.save();let r=o.color;if(this.wbTheme==="white_blank"&&(r==="#ffffff"||r==="#fff")&&(r="#0f172a"),t.strokeStyle=r,t.fillStyle=r,t.lineWidth=o.width,t.lineCap="round",t.lineJoin="round",t.globalAlpha=o.opacity,o.tool==="eraser"&&(t.globalCompositeOperation="destination-out",t.lineWidth=o.width*3),o.geometry){const{x1:d,y1:b,x2:p,y2:a}=o.geometry;if(o.tool==="line")t.beginPath(),t.moveTo(d,b),t.lineTo(p,a),t.stroke();else if(o.tool==="arrow"){t.beginPath(),t.moveTo(d,b),t.lineTo(p,a),t.stroke();const n=Math.atan2(a-b,p-d),h=Math.max(10,o.width*3);t.beginPath(),t.moveTo(p,a),t.lineTo(p-h*Math.cos(n-Math.PI/6),a-h*Math.sin(n-Math.PI/6)),t.moveTo(p,a),t.lineTo(p-h*Math.cos(n+Math.PI/6),a-h*Math.sin(n+Math.PI/6)),t.stroke()}else if(o.tool==="rect")t.strokeRect(Math.min(d,p),Math.min(b,a),Math.abs(p-d),Math.abs(a-b));else if(o.tool==="circle"){const n=Math.abs(p-d)/2,h=Math.abs(a-b)/2;t.beginPath(),t.ellipse(Math.min(d,p)+n,Math.min(b,a)+h,n,h,0,0,Math.PI*2),t.stroke()}else if(o.tool==="tree_node"){const n=Math.max(16,o.width*3.5);t.beginPath(),t.arc(d,b,n,0,Math.PI*2),t.fillStyle="rgba(15, 23, 42, 0.9)",t.fill(),t.stroke(),t.fillStyle="#ffffff",t.font="bold 11px monospace",t.textAlign="center",t.textBaseline="middle",t.fillText(o.geometry.label||"N",d,b)}}else if(o.points&&o.points.length>1){t.beginPath(),t.moveTo(o.points[0].x,o.points[0].y);for(let d=1;d<o.points.length;d++)t.lineTo(o.points[d].x,o.points[d].y);t.stroke()}t.restore()};this.wbStrokes.forEach(c),i?c({tool:this.wbTool,color:this.wbColor,width:this.wbTool==="highlighter"?14:this.wbWidth,opacity:this.wbTool==="highlighter"?.35:1,points:[],geometry:i}):e&&e.length>1&&c({tool:this.wbTool,color:this.wbColor,width:this.wbTool==="highlighter"?14:this.wbWidth,opacity:this.wbTool==="highlighter"?.35:1,points:e})}listenForRuntimeMessages(){var e;typeof chrome<"u"&&((e=chrome.runtime)!=null&&e.onMessage)&&chrome.runtime.onMessage.addListener(i=>{i.type==="WHITEBOARD_STROKE_LOCAL"&&i.stroke?this.wbStrokes.some(s=>s.id===i.stroke.id)||(this.wbStrokes.push(i.stroke),this.activeTab==="whiteboard"&&this.drawWbCanvas()):i.type==="WHITEBOARD_CLEAR_LOCAL"?(this.wbStrokes=[],this.wbRedoStack=[],this.activeTab==="whiteboard"&&this.drawWbCanvas()):i.type==="WHITEBOARD_UNDO_LOCAL"&&i.strokeId&&(this.wbStrokes=this.wbStrokes.filter(s=>s.id!==i.strokeId),this.activeTab==="whiteboard"&&this.drawWbCanvas())})}escapeHtml(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}formatTimestamp(e){return new Date(e).toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"})}renderFormattedText(e,i){return e.split(`
`).map((t,l)=>{if(t.startsWith("```")&&t.endsWith("```")&&t.length>6){const c=t.slice(3,-3);return`
          <div style="background:rgba(0,0,0,0.45);padding:6px 8px;border-radius:6px;margin:4px 0;font-family:var(--font-mono);font-size:11px;position:relative;">
            <pre style="margin:0;white-space:pre-wrap;word-break:break-all;">${this.escapeHtml(c)}</pre>
          </div>
        `}return t.includes("||")?`<p style="margin:2px 0;">${t.split(/(\|\|.*?\|\|)/g).map((r,d)=>{if(r.startsWith("||")&&r.endsWith("||")&&r.length>4){const b=r.slice(2,-2),p=`${i}-${l}-${d}`,a=!!this.revealedSpoilers[p];return`
              <span style="display:inline-block;padding:1px 6px;border-radius:4px;background:${a?"rgba(99, 102, 241, 0.25)":"rgba(255, 255, 255, 0.15)"};filter:${a?"none":"blur(4px)"};cursor:pointer;">
                ${this.escapeHtml(b)}
              </span>
            `}return this.escapeHtml(r)}).join("")}</p>`:`<p style="margin:2px 0;">${this.escapeHtml(t)}</p>`}).join("")}deduplicateMessages(e){var t,l;const i=new Set,s=[];for(const c of e)!c||!c.id||i.has(c.id)||(i.add(c.id),s.push({...c,isSelf:((t=c.from)==null?void 0:t.peerId)===((l=this.myIdentity)==null?void 0:l.peerId)||c.isSelf}));return s}async sendMessage(e,i){var c,o,r,d;if(!e.trim())return;!this.currentRoomStorageKey&&((c=this.currentProblem)!=null&&c.roomId)&&(this.currentRoomStorageKey=`synqto_chat_${this.currentProblem.roomId}`);const s=e.trim(),t="msg-"+Math.random().toString(36).slice(2,10)+Date.now(),l={id:t,from:this.myIdentity||{nickname:"You",avatar:"⚡",color:"#6366f1",peerId:"self"},text:s,timestamp:Date.now(),replyTo:i==null?void 0:i.id,replyPreview:i==null?void 0:i.preview,status:"sent",isSelf:!0};if(this.messages.push(l),this.messages=this.deduplicateMessages(this.messages),this.render(),this.scrollToBottom(),this.currentRoomStorageKey&&typeof chrome<"u"&&((o=chrome.storage)!=null&&o.local))try{const b=await chrome.storage.local.get([this.currentRoomStorageKey]),p=b[this.currentRoomStorageKey]&&Array.isArray(b[this.currentRoomStorageKey])?b[this.currentRoomStorageKey]:[],a=this.deduplicateMessages([...p,l]).slice(-150);await chrome.storage.local.set({[this.currentRoomStorageKey]:a})}catch{}typeof chrome<"u"&&((r=chrome.runtime)!=null&&r.sendMessage)&&chrome.runtime.sendMessage({type:"SEND_PAGE_CHAT_MESSAGE",messageId:t,text:l.text,replyTo:l.replyTo,replyPreview:l.replyPreview,roomId:(d=this.currentProblem)==null?void 0:d.roomId}).catch(()=>{})}async loadMessages(){var e;if(this.currentRoomStorageKey&&typeof chrome<"u"&&(e=chrome.storage)!=null&&e.local){const i=await chrome.storage.local.get([this.currentRoomStorageKey]);i[this.currentRoomStorageKey]&&Array.isArray(i[this.currentRoomStorageKey])&&(this.messages=this.deduplicateMessages(i[this.currentRoomStorageKey]),this.isOpen&&this.activeTab==="chat"&&(this.render(),this.scrollToBottom()))}}scrollToBottom(){setTimeout(()=>{var i;const e=(i=this.shadow)==null?void 0:i.getElementById("nb-messages");e&&(e.scrollTop=e.scrollHeight)},40)}listenToStorageChanges(){var e;typeof chrome<"u"&&((e=chrome.storage)!=null&&e.onChanged)&&chrome.storage.onChanged.addListener((i,s)=>{var t,l,c;if(s==="local"&&(i.nerd_buddy_sidepanel_open&&i.nerd_buddy_sidepanel_open.newValue===!0&&this.isOpen&&(this.isOpen=!1,this.render()),(i.synqto_live_stage||i.nerd_buddy_live_stage)&&(this.liveStage=(i.synqto_live_stage||i.nerd_buddy_live_stage).newValue,this.render()),(i.synqto_identity||i.nerd_buddy_identity)&&(this.myIdentity=(i.synqto_identity||i.nerd_buddy_identity).newValue),i[w]&&(this.settings=i[w].newValue,this.settings.positionMode==="permanent"&&this.settings.savedPosition&&(this.currentPosition={...this.settings.savedPosition}),this.checkVisibilityAndRender()),(i.synqto_active_problem||i.nerd_buddy_active_problem)&&(this.currentProblem=(i.synqto_active_problem||i.nerd_buddy_active_problem).newValue,this.currentRoomStorageKey=`synqto_chat_${((t=this.currentProblem)==null?void 0:t.roomId)||""}`,this.loadMessages(),this.checkVisibilityAndRender()),i.nerd_buddy_peer_count&&(this.peerCount=Math.max(1,i.nerd_buddy_peer_count.newValue||1),this.render()),this.currentRoomStorageKey&&i[this.currentRoomStorageKey])){const o=i[this.currentRoomStorageKey].newValue||[];this.messages=this.deduplicateMessages(o),!this.isOpen&&((l=i[this.currentRoomStorageKey].newValue)==null?void 0:l.length)>(((c=i[this.currentRoomStorageKey].oldValue)==null?void 0:c.length)||0)&&this.unreadCount++,this.render(),this.isOpen&&this.activeTab==="chat"&&this.scrollToBottom()}})}}console.log("[Nerd Buddy] Content script initialized on:",window.location.href),new I(u=>{var e;try{typeof chrome<"u"&&((e=chrome.runtime)!=null&&e.sendMessage)&&chrome.runtime.sendMessage({type:"PROBLEM_DETECTED",payload:u})}catch{}}),new L,new W})();
