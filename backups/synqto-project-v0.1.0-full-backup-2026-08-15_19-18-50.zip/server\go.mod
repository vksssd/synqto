module github.com/nerdbuddy/server

go 1.22

require github.com/gorilla/websocket v1.5.3
