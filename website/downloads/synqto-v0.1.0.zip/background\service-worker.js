const a = "nerd_buddy_keepalive";
let n = null;
chrome.alarms.create(a, { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener((e) => {
  e.name === a && i();
});
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: !0 }).catch((e) => console.error(e));
chrome.tabs.onActivated.addListener(async (e) => {
  try {
    const t = await chrome.tabs.get(e.tabId);
    t.url && chrome.storage.local.set({ nerd_buddy_active_url: t.url });
  } catch {
  }
});
chrome.tabs.onUpdated.addListener((e, t, r) => {
  r.active && t.url && chrome.storage.local.set({ nerd_buddy_active_url: t.url });
});
chrome.runtime.onMessage.addListener((e, t, r) => {
  var c, o;
  return e.type === "PROBLEM_DETECTED" ? (c = t.tab) != null && c.active && chrome.storage.local.set({
    nerd_buddy_active_problem: e.payload,
    nerd_buddy_active_url: e.payload.url
  }) : e.type === "LOCAL_CURSOR_MOVE" || e.type === "LOCAL_CLICK_PULSE" || e.type === "WHITEBOARD_STROKE_LOCAL" || e.type === "WHITEBOARD_CLEAR_LOCAL" || e.type === "WHITEBOARD_UNDO_LOCAL" ? chrome.runtime.sendMessage(e).catch(() => {
  }) : e.type === "OPEN_SIDEPANEL" ? (o = t.tab) != null && o.windowId && chrome.sidePanel.open({ windowId: t.tab.windowId }).catch(() => {
  }) : e.type === "SEND_PAGE_CHAT_MESSAGE" && chrome.runtime.sendMessage(e).catch(() => {
  }), !0;
});
async function i() {
  const e = "offscreen.html";
  if (!((await chrome.runtime.getContexts({
    contextTypes: ["OFFSCREEN_DOCUMENT"],
    documentUrls: [chrome.runtime.getURL(e)]
  })).length > 0)) {
    if (n) {
      await n;
      return;
    }
    n = chrome.offscreen.createDocument({
      url: e,
      reasons: ["WEB_RTC"],
      justification: "Maintain P2P presence and notifications when sidepanel is closed"
    }), await n, n = null;
  }
}
i();
