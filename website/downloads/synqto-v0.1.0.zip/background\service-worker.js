const m = "nerd_buddy_keepalive";
let i = null;
chrome.alarms.create(m, { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener((e) => {
  e.name === m && p();
});
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: !0 }).catch((e) => console.error(e));
chrome.tabs.onActivated.addListener(async (e) => {
  try {
    const t = await chrome.tabs.get(e.tabId);
    t.url && chrome.storage.local.set({ nerd_buddy_active_url: t.url });
  } catch {
  }
});
chrome.tabs.onUpdated.addListener((e, t, r) => {
  r.active && t.url && chrome.storage.local.set({ nerd_buddy_active_url: t.url });
});
chrome.runtime.onMessage.addListener((e, t, r) => {
  var n, s, c, l, d;
  if (e.type === "PROBLEM_DETECTED")
    (n = t.tab) != null && n.active && chrome.storage.local.set({
      nerd_buddy_active_problem: e.payload,
      nerd_buddy_active_url: e.payload.url
    });
  else if (e.type === "LOCAL_CURSOR_MOVE" || e.type === "LOCAL_CLICK_PULSE" || e.type === "WHITEBOARD_STROKE_LOCAL" || e.type === "WHITEBOARD_CLEAR_LOCAL" || e.type === "WHITEBOARD_UNDO_LOCAL")
    chrome.runtime.sendMessage(e).catch(() => {
    });
  else if (e.type === "OPEN_SIDEPANEL") {
    const o = (s = t.tab) == null ? void 0 : s.id, a = (c = t.tab) == null ? void 0 : c.windowId;
    return o && ((l = chrome.sidePanel) != null && l.open) ? chrome.sidePanel.open({ tabId: o }).catch(() => {
      a && chrome.sidePanel.open({ windowId: a }).catch(() => {
      });
    }) : a && ((d = chrome.sidePanel) != null && d.open) && chrome.sidePanel.open({ windowId: a }).catch(() => {
    }), chrome.storage.local.set({ nerd_buddy_sidepanel_open: !0 }), r({ success: !0 }), !0;
  } else if (e.type === "SEND_PAGE_CHAT_MESSAGE")
    chrome.runtime.sendMessage(e).catch(() => {
    });
  else if (e.type === "CAPTURE_ACTIVE_TAB")
    return chrome.windows.getLastFocused({ populate: !1 }, (o) => {
      const a = o == null ? void 0 : o.id;
      ((u) => {
        const _ = (f) => {
          var h;
          chrome.runtime.lastError || !f ? (console.warn("[ServiceWorker] captureVisibleTab failed:", chrome.runtime.lastError), r({ success: !1, error: ((h = chrome.runtime.lastError) == null ? void 0 : h.message) || "Capture failed" })) : r({ success: !0, dataUrl: f });
        };
        u !== void 0 ? chrome.tabs.captureVisibleTab(u, { format: "png" }, _) : chrome.tabs.captureVisibleTab({ format: "png" }, _);
      })(a);
    }), !0;
  return !0;
});
chrome.storage.onChanged.addListener((e, t) => {
  var r;
  if (t === "local" && (e.synqto_fab_settings || e.nerd_buddy_fab_settings)) {
    const n = (r = e.synqto_fab_settings || e.nerd_buddy_fab_settings) == null ? void 0 : r.newValue;
    n && chrome.tabs.query({}, (s) => {
      s.forEach((c) => {
        c.id && chrome.tabs.sendMessage(c.id, {
          type: "FAB_SETTINGS_UPDATED",
          payload: n
        }).catch(() => {
        });
      });
    });
  }
});
async function p() {
  const e = "offscreen.html";
  if (!((await chrome.runtime.getContexts({
    contextTypes: ["OFFSCREEN_DOCUMENT"],
    documentUrls: [chrome.runtime.getURL(e)]
  })).length > 0)) {
    if (i) {
      await i;
      return;
    }
    i = chrome.offscreen.createDocument({
      url: e,
      reasons: ["WEB_RTC"],
      justification: "Maintain P2P presence and notifications when sidepanel is closed"
    }), await i, i = null;
  }
}
p();
