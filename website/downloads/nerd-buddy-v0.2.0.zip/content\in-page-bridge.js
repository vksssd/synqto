(function(){"use strict";(()=>{if(typeof window>"u"||window.__SYNQTO_BRIDGE_ACTIVE__)return;window.__SYNQTO_BRIDGE_ACTIVE__=!0,document.documentElement&&document.documentElement.setAttribute("data-synqto-bridge","active");let u=null,l=null,i=null,s=null,c=!1,f={},y=null,g=null;if(!document.getElementById("synqto-editor-sync-styles")){const t=document.createElement("style");t.id="synqto-editor-sync-styles",t.textContent=`
      .synqto-remote-cursor-line {
        position: relative !important;
        border-left-width: 2.5px !important;
        border-left-style: solid !important;
        box-shadow: 0 0 8px currentColor !important;
        animation: synqtoCursorBlink 1.1s ease-in-out infinite !important;
      }
      .synqto-remote-badge {
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, monospace !important;
        font-size: 10px !important;
        font-weight: 700 !important;
        padding: 1px 6px !important;
        border-radius: 4px !important;
        color: #ffffff !important;
        display: inline-block !important;
        margin-left: 6px !important;
        vertical-align: middle !important;
        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.4) !important;
        pointer-events: none !important;
        user-select: none !important;
        z-index: 10 !important;
      }
      @keyframes synqtoCursorBlink {
        0%, 100% { opacity: 1; }
        50% { opacity: 0.35; }
      }
    `,(document.head||document.documentElement).appendChild(t)}const O=()=>{var e,o,m,E;const t=window.monaco;if(!t||!t.editor)return!1;const n=((o=(e=t.editor).getEditors)==null?void 0:o.call(e))||[],a=((E=(m=t.editor).getModels)==null?void 0:E.call(m))||[];return n.length>0?(l=n[0],i=l.getModel()||(a.length>0?a[0]:null)):a.length>0&&(i=a[0]),i?(u="monaco",i.onDidChangeContent(()=>{c||(clearTimeout(y),y=setTimeout(()=>{var d;const p=i.getValue(),r=l?l.getPosition():{lineNumber:1,column:1},C=((d=i.getLanguageId)==null?void 0:d.call(i))||"python";window.postMessage({source:"SYNQTO_EDITOR_BRIDGE",type:"LOCAL_CODE_CHANGED",payload:{code:p,line:(r==null?void 0:r.lineNumber)||1,col:(r==null?void 0:r.column)||1,language:C}},"*")},40))}),l&&l.onDidChangeCursorPosition(p=>{c||(clearTimeout(g),g=setTimeout(()=>{const r=p.position;window.postMessage({source:"SYNQTO_EDITOR_BRIDGE",type:"LOCAL_CURSOR_MOVED",payload:{line:r.lineNumber,ch:r.column}},"*")},80))}),console.log("[Synqto] Hooked into LeetCode Monaco Editor successfully in main world!"),!0):!1},I=()=>{const t=document.querySelector(".CodeMirror");return t&&t.CodeMirror?(s=t.CodeMirror,u="codemirror",s.on("change",(n,a)=>{c||a.origin==="setValue"||(clearTimeout(y),y=setTimeout(()=>{const e=s.getValue(),o=s.getCursor();window.postMessage({source:"SYNQTO_EDITOR_BRIDGE",type:"LOCAL_CODE_CHANGED",payload:{code:e,line:((o==null?void 0:o.line)||0)+1,col:((o==null?void 0:o.ch)||0)+1,language:"python"}},"*")},40))}),s.on("cursorActivity",()=>{c||(clearTimeout(g),g=setTimeout(()=>{const n=s.getCursor();window.postMessage({source:"SYNQTO_EDITOR_BRIDGE",type:"LOCAL_CURSOR_MOVED",payload:{line:((n==null?void 0:n.line)||0)+1,col:((n==null?void 0:n.ch)||0)+1}},"*")},80))}),console.log("[Synqto] Hooked into CodeMirror Editor successfully in main world!"),!0):!1},_=setInterval(()=>{(O()||I())&&clearInterval(_)},600);setTimeout(()=>clearInterval(_),3e4),window.addEventListener("message",t=>{if(!t.data||t.data.source!=="SYNQTO_CONTENT_SCRIPT")return;const{type:n,payload:a}=t.data;if(n==="APPLY_REMOTE_CODE"){const{code:e}=a;if(u==="monaco"&&i){if(i.getValue()!==e){c=!0;try{i.setValue(e)}finally{c=!1}}}else if(u==="codemirror"&&s&&s.getValue()!==e){c=!0;try{s.setValue(e)}finally{c=!1}}}else if(n==="APPLY_REMOTE_CURSOR"){const{peerId:e,nickname:o,color:m,line:E,ch:p}=a;if(u==="monaco"&&l){const r=window.monaco;if(!r)return;const C=`synqto-peer-style-${e}`;let d=document.getElementById(C);d||(d=document.createElement("style"),d.id=C,document.head.appendChild(d)),d.textContent=`
          .synqto-cursor-${e} {
            border-left: 2.5px solid ${m||"#3b82f6"} !important;
            box-shadow: 0 0 6px ${m||"#3b82f6"} !important;
          }
          .synqto-badge-${e} {
            background: ${m||"#3b82f6"} !important;
          }
        `;const T=Math.max(1,E||1),w=Math.max(1,p||1),b={range:new r.Range(T,w,T,w),options:{className:`synqto-remote-cursor-line synqto-cursor-${e}`,after:{content:` ✍️ ${o||"Peer"}`,inlineClassName:`synqto-remote-badge synqto-badge-${e}`}}},h=f[e]||[];f[e]=l.deltaDecorations(h,[b])}}else if(n==="REMOVE_PEER_CURSOR"){const{peerId:e}=a;if(u==="monaco"&&l){const o=f[e]||[];o.length>0&&(l.deltaDecorations(o,[]),delete f[e])}}}),console.log("[Synqto] In-page editor bridge initialized in MAIN world.")})()})();
