(function(){"use strict";function Y(v){let t=2166136261,i=2166136261;for(let e=0;e<v.length;e++){const a=v.charCodeAt(e);t=Math.imul(t^a&255,16777619),i=Math.imul(i^a>>8,16777619)}return((t>>>0^i>>>0)>>>0).toString(16).padStart(8,"0")}function j(v,t){let i=null;return(...o)=>{i&&clearTimeout(i),i=setTimeout(()=>v(...o),t)}}function F(v,t){var i;try{const o=new URL(v),e=o.hostname.toLowerCase(),a=o.pathname;if(e.includes("leetcode.com")||e.includes("leetcode.cn")){const s=a.match(/\/problems\/([a-zA-Z0-9-_]+)/);if(s&&s[1]){const n=s[1],r=A(n),p=e.includes("leetcode.cn")?"leetcode.cn":"leetcode.com";return{platform:"LeetCode",slug:n,title:r,url:v,canonicalUrl:`https://${p}/problems/${n}/`}}}if(e.includes("neetcode.io")){const s=a.match(/\/problems\/([a-zA-Z0-9-_]+)/);if(s&&s[1]){const n=s[1],r=A(n);return{platform:"NeetCode",slug:n,title:r,url:v,canonicalUrl:`https://neetcode.io/problems/${n}`}}}if(e.includes("codeforces.com")||e.includes("codeforces.net")){const s=a.match(/\/(?:contest\/(\d+)\/problem|problemset\/problem\/(\d+)|gym\/(\d+)\/problem)\/([a-zA-Z0-9]+)/i);if(s){const n=s[1]||s[2]||s[3],r=s[4].toUpperCase();return{platform:"Codeforces",slug:`cf-${n}-${r}`,title:`Codeforces ${n}${r}`,url:v,canonicalUrl:`https://codeforces.com/problemset/problem/${n}/${r}`}}}if(e.includes("atcoder.jp")){const s=a.match(/\/contests\/([a-zA-Z0-9-_]+)\/tasks\/([a-zA-Z0-9-_]+)/);if(s){const n=s[1],r=s[2];return{platform:"AtCoder",slug:`atcoder-${r}`,title:A(r),url:v,canonicalUrl:`https://atcoder.jp/contests/${n}/tasks/${r}`}}}if(e.includes("hackerrank.com")){const s=a.match(/\/challenges\/([a-zA-Z0-9-_]+)/);if(s&&s[1]){const n=s[1];return{platform:"HackerRank",slug:n,title:A(n),url:v,canonicalUrl:`https://www.hackerrank.com/challenges/${n}/problem`}}}if(e.includes("codechef.com")){const s=a.match(/\/problems\/([a-zA-Z0-9-_]+)/);if(s&&s[1]){const n=s[1];return{platform:"CodeChef",slug:n,title:`CodeChef ${n}`,url:v,canonicalUrl:`https://www.codechef.com/problems/${n}`}}}if(e.includes("geeksforgeeks.org")){const s=a.match(/\/problems\/([a-zA-Z0-9-_]+)/);if(s&&s[1]){const n=s[1],r=n.replace(/-\d{6,}$/,"");return{platform:"GeeksforGeeks",slug:n,title:A(r),url:v,canonicalUrl:`https://www.geeksforgeeks.org/problems/${n}/1`}}}if(e.includes("youtube.com")||e.includes("youtu.be")){let s=o.searchParams.get("v");if(!s&&e.includes("youtu.be")&&(s=a.slice(1)),!s&&a.includes("/shorts/")&&(s=(i=a.split("/shorts/")[1])==null?void 0:i.split("/")[0]),s){const n=t?V(t):`YouTube Video (${s})`;return{platform:"YouTube",slug:`yt-${s}`,title:n,url:v,canonicalUrl:`https://www.youtube.com/watch?v=${s}`}}}if(e.includes("arxiv.org")){const s=a.match(/\/(?:abs|pdf)\/(\d+\.\d+(?:v\d+)?)/);if(s&&s[1]){const n=s[1];return{platform:"ArXiv",slug:`arxiv-${n.replace(/\./g,"-")}`,title:t?G(t):`ArXiv ${n}`,url:v,canonicalUrl:`https://arxiv.org/abs/${n}`}}}if(e.includes("github.com")){const s=a.match(/^\/([^\/]+)\/([^\/]+)\/(?:issues|pull)\/(\d+)/);if(s){const n=s[1],r=s[2],p=s[3];return{platform:"GitHub",slug:`gh-${n}-${r}-${p}`,title:`${n}/${r} #${p}`,url:v,canonicalUrl:`https://github.com/${n}/${r}/issues/${p}`}}}return{platform:"Web",slug:e.replace(/\./g,"-")||"general-study",title:t||e||"General Study Room",url:v,canonicalUrl:v}}catch{return null}}function A(v){return v.split(/[-_]/).map(t=>t.charAt(0).toUpperCase()+t.slice(1)).join(" ")}function V(v){return v.replace(/\s*-\s*YouTube\s*$/,"").trim()}function G(v){return v.replace(/^\[[^\]]+\]\s*/,"").replace(/\s*-\s*arXiv.*$/,"").trim()}function H(){try{return!!(typeof chrome<"u"&&chrome.runtime&&chrome.runtime.id)}catch{return!1}}class K{constructor(t){this.lastUrl="",this.lastTitle="",this.mutationObserver=null,this.pollTimer=null,this.debouncedCheck=j(()=>{if(!H()){this.destroy();return}this.checkCurrentPage()},250),this.callback=t,this.init()}init(){if(this.checkCurrentPage(),typeof window<"u"&&window.history){const t=window.history.pushState,i=window.history.replaceState;typeof t=="function"&&(window.history.pushState=(...o)=>{t.apply(window.history,o),this.debouncedCheck()}),typeof i=="function"&&(window.history.replaceState=(...o)=>{i.apply(window.history,o),this.debouncedCheck()})}if(typeof window<"u"&&(window.addEventListener("popstate",()=>this.debouncedCheck()),window.addEventListener("hashchange",()=>this.debouncedCheck()),window.addEventListener("yt-navigate-finish",()=>this.debouncedCheck())),typeof MutationObserver<"u"&&typeof document<"u"){this.mutationObserver=new MutationObserver(()=>{document.title!==this.lastTitle&&this.debouncedCheck()});const t=document.querySelector("title");t&&this.mutationObserver.observe(t,{subtree:!0,characterData:!0,childList:!0})}this.pollTimer=setInterval(()=>{if(!H()){this.destroy();return}window.location.href!==this.lastUrl&&this.checkCurrentPage()},350)}checkCurrentPage(){const t=window.location.href,i=document.title;if(t===this.lastUrl&&i===this.lastTitle)return;this.lastUrl=t,this.lastTitle=i;const o=F(t,i);o&&this.callback(o)}destroy(){this.mutationObserver&&(this.mutationObserver.disconnect(),this.mutationObserver=null),this.pollTimer&&(clearInterval(this.pollTimer),this.pollTimer=null)}}function W(){try{return!!(typeof chrome<"u"&&chrome.runtime&&chrome.runtime.id)}catch{return!1}}class X{constructor(){this.container=null,this.cursorElements=new Map,this.cursorTimeouts=new Map,this.myIdentity=null,this.liveStage=null,this.createContainer(),this.loadState(),this.listenToStorage(),this.listenForMessages(),this.setupLocalTrackers()}async loadState(){var t;if(typeof chrome<"u"&&((t=chrome.storage)!=null&&t.local))try{const i=await chrome.storage.local.get(["nerd_buddy_identity","synqme_identity","nerd_buddy_live_stage","synqme_live_stage"]);this.myIdentity=i.synqme_identity||i.nerd_buddy_identity||null,this.liveStage=i.synqme_live_stage||i.nerd_buddy_live_stage||null,(!this.liveStage||!this.liveStage.isActive)&&this.clearAllCursors()}catch{}}listenToStorage(){var t;typeof chrome<"u"&&((t=chrome.storage)!=null&&t.onChanged)&&chrome.storage.onChanged.addListener((i,o)=>{o==="local"&&((i.synqme_identity||i.nerd_buddy_identity)&&(this.myIdentity=(i.synqme_identity||i.nerd_buddy_identity).newValue),(i.synqme_live_stage||i.nerd_buddy_live_stage)&&(this.liveStage=(i.synqme_live_stage||i.nerd_buddy_live_stage).newValue,(!this.liveStage||!this.liveStage.isActive)&&this.clearAllCursors()))})}clearAllCursors(){this.cursorTimeouts.forEach(t=>clearTimeout(t)),this.cursorTimeouts.clear(),this.cursorElements.forEach(t=>{t.remove()}),this.cursorElements.clear(),this.container&&(this.container.innerHTML="")}isLocalUserOnStage(){var i,o;if(!this.liveStage||!this.liveStage.isActive)return!1;const t=(i=this.myIdentity)==null?void 0:i.peerId;return t?!!(((o=this.liveStage.tutorIdentity)==null?void 0:o.peerId)===t||this.liveStage.tutorPeerId===t||this.liveStage.myRole==="tutor"||Array.isArray(this.liveStage.guestSpeakers)&&this.liveStage.guestSpeakers.some(e=>e.peerId===t)):!1}createContainer(){var i;if(document.getElementById("nerd-buddy-cursor-overlay"))return;if(!document.body){document.readyState==="loading"?document.addEventListener("DOMContentLoaded",()=>this.createContainer(),{once:!0}):window.addEventListener("load",()=>this.createContainer(),{once:!0});return}const t=document.createElement("div");if(t.id="nerd-buddy-cursor-overlay",t.style.cssText=`
      position: fixed !important;
      top: 0 !important;
      left: 0 !important;
      width: 100vw !important;
      height: 100vh !important;
      pointer-events: none !important;
      z-index: 2147483645 !important;
      overflow: hidden !important;
      box-sizing: border-box !important;
    `,document.body.appendChild(t),this.container=t,!document.getElementById("nerd-buddy-cursor-styles")){const o=document.createElement("style");o.id="nerd-buddy-cursor-styles",o.textContent=`
        @keyframes nb-click-ripple {
          0% { transform: scale(0.15); opacity: 1; }
          40% { opacity: 0.9; }
          100% { transform: scale(2.8); opacity: 0; }
        }
      `,(i=document.head||document.documentElement||document.body)==null||i.appendChild(o)}}listenForMessages(){var t;if(!(!W()||!((t=chrome.runtime)!=null&&t.onMessage)))try{chrome.runtime.onMessage.addListener(i=>{var o,e,a,l;if(W()){if(i.type==="NERD_BUDDY_STAGE_ENDED"||i.type==="NERD_BUDDY_STAGE_INACTIVE"){this.clearAllCursors();return}if(i.type==="NERD_BUDDY_CURSOR_UPDATE"&&i.cursor){const s=i.cursor;(s.isTutor||this.liveStage&&(((o=this.liveStage.tutorIdentity)==null?void 0:o.peerId)===s.peerId||this.liveStage.tutorPeerId===s.peerId||((e=this.liveStage.guestSpeakers)==null?void 0:e.some(r=>r.peerId===s.peerId)))||!this.liveStage)&&this.renderCursor(s)}else if(i.type==="NERD_BUDDY_CLICK_PULSE"&&i.click){const s=i.click;(s.isTutor||this.liveStage&&(((a=this.liveStage.tutorIdentity)==null?void 0:a.peerId)===s.peerId||this.liveStage.tutorPeerId===s.peerId||((l=this.liveStage.guestSpeakers)==null?void 0:l.some(r=>r.peerId===s.peerId)))||s.isTutor||!this.liveStage)&&this.renderClickPulse(s)}}})}catch{}}renderCursor(t){if(this.container||this.createContainer(),!this.container)return;let i=this.cursorElements.get(t.peerId);i||(i=document.createElement("div"),i.style.cssText=`
        position: fixed !important;
        pointer-events: none !important;
        transition: left 0.05s linear, top 0.05s linear, opacity 0.3s ease !important;
        display: flex !important;
        align-items: center !important;
        gap: 5px !important;
        opacity: 1 !important;
        z-index: 2147483646 !important;
      `,this.container.appendChild(i),this.cursorElements.set(t.peerId,i));const o=Math.max(0,Math.min(window.innerWidth-30,t.xPct/100*window.innerWidth)),e=Math.max(0,Math.min(window.innerHeight-30,t.yPct/100*window.innerHeight));i.style.left=`${o}px`,i.style.top=`${e}px`,i.style.opacity="1";const a=t.isTutor?"#8b5cf6":t.color||"#6366f1";i.innerHTML=`
      <div style="
        width: 18px;
        height: 18px;
        border-radius: 50%;
        background: ${a};
        box-shadow: 0 0 16px ${a}, 0 0 6px #ffffff;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 11px;
        color: #fff;
        border: 2px solid #ffffff;
      ">
        ${t.avatar||"👑"}
      </div>
      <div style="
        background: rgba(15, 23, 42, 0.92);
        border: 1px solid ${a};
        color: #f8fafc;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        font-size: 10px;
        font-weight: 600;
        padding: 2px 6px;
        border-radius: 4px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.6);
        white-space: nowrap;
      ">
        ${t.nickname} ${t.isTutor?"🎓 (Tutor)":"🎤 (Speaker)"}
      </div>
    `;const l=this.cursorTimeouts.get(t.peerId);l&&clearTimeout(l);const s=window.setTimeout(()=>{i&&(i.style.opacity="0")},4e3);this.cursorTimeouts.set(t.peerId,s)}renderClickPulse(t){if(this.container||this.createContainer(),!this.container)return;const i=t.xPct/100*window.innerWidth,o=t.yPct/100*window.innerHeight,e=document.createElement("div"),a=t.color||(t.isTutor?"#8b5cf6":"#6366f1");e.style.cssText=`
      position: fixed !important;
      left: ${i-22}px !important;
      top: ${o-22}px !important;
      width: 44px !important;
      height: 44px !important;
      border-radius: 50% !important;
      border: 3px solid ${a} !important;
      box-shadow: 0 0 16px ${a}, inset 0 0 8px ${a} !important;
      pointer-events: none !important;
      z-index: 2147483647 !important;
      box-sizing: border-box !important;
      animation: nb-click-ripple 0.85s cubic-bezier(0.1, 0.8, 0.3, 1) forwards !important;
    `,this.container.appendChild(e),setTimeout(()=>{e.remove()},900)}setupLocalTrackers(){let t=0;window.addEventListener("mousemove",i=>{if(!W()||!this.isLocalUserOnStage())return;const o=Date.now();if(o-t<40)return;t=o;const e=i.clientX/window.innerWidth*100,a=i.clientY/window.innerHeight*100;try{chrome.runtime.sendMessage({type:"LOCAL_CURSOR_MOVE",xPct:e,yPct:a}).catch(()=>{})}catch{}}),window.addEventListener("click",i=>{var a,l,s;if(!W()||!this.isLocalUserOnStage())return;const o=i.clientX/window.innerWidth*100,e=i.clientY/window.innerHeight*100;this.renderClickPulse({peerId:((a=this.myIdentity)==null?void 0:a.peerId)||"local",nickname:((l=this.myIdentity)==null?void 0:l.nickname)||"You",xPct:o,yPct:e,color:((s=this.myIdentity)==null?void 0:s.color)||"#8b5cf6",isTutor:!0,timestamp:Date.now()});try{chrome.runtime.sendMessage({type:"LOCAL_CLICK_PULSE",xPct:o,yPct:e}).catch(()=>{})}catch{}})}}const q={mode:"all_sites",clickAction:"open_popup",customDomains:["leetcode.com","neetcode.io","codeforces.com","hackerrank.com","geeksforgeeks.org","codechef.com","atcoder.jp","localhost","127.0.0.1"],enableWhiteboard:!0,enableTimer:!0,popupContentMode:"both",positionMode:"permanent",savedPosition:{right:24,bottom:24},whiteboardPrefs:{defaultPrivacyMode:"collaborative",defaultBackgroundType:"grid",defaultBgColor:"#090d16",defaultPenColor:"#6366f1",defaultPenWidth:4,disappearingInkDurationSec:3,autoSavePersonalNotebook:!0}},D="nerd_buddy_fab_settings",B="synqto_fab_settings";function Q(v,t){const i=v.toLowerCase().replace(/[^a-z0-9-_]/g,"-").slice(0,24).replace(/-+$/,""),o=Y(t);return`room:${i||"lobby"}-${o}`}function Z(v){switch(v.toLowerCase()){case"leetcode":return"#FFA116";case"neetcode":return"#8B5CF6";case"codeforces":return"#318CE7";case"hackerrank":return"#2EC866";case"codechef":return"#5B4638";case"geeksforgeeks":return"#2F8D46";case"youtube":return"#FF0000";case"arxiv":return"#B31B1B";case"github":return"#24292F";case"group":return"#8B5CF6";default:return"#6366F1"}}const U={enabled:!1,workDurationMin:25,shortBreakMin:5,longBreakMin:15,autoStartBreaks:!1,soundAlerts:!0},z="synqto_pomodoro_config",I="synqto_pomodoro_state";class J{constructor(){this.hostElement=null,this.shadow=null,this.isOpen=!1,this.settings=q,this.currentProblem=null,this.messages=[],this.unreadCount=0,this.currentRoomStorageKey="",this.myIdentity=null,this.liveStage=null,this.peerCount=1,this.isServerConnected=!0,this.serverToastMessage=null,this.replyingTo=null,this.revealedSpoilers={},this.currentPosition={right:24,bottom:24},this.isDragging=!1,this.dragMoved=!1,this.popupSize="compact",this.activeTab="chat",this.isTimerOpen=!1,this.timerConfig=U,this.timerState={mode:"pomodoro",timeLeftSec:1500,targetDurationSec:1500,isRunning:!1,sessionsCompleted:0,lastUpdated:Date.now()},this.timerInterval=null,this.wbTool="pen",this.wbShowShapesDrawer=!1,this.wbShowDsaDrawer=!1,this.wbShowArchDrawer=!1,this.wbShowPresetsDrawer=!1,this.wbShowThemesDrawer=!1,this.wbPresetTab="dsa",this.toolStyles={pen:{color:"#6366f1",width:3},brush:{color:"#06b6d4",width:6},highlighter:{color:"#f59e0b",width:16},temp_pen:{color:"#38bdf8",width:3},laser:{color:"#ef4444",width:3},torch:{color:"#facc15",width:65},eraser:{color:"#ffffff",width:18},text:{color:"#ffffff",width:3},code_box:{color:"#38bdf8",width:2},line:{color:"#6366f1",width:3},arrow:{color:"#6366f1",width:3},arrow_bi:{color:"#6366f1",width:3},rect:{color:"#6366f1",width:3},rounded_rect:{color:"#6366f1",width:3},circle:{color:"#6366f1",width:3},triangle:{color:"#10b981",width:3},star:{color:"#f59e0b",width:3},decision_diamond:{color:"#f59e0b",width:3},tree_node:{color:"#10b981",width:3},sticky_note:{color:"#fef3c7",width:2},db_cylinder:{color:"#10b981",width:2.5},db_nosql:{color:"#34d399",width:2.5},cloud:{color:"#38bdf8",width:2.5},load_balancer:{color:"#f59e0b",width:2.5},message_queue:{color:"#a855f7",width:2.5},server_box:{color:"#818cf8",width:2.5},cache_mem:{color:"#f43f5e",width:2.5},dns_router:{color:"#38bdf8",width:2.5},firewall:{color:"#f43f5e",width:2.5},user_client:{color:"#3b82f6",width:2.5},mobile_client:{color:"#06b6d4",width:2.5},array_cells:{color:"#38bdf8",width:2.5},stack_lifo:{color:"#f59e0b",width:2.5},queue_fifo:{color:"#10b981",width:2.5},hashmap_table:{color:"#a855f7",width:2.5},two_pointers:{color:"#ec4899",width:2},cdn_edge:{color:"#06b6d4",width:2.5},object_storage:{color:"#f97316",width:2.5},auth_jwt:{color:"#eab308",width:2.5},websocket_gw:{color:"#6366f1",width:2.5},elasticsearch:{color:"#14b8a6",width:2.5},async_arrow:{color:"#a855f7",width:2},tradeoff_note:{color:"#facc15",width:2}},this.wbColor="#6366f1",this.wbWidth=3,this.wbTheme="grid",this.wbBgColor="#090d16",this.wbPrivacyMode="collaborative",this.wbStrokes=[],this.wbPersonalStrokes=[],this.wbRedoStack=[],this.isWbDrawing=!1,this.wbCurrentPoints=[],this.wbStartPoint=null,this.tempDisappearingStrokes=[],this.wbLaserTrails=[],this.wbTorchPos=null,this.wbEraserPos=null,this.themeSettings=null,this.init()}async init(){await this.loadIdentity(),await this.loadSettings(),await this.loadServerConnectionStatus(),await this.loadTimerState(),this.startTimerTickLoop(),this.detectCurrentPageProblem(),this.checkVisibilityAndRender(),this.listenToStorageChanges(),this.listenForRuntimeMessages(),console.log("[Synqto] Floating widget initialized. State:",this.shouldShow()?"VISIBLE":"HIDDEN","Mode:",this.settings.mode)}async loadServerConnectionStatus(){var t;if(typeof chrome<"u"&&((t=chrome.storage)!=null&&t.local))try{const i=await chrome.storage.local.get(["synqto_server_connected","nerd_buddy_server_connected"]);this.isServerConnected=!!(i.synqto_server_connected??i.nerd_buddy_server_connected??!0)}catch{this.isServerConnected=!0}}async loadIdentity(){var t;if(typeof chrome<"u"&&((t=chrome.storage)!=null&&t.local)){const i=await chrome.storage.local.get(["synqto_identity","nerd_buddy_identity"]);this.myIdentity=i.synqto_identity||i.nerd_buddy_identity||null}}async loadSettings(){var t,i;if(typeof chrome<"u"&&((t=chrome.storage)!=null&&t.local)){const o=await chrome.storage.local.get([D,B,"synqto_theme_settings","synqto_collab_notebook","synqto_personal_notebook","synqto_active_problem","nerd_buddy_active_problem","synqto_live_stage","nerd_buddy_live_stage","nerd_buddy_sidepanel_open","nerd_buddy_peer_count"]);if(o.synqto_theme_settings&&(this.themeSettings=o.synqto_theme_settings),o.synqto_collab_notebook&&Array.isArray(o.synqto_collab_notebook.pages)){const a=o.synqto_collab_notebook,l=a.pages.find(s=>s.id===a.activePageId)||a.pages[0];l&&(this.wbStrokes=l.strokes||[],l.background&&(this.wbTheme=l.background),l.bgColor&&(this.wbBgColor=l.bgColor))}if(o.synqto_personal_notebook&&Array.isArray(o.synqto_personal_notebook.pages)){const a=o.synqto_personal_notebook,l=a.pages.find(s=>s.id===a.activePageId)||a.pages[0];l&&(this.wbPersonalStrokes=l.strokes||[])}(o[B]||o[D])&&(this.settings={...q,...o[B]||o[D]}),this.settings.positionMode==="permanent"&&this.settings.savedPosition?this.currentPosition={...this.settings.savedPosition}:this.currentPosition={right:24,bottom:24};const e=o.synqto_active_problem||o.nerd_buddy_active_problem;e&&(this.currentProblem=e,this.currentRoomStorageKey=`synqto_chat_${((i=this.currentProblem)==null?void 0:i.roomId)||""}`,await this.loadMessages()),(o.synqto_live_stage||o.nerd_buddy_live_stage)&&(this.liveStage=o.synqto_live_stage||o.nerd_buddy_live_stage),typeof o.nerd_buddy_peer_count=="number"&&(this.peerCount=Math.max(1,o.nerd_buddy_peer_count))}}detectCurrentPageProblem(){const t=F(window.location.href,document.title);if(t){const i=Q(t.slug,t.canonicalUrl);this.currentProblem={platform:t.platform,slug:t.slug,title:t.title,canonicalUrl:t.canonicalUrl,roomId:i},this.currentRoomStorageKey=`synqto_chat_${i}`,this.loadMessages()}}shouldShow(){if(this.settings.mode==="disabled"||this.settings.popupContentMode==="none")return!1;if(this.settings.mode==="all_sites")return!0;const t=window.location.hostname.toLowerCase();if(this.settings.mode==="custom_sites")return this.settings.customDomains.some(a=>t.includes(a.toLowerCase()));const o=["leetcode.com","leetcode.cn","neetcode.io","codeforces.com","codeforces.net","hackerrank.com","geeksforgeeks.org","codechef.com","atcoder.jp","hackerearth.com","topcoder.com","spoj.com","codewars.com","exercism.org","github.com","youtube.com","arxiv.org","localhost","127.0.0.1"].some(a=>t.includes(a)),e=!!(this.currentProblem||F(window.location.href,document.title));return o||e}checkVisibilityAndRender(){const t=this.shouldShow();t&&!this.hostElement?this.createWidgetDOM():!t&&this.hostElement&&this.destroyWidgetDOM()}destroyWidgetDOM(){this.hostElement&&(this.hostElement.remove(),this.hostElement=null,this.shadow=null)}createWidgetDOM(){var e,a;if(document.getElementById("synqto-floating-host"))return;if(!document.body){document.readyState==="loading"?document.addEventListener("DOMContentLoaded",()=>this.checkVisibilityAndRender(),{once:!0}):window.addEventListener("load",()=>this.checkVisibilityAndRender(),{once:!0});return}const t=document.createElement("div");t.id="synqto-floating-host";const i=Number.isFinite((e=this.currentPosition)==null?void 0:e.right)?this.currentPosition.right:24,o=Number.isFinite((a=this.currentPosition)==null?void 0:a.bottom)?this.currentPosition.bottom:24;t.style.cssText=`
      position: fixed !important;
      bottom: ${o}px !important;
      right: ${i}px !important;
      z-index: 2147483647 !important;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif !important;
      touch-action: none !important;
      pointer-events: auto !important;
      display: block !important;
      visibility: visible !important;
      opacity: 1 !important;
    `,document.body.appendChild(t),this.hostElement=t,this.shadow=t.attachShadow({mode:"open"}),this.render()}applyHostPosition(){var a,l;if(!this.hostElement)return;const t=Number.isFinite((a=this.currentPosition)==null?void 0:a.right)?this.currentPosition.right:24,i=Number.isFinite((l=this.currentPosition)==null?void 0:l.bottom)?this.currentPosition.bottom:24,o=Math.max(10,Math.min(window.innerWidth-130,t)),e=Math.max(10,Math.min(window.innerHeight-55,i));this.hostElement.style.setProperty("right",`${o}px`,"important"),this.hostElement.style.setProperty("bottom",`${e}px`,"important")}render(){var w,g,S,u;if(!this.shadow)return;const t=this.settings.popupContentMode||(this.settings.enableWhiteboard?"both":"chat_only");if(t==="none"||this.settings.mode==="disabled"){this.destroyWidgetDOM();return}this.applyHostPosition();const i=!!(this.liveStage&&this.liveStage.isActive),o=((g=(w=this.liveStage)==null?void 0:w.tutorIdentity)==null?void 0:g.nickname)||"Tutor",e=((S=this.currentProblem)==null?void 0:S.title)||"Global Problem Lobby",a=((u=this.currentProblem)==null?void 0:u.platform)||"LeetCode",l=Z(a),s=t==="whiteboard_only"||t==="both"&&this.activeTab==="whiteboard",n=t==="whiteboard_only"?"🎨":"⚡",r="synqto",p=this.currentPosition.bottom>window.innerHeight-540,f=this.currentPosition.right>window.innerWidth-420;this.shadow.innerHTML=`
      <style>
        :host {
          ${this.getThemeCSS()}
          --font-mono: 'JetBrains Mono', 'Fira Code', monospace;
        }

        * {
          box-sizing: border-box;
          margin: 0;
          padding: 0;
        }

        /* Floating Action Button (FAB) */
        .fab-button {
          position: relative;
          display: flex;
          align-items: center;
          gap: 7px;
          padding: 10px 14px;
          border-radius: 9999px;
          background: linear-gradient(135deg, #4f46e5, #7c3aed);
          border: 1px solid rgba(255, 255, 255, 0.2);
          box-shadow: 0 10px 25px -5px rgba(99, 102, 241, 0.5), 0 0 15px rgba(124, 58, 237, 0.3);
          color: #ffffff;
          font-size: 12px;
          font-weight: 700;
          cursor: grab;
          transition: transform 0.15s cubic-bezier(0.16, 1, 0.3, 1), box-shadow 0.15s;
          user-select: none;
        }

        .fab-button:active {
          cursor: grabbing;
        }

        .fab-button:hover {
          transform: translateY(-2px) scale(1.02);
          box-shadow: 0 14px 28px -5px rgba(99, 102, 241, 0.65), 0 0 20px rgba(124, 58, 237, 0.4);
        }

        .drag-grip {
          opacity: 0.5;
          font-size: 11px;
          cursor: grab;
        }

        .live-dot {
          width: 8px;
          height: 8px;
          border-radius: 50%;
          background: #ef4444;
          box-shadow: 0 0 10px #ef4444;
          animation: livePulse 1.5s infinite;
        }

        .timer-dot {
          width: 7px;
          height: 7px;
          border-radius: 50%;
          background: #f43f5e;
          box-shadow: 0 0 8px #f43f5e;
          animation: livePulse 1.2s infinite;
        }

        @keyframes livePulse {
          0%, 100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.4; transform: scale(1.2); }
        }

        @keyframes rocketThrust {
          0% { transform: translateY(0px) rotate(45deg); }
          100% { transform: translateY(-2px) rotate(52deg); }
        }

        @keyframes flameFlicker {
          0% { opacity: 0.7; transform: scale(0.85); }
          100% { opacity: 1; transform: scale(1.25); }
        }

        @keyframes neonTrackGlow {
          0% { box-shadow: 0 0 5px rgba(244, 63, 94, 0.4); }
          100% { box-shadow: 0 0 15px rgba(244, 63, 94, 0.8), 0 0 25px rgba(99, 102, 241, 0.5); }
        }

        /* Standalone Rocket Racing Focus Timer FAB */
        .timer-fab-button {
          position: relative;
          display: flex;
          align-items: center;
          gap: 8px;
          padding: 8px 14px;
          border-radius: 9999px;
          background: linear-gradient(135deg, #1e1035 0%, #0f172a 100%);
          border: 1px solid rgba(244, 63, 94, 0.55);
          box-shadow: 0 10px 25px -5px rgba(244, 63, 94, 0.45), 0 0 18px rgba(99, 102, 241, 0.3);
          color: #ffffff;
          font-size: 12px;
          font-weight: 700;
          cursor: pointer;
          transition: transform 0.15s cubic-bezier(0.16, 1, 0.3, 1), box-shadow 0.2s, border-color 0.2s;
          user-select: none;
          backdrop-filter: blur(16px);
        }

        .timer-fab-button:hover {
          transform: translateY(-2px) scale(1.03);
          box-shadow: 0 14px 28px -5px rgba(244, 63, 94, 0.65), 0 0 25px rgba(244, 63, 94, 0.5);
          border-color: rgba(244, 63, 94, 0.85);
        }

        .timer-fab-track {
          width: 52px;
          height: 6px;
          border-radius: 3px;
          background: rgba(255, 255, 255, 0.12);
          position: relative;
          overflow: hidden;
        }

        .timer-fab-fill {
          height: 100%;
          background: linear-gradient(90deg, #6366f1, #f43f5e);
          box-shadow: 0 0 8px rgba(244, 63, 94, 0.8);
          transition: width 0.4s ease;
        }

        .timer-fab-rocket {
          font-size: 13px;
          display: inline-block;
          filter: drop-shadow(0 0 6px rgba(244, 63, 94, 0.9));
        }

        .fab-badge {
          position: absolute;
          top: -4px;
          right: -4px;
          background: #f59e0b;
          color: #ffffff;
          font-size: 10px;
          font-weight: 700;
          padding: 2px 6px;
          border-radius: 9999px;
        }

        /* In-Page Popup Card */
        .popup-card {
          display: ${this.isOpen?"flex":"none"};
          flex-direction: column;
          position: absolute;
          ${p?"top: 52px; bottom: auto;":"bottom: 52px; top: auto;"}
          ${f?"left: 0; right: auto;":"right: 0; left: auto;"}
          width: ${this.popupSize==="fullscreen"?"min(1180px, 95vw)":this.popupSize==="large"?"min(860px, 92vw)":this.popupSize==="medium"?"min(620px, 88vw)":"420px"};
          height: ${this.popupSize==="fullscreen"?"min(880px, 92vh)":this.popupSize==="large"?"min(740px, 88vh)":this.popupSize==="medium"?"min(640px, 84vh)":"540px"};
          max-height: 94vh;
          max-width: 96vw;
          background: rgba(15, 23, 42, 0.97);
          border: 1px solid ${i?"rgba(239, 68, 68, 0.45)":"rgba(99, 102, 241, 0.35)"};
          border-radius: 16px;
          box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.9), 0 0 28px ${i?"rgba(239, 68, 68, 0.25)":"rgba(99, 102, 241, 0.25)"};
          backdrop-filter: blur(24px);
          -webkit-backdrop-filter: blur(24px);
          overflow: hidden;
          animation: slideIn 0.2s cubic-bezier(0.16, 1, 0.3, 1);
          color: var(--text-primary);
          transition: width 0.2s cubic-bezier(0.16, 1, 0.3, 1), height 0.2s cubic-bezier(0.16, 1, 0.3, 1);
        }

        /* Dedicated Standalone Timer & Pomodoro Popup Window */
        .timer-popup-card {
          display: ${this.isTimerOpen?"flex":"none"};
          flex-direction: column;
          position: absolute;
          ${p?"top: 52px; bottom: auto;":"bottom: 52px; top: auto;"}
          ${f?"left: 0; right: auto;":"right: 0; left: auto;"}
          width: 320px;
          background: rgba(15, 23, 42, 0.98);
          border: 1px solid rgba(244, 63, 94, 0.5);
          border-radius: 16px;
          box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.95), 0 0 28px rgba(244, 63, 94, 0.3);
          backdrop-filter: blur(24px);
          -webkit-backdrop-filter: blur(24px);
          z-index: 100;
          overflow: hidden;
          animation: slideIn 0.2s cubic-bezier(0.16, 1, 0.3, 1);
          color: var(--text-primary);
        }

        @keyframes slideIn {
          from { opacity: 0; transform: translateY(12px) scale(0.96); }
          to { opacity: 1; transform: translateY(0) scale(1); }
        }

        /* Room Header */
        .room-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 10px 12px;
          background: linear-gradient(135deg, rgba(30, 41, 59, 0.95), rgba(15, 23, 42, 0.95));
          border-bottom: 1px solid var(--border-subtle);
        }

        .room-info {
          display: flex;
          align-items: center;
          gap: 10px;
          overflow: hidden;
        }

        .platform-icon-box {
          width: 32px;
          height: 32px;
          border-radius: 8px;
          background: rgba(99, 102, 241, 0.15);
          border: 1px solid rgba(255, 255, 255, 0.1);
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 16px;
          flex-shrink: 0;
        }

        .problem-title {
          font-size: 13px;
          font-weight: 700;
          color: var(--text-primary);
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
          max-width: 170px;
        }

        .badges-row {
          display: flex;
          align-items: center;
          gap: 6px;
          margin-top: 2px;
        }

        .platform-pill {
          font-size: 9px;
          font-weight: 700;
          padding: 1px 6px;
          border-radius: 4px;
          background: ${l}20;
          border: 1px solid ${l}50;
          color: ${l};
          text-transform: uppercase;
        }

        .peer-count-pill {
          font-size: 10px;
          color: var(--text-secondary);
          display: flex;
          align-items: center;
          gap: 4px;
        }

        .header-actions {
          display: flex;
          align-items: center;
          gap: 4px;
        }

        .icon-btn {
          background: transparent;
          border: none;
          color: var(--text-secondary);
          cursor: pointer;
          padding: 5px;
          border-radius: 6px;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: all 0.15s;
        }

        .icon-btn:hover {
          background: rgba(255, 255, 255, 0.1);
          color: #ffffff;
        }

        /* Segmented View Switcher */
        .tab-switcher {
          display: flex;
          background: rgba(15, 23, 42, 0.9);
          padding: 3px 6px;
          border-bottom: 1px solid var(--border-subtle);
          gap: 4px;
        }

        .tab-btn {
          flex: 1;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 6px;
          padding: 5px 8px;
          font-size: 11px;
          font-weight: 600;
          border-radius: 6px;
          border: none;
          cursor: pointer;
          transition: all 0.15s;
          background: transparent;
          color: var(--text-muted);
        }

        .tab-btn.active {
          background: var(--primary);
          color: #ffffff;
        }

        /* Messages List */
        .message-list {
          flex: 1;
          overflow-y: auto;
          padding: 12px;
          display: flex;
          flex-direction: column;
          gap: 10px;
        }

        .chat-bubble {
          display: flex;
          flex-direction: column;
          max-width: 86%;
          padding: 8px 12px;
          border-radius: 14px;
          font-size: 12px;
          position: relative;
          word-break: break-word;
          line-height: 1.45;
        }

        .chat-bubble.self {
          align-self: flex-end;
          background: linear-gradient(135deg, rgba(99, 102, 241, 0.28), rgba(139, 92, 246, 0.22));
          border: 1px solid rgba(99, 102, 241, 0.35);
          border-bottom-right-radius: 4px;
          color: #ffffff;
        }

        .chat-bubble.other {
          align-self: flex-start;
          background: var(--bg-surface-elevated);
          border: 1px solid var(--border-subtle);
          border-bottom-left-radius: 4px;
          color: #f1f5f9;
        }

        .chat-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 8px;
          margin-bottom: 4px;
          font-size: 11px;
        }

        .chat-author {
          font-weight: 600;
          display: flex;
          align-items: center;
          gap: 4px;
        }

        .chat-timestamp {
          color: var(--text-dim);
          font-size: 10px;
        }

        .chat-footer {
          margin-top: 3px;
          display: flex;
          align-items: center;
          justify-content: flex-end;
          font-size: 10px;
        }

        .ack-read {
          color: #38bdf8;
          font-weight: 700;
        }

        /* Whiteboard Toolbar & Canvas */
        .whiteboard-container {
          flex: 1;
          display: flex;
          flex-direction: column;
          background: #090d16;
          overflow: hidden;
          position: relative;
        }

        .wb-toolbar {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 6px 8px;
          background: rgba(15, 23, 42, 0.95);
          border-bottom: 1px solid var(--border-subtle);
          flex-wrap: wrap;
          gap: 4px;
        }

        .wb-tool-group {
          display: flex;
          gap: 3px;
          align-items: center;
        }

        .wb-tool-btn {
          padding: 4px 6px;
          border-radius: 4px;
          border: 1px solid transparent;
          background: transparent;
          color: var(--text-muted);
          cursor: pointer;
          font-size: 11px;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .wb-tool-btn.active {
          border-color: var(--primary);
          background: rgba(99, 102, 241, 0.25);
          color: #c7d2fe;
        }

        .wb-palette-bar {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 3px 8px;
          background: rgba(0, 0, 0, 0.3);
          border-bottom: 1px solid var(--border-subtle);
        }

        .color-dot {
          width: 13px;
          height: 13px;
          border-radius: 50%;
          border: 1px solid rgba(255, 255, 255, 0.2);
          cursor: pointer;
        }

        .color-dot.active {
          border: 2px solid #ffffff;
          box-shadow: 0 0 6px rgba(255, 255, 255, 0.5);
        }

        .size-pill {
          font-size: 9px;
          font-weight: 700;
          padding: 1px 4px;
          border-radius: 3px;
          background: rgba(255, 255, 255, 0.05);
          border: 1px solid transparent;
          color: var(--text-dim);
          cursor: pointer;
        }

        .size-pill.active {
          background: rgba(99, 102, 241, 0.3);
          border-color: var(--primary);
          color: #ffffff;
        }

        #nb-whiteboard-canvas {
          flex-grow: 1;
          width: 100%;
          height: 100%;
          cursor: crosshair;
          touch-action: none;
        }

        /* Input Composer */
        .composer-box {
          display: flex;
          align-items: center;
          gap: 6px;
          padding: 8px 10px;
          background: rgba(15, 23, 42, 0.95);
          border-top: 1px solid var(--border-subtle);
        }

        .input-glass {
          flex: 1;
          background: rgba(0, 0, 0, 0.4);
          border: 1px solid var(--border-subtle);
          border-radius: 8px;
          padding: 7px 10px;
          color: #ffffff;
          font-size: 11px;
          outline: none;
        }

        .input-glass:focus {
          border-color: var(--primary);
        }

        .btn-send {
          background: var(--primary);
          border: none;
          color: #ffffff;
          padding: 6px 10px;
          border-radius: 8px;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .prompt-pills-row {
          display: flex;
          gap: 4px;
          padding: 4px 8px;
          overflow-x: auto;
          background: rgba(0, 0, 0, 0.3);
          border-top: 1px solid var(--border-subtle);
        }

        .prompt-pill {
          background: rgba(255, 255, 255, 0.06);
          border: 1px solid var(--border-subtle);
          color: var(--text-secondary);
          font-size: 9px;
          font-weight: 600;
          padding: 2px 6px;
          border-radius: 4px;
          cursor: pointer;
          white-space: nowrap;
        }

        .prompt-pill:hover {
          background: rgba(99, 102, 241, 0.2);
          color: #ffffff;
        }
      </style>

      <!-- In-Page Popup Card Window -->
      <div class="popup-card" id="nb-popup-card">
        <!-- Room Header Bar -->
        <div class="room-header">
          <div class="room-info">
            <div class="platform-icon-box">⚡</div>
            <div>
              <div class="problem-title">${this.escapeHtml(e)}</div>
              <div class="badges-row">
                <span class="platform-pill">${a}</span>
                <span class="peer-count-pill" title="${this.isServerConnected?"Signaling Server: Connected (wss://synqto-server.onrender.com/ws/)":"Signaling Server: Disconnected (Offline Mode)"}">
                  <span style="display:inline-block;width:6px;height:6px;border-radius:50%;background:${this.isServerConnected?"#10b981":"#ef4444"};box-shadow:0 0 6px ${this.isServerConnected?"#10b981":"#ef4444"};"></span>
                  <span>${this.peerCount} Online ${this.isServerConnected?"":"(Offline)"}</span>
                </span>
              </div>
            </div>
          </div>

          <div class="header-actions">
            <!-- Popup Size Mode Switcher Pills -->
            <div class="popup-size-group" style="display:flex;gap:2px;align-items:center;background:rgba(0,0,0,0.35);padding:2px;border-radius:6px;border:1px solid rgba(255,255,255,0.08);margin-right:2px;">
              <button class="size-mode-pill ${this.popupSize==="compact"?"active":""}" data-popsize="compact" title="Compact Size (420x540)" style="font-size:9px;font-weight:700;padding:2px 5px;border-radius:4px;border:none;cursor:pointer;background:${this.popupSize==="compact"?"var(--primary)":"transparent"};color:${this.popupSize==="compact"?"#fff":"var(--text-muted)"};">📱 S</button>
              <button class="size-mode-pill ${this.popupSize==="medium"?"active":""}" data-popsize="medium" title="Medium Split Size (620x640)" style="font-size:9px;font-weight:700;padding:2px 5px;border-radius:4px;border:none;cursor:pointer;background:${this.popupSize==="medium"?"var(--primary)":"transparent"};color:${this.popupSize==="medium"?"#fff":"var(--text-muted)"};">🌗 M</button>
              <button class="size-mode-pill ${this.popupSize==="large"?"active":""}" data-popsize="large" title="Large Widescreen (860x740)" style="font-size:9px;font-weight:700;padding:2px 5px;border-radius:4px;border:none;cursor:pointer;background:${this.popupSize==="large"?"var(--primary)":"transparent"};color:${this.popupSize==="large"?"#fff":"var(--text-muted)"};">🖥️ L</button>
              <button class="size-mode-pill ${this.popupSize==="fullscreen"?"active":""}" data-popsize="fullscreen" title="Full Screen View (1180x880)" style="font-size:9px;font-weight:700;padding:2px 5px;border-radius:4px;border:none;cursor:pointer;background:${this.popupSize==="fullscreen"?"var(--primary)":"transparent"};color:${this.popupSize==="fullscreen"?"#fff":"var(--text-muted)"};">📺 XL</button>
            </div>

            <button class="icon-btn" id="nb-open-sidepanel" title="Open complete extension in side panel">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M15 3h6v6M10 14L21 3M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6"/>
              </svg>
            </button>
            <button class="icon-btn" id="nb-close-popup" title="Minimize">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M18 6L6 18M6 6l12 12"/>
              </svg>
            </button>
          </div>
        </div>

        <!-- Green Vanishing Toast on Server Connection Established -->
        ${this.serverToastMessage?`
          <div style="background:linear-gradient(135deg, rgba(16, 185, 129, 0.96), rgba(5, 150, 105, 0.96));color:#fff;padding:6px 10px;font-size:10.5px;font-weight:600;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid rgba(255,255,255,0.2);box-shadow:0 4px 12px rgba(16, 185, 129, 0.4);">
            <div style="display:flex;align-items:center;gap:6px;">
              <span>⚡</span>
              <span>${this.escapeHtml(this.serverToastMessage)}</span>
            </div>
            <span style="font-size:8.5px;background:rgba(0,0,0,0.25);padding:1px 5px;border-radius:3px;">P2P Active</span>
          </div>
        `:""}

        <!-- Red Offline Notice Banner when Server is Unreachable -->
        ${this.isServerConnected?"":`
          <div style="background:linear-gradient(135deg, #ef4444, #dc2626);color:#fff;padding:5px 10px;font-size:10px;font-weight:600;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid rgba(255,255,255,0.2);">
            <div style="display:flex;align-items:center;gap:5px;">
              <span>⚠️</span>
              <span>Server Offline (Local Mode)</span>
            </div>
            <button id="nb-offline-sidepanel-reconnect" style="background:rgba(0,0,0,0.3);color:#fff;border:1px solid rgba(255,255,255,0.25);padding:2px 6px;border-radius:4px;font-size:9px;font-weight:700;cursor:pointer;">
              Reconnect in Side Panel ⚡
            </button>
          </div>
        `}

        <!-- Segmented Switcher for Chat and Whiteboard -->
        <div class="tab-switcher" style="display:flex;border-bottom:1px solid var(--border-subtle);background:rgba(0,0,0,0.25);">
          <button class="tab-btn ${this.activeTab==="chat"?"active":""}" id="nb-tab-chat" style="flex:1;display:flex;align-items:center;justify-content:center;gap:5px;padding:8px 4px;font-size:11px;font-weight:600;background:transparent;border:none;border-bottom:2px solid ${this.activeTab==="chat"?"var(--primary)":"transparent"};color:${this.activeTab==="chat"?"#fff":"var(--text-muted)"};cursor:pointer;">
            <span>💬 Live Chat</span>
          </button>
          ${this.settings.enableWhiteboard?`
            <button class="tab-btn ${this.activeTab==="whiteboard"?"active":""}" id="nb-tab-whiteboard" style="flex:1;display:flex;align-items:center;justify-content:center;gap:5px;padding:8px 4px;font-size:11px;font-weight:600;background:transparent;border:none;border-bottom:2px solid ${this.activeTab==="whiteboard"?"var(--primary)":"transparent"};color:${this.activeTab==="whiteboard"?"#fff":"var(--text-muted)"};cursor:pointer;">
              <span>🎨 Whiteboard</span>
            </button>
          `:""}
        </div>

        <!-- Multi-Broadcaster Live Streams List -->
        ${i?`
          <div style="background:linear-gradient(135deg, rgba(239, 68, 68, 0.22), rgba(139, 92, 246, 0.18));border-bottom:1px solid rgba(239, 68, 68, 0.35);padding:6px 10px;display:flex;flex-direction:column;gap:5px;">
            <div style="display:flex;align-items:center;justify-content:space-between;font-size:10px;color:#fca5a5;">
              <div style="display:flex;align-items:center;gap:5px;font-weight:700;">
                <span class="live-dot"></span>
                <span>LIVE STREAMS (${this.liveStage.activeStreams&&this.liveStage.activeStreams.length||1}):</span>
              </div>
              <button id="nb-live-tunein" style="background:#ef4444;color:#fff;border:none;padding:2px 8px;border-radius:4px;font-size:9px;font-weight:700;cursor:pointer;">
                Open Side Panel 📺
              </button>
            </div>

            <div style="display:flex;gap:4px;overflow-x:auto;padding-bottom:2px;">
              ${(this.liveStage.activeStreams&&this.liveStage.activeStreams.length>0?this.liveStage.activeStreams:[{broadcasterIdentity:this.liveStage.tutorIdentity||{nickname:o,avatar:"👑"},title:`${o}'s Walkthrough`,broadcastType:this.liveStage.broadcastType||"screen"}]).map(d=>{var k,y;return`
                <div style="display:flex;align-items:center;gap:4px;padding:3px 6px;border-radius:4px;background:rgba(0,0,0,0.4);border:1px solid rgba(255,255,255,0.1);font-size:10px;color:#f8fafc;white-space:nowrap;">
                  <span>${((k=d.broadcasterIdentity)==null?void 0:k.avatar)||"👤"}</span>
                  <span style="font-weight:600;">${((y=d.broadcasterIdentity)==null?void 0:y.nickname)||"Streamer"}:</span>
                  <span style="color:#c7d2fe;max-width:110px;overflow:hidden;text-overflow:ellipsis;">${this.escapeHtml(d.title||"Live Stream")}</span>
                  <span style="font-size:8px;padding:1px 4px;border-radius:3px;background:rgba(239,68,68,0.3);color:#fca5a5;text-transform:uppercase;">${d.broadcastType||"live"}</span>
                </div>
              `}).join("")}
            </div>
          </div>
        `:""}

        <!-- Main Body: Whiteboard or Problem Chat Stream -->
        ${s?`
          <!-- Whiteboard View -->
          <div class="whiteboard-container">
            <div class="wb-toolbar">
              <div class="wb-tool-group" style="flex-wrap:wrap;gap:2px;">
                <button class="wb-tool-btn ${this.wbTool==="pen"?"active":""}" data-wbtool="pen" title="Fine Pen">✏️</button>
                <button class="wb-tool-btn ${this.wbTool==="brush"?"active":""}" data-wbtool="brush" title="Brush Pen">✒️</button>
                <button class="wb-tool-btn ${this.wbTool==="highlighter"?"active":""}" data-wbtool="highlighter" title="Highlighter">🖍️</button>
                <button class="wb-tool-btn ${this.wbTool==="temp_pen"?"active":""}" data-wbtool="temp_pen" title="⏳ Disappearing Ink (3s)">⏳</button>
                <button class="wb-tool-btn ${this.wbTool==="laser"?"active":""}" data-wbtool="laser" title="Laser Pointer">🔴</button>
                <button class="wb-tool-btn ${this.wbTool==="torch"?"active":""}" data-wbtool="torch" title="Spotlight Torch">🔦</button>
                <button class="wb-tool-btn ${this.wbTool==="eraser"?"active":""}" data-wbtool="eraser" title="Eraser">🧹</button>
                <button class="wb-tool-btn ${this.wbTool==="text"?"active":""}" data-wbtool="text" title="Text Label">T</button>

                <div style="width:1px;height:12px;background:var(--border-subtle);margin:0 1px;"></div>

                <!-- Drawer Toggles -->
                <button class="wb-drawer-toggle ${this.wbShowShapesDrawer?"active":""}" id="nb-wb-toggle-shapes" style="font-size:9px;padding:2px 4px;border-radius:4px;border:1px solid var(--border-subtle);background:${this.wbShowShapesDrawer?"rgba(99,102,241,0.25)":"transparent"};color:${this.wbShowShapesDrawer?"#fff":"var(--text-muted)"};cursor:pointer;">
                  🔷 Shapes ${this.wbShowShapesDrawer?"▲":"▼"}
                </button>

                <button class="wb-drawer-toggle ${this.wbShowDsaDrawer?"active":""}" id="nb-wb-toggle-dsa" style="font-size:9px;padding:2px 4px;border-radius:4px;border:1px solid rgba(56,189,248,0.3);background:${this.wbShowDsaDrawer?"rgba(56,189,248,0.2)":"transparent"};color:${this.wbShowDsaDrawer?"#38bdf8":"var(--text-muted)"};cursor:pointer;">
                  🔲 DSA ${this.wbShowDsaDrawer?"▲":"▼"}
                </button>

                <button class="wb-drawer-toggle ${this.wbShowArchDrawer?"active":""}" id="nb-wb-toggle-arch" style="font-size:9px;padding:2px 4px;border-radius:4px;border:1px solid var(--border-subtle);background:${this.wbShowArchDrawer?"rgba(99,102,241,0.25)":"transparent"};color:${this.wbShowArchDrawer?"#fff":"var(--text-muted)"};cursor:pointer;">
                  🏛️ Arch ${this.wbShowArchDrawer?"▲":"▼"}
                </button>

                <button class="wb-drawer-toggle ${this.wbShowPresetsDrawer?"active":""}" id="nb-wb-toggle-presets" style="font-size:9px;padding:2px 4px;border-radius:4px;border:1px solid rgba(16,185,129,0.35);background:${this.wbShowPresetsDrawer?"rgba(16,185,129,0.2)":"transparent"};color:${this.wbShowPresetsDrawer?"#34d399":"var(--text-muted)"};cursor:pointer;">
                  ⚡ Presets ${this.wbShowPresetsDrawer?"▲":"▼"}
                </button>

                <button class="wb-drawer-toggle ${this.wbShowThemesDrawer?"active":""}" id="nb-wb-toggle-themes" style="font-size:9px;padding:2px 4px;border-radius:4px;border:1px solid var(--border-subtle);background:${this.wbShowThemesDrawer?"rgba(99,102,241,0.25)":"transparent"};color:${this.wbShowThemesDrawer?"#fff":"var(--text-muted)"};cursor:pointer;">
                  🎨 Style ${this.wbShowThemesDrawer?"▲":"▼"}
                </button>
              </div>

              <!-- Right Controls -->
              <div class="wb-tool-group">
                <div style="display:flex;gap:2px;align-items:center;background:rgba(0,0,0,0.3);padding:2px 3px;border-radius:4px;">
                  <button class="wb-privacy-btn" data-wbprivacy="collaborative" style="font-size:9px;font-weight:700;padding:2px 4px;border-radius:3px;border:none;cursor:pointer;background:${this.wbPrivacyMode==="collaborative"?"var(--primary)":"transparent"};color:${this.wbPrivacyMode==="collaborative"?"#fff":"var(--text-muted)"};" title="👥 Collaborative with Room Peers">👥 Collab</button>
                  <button class="wb-privacy-btn" data-wbprivacy="personal" style="font-size:9px;font-weight:700;padding:2px 4px;border-radius:3px;border:none;cursor:pointer;background:${this.wbPrivacyMode==="personal"?"var(--primary)":"transparent"};color:${this.wbPrivacyMode==="personal"?"#fff":"var(--text-muted)"};" title="🔒 Personal Private Scratchpad">🔒 Personal</button>
                </div>
                <button class="wb-tool-btn" id="nb-wb-undo" title="Undo">↩️</button>
                <button class="wb-tool-btn" id="nb-wb-redo" title="Redo">↪️</button>
                <button class="wb-tool-btn" id="nb-wb-clear" title="Clear Canvas" style="color:#f87171;">🗑️</button>
                <button class="wb-tool-btn" id="nb-wb-save" title="Export PNG">💾</button>
                <button class="wb-tool-btn" id="nb-wb-popout" title="Open Standalone Popup Window">↗️</button>
              </div>
            </div>

            <!-- Drawer: Shapes -->
            ${this.wbShowShapesDrawer?`
              <div style="display:flex;align-items:center;gap:3px;padding:3px 6px;background:rgba(0,0,0,0.85);border-bottom:1px solid var(--border-subtle);overflow-x:auto;">
                <span style="font-size:8.5px;color:var(--text-muted);font-weight:600;">Shapes:</span>
                ${[{id:"line",label:"Line 📏"},{id:"arrow",label:"Arrow ➡️"},{id:"arrow_bi",label:"Bi-Arrow ↔️"},{id:"rect",label:"Rect 🔲"},{id:"rounded_rect",label:"Rounded ▢"},{id:"circle",label:"Circle ⭕"},{id:"triangle",label:"Triangle ▲"},{id:"star",label:"Star ⭐"},{id:"decision_diamond",label:"Diamond 💎"},{id:"sticky_note",label:"Sticky 📝"},{id:"code_box",label:"Code &lt;/&gt;"}].map(d=>`
                  <button class="wb-tool-btn ${this.wbTool===d.id?"active":""}" data-wbtool="${d.id}" style="font-size:9px;padding:2px 5px;white-space:nowrap;">${d.label}</button>
                `).join("")}
              </div>
            `:""}

            <!-- Drawer: DSA Visualizers -->
            ${this.wbShowDsaDrawer?`
              <div style="display:flex;align-items:center;gap:3px;padding:3px 6px;background:rgba(8,28,44,0.95);border-bottom:1px solid rgba(56,189,248,0.3);overflow-x:auto;">
                <span style="font-size:8.5px;color:#7dd3fc;font-weight:700;">🔲 DSA:</span>
                ${[{id:"array_cells",label:"Array [0..N]"},{id:"two_pointers",label:"Two Pointers (L/R)"},{id:"stack_lifo",label:"Stack (LIFO)"},{id:"queue_fifo",label:"Queue (FIFO)"},{id:"tree_node",label:"Tree Node"},{id:"hashmap_table",label:"HashMap Bucket"},{id:"decision_diamond",label:"Branch Diamond"},{id:"code_box",label:"Pseudocode Box"}].map(d=>`
                  <button class="wb-tool-btn ${this.wbTool===d.id?"active":""}" data-wbtool="${d.id}" style="font-size:9px;padding:2px 5px;white-space:nowrap;color:#7dd3fc;">${d.label}</button>
                `).join("")}
              </div>
            `:""}

            <!-- Drawer: Architecture Shapes -->
            ${this.wbShowArchDrawer?`
              <div style="display:flex;align-items:center;gap:3px;padding:3px 6px;background:rgba(0,0,0,0.9);border-bottom:1px solid var(--border-subtle);overflow-x:auto;">
                <span style="font-size:8.5px;color:var(--text-muted);font-weight:600;">Arch:</span>
                ${[{id:"db_cylinder",label:"SQL DB"},{id:"db_nosql",label:"NoSQL"},{id:"cache_mem",label:"Redis"},{id:"message_queue",label:"Kafka"},{id:"load_balancer",label:"LB"},{id:"server_box",label:"App Server"},{id:"cloud",label:"API GW"},{id:"cdn_edge",label:"CDN Edge"},{id:"object_storage",label:"S3 Bucket"},{id:"auth_jwt",label:"Auth Shield"},{id:"websocket_gw",label:"WS Gateway"},{id:"elasticsearch",label:"ES Search"},{id:"dns_router",label:"DNS"},{id:"firewall",label:"Firewall"},{id:"user_client",label:"Client"},{id:"mobile_client",label:"Mobile"},{id:"async_arrow",label:"Async ⇢"},{id:"tradeoff_note",label:"⚖️ CAP Card"}].map(d=>`
                  <button class="wb-tool-btn ${this.wbTool===d.id?"active":""}" data-wbtool="${d.id}" style="font-size:9px;padding:2px 5px;white-space:nowrap;">${d.label}</button>
                `).join("")}
              </div>
            `:""}

            <!-- Drawer: 1-Click Blueprints Presets -->
            ${this.wbShowPresetsDrawer?`
              <div style="display:flex;flex-direction:column;gap:3px;padding:4px 6px;background:rgba(6,44,36,0.96);border-bottom:1px solid rgba(16,185,129,0.35);">
                <div style="display:flex;gap:3px;align-items:center;">
                  <button class="wb-preset-tab-btn" data-presettab="dsa" style="font-size:9px;font-weight:700;padding:2px 6px;border-radius:3px;border:none;background:${this.wbPresetTab==="dsa"?"#10b981":"rgba(255,255,255,0.08)"};color:${this.wbPresetTab==="dsa"?"#fff":"#a7f3d0"};cursor:pointer;">🔲 DSA Presets (10)</button>
                  <button class="wb-preset-tab-btn" data-presettab="arch" style="font-size:9px;font-weight:700;padding:2px 6px;border-radius:3px;border:none;background:${this.wbPresetTab==="arch"?"#10b981":"rgba(255,255,255,0.08)"};color:${this.wbPresetTab==="arch"?"#fff":"#a7f3d0"};cursor:pointer;">🏛️ System Design (8)</button>
                </div>
                <div style="display:flex;gap:3px;overflow-x:auto;padding-bottom:2px;">
                  ${this.wbPresetTab==="dsa"?[{id:"two_pointers",label:"👆 Two Pointers"},{id:"bst",label:"🌲 BST Tree"},{id:"floyd_cycle",label:"🐢 Floyd Cycle"},{id:"mono_stack",label:"📥 Monotonic Stack"},{id:"dp_table",label:"📊 2D DP Table"},{id:"trie",label:"🌳 Prefix Trie"},{id:"graph_bfs",label:"🔵 Graph BFS"},{id:"min_heap",label:"🏔️ Min-Heap"},{id:"intervals",label:"📏 Intervals"},{id:"recursion_tree",label:"🌿 Recursion"}].map(d=>`
                    <button class="wb-stamp-preset-btn" data-preset="${d.id}" style="font-size:9px;padding:2px 5px;border-radius:3px;background:rgba(16,185,129,0.25);border:1px solid rgba(16,185,129,0.4);color:#fff;cursor:pointer;white-space:nowrap;">${d.label}</button>
                  `).join(""):[{id:"url_shortener",label:"🔗 TinyURL"},{id:"rate_limiter",label:"🚦 Rate Limiter"},{id:"chat_system",label:"💬 Chat System"},{id:"distributed_cache",label:"⚡ Dist. Cache"},{id:"ecommerce_saga",label:"🛒 Order Saga"},{id:"web_crawler",label:"🕷️ Web Crawler"},{id:"microservices_3tier",label:"🏛️ 3-Tier App"},{id:"search_analytics",label:"🔍 ES Cluster"}].map(d=>`
                    <button class="wb-stamp-preset-btn" data-preset="${d.id}" style="font-size:9px;padding:2px 5px;border-radius:3px;background:rgba(16,185,129,0.25);border:1px solid rgba(16,185,129,0.4);color:#fff;cursor:pointer;white-space:nowrap;">${d.label}</button>
                  `).join("")}
                </div>
              </div>
            `:""}

            <!-- Drawer: Style & Themes -->
            ${this.wbShowThemesDrawer?`
              <div class="wb-palette-bar" style="flex-wrap:wrap;gap:4px;">
                <div style="display:flex;gap:2px;align-items:center;overflow-x:auto;">
                  <button class="size-pill ${this.wbTheme==="grid"?"active":""}" data-wbtheme="grid">⬛ Grid</button>
                  <button class="size-pill ${this.wbTheme==="isometric"?"active":""}" data-wbtheme="isometric">📐 3D Iso</button>
                  <button class="size-pill ${this.wbTheme==="ruled"?"active":""}" data-wbtheme="ruled">📏 Ruled</button>
                  <button class="size-pill ${this.wbTheme==="plot"?"active":""}" data-wbtheme="plot">📈 Plot</button>
                  <button class="size-pill ${this.wbTheme==="matrix"?"active":""}" data-wbtheme="matrix">📊 Matrix</button>
                  <button class="size-pill ${this.wbTheme==="dotted"?"active":""}" data-wbtheme="dotted">🟦 Dots</button>
                  <button class="size-pill ${this.wbTheme==="blank"?"active":""}" data-wbtheme="blank">Blank</button>
                </div>

                <div style="display:flex;gap:3px;align-items:center;">
                  ${["#090d16","#0f172a","#062c24","#fef3c7","#ffffff","#1e1035"].map(d=>`
                    <div class="bg-dot" data-wbbg="${d}" style="width:10px;height:10px;border-radius:2px;background:${d};border:${this.wbBgColor===d?"2px solid #6366f1":"1px solid rgba(255,255,255,0.2)"};cursor:pointer;" title="Background Color"></div>
                  `).join("")}
                </div>

                <div style="display:flex;gap:4px;align-items:center;">
                  ${["#6366f1","#06b6d4","#10b981","#f59e0b","#f43f5e","#ffffff"].map(d=>`
                    <div class="color-dot ${this.wbColor===d?"active":""}" data-color="${d}" style="background:${d};"></div>
                  `).join("")}
                </div>

                <div style="display:flex;gap:2px;align-items:center;">
                  <button class="size-pill ${this.wbWidth===2?"active":""}" data-size="2">S</button>
                  <button class="size-pill ${this.wbWidth===4?"active":""}" data-size="4">M</button>
                  <button class="size-pill ${this.wbWidth===8?"active":""}" data-size="8">L</button>
                </div>
              </div>
            `:""}

            <!-- HTML5 Interactive Canvas -->
            <canvas id="nb-whiteboard-canvas"></canvas>
          </div>
        `:`
          <!-- Chat Messages View -->
          <div class="message-list" id="nb-messages">
            ${this.messages.length===0?`
              <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:100%;color:var(--text-muted);gap:8px;padding:30px 10px;text-align:center;">
                <div style="font-size:28px;">💬</div>
                <div style="font-size:13px;font-weight:600;color:var(--text-secondary);">No messages yet</div>
                <div style="font-size:11px;max-width:220px;">Say hello or ask for a hint! Messages are synchronized P2P across all peers.</div>
              </div>
            `:this.messages.map((d,k)=>{var y,x,$,_;return`
              <div class="chat-bubble ${d.isSelf?"self":"other"}">
                ${d.replyPreview?`<div style="border-left:2px solid var(--primary);padding-left:6px;margin-bottom:4px;font-size:10px;color:var(--text-muted);">${this.escapeHtml(d.replyPreview)}</div>`:""}
                
                <div class="chat-header">
                  <div class="chat-author">
                    <span>${((y=d.from)==null?void 0:y.avatar)||"👤"}</span>
                    <span style="color:${d.isSelf?"#ffffff":((x=d.from)==null?void 0:x.color)||"#a5b4fc"}">
                      ${d.isSelf?"You":(($=d.from)==null?void 0:$.nickname)||"Buddy"}
                    </span>
                  </div>
                  <div style="display:flex;align-items:center;gap:4px;">
                    <span class="chat-timestamp">${this.formatTimestamp(d.timestamp)}</span>
                    <button class="icon-btn nb-reply-trigger" data-id="${d.id}" data-text="${this.escapeHtml(d.text.slice(0,35))}" data-nick="${this.escapeHtml(((_=d.from)==null?void 0:_.nickname)||"Buddy")}" style="padding:0;width:18px;height:18px;" title="Reply">
                      ↩
                    </button>
                  </div>
                </div>

                <div class="chat-body">${this.renderFormattedText(d.text,k,d)}</div>

                ${d.isSelf?`
                  <div class="chat-footer">
                    ${d.status==="pending"?"<span>⏳</span>":""}
                    ${d.status==="sent"?'<span style="color:var(--text-dim);">✓</span>':""}
                    ${d.status==="delivered"?'<span style="color:var(--text-secondary);">✓✓</span>':""}
                    ${d.status==="read"?'<span class="ack-read">✓✓</span>':""}
                  </div>
                `:""}
              </div>
            `}).join("")}
          </div>

          <!-- Quick Strategy Prompt Pills -->
          <div class="prompt-pills-row">
            <button class="prompt-pill" data-text="⚡ O(N) Time">⚡ O(N) Time</button>
            <button class="prompt-pill" data-text="💾 O(1) Space">💾 O(1) Space</button>
            <button class="prompt-pill" data-text="👉 Two Pointers">👉 Two Pointers</button>
            <button class="prompt-pill" data-text="🔍 Binary Search">🔍 Binary Search</button>
            <button class="prompt-pill" data-text="🧠 DP / Memo">🧠 DP / Memo</button>
            <button class="prompt-pill" data-text="💡 Sliding Window">💡 Sliding Window</button>
          </div>

          <!-- Input Box & Composer -->
          <form class="composer-box" id="nb-composer">
            <button type="button" class="icon-btn" id="nb-spoiler-insert" title="Insert Spoiler Blur ||text||" style="width:28px;height:28px;flex-shrink:0;">
              👁️
            </button>
            <input type="text" class="input-glass" id="nb-input" placeholder="Type a hint, code snippet, or ||spoiler||..." />
            <button type="submit" class="btn-send">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <line x1="22" y1="2" x2="11" y2="13"></line>
                <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
              </svg>
            </button>
          </form>
        `}
      </div>

      <!-- Dedicated Standalone Focus Timer & Pomodoro Popup Window -->
      <div class="timer-popup-card" id="nb-timer-popup-card">
        <!-- Timer Header Bar -->
        <div style="display:flex;align-items:center;justify-content:space-between;padding:10px 14px;border-bottom:1px solid rgba(255,255,255,0.08);background:linear-gradient(135deg, rgba(30, 16, 53, 0.95), rgba(15, 23, 42, 0.95));">
          <div style="display:flex;align-items:center;gap:7px;">
            <span style="font-size:16px;">🍅</span>
            <div>
              <div style="font-size:12px;font-weight:700;color:#ffffff;line-height:1.2;">Focus Timer & Pomodoro</div>
              <div style="font-size:9.5px;color:#fca5a5;font-weight:600;text-transform:uppercase;">
                ${this.timerState.mode==="pomodoro"?"Deep Focus Session":this.timerState.mode==="short_break"?"Short Refresh Break":this.timerState.mode==="long_break"?"Extended Rest":"Open Stopwatch"}
              </div>
            </div>
          </div>
          <button class="icon-btn" id="nb-close-timer-popup" title="Minimize Timer" style="width:24px;height:24px;border-radius:6px;background:rgba(255,255,255,0.06);border:none;color:#94a3b8;cursor:pointer;display:flex;align-items:center;justify-content:center;">
            ✕
          </button>
        </div>

        <!-- Timer Body -->
        <div style="padding:16px 14px;display:flex;flex-direction:column;gap:14px;align-items:center;">
          <!-- Mode Switcher Pills -->
          <div style="display:flex;gap:4px;background:rgba(0,0,0,0.4);padding:3px;border-radius:8px;border:1px solid rgba(255,255,255,0.08);width:100%;justify-content:space-between;">
            <button class="timer-mode-btn ${this.timerState.mode==="pomodoro"?"active":""}" data-tmode="pomodoro" style="flex:1;font-size:10px;font-weight:700;padding:6px 2px;border-radius:6px;border:none;cursor:pointer;background:${this.timerState.mode==="pomodoro"?"#f43f5e":"transparent"};color:${this.timerState.mode==="pomodoro"?"#fff":"var(--text-muted)"};">🍅 Focus</button>
            <button class="timer-mode-btn ${this.timerState.mode==="short_break"?"active":""}" data-tmode="short_break" style="flex:1;font-size:10px;font-weight:700;padding:6px 2px;border-radius:6px;border:none;cursor:pointer;background:${this.timerState.mode==="short_break"?"#10b981":"transparent"};color:${this.timerState.mode==="short_break"?"#fff":"var(--text-muted)"};">☕ Break</button>
            <button class="timer-mode-btn ${this.timerState.mode==="long_break"?"active":""}" data-tmode="long_break" style="flex:1;font-size:10px;font-weight:700;padding:6px 2px;border-radius:6px;border:none;cursor:pointer;background:${this.timerState.mode==="long_break"?"#06b6d4":"transparent"};color:${this.timerState.mode==="long_break"?"#fff":"var(--text-muted)"};">🌴 Long</button>
            <button class="timer-mode-btn ${this.timerState.mode==="stopwatch"?"active":""}" data-tmode="stopwatch" style="flex:1;font-size:10px;font-weight:700;padding:6px 2px;border-radius:6px;border:none;cursor:pointer;background:${this.timerState.mode==="stopwatch"?"#8b5cf6":"transparent"};color:${this.timerState.mode==="stopwatch"?"#fff":"var(--text-muted)"};">⏱️ Clock</button>
          </div>

          <!-- Digital Clock Display & Rocket Racing Track -->
          <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;width:100%;padding:18px 12px;background:rgba(255,255,255,0.02);border:1px solid ${this.timerState.isRunning?this.timerState.mode==="pomodoro"?"#f43f5e50":this.timerState.mode==="short_break"?"#10b98150":this.timerState.mode==="long_break"?"#06b6d450":"#8b5cf650":"rgba(255,255,255,0.08)"};border-radius:14px;box-shadow:${this.timerState.isRunning?"0 10px 30px -10px rgba(0,0,0,0.8)":"none"};position:relative;overflow:hidden;box-sizing:border-box;">
            
            <!-- 🚀 Rocket Racing Progress Track -->
            <div style="width:100%;height:8px;background:rgba(255,255,255,0.08);position:relative;overflow:hidden;border-radius:4px;">
              <div id="nb-timer-progress-fill" style="height:100%;width:${this.getTimerProgressPct()}%;background:linear-gradient(90deg, #6366f1, ${this.timerState.mode==="pomodoro"?"#f43f5e":this.timerState.mode==="short_break"?"#10b981":this.timerState.mode==="long_break"?"#06b6d4":"#8b5cf6"});transition:width 0.4s ease;box-shadow:${this.timerState.isRunning?"0 0 10px rgba(244,63,94,0.8)":"none"};"></div>
              <div style="position:absolute;top:-4px;left:calc(${Math.min(94,Math.max(2,this.getTimerProgressPct()))}% - 8px);font-size:11px;pointer-events:none;transition:left 0.4s ease;">
                <span style="display:inline-block;animation:${this.timerState.isRunning?"rocketThrust 0.8s ease-in-out infinite alternate":"none"};">🚀</span>
              </div>
            </div>

            <div id="nb-timer-time" style="font-family:var(--font-mono);font-size:42px;font-weight:800;color:#ffffff;letter-spacing:-1px;line-height:1;margin-top:12px;">
              ${this.formatTimerTime(this.timerState.timeLeftSec)}
            </div>

            <!-- Racing Track Waypoints -->
            <div style="display:flex;justify-content:space-between;width:100%;font-size:9px;color:var(--text-muted);margin-top:8px;padding:0 2px;">
              <span>🛫 Launchpad</span>
              <span style="font-weight:700;color:#fca5a5;">${Math.round(this.getTimerProgressPct())}% Completed</span>
              <span>🏁 Goal</span>
            </div>

            ${this.timerState.sessionsCompleted>0?`
              <div style="display:flex;align-items:center;gap:4px;margin-top:8px;font-size:10px;padding:2px 8px;border-radius:10px;background:rgba(244,63,94,0.15);color:#f43f5e;font-weight:600;">
                <span>🎯</span>
                <span>${this.timerState.sessionsCompleted} Sessions Done</span>
              </div>
            `:""}
          </div>

          <!-- Timer Action Buttons -->
          <div style="display:flex;align-items:center;gap:8px;width:100%;">
            <button id="nb-timer-toggle" style="flex:2;display:flex;align-items:center;justify-content:center;gap:6px;padding:10px;border-radius:8px;border:none;background:${this.timerState.isRunning?"#ef4444":"linear-gradient(135deg, #4f46e5, #7c3aed)"};color:#ffffff;font-size:12px;font-weight:700;cursor:pointer;box-shadow:0 4px 15px rgba(99,102,241,0.4);">
              <span>${this.timerState.isRunning?"⏸ Pause":"▶ Start Focus"}</span>
            </button>
            <button id="nb-timer-add-1m" style="flex:1;padding:10px 4px;border-radius:8px;border:1px solid rgba(255,255,255,0.1);background:rgba(255,255,255,0.06);color:#f8fafc;font-size:11px;font-weight:600;cursor:pointer;" title="Add 1 minute">+1m</button>
            <button id="nb-timer-add-5m" style="flex:1;padding:10px 4px;border-radius:8px;border:1px solid rgba(255,255,255,0.1);background:rgba(255,255,255,0.06);color:#f8fafc;font-size:11px;font-weight:600;cursor:pointer;" title="Add 5 minutes">+5m</button>
            <button id="nb-timer-reset" style="padding:10px 12px;border-radius:8px;border:1px solid rgba(255,255,255,0.1);background:rgba(255,255,255,0.06);color:#f8fafc;font-size:12px;font-weight:600;cursor:pointer;" title="Reset Timer">🔄</button>
          </div>
        </div>
      </div>

      <!-- FAB Controls Row: Standalone Rocket Racing Timer FAB + Main Synqto FAB -->
      <div class="fab-row" style="display:flex;align-items:center;gap:8px;position:relative;">
        <!-- 1. Separate Standalone Rocket Racing Focus Timer FAB (Shown when timer is on/enabled) -->
        ${this.timerConfig.enabled||this.timerState.isRunning?`
          <button class="timer-fab-button" id="nb-timer-fab-trigger" title="Focus Timer (Click to open, click play icon to toggle)">
            <span style="font-size:13px;">${this.timerState.mode==="pomodoro"?"🍅":this.timerState.mode==="short_break"?"☕":this.timerState.mode==="long_break"?"🌴":"⏱️"}</span>
            <span class="timer-fab-rocket" style="animation:${this.timerState.isRunning?"rocketThrust 0.8s ease-in-out infinite alternate":"none"};">🚀</span>
            ${this.timerState.isRunning?'<span style="font-size:10px;margin-left:-5px;animation:flameFlicker 0.3s ease-in-out infinite alternate;">🔥</span>':""}
            <div class="timer-fab-track">
              <div id="nb-timer-fab-fill" class="timer-fab-fill" style="width:${this.getTimerProgressPct()}%;"></div>
            </div>
            <span id="nb-timer-fab-time" style="font-family:var(--font-mono);font-size:11px;font-weight:800;color:#ffffff;min-width:38px;">
              ${this.formatTimerTime(this.timerState.timeLeftSec)}
            </span>
            <span id="nb-timer-fab-toggle-btn" style="display:inline-flex;align-items:center;justify-content:center;width:22px;height:22px;border-radius:50%;background:${this.timerState.isRunning?"#ef4444":"rgba(255,255,255,0.15)"};color:#ffffff;font-size:9px;margin-left:2px;cursor:pointer;box-shadow:0 2px 6px rgba(0,0,0,0.3);" title="${this.timerState.isRunning?"Pause Timer":"Start Timer"}">
              ${this.timerState.isRunning?"⏸":"▶"}
            </span>
          </button>
        `:""}

        <!-- 2. Main Synqto App FAB -->
        <button class="fab-button" id="nb-fab-trigger" title="Drag anywhere or click to open Synqto">
          <span class="drag-grip">⠿</span>
          ${i?'<span class="live-dot"></span>':`<span>${n}</span>`}
          <span>${r}</span>
          ${this.unreadCount>0?`<span class="fab-badge">${this.unreadCount}</span>`:""}
        </button>
      </div>
    `,this.attachEventListeners(),s&&this.initWhiteboardCanvas()}attachEventListeners(){if(!this.shadow)return;const t=this.shadow.getElementById("nb-fab-trigger");if(t){let _=0,P=0,C=24,O=24;const h=m=>{if(!this.isDragging)return;const T="touches"in m?m.touches[0].clientX:m.clientX,E="touches"in m?m.touches[0].clientY:m.clientY,M=T-_,L=E-P;if(Math.hypot(M,L)>4){this.dragMoved=!0;const R=C-M,N=O-L;this.currentPosition={right:Math.max(10,Math.min(window.innerWidth-130,R)),bottom:Math.max(10,Math.min(window.innerHeight-55,N))},this.applyHostPosition()}},c=()=>{var m;if(this.isDragging&&(this.isDragging=!1,window.removeEventListener("mousemove",h),window.removeEventListener("mouseup",c),window.removeEventListener("touchmove",h),window.removeEventListener("touchend",c),this.dragMoved)){if(this.settings.positionMode==="permanent"){const T={...this.settings,savedPosition:{...this.currentPosition}};this.settings=T,typeof chrome<"u"&&((m=chrome.storage)!=null&&m.local)&&chrome.storage.local.set({[D]:T})}setTimeout(()=>{this.dragMoved=!1},60)}},b=m=>{this.isDragging=!0,this.dragMoved=!1,_="touches"in m?m.touches[0].clientX:m.clientX,P="touches"in m?m.touches[0].clientY:m.clientY,C=this.currentPosition.right,O=this.currentPosition.bottom,window.addEventListener("mousemove",h,{passive:!0}),window.addEventListener("mouseup",c),window.addEventListener("touchmove",h,{passive:!0}),window.addEventListener("touchend",c)};t.addEventListener("mousedown",b),t.addEventListener("touchstart",b,{passive:!0}),t.addEventListener("click",()=>{var m;if(!this.dragMoved){if(this.settings.clickAction==="open_extension"){typeof chrome<"u"&&((m=chrome.runtime)!=null&&m.sendMessage)&&chrome.runtime.sendMessage({type:"OPEN_SIDEPANEL"}).catch(()=>{});return}this.isOpen=!this.isOpen,this.unreadCount=0,this.render(),this.isOpen&&this.activeTab==="chat"&&this.scrollToBottom()}})}const i=this.shadow.getElementById("nb-timer-fab-trigger"),o=this.shadow.getElementById("nb-timer-fab-toggle-btn");o==null||o.addEventListener("click",_=>{_.stopPropagation(),this.toggleTimer()}),i==null||i.addEventListener("click",()=>{this.isTimerOpen=!this.isTimerOpen,this.render()});const e=this.shadow.getElementById("nb-close-timer-popup");e==null||e.addEventListener("click",()=>{this.isTimerOpen=!1,this.render()}),this.shadow.querySelectorAll(".size-mode-pill[data-popsize]").forEach(_=>{_.addEventListener("click",P=>{const C=P.currentTarget.getAttribute("data-popsize");C&&(this.popupSize=C,this.render())})});const l=this.shadow.getElementById("nb-close-popup");l==null||l.addEventListener("click",()=>{this.isOpen=!1,this.render()});const s=this.shadow.getElementById("nb-open-sidepanel");s==null||s.addEventListener("click",()=>{var _;this.isOpen=!1,this.render(),typeof chrome<"u"&&((_=chrome.runtime)!=null&&_.sendMessage)&&chrome.runtime.sendMessage({type:"OPEN_SIDEPANEL"}).catch(()=>{})});const n=this.shadow.getElementById("nb-tab-chat");n==null||n.addEventListener("click",()=>{this.activeTab="chat",this.render(),this.scrollToBottom()});const r=this.shadow.getElementById("nb-tab-whiteboard");r==null||r.addEventListener("click",()=>{this.activeTab="whiteboard",this.render()});const p=this.shadow.getElementById("nb-timer-toggle");p==null||p.addEventListener("click",()=>{this.toggleTimer()});const f=this.shadow.getElementById("nb-timer-reset");f==null||f.addEventListener("click",()=>{this.resetTimer()});const w=this.shadow.getElementById("nb-timer-add-1m");w==null||w.addEventListener("click",()=>{this.addTimerTime(60)});const g=this.shadow.getElementById("nb-timer-add-5m");g==null||g.addEventListener("click",()=>{this.addTimerTime(300)}),this.shadow.querySelectorAll(".timer-mode-btn[data-tmode]").forEach(_=>{_.addEventListener("click",P=>{const C=P.currentTarget.getAttribute("data-tmode");C&&this.setTimerMode(C)})});const u=this.shadow.getElementById("nb-live-tunein");u==null||u.addEventListener("click",()=>{var _;this.isOpen=!1,this.render(),typeof chrome<"u"&&((_=chrome.runtime)!=null&&_.sendMessage)&&chrome.runtime.sendMessage({type:"OPEN_SIDEPANEL"}).catch(()=>{})});const d=this.shadow.getElementById("nb-offline-sidepanel-reconnect");d==null||d.addEventListener("click",()=>{var _;this.isOpen=!1,this.render(),typeof chrome<"u"&&((_=chrome.runtime)!=null&&_.sendMessage)&&chrome.runtime.sendMessage({type:"OPEN_SIDEPANEL"}).catch(()=>{})}),this.shadow.querySelectorAll(".prompt-pill").forEach(_=>{_.addEventListener("click",P=>{const C=P.target.getAttribute("data-text");C&&this.sendMessage(C)})});const y=this.shadow.getElementById("nb-spoiler-insert"),x=this.shadow.getElementById("nb-input");if(y==null||y.addEventListener("click",()=>{x&&(x.value=`${x.value}||hint solution||`,x.focus())}),x){const _=P=>P.stopPropagation();x.addEventListener("keydown",_),x.addEventListener("keyup",_),x.addEventListener("keypress",_)}const $=this.shadow.getElementById("nb-composer");$==null||$.addEventListener("submit",_=>{_.preventDefault();const P=x==null?void 0:x.value.trim();P&&(this.sendMessage(P,this.replyingTo?{id:this.replyingTo.id,preview:`${this.replyingTo.from.nickname}: ${this.replyingTo.text.slice(0,30)}`}:void 0),x&&(x.value=""),this.replyingTo=null)})}initWhiteboardCanvas(){var u,d,k,y,x,$,_,P,C,O;if(!this.shadow)return;const t=this.shadow.getElementById("nb-whiteboard-canvas");if(!t)return;this.shadow.querySelectorAll(".wb-tool-btn[data-wbtool]").forEach(h=>{h.addEventListener("click",c=>{const b=c.currentTarget.getAttribute("data-wbtool");if(b){this.wbTool=b;const m=this.toolStyles[b]||{color:"#6366f1",width:3};this.wbColor=m.color,this.wbWidth=m.width,this.render()}})});const o=h=>{this.wbShowShapesDrawer=h==="shapes"?!this.wbShowShapesDrawer:!1,this.wbShowDsaDrawer=h==="dsa"?!this.wbShowDsaDrawer:!1,this.wbShowArchDrawer=h==="arch"?!this.wbShowArchDrawer:!1,this.wbShowPresetsDrawer=h==="presets"?!this.wbShowPresetsDrawer:!1,this.wbShowThemesDrawer=h==="themes"?!this.wbShowThemesDrawer:!1,this.render()};(u=this.shadow.getElementById("nb-wb-toggle-shapes"))==null||u.addEventListener("click",()=>o("shapes")),(d=this.shadow.getElementById("nb-wb-toggle-dsa"))==null||d.addEventListener("click",()=>o("dsa")),(k=this.shadow.getElementById("nb-wb-toggle-arch"))==null||k.addEventListener("click",()=>o("arch")),(y=this.shadow.getElementById("nb-wb-toggle-presets"))==null||y.addEventListener("click",()=>o("presets")),(x=this.shadow.getElementById("nb-wb-toggle-themes"))==null||x.addEventListener("click",()=>o("themes")),this.shadow.querySelectorAll(".wb-preset-tab-btn[data-presettab]").forEach(h=>{h.addEventListener("click",c=>{const b=c.currentTarget.getAttribute("data-presettab");b&&(this.wbPresetTab=b,this.render())})}),this.shadow.querySelectorAll(".wb-stamp-preset-btn[data-preset]").forEach(h=>{h.addEventListener("click",c=>{const b=c.currentTarget.getAttribute("data-preset");b&&this.handleStampPreset(b)})}),($=this.shadow.getElementById("nb-wb-popout"))==null||$.addEventListener("click",()=>{var h,c;typeof chrome<"u"&&((h=chrome.windows)!=null&&h.create)?chrome.windows.create({url:chrome.runtime.getURL("sidepanel.html?view=whiteboard"),type:"popup",width:900,height:650}):typeof chrome<"u"&&((c=chrome.runtime)!=null&&c.sendMessage)&&chrome.runtime.sendMessage({type:"OPEN_STANDALONE_WHITEBOARD"}).catch(()=>{})}),this.shadow.querySelectorAll(".wb-privacy-btn[data-wbprivacy]").forEach(h=>{h.addEventListener("click",c=>{const b=c.currentTarget.getAttribute("data-wbprivacy");b&&(this.wbPrivacyMode=b,this.render())})}),this.shadow.querySelectorAll(".size-pill[data-wbtheme]").forEach(h=>{h.addEventListener("click",c=>{var m;const b=c.currentTarget.getAttribute("data-wbtheme");b&&(this.wbTheme=b,b==="clean_white"&&this.wbColor==="#ffffff"&&(this.wbColor="#0f172a"),typeof chrome<"u"&&((m=chrome.runtime)!=null&&m.sendMessage)&&this.wbPrivacyMode==="collaborative"&&chrome.runtime.sendMessage({type:"WHITEBOARD_BG_LOCAL",background:b,bgColor:this.wbBgColor}).catch(()=>{}),this.render())})}),this.shadow.querySelectorAll(".bg-dot[data-wbbg]").forEach(h=>{h.addEventListener("click",c=>{var m;const b=c.currentTarget.getAttribute("data-wbbg");b&&(this.wbBgColor=b,typeof chrome<"u"&&((m=chrome.runtime)!=null&&m.sendMessage)&&this.wbPrivacyMode==="collaborative"&&chrome.runtime.sendMessage({type:"WHITEBOARD_BG_LOCAL",background:this.wbTheme,bgColor:b}).catch(()=>{}),this.render())})}),this.shadow.querySelectorAll(".color-dot").forEach(h=>{h.addEventListener("click",c=>{const b=c.currentTarget.getAttribute("data-color");b&&(this.wbColor=b,this.toolStyles[this.wbTool]&&(this.toolStyles[this.wbTool].color=b),this.render())})}),this.shadow.querySelectorAll(".size-pill[data-size]").forEach(h=>{h.addEventListener("click",c=>{const b=Number(c.currentTarget.getAttribute("data-size"));b&&(this.wbWidth=b,this.toolStyles[this.wbTool]&&(this.toolStyles[this.wbTool].width=b),this.render())})}),(_=this.shadow.getElementById("nb-wb-undo"))==null||_.addEventListener("click",()=>{var c;const h=this.wbPrivacyMode==="personal"?this.wbPersonalStrokes:this.wbStrokes;if(h.length===0&&this.wbRedoStack.length>0){this.wbPrivacyMode==="personal"?this.wbPersonalStrokes=[...this.wbRedoStack]:(this.wbStrokes=[...this.wbRedoStack],this.wbStrokes.forEach(b=>{var m;typeof chrome<"u"&&((m=chrome.runtime)!=null&&m.sendMessage)&&chrome.runtime.sendMessage({type:"WHITEBOARD_STROKE_LOCAL",stroke:b}).catch(()=>{})})),this.wbRedoStack=[],this.drawWbCanvas();return}if(h.length>0){const b=h.pop();b&&(this.wbRedoStack.push(b),this.drawWbCanvas(),this.wbPrivacyMode==="collaborative"&&typeof chrome<"u"&&((c=chrome.runtime)!=null&&c.sendMessage)&&chrome.runtime.sendMessage({type:"WHITEBOARD_UNDO_LOCAL",strokeId:b.id}).catch(()=>{}))}}),(P=this.shadow.getElementById("nb-wb-redo"))==null||P.addEventListener("click",()=>{var h;if(this.wbRedoStack.length>0){const c=this.wbRedoStack.pop();c&&((this.wbPrivacyMode==="personal"?this.wbPersonalStrokes:this.wbStrokes).push(c),this.drawWbCanvas(),this.wbPrivacyMode==="collaborative"&&typeof chrome<"u"&&((h=chrome.runtime)!=null&&h.sendMessage)&&chrome.runtime.sendMessage({type:"WHITEBOARD_STROKE_LOCAL",stroke:c}).catch(()=>{}))}}),(C=this.shadow.getElementById("nb-wb-clear"))==null||C.addEventListener("click",()=>{var c;const h=this.wbPrivacyMode==="personal"?this.wbPersonalStrokes:this.wbStrokes;h.length!==0&&(this.wbRedoStack=[...h],this.wbPrivacyMode==="personal"?this.wbPersonalStrokes=[]:(this.wbStrokes=[],typeof chrome<"u"&&((c=chrome.runtime)!=null&&c.sendMessage)&&chrome.runtime.sendMessage({type:"WHITEBOARD_CLEAR_LOCAL"}).catch(()=>{})),this.drawWbCanvas())}),(O=this.shadow.getElementById("nb-wb-save"))==null||O.addEventListener("click",()=>{const h=t.toDataURL("image/png"),c=document.createElement("a");c.download=`synqto-whiteboard-${Date.now()}.png`,c.href=h,c.click()}),setTimeout(()=>{const h=t.getBoundingClientRect(),c=window.devicePixelRatio||1;t.width=(h.width||380)*c,t.height=(h.height||360)*c;const b=t.getContext("2d");b&&b.scale(c,c),this.drawWbCanvas()},30);const f=h=>{const c=t.getBoundingClientRect();let b=0,m=0;return"touches"in h&&h.touches.length>0?(b=h.touches[0].clientX,m=h.touches[0].clientY):"clientX"in h&&(b=h.clientX,m=h.clientY),{x:b-c.left,y:m-c.top}},w=h=>["line","arrow","arrow_bi","rect","rounded_rect","circle","triangle","star","decision_diamond","tree_node","sticky_note","text","code_box","db_cylinder","db_nosql","cloud","cdn_edge","object_storage","auth_jwt","websocket_gw","elasticsearch","load_balancer","message_queue","server_box","cache_mem","dns_router","firewall","user_client","mobile_client","async_arrow","tradeoff_note","array_cells","two_pointers","stack_lifo","queue_fifo","hashmap_table"].includes(h),g=(h,c,b)=>{if(h.geometry){const{x1:m,y1:T,x2:E,y2:M}=h.geometry,L=Math.min(m,E)-b,R=Math.max(m,E)+b,N=Math.min(T,M)-b,te=Math.max(T,M)+b;return c.x>=L&&c.x<=R&&c.y>=N&&c.y<=te}if(h.points&&h.points.length>0){const m=b+h.width/2;return h.points.some(T=>Math.hypot(T.x-c.x,T.y-c.y)<=m)}return!1};t.addEventListener("mousedown",h=>{const c=f(h);if(this.wbTool==="eraser"){this.isWbDrawing=!0,this.wbEraserPos=c;const b=(this.wbWidth||4)*3,m=this.wbPrivacyMode==="personal"?this.wbPersonalStrokes:this.wbStrokes,T=m.filter(E=>!g(E,c,b));if(T.length!==m.length){const E=m.filter(M=>g(M,c,b));this.wbRedoStack.push(...E),this.wbPrivacyMode==="personal"?this.wbPersonalStrokes=T:(this.wbStrokes=T,E.forEach(M=>{var L;typeof chrome<"u"&&((L=chrome.runtime)!=null&&L.sendMessage)&&chrome.runtime.sendMessage({type:"WHITEBOARD_UNDO_LOCAL",strokeId:M.id}).catch(()=>{})}))}this.drawWbCanvas();return}if(this.wbTool==="laser"){this.wbLaserTrails.push({x:c.x,y:c.y,alpha:1,timestamp:Date.now()}),this.drawWbCanvas();return}if(this.wbTool==="torch"){this.wbTorchPos=c,this.drawWbCanvas();return}this.isWbDrawing=!0,this.wbStartPoint=c,this.wbCurrentPoints=[c]}),t.addEventListener("mousemove",h=>{const c=f(h);if(this.wbTool==="eraser"){if(this.wbEraserPos=c,this.isWbDrawing){const m=(this.wbWidth||4)*3,T=this.wbPrivacyMode==="personal"?this.wbPersonalStrokes:this.wbStrokes,E=T.filter(M=>!g(M,c,m));if(E.length!==T.length){const M=T.filter(L=>g(L,c,m));this.wbRedoStack.push(...M),this.wbPrivacyMode==="personal"?this.wbPersonalStrokes=E:(this.wbStrokes=E,M.forEach(L=>{var R;typeof chrome<"u"&&((R=chrome.runtime)!=null&&R.sendMessage)&&chrome.runtime.sendMessage({type:"WHITEBOARD_UNDO_LOCAL",strokeId:L.id}).catch(()=>{})}))}}this.drawWbCanvas();return}if(this.wbTool==="laser"){this.wbLaserTrails.push({x:c.x,y:c.y,alpha:1,timestamp:Date.now()}),this.drawWbCanvas();return}if(this.wbTool==="torch"){this.wbTorchPos=c,this.drawWbCanvas();return}if(!this.isWbDrawing)return;w(this.wbTool)&&this.wbStartPoint?this.drawWbCanvas(void 0,{x1:this.wbStartPoint.x,y1:this.wbStartPoint.y,x2:c.x,y2:c.y}):(this.wbCurrentPoints.push(c),this.drawWbCanvas(this.wbCurrentPoints))});const S=h=>{var E;if(this.wbTool==="eraser"){this.isWbDrawing=!1,this.wbEraserPos=null,this.drawWbCanvas();return}if(this.wbTool==="torch"){this.wbTorchPos=null,this.drawWbCanvas();return}if(!this.isWbDrawing)return;this.isWbDrawing=!1;const c=f(h),b=w(this.wbTool),m=this.wbTool==="highlighter"?16:this.wbWidth,T={id:"stroke-"+Math.random().toString(36).slice(2,10),tool:this.wbTool,color:this.wbColor,width:m,opacity:this.wbTool==="highlighter"?.35:1,points:b?[]:[...this.wbCurrentPoints],geometry:b&&this.wbStartPoint?{x1:this.wbStartPoint.x,y1:this.wbStartPoint.y,x2:c.x,y2:c.y}:void 0};this.wbTool==="temp_pen"?this.tempDisappearingStrokes.push({stroke:T,createdAt:Date.now(),durationMs:3e3}):this.wbPrivacyMode==="personal"?this.wbPersonalStrokes.push(T):(this.wbStrokes.push(T),typeof chrome<"u"&&((E=chrome.runtime)!=null&&E.sendMessage)&&chrome.runtime.sendMessage({type:"WHITEBOARD_STROKE_LOCAL",stroke:T}).catch(()=>{})),this.wbRedoStack=[],this.wbCurrentPoints=[],this.wbStartPoint=null,this.drawWbCanvas()};t.addEventListener("mouseup",S),t.addEventListener("mouseleave",S)}drawWbCanvas(t,i){if(!this.shadow)return;const o=this.shadow.getElementById("nb-whiteboard-canvas");if(!o)return;const e=o.getContext("2d");if(!e)return;e.clearRect(0,0,o.width,o.height),e.save();const a=this.wbBgColor==="#ffffff"||this.wbBgColor==="#f8fafc"||this.wbBgColor==="#fef3c7";if(e.fillStyle=this.wbBgColor||(a?"#f8fafc":"#090d16"),e.fillRect(0,0,o.width,o.height),this.wbTheme==="ruled"){e.strokeStyle="rgba(99, 102, 241, 0.18)",e.lineWidth=1;for(let r=28;r<o.height;r+=24)e.beginPath(),e.moveTo(0,r),e.lineTo(o.width,r),e.stroke();e.strokeStyle="rgba(244, 63, 94, 0.4)",e.lineWidth=1.5,e.beginPath(),e.moveTo(40,0),e.lineTo(40,o.height),e.stroke()}else if(this.wbTheme==="plot"){const r=Math.floor(o.width/2),p=Math.floor(o.height/2);e.strokeStyle="#6366f1",e.lineWidth=1.5,e.beginPath(),e.moveTo(0,p),e.lineTo(o.width,p),e.moveTo(r,0),e.lineTo(r,o.height),e.stroke()}else if(this.wbTheme==="dotted"){e.fillStyle="rgba(255, 255, 255, 0.16)";for(let r=8;r<o.width;r+=18)for(let p=8;p<o.height;p+=18)e.beginPath(),e.arc(r,p,1.2,0,Math.PI*2),e.fill()}else if(this.wbTheme==="matrix"){e.strokeStyle="rgba(99, 102, 241, 0.15)",e.lineWidth=1;const r=26;for(let p=0;p<o.width;p+=r)e.beginPath(),e.moveTo(p,0),e.lineTo(p,o.height),e.stroke();for(let p=0;p<o.height;p+=r)e.beginPath(),e.moveTo(0,p),e.lineTo(o.width,p),e.stroke()}else if(this.wbTheme==="grid"){e.strokeStyle="rgba(255, 255, 255, 0.04)",e.lineWidth=1;const r=20;for(let p=0;p<o.width;p+=r)e.beginPath(),e.moveTo(p,0),e.lineTo(p,o.height),e.stroke();for(let p=0;p<o.height;p+=r)e.beginPath(),e.moveTo(0,p),e.lineTo(o.width,p),e.stroke()}if(e.restore(),this.wbTool==="eraser"&&this.wbEraserPos){e.save();const r=(this.wbWidth||4)*3;e.strokeStyle="#ef4444",e.lineWidth=1.5,e.setLineDash([3,3]),e.beginPath(),e.arc(this.wbEraserPos.x,this.wbEraserPos.y,r,0,Math.PI*2),e.stroke(),e.restore()}const l=r=>{if(r.tool==="eraser")return;e.save();let p=r.color;if(this.wbTheme==="white_blank"&&(p==="#ffffff"||p==="#fff")&&(p="#0f172a"),e.strokeStyle=p,e.fillStyle=p,e.lineWidth=r.width,e.lineCap="round",e.lineJoin="round",e.globalAlpha=r.opacity,r.geometry){const{x1:f,y1:w,x2:g,y2:S}=r.geometry;if(r.tool==="line")e.beginPath(),e.moveTo(f,w),e.lineTo(g,S),e.stroke();else if(r.tool==="arrow"){e.beginPath(),e.moveTo(f,w),e.lineTo(g,S),e.stroke();const u=Math.atan2(S-w,g-f),d=Math.max(10,r.width*3);e.beginPath(),e.moveTo(g,S),e.lineTo(g-d*Math.cos(u-Math.PI/6),S-d*Math.sin(u-Math.PI/6)),e.moveTo(g,S),e.lineTo(g-d*Math.cos(u+Math.PI/6),S-d*Math.sin(u+Math.PI/6)),e.stroke()}else if(r.tool==="rect")e.strokeRect(Math.min(f,g),Math.min(w,S),Math.abs(g-f),Math.abs(S-w));else if(r.tool==="circle"){const u=Math.abs(g-f)/2,d=Math.abs(S-w)/2;e.beginPath(),e.ellipse(Math.min(f,g)+u,Math.min(w,S)+d,u,d,0,0,Math.PI*2),e.stroke()}else if(r.tool==="tree_node"){const u=Math.max(16,r.width*3.5);e.beginPath(),e.arc(f,w,u,0,Math.PI*2),e.fillStyle="rgba(15, 23, 42, 0.9)",e.fill(),e.stroke(),r.geometry.label&&(e.fillStyle="#ffffff",e.font="bold 11px monospace",e.textAlign="center",e.textBaseline="middle",e.fillText(r.geometry.label,f,w))}else if(r.tool==="db_cylinder"){const u=Math.max(50,Math.abs(g-f)),d=Math.max(55,Math.abs(S-w)),k=Math.min(f,g),y=Math.min(w,S),x=Math.min(14,d*.2);e.fillStyle="rgba(15, 23, 42, 0.95)",e.beginPath(),e.ellipse(k+u/2,y+x,u/2,x,0,Math.PI,0),e.lineTo(k+u,y+d-x),e.ellipse(k+u/2,y+d-x,u/2,x,0,0,Math.PI),e.lineTo(k,y+x),e.fill(),e.stroke(),e.beginPath(),e.ellipse(k+u/2,y+x,u/2,x,0,0,Math.PI*2),e.stroke(),r.geometry.label&&(e.fillStyle="#ffffff",e.font="bold 10px sans-serif",e.textAlign="center",e.textBaseline="middle",e.fillText(r.geometry.label,k+u/2,y+d/2+4))}else if(r.tool==="cloud"){const u=Math.max(65,Math.abs(g-f)),d=Math.max(40,Math.abs(S-w)),k=Math.min(f,g),y=Math.min(w,S);e.fillStyle="rgba(15, 23, 42, 0.95)",e.beginPath(),e.roundRect(k,y,u,d,14),e.fill(),e.stroke(),r.geometry.label&&(e.fillStyle="#ffffff",e.font="bold 10px sans-serif",e.textAlign="center",e.textBaseline="middle",e.fillText(r.geometry.label,k+u/2,y+d/2))}else if(r.tool==="load_balancer"){const u=Math.max(55,Math.abs(g-f)),d=Math.max(55,Math.abs(S-w)),k=Math.min(f,g),y=Math.min(w,S),x=k+u/2,$=y+d/2;e.fillStyle="rgba(15, 23, 42, 0.95)",e.beginPath(),e.moveTo(x,y),e.lineTo(k+u,$),e.lineTo(x,y+d),e.lineTo(k,$),e.closePath(),e.fill(),e.stroke(),r.geometry.label&&(e.fillStyle="#ffffff",e.font="bold 10px sans-serif",e.textAlign="center",e.textBaseline="middle",e.fillText(r.geometry.label,x,$))}else if(r.tool==="message_queue"){const u=Math.max(70,Math.abs(g-f)),d=Math.max(34,Math.abs(S-w)),k=Math.min(f,g),y=Math.min(w,S);e.fillStyle="rgba(15, 23, 42, 0.95)",e.beginPath(),e.roundRect(k,y,u,d,6),e.fill(),e.stroke(),r.geometry.label&&(e.fillStyle="#ffffff",e.font="bold 9px sans-serif",e.textAlign="center",e.textBaseline="middle",e.fillText(r.geometry.label,k+u/2,y+d/2))}else if(r.tool==="server_box"){const u=Math.max(65,Math.abs(g-f)),d=Math.max(40,Math.abs(S-w)),k=Math.min(f,g),y=Math.min(w,S);e.fillStyle="rgba(15, 23, 42, 0.95)",e.beginPath(),e.roundRect(k,y,u,d,6),e.fill(),e.stroke(),e.fillStyle="#10b981",e.beginPath(),e.arc(k+10,y+10,3,0,Math.PI*2),e.fill(),r.geometry.label&&(e.fillStyle="#ffffff",e.font="bold 9px sans-serif",e.textAlign="center",e.textBaseline="middle",e.fillText(r.geometry.label,k+u/2,y+d/2+2))}}else if(r.points&&r.points.length>0)if(r.points.length===1)e.beginPath(),e.arc(r.points[0].x,r.points[0].y,r.width/2,0,Math.PI*2),e.fill();else{e.beginPath(),e.moveTo(r.points[0].x,r.points[0].y);for(let f=1;f<r.points.length-1;f++){const w=(r.points[f].x+r.points[f+1].x)/2,g=(r.points[f].y+r.points[f+1].y)/2;e.quadraticCurveTo(r.points[f].x,r.points[f].y,w,g)}e.lineTo(r.points[r.points.length-1].x,r.points[r.points.length-1].y),e.stroke()}e.restore()};(this.wbPrivacyMode==="personal"?this.wbPersonalStrokes:this.wbStrokes).forEach(l);const n=Date.now();this.tempDisappearingStrokes.forEach(r=>{const p=Math.max(0,1-(n-r.createdAt)/r.durationMs);l({...r.stroke,opacity:p})}),i?l({tool:this.wbTool,color:this.wbColor,width:this.wbTool==="highlighter"?14:this.wbWidth,opacity:this.wbTool==="highlighter"?.35:1,points:[],geometry:i}):t&&t.length>1&&l({tool:this.wbTool,color:this.wbColor,width:this.wbTool==="highlighter"?14:this.wbWidth,opacity:this.wbTool==="highlighter"?.35:1,points:t}),this.wbTool==="torch"&&this.wbTorchPos&&(e.save(),e.fillStyle="rgba(0, 0, 0, 0.75)",e.fillRect(0,0,o.width,o.height),e.globalCompositeOperation="destination-out",e.beginPath(),e.arc(this.wbTorchPos.x,this.wbTorchPos.y,55,0,Math.PI*2),e.fill(),e.globalCompositeOperation="source-over",e.strokeStyle="rgba(253, 224, 71, 0.85)",e.lineWidth=2.5,e.shadowColor="#fde047",e.shadowBlur=10,e.beginPath(),e.arc(this.wbTorchPos.x,this.wbTorchPos.y,55,0,Math.PI*2),e.stroke(),e.restore()),this.wbLaserTrails.forEach(r=>{e.save(),e.globalAlpha=r.alpha,e.fillStyle="#ef4444",e.shadowColor="#ef4444",e.shadowBlur=8,e.beginPath(),e.arc(r.x,r.y,4.5*r.alpha,0,Math.PI*2),e.fill(),e.restore()})}listenForRuntimeMessages(){var t;typeof chrome<"u"&&((t=chrome.runtime)!=null&&t.onMessage)&&chrome.runtime.onMessage.addListener(i=>{i.type==="FAB_SETTINGS_UPDATED"&&i.payload?(this.settings={...q,...i.payload},this.settings.positionMode==="permanent"&&this.settings.savedPosition&&(this.currentPosition={...this.settings.savedPosition}),this.checkVisibilityAndRender(),this.hostElement&&this.render()):i.type==="WHITEBOARD_STROKE_LOCAL"&&i.stroke?this.wbStrokes.some(o=>o.id===i.stroke.id)||(this.wbStrokes.push(i.stroke),this.activeTab==="whiteboard"&&this.drawWbCanvas()):i.type==="WHITEBOARD_CLEAR_LOCAL"?(this.wbStrokes=[],this.wbRedoStack=[],this.activeTab==="whiteboard"&&this.drawWbCanvas()):i.type==="WHITEBOARD_UNDO_LOCAL"&&i.strokeId&&(this.wbStrokes=this.wbStrokes.filter(o=>o.id!==i.strokeId),this.activeTab==="whiteboard"&&this.drawWbCanvas())})}escapeHtml(t){return t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}formatTimestamp(t){return new Date(t).toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"})}renderFormattedText(t,i,o){let e="";o!=null&&o.imageUrl&&(e+=`
        <div style="margin:4px 0;border-radius:6px;overflow:hidden;border:1px solid rgba(255,255,255,0.1);">
          <img src="${o.imageUrl}" alt="Shared image" style="width:100%;max-height:180px;object-fit:cover;display:block;" />
        </div>
      `);const l=t.split(`
`).map((s,n)=>{if(s.startsWith("```")&&s.endsWith("```")&&s.length>6){const r=s.slice(3,-3);return`
          <div style="background:rgba(0,0,0,0.45);padding:6px 8px;border-radius:6px;margin:4px 0;font-family:var(--font-mono);font-size:11px;position:relative;">
            <pre style="margin:0;white-space:pre-wrap;word-break:break-all;">${this.escapeHtml(r)}</pre>
          </div>
        `}return s.includes("||")?`<p style="margin:2px 0;">${s.split(/(\|\|.*?\|\|)/g).map((f,w)=>{if(f.startsWith("||")&&f.endsWith("||")&&f.length>4){const g=f.slice(2,-2),S=`${i}-${n}-${w}`,u=!!this.revealedSpoilers[S];return`
              <span style="display:inline-block;padding:1px 6px;border-radius:4px;background:${u?"rgba(99, 102, 241, 0.25)":"rgba(255, 255, 255, 0.15)"};filter:${u?"none":"blur(4px)"};cursor:pointer;">
                ${this.escapeHtml(g)}
              </span>
            `}return this.renderMentionsHtml(this.escapeHtml(f))}).join("")}</p>`:`<p style="margin:2px 0;">${this.renderMentionsHtml(this.escapeHtml(s))}</p>`}).join("");return e+l}renderMentionsHtml(t){return t.includes("@")?t.replace(/(@everyone|@all)/g,'<span style="background:rgba(245,158,11,0.25);border:1px solid rgba(245,158,11,0.5);color:#fbbf24;padding:1px 4px;border-radius:3px;font-weight:700;font-size:10px;">📣 $1</span>').replace(/(@[a-zA-Z0-9_-]+)/g,'<span style="background:rgba(99,102,241,0.25);border:1px solid rgba(99,102,241,0.4);color:#c7d2fe;padding:1px 4px;border-radius:3px;font-weight:600;font-size:10px;">$1</span>'):t}deduplicateMessages(t){var e,a;const i=new Set,o=[];for(const l of t)!l||!l.id||i.has(l.id)||(i.add(l.id),o.push({...l,isSelf:((e=l.from)==null?void 0:e.peerId)===((a=this.myIdentity)==null?void 0:a.peerId)||l.isSelf}));return o}async sendMessage(t,i){var l,s,n,r;if(!t.trim())return;!this.currentRoomStorageKey&&((l=this.currentProblem)!=null&&l.roomId)&&(this.currentRoomStorageKey=`synqto_chat_${this.currentProblem.roomId}`);const o=t.trim(),e="msg-"+Math.random().toString(36).slice(2,10)+Date.now(),a={id:e,from:this.myIdentity||{nickname:"You",avatar:"⚡",color:"#6366f1",peerId:"self"},text:o,timestamp:Date.now(),replyTo:i==null?void 0:i.id,replyPreview:i==null?void 0:i.preview,status:"sent",isSelf:!0};if(this.messages.push(a),this.messages=this.deduplicateMessages(this.messages),this.render(),this.scrollToBottom(),this.currentRoomStorageKey&&typeof chrome<"u"&&((s=chrome.storage)!=null&&s.local))try{const p=await chrome.storage.local.get([this.currentRoomStorageKey]),f=p[this.currentRoomStorageKey]&&Array.isArray(p[this.currentRoomStorageKey])?p[this.currentRoomStorageKey]:[],w=this.deduplicateMessages([...f,a]).slice(-150);await chrome.storage.local.set({[this.currentRoomStorageKey]:w})}catch{}typeof chrome<"u"&&((n=chrome.runtime)!=null&&n.sendMessage)&&chrome.runtime.sendMessage({type:"SEND_PAGE_CHAT_MESSAGE",messageId:e,text:a.text,replyTo:a.replyTo,replyPreview:a.replyPreview,roomId:(r=this.currentProblem)==null?void 0:r.roomId}).catch(()=>{})}async loadMessages(){var t;if(this.currentRoomStorageKey&&typeof chrome<"u"&&(t=chrome.storage)!=null&&t.local){const i=await chrome.storage.local.get([this.currentRoomStorageKey]);i[this.currentRoomStorageKey]&&Array.isArray(i[this.currentRoomStorageKey])&&(this.messages=this.deduplicateMessages(i[this.currentRoomStorageKey]),this.isOpen&&this.activeTab==="chat"&&(this.render(),this.scrollToBottom()))}}scrollToBottom(){setTimeout(()=>{var i;const t=(i=this.shadow)==null?void 0:i.getElementById("nb-messages");t&&(t.scrollTop=t.scrollHeight)},40)}listenToStorageChanges(){var t;typeof chrome<"u"&&((t=chrome.storage)!=null&&t.onChanged)&&chrome.storage.onChanged.addListener((i,o)=>{var e,a,l,s;if(o==="local"){if(i.nerd_buddy_sidepanel_open&&i.nerd_buddy_sidepanel_open.newValue===!0&&this.isOpen&&(this.isOpen=!1,this.render()),(i.synqto_live_stage||i.nerd_buddy_live_stage)&&(this.liveStage=(i.synqto_live_stage||i.nerd_buddy_live_stage).newValue,this.render()),(i.synqto_identity||i.nerd_buddy_identity)&&(this.myIdentity=(i.synqto_identity||i.nerd_buddy_identity).newValue),i[B]||i[D]){const n=(e=i[B]||i[D])==null?void 0:e.newValue;n&&(this.settings={...q,...n},this.settings.positionMode==="permanent"&&this.settings.savedPosition&&(this.currentPosition={...this.settings.savedPosition}),this.checkVisibilityAndRender(),this.hostElement&&this.render())}if((i.synqto_active_problem||i.nerd_buddy_active_problem)&&(this.currentProblem=(i.synqto_active_problem||i.nerd_buddy_active_problem).newValue,this.currentRoomStorageKey=`synqto_chat_${((a=this.currentProblem)==null?void 0:a.roomId)||""}`,this.loadMessages(),this.checkVisibilityAndRender()),i.nerd_buddy_peer_count&&(this.peerCount=Math.max(1,i.nerd_buddy_peer_count.newValue||1),this.render()),this.currentRoomStorageKey&&i[this.currentRoomStorageKey]){const n=i[this.currentRoomStorageKey].newValue||[];this.messages=this.deduplicateMessages(n),!this.isOpen&&((l=i[this.currentRoomStorageKey].newValue)==null?void 0:l.length)>(((s=i[this.currentRoomStorageKey].oldValue)==null?void 0:s.length)||0)&&this.unreadCount++,this.render(),this.isOpen&&this.activeTab==="chat"&&this.scrollToBottom()}if(i.synqto_server_connected||i.nerd_buddy_server_connected){const n=i.synqto_server_connected||i.nerd_buddy_server_connected,r=!!n.newValue,p=!!n.oldValue;this.isServerConnected=r,r&&!p&&this.showServerConnectedToast("⚡ Connected to Synqto Server"),this.render()}if(i.synqto_theme_settings&&(this.themeSettings=i.synqto_theme_settings.newValue,this.render()),i[z]){const n=i[z].newValue;n&&(this.timerConfig={...U,...n},this.render())}if(i[I]){const n=i[I].newValue;n&&(this.timerState=n,this.updateTimerDisplay(),this.isOpen&&this.activeTab==="timer"&&this.render())}}})}showServerConnectedToast(t){this.serverToastMessage=t,this.render(),setTimeout(()=>{this.serverToastMessage=null,this.render()},3200)}async loadTimerState(){var t;if(typeof chrome<"u"&&((t=chrome.storage)!=null&&t.local))try{const i=await chrome.storage.local.get([z,I]);if(i[z]&&(this.timerConfig={...U,...i[z]}),i[I]){const o=i[I];if(o.isRunning){const e=Math.floor((Date.now()-o.lastUpdated)/1e3);o.mode==="stopwatch"?o.timeLeftSec+=e:(o.timeLeftSec=Math.max(0,o.timeLeftSec-e),o.timeLeftSec===0&&(o.isRunning=!1))}this.timerState=o}}catch{}}saveTimerState(){var t;typeof chrome<"u"&&((t=chrome.storage)!=null&&t.local)&&chrome.storage.local.set({[I]:this.timerState})}startTimerTickLoop(){this.timerInterval&&clearInterval(this.timerInterval),this.timerInterval=setInterval(()=>{this.timerState.isRunning&&(this.timerState.mode==="stopwatch"?(this.timerState.timeLeftSec+=1,this.timerState.lastUpdated=Date.now(),this.updateTimerDisplay()):this.timerState.timeLeftSec>0&&(this.timerState.timeLeftSec-=1,this.timerState.lastUpdated=Date.now(),this.updateTimerDisplay(),this.timerState.timeLeftSec===0?this.handleTimerSessionComplete():this.timerState.timeLeftSec%5===0&&this.saveTimerState()))},1e3)}updateTimerDisplay(){if(!this.shadow)return;const t=this.shadow.getElementById("nb-timer-time");t&&(t.textContent=this.formatTimerTime(this.timerState.timeLeftSec));const i=this.shadow.getElementById("nb-timer-fab-time");i&&(i.textContent=this.formatTimerTime(this.timerState.timeLeftSec));const o=this.shadow.getElementById("nb-timer-fab-fill");if(o){const a=this.getTimerProgressPct();o.style.width=`${a}%`}const e=this.shadow.getElementById("nb-timer-progress-fill");if(e){const a=this.getTimerProgressPct();e.style.width=`${a}%`}}getTimerProgressPct(){if(this.timerState.mode==="stopwatch"||this.timerState.targetDurationSec===0)return 100;const t=1-this.timerState.timeLeftSec/this.timerState.targetDurationSec;return Math.min(100,Math.max(0,t*100))}handleTimerSessionComplete(){if(this.timerState.isRunning=!1,this.timerState.lastUpdated=Date.now(),this.timerConfig.soundAlerts&&this.playTimerChime(),this.timerState.mode==="pomodoro"){this.timerState.sessionsCompleted+=1;const i=this.timerState.sessionsCompleted%4===0?"long_break":"short_break";this.resetTimerToMode(i),this.timerConfig.autoStartBreaks&&(this.timerState.isRunning=!0)}else this.resetTimerToMode("pomodoro");this.saveTimerState(),this.render()}resetTimerToMode(t){this.timerState.mode=t;let i=1500;t==="pomodoro"?i=(this.timerConfig.workDurationMin||25)*60:t==="short_break"?i=(this.timerConfig.shortBreakMin||5)*60:t==="long_break"?i=(this.timerConfig.longBreakMin||15)*60:t==="stopwatch"&&(i=0),this.timerState.timeLeftSec=i,this.timerState.targetDurationSec=i,this.timerState.lastUpdated=Date.now()}toggleTimer(){this.timerState.isRunning=!this.timerState.isRunning,this.timerState.lastUpdated=Date.now(),this.saveTimerState(),this.render()}resetTimer(){this.timerState.isRunning=!1,this.resetTimerToMode(this.timerState.mode),this.saveTimerState(),this.render()}setTimerMode(t){this.timerState.isRunning=!1,this.resetTimerToMode(t),this.saveTimerState(),this.render()}addTimerTime(t){this.timerState.mode!=="stopwatch"?(this.timerState.timeLeftSec=Math.max(0,this.timerState.timeLeftSec+t),this.timerState.targetDurationSec=Math.max(this.timerState.timeLeftSec,this.timerState.targetDurationSec+t)):this.timerState.timeLeftSec=Math.max(0,this.timerState.timeLeftSec+t),this.saveTimerState(),this.render()}formatTimerTime(t){const i=Math.floor(t/60),o=t%60;return`${i.toString().padStart(2,"0")}:${o.toString().padStart(2,"0")}`}playTimerChime(){try{const t=window.AudioContext||window.webkitAudioContext;if(!t)return;const i=new t,o=(e,a,l)=>{const s=i.createOscillator(),n=i.createGain();s.type="sine",s.frequency.setValueAtTime(e,i.currentTime+a),n.gain.setValueAtTime(0,i.currentTime+a),n.gain.linearRampToValueAtTime(.2,i.currentTime+a+.05),n.gain.exponentialRampToValueAtTime(.001,i.currentTime+a+l),s.connect(n),n.connect(i.destination),s.start(i.currentTime+a),s.stop(i.currentTime+a+l)};o(523.25,0,1.2),o(659.25,.15,1.2),o(783.99,.3,1.5),o(1046.5,.45,2)}catch{}}getThemeCSS(){var p,f,w,g,S,u,d,k,y,x;const t=((p=this.themeSettings)==null?void 0:p.mode)||"system",i=t==="day"||t==="light"||t==="leetcode_light"||t==="solarized_light"||t==="sakura"||t==="system"&&typeof window<"u"&&((f=window.matchMedia)==null?void 0:f.call(window,"(prefers-color-scheme: light)").matches);let o="rgba(26, 38, 41, 0.96)",e="rgba(38, 55, 59, 0.95)",a="rgba(45, 212, 191, 0.18)",l="#ecfdf5",s="#a7f3d0",n="#2dd4bf",r="#14b8a6";return(w=this.themeSettings)!=null&&w.customPaletteEnabled?(o=this.themeSettings.customBgSurface||"#1e2b2f",e=this.themeSettings.customBgSurface||"#26373b",n=this.themeSettings.customPrimary||"#2dd4bf",r=this.themeSettings.customPrimary||"#14b8a6",l=this.themeSettings.customTextPrimary||"#ecfdf5",s=this.themeSettings.customTextSecondary||"#94a3b8",a=`${s}33`):t==="nordic_forest"?(o="rgba(26, 38, 41, 0.96)",e="rgba(38, 55, 59, 0.95)",a="rgba(45, 212, 191, 0.22)",l="#ecfdf5",s="#a7f3d0",n="#2dd4bf",r="#14b8a6"):t==="leetcode_dark"?(o="rgba(38, 38, 38, 0.96)",e="rgba(48, 48, 48, 0.95)",a="rgba(255, 161, 22, 0.25)",l="#eff1f6",s="#abb2bf",n="#FFA116",r="#f59e0b"):t==="leetcode_light"?(o="#ffffff",e="#f7f7f8",a="rgba(230, 138, 0, 0.25)",l="#262626",s="#595959",n="#e68a00",r="#cc7a00"):t==="oled"?(o="rgba(10, 10, 10, 0.98)",e="rgba(24, 24, 24, 0.95)",a="rgba(255, 255, 255, 0.18)",l="#ffffff",s="#e2e8f0"):t==="espresso"?(o="rgba(32, 21, 14, 0.96)",e="rgba(48, 32, 22, 0.95)",a="rgba(245, 158, 11, 0.2)",l="#fef3c7",s="#fde68a",n="#f59e0b",r="#d97706"):t==="forest"?(o="rgba(8, 28, 17, 0.96)",e="rgba(14, 42, 27, 0.95)",a="rgba(16, 185, 129, 0.2)",l="#ecfdf5",s="#a7f3d0",n="#10b981",r="#059669"):t==="nord"?(o="rgba(46, 52, 64, 0.96)",e="rgba(59, 66, 82, 0.95)",a="rgba(136, 192, 208, 0.2)",l="#eceff4",s="#e5e9f0",n="#88c0d0",r="#81a1c1"):t==="dracula"?(o="rgba(40, 42, 54, 0.96)",e="rgba(68, 71, 90, 0.95)",a="rgba(189, 147, 249, 0.2)",l="#f8f8f2",s="#bd93f9",n="#bd93f9",r="#a855f7"):t==="synthwave"?(o="rgba(38, 20, 71, 0.96)",e="rgba(54, 28, 102, 0.95)",a="rgba(244, 114, 182, 0.25)",l="#fff0f5",s="#f472b6",n="#f472b6",r="#ec4899"):t==="solarized_dark"?(o="rgba(0, 43, 54, 0.96)",e="rgba(7, 54, 66, 0.95)",a="rgba(42, 161, 152, 0.25)",l="#fdf6e3",s="#eee8d5",n="#2aa198",r="#268bd2"):t==="solarized_light"?(o="#fdf6e3",e="#eee8d5",a="rgba(7, 54, 66, 0.2)",l="#073642",s="#586e75",n="#268bd2",r="#1e6ea8"):t==="sakura"?(o="#ffffff",e="#fff0f3",a="rgba(244, 63, 94, 0.2)",l="#4c0519",s="#881337",n="#f43f5e",r="#e11d48"):i?(o="#ffffff",e="#f6f8fa",a="rgba(31, 35, 40, 0.15)",l="#1f2328",s="#4b5563",n="#4f46e5",r="#4338ca"):t==="night"&&(o="rgba(22, 27, 34, 0.96)",e="rgba(33, 38, 45, 0.95)",a="rgba(255, 255, 255, 0.12)",l="#f0f6fc",s="#c9d1d9",n="#6366f1",r="#4f46e5"),(g=this.themeSettings)!=null&&g.customPaletteEnabled||(((S=this.themeSettings)==null?void 0:S.accent)==="leetcode"?(n="#FFA116",r="#f59e0b"):((u=this.themeSettings)==null?void 0:u.accent)==="emerald"?(n="#10b981",r="#059669"):((d=this.themeSettings)==null?void 0:d.accent)==="cyan"?(n="#06b6d4",r="#0891b2"):((k=this.themeSettings)==null?void 0:k.accent)==="rose"?(n="#f43f5e",r="#e11d48"):((y=this.themeSettings)==null?void 0:y.accent)==="amber"?(n="#f59e0b",r="#d97706"):((x=this.themeSettings)==null?void 0:x.accent)==="purple"&&(n="#a855f7",r="#9333ea")),`
      --primary: ${n};
      --primary-hover: ${r};
      --bg-card: ${o};
      --bg-surface-elevated: ${e};
      --border-subtle: ${a};
      --text-primary: ${l};
      --text-secondary: ${s};
      --text-muted: ${i?"#6b7280":"#8b949e"};
      --text-dim: ${i?"#9ca3af":"#6e7681"};
    `}}class ee{constructor(){this.isEnabled=!0,this.activePeers=new Map,this.containerEl=null,this.lastSentCode="",this.lastSentCursor={line:1,ch:1},this.cleanupInterval=null,this.init()}async init(){var t,i;if(typeof chrome<"u"&&((t=chrome.storage)!=null&&t.local)){const o=await chrome.storage.local.get(["synqto_code_together_enabled"]);this.isEnabled=o.synqto_code_together_enabled!==!1}this.injectMainWorldBridge(),this.setupPageMessageListeners(),this.setupRuntimeListeners(),this.renderFloatingDock(),this.startCursorCleanup(),typeof chrome<"u"&&((i=chrome.runtime)!=null&&i.sendMessage)&&chrome.runtime.sendMessage({type:"CODE_GET_STATE"},o=>{o&&o.code&&this.isEnabled&&this.applyRemoteCodeToPage(o.code,o.language||"python",o.lastEditedBy,1,1)})}injectMainWorldBridge(){var t,i;if(!(typeof document>"u")&&((t=document.documentElement)==null?void 0:t.getAttribute("data-synqto-bridge"))!=="active"&&!document.getElementById("synqto-inpage-editor-bridge"))try{if(typeof chrome<"u"&&((i=chrome.runtime)!=null&&i.getURL)){const o=document.createElement("script");o.id="synqto-inpage-editor-bridge",o.src=chrome.runtime.getURL("content/in-page-bridge.js"),o.async=!0,(document.head||document.documentElement).appendChild(o)}}catch(o){console.warn("[Synqto] Could not inject in-page editor bridge:",o)}}setupPageMessageListeners(){window.addEventListener("message",t=>{var e,a;if(!t.data||t.data.source!=="SYNQTO_EDITOR_BRIDGE")return;const{type:i,payload:o}=t.data;if(this.isEnabled){if(i==="LOCAL_CODE_CHANGED"){const{code:l,line:s,col:n,language:r}=o;l!==this.lastSentCode&&(this.lastSentCode=l,this.lastSentCursor={line:s,ch:n},typeof chrome<"u"&&((e=chrome.runtime)!=null&&e.sendMessage)&&chrome.runtime.sendMessage({type:"CODE_DELTA_LOCAL",payload:{code:l,cursorLine:s,cursorCol:n,language:r||"python"}}).catch(()=>{}))}else if(i==="LOCAL_CURSOR_MOVED"){const{line:l,ch:s}=o;(l!==this.lastSentCursor.line||s!==this.lastSentCursor.ch)&&(this.lastSentCursor={line:l,ch:s},typeof chrome<"u"&&((a=chrome.runtime)!=null&&a.sendMessage)&&chrome.runtime.sendMessage({type:"CODE_CURSOR_LOCAL",payload:{line:l,ch:s}}).catch(()=>{}))}}})}setupRuntimeListeners(){var t;typeof chrome>"u"||!((t=chrome.runtime)!=null&&t.onMessage)||chrome.runtime.onMessage.addListener(i=>{if(this.isEnabled){if(i.type==="CODE_DELTA_REMOTE"||i.type==="CODE_SYNC_REMOTE"){const{code:o,language:e,cursorLine:a,cursorCol:l,sender:s,lastEditedBy:n}=i.payload;this.applyRemoteCodeToPage(o,e,(s==null?void 0:s.nickname)||n||"Peer",a||1,l||1),s&&(this.activePeers.set(s.peerId,{peerId:s.peerId,nickname:s.nickname,color:s.color||"#3b82f6",line:a||1,ch:l||1,lastActive:Date.now()}),this.updateFloatingDock())}else if(i.type==="CODE_CURSOR_REMOTE"){const{peerId:o,nickname:e,color:a,line:l,ch:s}=i.payload;this.applyRemoteCursorToPage(o,e,a,l,s),this.activePeers.set(o,{peerId:o,nickname:e,color:a||"#3b82f6",line:l,ch:s,lastActive:Date.now()}),this.updateFloatingDock()}}})}applyRemoteCodeToPage(t,i,o,e,a){this.lastSentCode=t,window.postMessage({source:"SYNQTO_CONTENT_SCRIPT",type:"APPLY_REMOTE_CODE",payload:{code:t,language:i,cursorLine:e,cursorCol:a,sender:o}},"*")}applyRemoteCursorToPage(t,i,o,e,a){window.postMessage({source:"SYNQTO_CONTENT_SCRIPT",type:"APPLY_REMOTE_CURSOR",payload:{peerId:t,nickname:i,color:o,line:e,ch:a}},"*")}renderFloatingDock(){this.containerEl&&this.containerEl.remove();const t=document.createElement("div");t.id="synqto-code-together-dock",t.style.cssText=`
      position: fixed !important;
      top: 16px !important;
      right: 90px !important;
      z-index: 2147483640 !important;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, monospace !important;
      display: flex !important;
      align-items: center !important;
      gap: 6px !important;
      padding: 5px 10px !important;
      border-radius: 9999px !important;
      background: linear-gradient(135deg, rgba(15, 23, 42, 0.95), rgba(30, 41, 59, 0.95)) !important;
      border: 1px solid ${this.isEnabled?"rgba(99, 102, 241, 0.45)":"rgba(255, 255, 255, 0.12)"} !important;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.4) !important;
      color: #ffffff !important;
      font-size: 11px !important;
      font-weight: 700 !important;
      cursor: pointer !important;
      backdrop-filter: blur(16px) !important;
      user-select: none !important;
      transition: all 0.2s ease !important;
    `,document.body.appendChild(t),this.containerEl=t,t.addEventListener("click",()=>{this.toggleCodeTogether()}),this.updateFloatingDock()}updateFloatingDock(){if(!this.containerEl)return;const t=this.activePeers.size;this.containerEl.innerHTML=`
      <span style="font-size: 13px;">${this.isEnabled?"👥":"🔒"}</span>
      <span style="color: ${this.isEnabled?"#818cf8":"#94a3b8"};">Code Together:</span>
      <span style="padding: 1px 6px; border-radius: 10px; font-size: 10px; background: ${this.isEnabled?"rgba(16, 185, 129, 0.2)":"rgba(255, 255, 255, 0.08)"}; color: ${this.isEnabled?"#34d399":"#94a3b8"};">
        ${this.isEnabled?t>0?`Synced (${t+1})`:"Active ⚡":"Solo"}
      </span>
      ${this.isEnabled&&t>0?`
        <div style="display:flex;align-items:center;gap:2px;margin-left:4px;">
          ${Array.from(this.activePeers.values()).map(i=>`
            <span style="display:inline-block;width:7px;height:7px;border-radius:50%;background:${i.color||"#3b82f6"};box-shadow:0 0 6px ${i.color||"#3b82f6"};" title="${i.nickname} (line ${i.line}, col ${i.ch})"></span>
          `).join("")}
        </div>
      `:""}
    `,this.containerEl.style.borderColor=this.isEnabled?"rgba(99, 102, 241, 0.5)":"rgba(255, 255, 255, 0.12)"}toggleCodeTogether(){var t;this.isEnabled=!this.isEnabled,typeof chrome<"u"&&((t=chrome.storage)!=null&&t.local)&&chrome.storage.local.set({synqto_code_together_enabled:this.isEnabled}),this.updateFloatingDock()}startCursorCleanup(){this.cleanupInterval&&clearInterval(this.cleanupInterval),this.cleanupInterval=setInterval(()=>{const t=Date.now();let i=!1;this.activePeers.forEach((o,e)=>{t-o.lastActive>15e3&&(this.activePeers.delete(e),window.postMessage({source:"SYNQTO_CONTENT_SCRIPT",type:"REMOVE_PEER_CURSOR",payload:{peerId:e}},"*"),i=!0)}),i&&this.updateFloatingDock()},4e3)}}console.log("[Synqto] Content script initialized on:",window.location.href),new K(v=>{var t;try{typeof chrome<"u"&&((t=chrome.runtime)!=null&&t.sendMessage)&&chrome.runtime.sendMessage({type:"PROBLEM_DETECTED",payload:v})}catch{}}),new X,new J,new ee})();
