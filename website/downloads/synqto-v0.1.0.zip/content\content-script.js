(function(){"use strict";function B(y){let e=2166136261,i=2166136261;for(let t=0;t<y.length;t++){const h=y.charCodeAt(t);e=Math.imul(e^h&255,16777619),i=Math.imul(i^h>>8,16777619)}return((e>>>0^i>>>0)>>>0).toString(16).padStart(8,"0")}function z(y,e){let i=null;return(...r)=>{i&&clearTimeout(i),i=setTimeout(()=>y(...r),e)}}function C(y,e){var i;try{const r=new URL(y),t=r.hostname.toLowerCase(),h=r.pathname;if(t.includes("leetcode.com")){const l=h.match(/\/problems\/([a-zA-Z0-9-_]+)/);if(l&&l[1]){const c=l[1],s=P(c);return{platform:"LeetCode",slug:c,title:s,url:y,canonicalUrl:`https://leetcode.com/problems/${c}/`}}}if(t.includes("neetcode.io")){const l=h.match(/\/problems\/([a-zA-Z0-9-_]+)/);if(l&&l[1]){const c=l[1],s=P(c);return{platform:"NeetCode",slug:c,title:s,url:y,canonicalUrl:`https://neetcode.io/problems/${c}`}}}if(t.includes("codeforces.com")){const l=h.match(/\/(?:contest|problemset\/problem)\/(\d+)\/([A-Z0-9]+)/i);if(l){const c=l[1],s=l[2].toUpperCase();return{platform:"Codeforces",slug:`cf-${c}-${s}`,title:`Codeforces ${c}${s}`,url:y,canonicalUrl:`https://codeforces.com/problemset/problem/${c}/${s}`}}}if(t.includes("hackerrank.com")){const l=h.match(/\/challenges\/([a-zA-Z0-9-_]+)/);if(l&&l[1]){const c=l[1];return{platform:"HackerRank",slug:c,title:P(c),url:y,canonicalUrl:`https://www.hackerrank.com/challenges/${c}/problem`}}}if(t.includes("codechef.com")){const l=h.match(/\/problems\/([a-zA-Z0-9-_]+)/);if(l&&l[1]){const c=l[1];return{platform:"CodeChef",slug:c,title:`CodeChef ${c}`,url:y,canonicalUrl:`https://www.codechef.com/problems/${c}`}}}if(t.includes("geeksforgeeks.org")){const l=h.match(/\/problems\/([a-zA-Z0-9-_]+)/);if(l&&l[1]){const c=l[1];return{platform:"GeeksforGeeks",slug:c,title:P(c),url:y,canonicalUrl:`https://www.geeksforgeeks.org/problems/${c}/1`}}}if(t.includes("youtube.com")||t.includes("youtu.be")){let l=r.searchParams.get("v");if(!l&&t.includes("youtu.be")&&(l=h.slice(1)),!l&&h.includes("/shorts/")&&(l=(i=h.split("/shorts/")[1])==null?void 0:i.split("/")[0]),l){const c=e?A(e):`YouTube Video (${l})`;return{platform:"YouTube",slug:`yt-${l}`,title:c,url:y,canonicalUrl:`https://www.youtube.com/watch?v=${l}`}}}if(t.includes("arxiv.org")){const l=h.match(/\/(?:abs|pdf)\/(\d+\.\d+(?:v\d+)?)/);if(l&&l[1]){const c=l[1];return{platform:"ArXiv",slug:`arxiv-${c.replace(/\./g,"-")}`,title:e?R(e):`ArXiv ${c}`,url:y,canonicalUrl:`https://arxiv.org/abs/${c}`}}}if(t.includes("github.com")){const l=h.match(/^\/([^\/]+)\/([^\/]+)\/(?:issues|pull)\/(\d+)/);if(l){const c=l[1],s=l[2],d=l[3];return{platform:"GitHub",slug:`gh-${c}-${s}-${d}`,title:`${c}/${s} #${d}`,url:y,canonicalUrl:`https://github.com/${c}/${s}/issues/${d}`}}}return{platform:"Web",slug:t.replace(/\./g,"-")||"general-study",title:e||t||"General Study Room",url:y,canonicalUrl:y}}catch{return null}}function P(y){return y.split(/[-_]/).map(e=>e.charAt(0).toUpperCase()+e.slice(1)).join(" ")}function A(y){return y.replace(/\s*-\s*YouTube\s*$/,"").trim()}function R(y){return y.replace(/^\[[^\]]+\]\s*/,"").replace(/\s*-\s*arXiv.*$/,"").trim()}function L(){try{return!!(typeof chrome<"u"&&chrome.runtime&&chrome.runtime.id)}catch{return!1}}class D{constructor(e){this.lastUrl="",this.lastTitle="",this.mutationObserver=null,this.pollTimer=null,this.debouncedCheck=z(()=>{if(!L()){this.destroy();return}this.checkCurrentPage()},250),this.callback=e,this.init()}init(){this.checkCurrentPage();const e=history.pushState,i=history.replaceState;history.pushState=(...t)=>{e.apply(history,t),this.debouncedCheck()},history.replaceState=(...t)=>{i.apply(history,t),this.debouncedCheck()},window.addEventListener("popstate",()=>this.debouncedCheck()),window.addEventListener("hashchange",()=>this.debouncedCheck()),window.addEventListener("yt-navigate-finish",()=>this.debouncedCheck()),this.mutationObserver=new MutationObserver(()=>{document.title!==this.lastTitle&&this.debouncedCheck()});const r=document.querySelector("title");r&&this.mutationObserver.observe(r,{subtree:!0,characterData:!0,childList:!0}),this.pollTimer=setInterval(()=>{if(!L()){this.destroy();return}window.location.href!==this.lastUrl&&this.checkCurrentPage()},350)}checkCurrentPage(){const e=window.location.href,i=document.title;if(e===this.lastUrl&&i===this.lastTitle)return;this.lastUrl=e,this.lastTitle=i;const r=C(e,i);r&&this.callback(r)}destroy(){this.mutationObserver&&(this.mutationObserver.disconnect(),this.mutationObserver=null),this.pollTimer&&(clearInterval(this.pollTimer),this.pollTimer=null)}}function M(){try{return!!(typeof chrome<"u"&&chrome.runtime&&chrome.runtime.id)}catch{return!1}}class W{constructor(){this.container=null,this.cursorElements=new Map,this.cursorTimeouts=new Map,this.myIdentity=null,this.liveStage=null,this.createContainer(),this.loadState(),this.listenToStorage(),this.listenForMessages(),this.setupLocalTrackers()}async loadState(){var e;if(typeof chrome<"u"&&((e=chrome.storage)!=null&&e.local))try{const i=await chrome.storage.local.get(["nerd_buddy_identity","synqme_identity","nerd_buddy_live_stage","synqme_live_stage"]);this.myIdentity=i.synqme_identity||i.nerd_buddy_identity||null,this.liveStage=i.synqme_live_stage||i.nerd_buddy_live_stage||null,(!this.liveStage||!this.liveStage.isActive)&&this.clearAllCursors()}catch{}}listenToStorage(){var e;typeof chrome<"u"&&((e=chrome.storage)!=null&&e.onChanged)&&chrome.storage.onChanged.addListener((i,r)=>{r==="local"&&((i.synqme_identity||i.nerd_buddy_identity)&&(this.myIdentity=(i.synqme_identity||i.nerd_buddy_identity).newValue),(i.synqme_live_stage||i.nerd_buddy_live_stage)&&(this.liveStage=(i.synqme_live_stage||i.nerd_buddy_live_stage).newValue,(!this.liveStage||!this.liveStage.isActive)&&this.clearAllCursors()))})}clearAllCursors(){this.cursorTimeouts.forEach(e=>clearTimeout(e)),this.cursorTimeouts.clear(),this.cursorElements.forEach(e=>{e.remove()}),this.cursorElements.clear(),this.container&&(this.container.innerHTML="")}isLocalUserOnStage(){var i,r;if(!this.liveStage||!this.liveStage.isActive)return!1;const e=(i=this.myIdentity)==null?void 0:i.peerId;return e?!!(((r=this.liveStage.tutorIdentity)==null?void 0:r.peerId)===e||this.liveStage.tutorPeerId===e||this.liveStage.myRole==="tutor"||Array.isArray(this.liveStage.guestSpeakers)&&this.liveStage.guestSpeakers.some(t=>t.peerId===e)):!1}createContainer(){if(document.getElementById("nerd-buddy-cursor-overlay"))return;const e=document.createElement("div");if(e.id="nerd-buddy-cursor-overlay",e.style.cssText=`
      position: fixed !important;
      top: 0 !important;
      left: 0 !important;
      width: 100vw !important;
      height: 100vh !important;
      pointer-events: none !important;
      z-index: 2147483645 !important;
      overflow: hidden !important;
      box-sizing: border-box !important;
    `,document.body.appendChild(e),this.container=e,!document.getElementById("nerd-buddy-cursor-styles")){const i=document.createElement("style");i.id="nerd-buddy-cursor-styles",i.textContent=`
        @keyframes nb-click-ripple {
          0% { transform: scale(0.15); opacity: 1; }
          40% { opacity: 0.9; }
          100% { transform: scale(2.8); opacity: 0; }
        }
      `,document.head.appendChild(i)}}listenForMessages(){var e;if(!(!M()||!((e=chrome.runtime)!=null&&e.onMessage)))try{chrome.runtime.onMessage.addListener(i=>{var r,t,h,f;if(M()){if(i.type==="NERD_BUDDY_STAGE_ENDED"||i.type==="NERD_BUDDY_STAGE_INACTIVE"){this.clearAllCursors();return}if(i.type==="NERD_BUDDY_CURSOR_UPDATE"&&i.cursor){const l=i.cursor;(l.isTutor||this.liveStage&&(((r=this.liveStage.tutorIdentity)==null?void 0:r.peerId)===l.peerId||this.liveStage.tutorPeerId===l.peerId||((t=this.liveStage.guestSpeakers)==null?void 0:t.some(s=>s.peerId===l.peerId)))||!this.liveStage)&&this.renderCursor(l)}else if(i.type==="NERD_BUDDY_CLICK_PULSE"&&i.click){const l=i.click;(l.isTutor||this.liveStage&&(((h=this.liveStage.tutorIdentity)==null?void 0:h.peerId)===l.peerId||this.liveStage.tutorPeerId===l.peerId||((f=this.liveStage.guestSpeakers)==null?void 0:f.some(s=>s.peerId===l.peerId)))||l.isTutor||!this.liveStage)&&this.renderClickPulse(l)}}})}catch{}}renderCursor(e){if(this.container||this.createContainer(),!this.container)return;let i=this.cursorElements.get(e.peerId);i||(i=document.createElement("div"),i.style.cssText=`
        position: fixed !important;
        pointer-events: none !important;
        transition: left 0.05s linear, top 0.05s linear, opacity 0.3s ease !important;
        display: flex !important;
        align-items: center !important;
        gap: 5px !important;
        opacity: 1 !important;
        z-index: 2147483646 !important;
      `,this.container.appendChild(i),this.cursorElements.set(e.peerId,i));const r=Math.max(0,Math.min(window.innerWidth-30,e.xPct/100*window.innerWidth)),t=Math.max(0,Math.min(window.innerHeight-30,e.yPct/100*window.innerHeight));i.style.left=`${r}px`,i.style.top=`${t}px`,i.style.opacity="1";const h=e.isTutor?"#8b5cf6":e.color||"#6366f1";i.innerHTML=`
      <div style="
        width: 18px;
        height: 18px;
        border-radius: 50%;
        background: ${h};
        box-shadow: 0 0 16px ${h}, 0 0 6px #ffffff;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 11px;
        color: #fff;
        border: 2px solid #ffffff;
      ">
        ${e.avatar||"👑"}
      </div>
      <div style="
        background: rgba(15, 23, 42, 0.92);
        border: 1px solid ${h};
        color: #f8fafc;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        font-size: 10px;
        font-weight: 600;
        padding: 2px 6px;
        border-radius: 4px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.6);
        white-space: nowrap;
      ">
        ${e.nickname} ${e.isTutor?"🎓 (Tutor)":"🎤 (Speaker)"}
      </div>
    `;const f=this.cursorTimeouts.get(e.peerId);f&&clearTimeout(f);const l=window.setTimeout(()=>{i&&(i.style.opacity="0")},4e3);this.cursorTimeouts.set(e.peerId,l)}renderClickPulse(e){if(this.container||this.createContainer(),!this.container)return;const i=e.xPct/100*window.innerWidth,r=e.yPct/100*window.innerHeight,t=document.createElement("div"),h=e.color||(e.isTutor?"#8b5cf6":"#6366f1");t.style.cssText=`
      position: fixed !important;
      left: ${i-22}px !important;
      top: ${r-22}px !important;
      width: 44px !important;
      height: 44px !important;
      border-radius: 50% !important;
      border: 3px solid ${h} !important;
      box-shadow: 0 0 16px ${h}, inset 0 0 8px ${h} !important;
      pointer-events: none !important;
      z-index: 2147483647 !important;
      box-sizing: border-box !important;
      animation: nb-click-ripple 0.85s cubic-bezier(0.1, 0.8, 0.3, 1) forwards !important;
    `,this.container.appendChild(t),setTimeout(()=>{t.remove()},900)}setupLocalTrackers(){let e=0;window.addEventListener("mousemove",i=>{if(!M()||!this.isLocalUserOnStage())return;const r=Date.now();if(r-e<40)return;e=r;const t=i.clientX/window.innerWidth*100,h=i.clientY/window.innerHeight*100;try{chrome.runtime.sendMessage({type:"LOCAL_CURSOR_MOVE",xPct:t,yPct:h}).catch(()=>{})}catch{}}),window.addEventListener("click",i=>{var h,f,l;if(!M()||!this.isLocalUserOnStage())return;const r=i.clientX/window.innerWidth*100,t=i.clientY/window.innerHeight*100;this.renderClickPulse({peerId:((h=this.myIdentity)==null?void 0:h.peerId)||"local",nickname:((f=this.myIdentity)==null?void 0:f.nickname)||"You",xPct:r,yPct:t,color:((l=this.myIdentity)==null?void 0:l.color)||"#8b5cf6",isTutor:!0,timestamp:Date.now()});try{chrome.runtime.sendMessage({type:"LOCAL_CLICK_PULSE",xPct:r,yPct:t}).catch(()=>{})}catch{}})}}const E={mode:"coding_sites",clickAction:"open_popup",customDomains:["leetcode.com","neetcode.io","codeforces.com","hackerrank.com","geeksforgeeks.org"],enableWhiteboard:!0,popupContentMode:"both",positionMode:"permanent",savedPosition:{right:24,bottom:24},whiteboardPrefs:{defaultPrivacyMode:"collaborative",defaultBackgroundType:"grid",defaultBgColor:"#090d16",defaultPenColor:"#6366f1",defaultPenWidth:4,disappearingInkDurationSec:3,autoSavePersonalNotebook:!0}},T="nerd_buddy_fab_settings",_="synqto_fab_settings";function O(y,e){const i=y.toLowerCase().replace(/[^a-z0-9-_]/g,"-").slice(0,24).replace(/-+$/,""),r=B(e);return`room:${i||"lobby"}-${r}`}function q(y){switch(y.toLowerCase()){case"leetcode":return"#FFA116";case"neetcode":return"#8B5CF6";case"codeforces":return"#318CE7";case"hackerrank":return"#2EC866";case"codechef":return"#5B4638";case"geeksforgeeks":return"#2F8D46";case"youtube":return"#FF0000";case"arxiv":return"#B31B1B";case"github":return"#24292F";case"group":return"#8B5CF6";default:return"#6366F1"}}class H{constructor(){this.hostElement=null,this.shadow=null,this.isOpen=!1,this.settings=E,this.currentProblem=null,this.messages=[],this.unreadCount=0,this.currentRoomStorageKey="",this.myIdentity=null,this.liveStage=null,this.peerCount=1,this.replyingTo=null,this.revealedSpoilers={},this.currentPosition={right:24,bottom:24},this.isDragging=!1,this.dragMoved=!1,this.popupSize="compact",this.activeTab="chat",this.wbTool="pen",this.toolStyles={pen:{color:"#6366f1",width:3},brush:{color:"#06b6d4",width:6},highlighter:{color:"#f59e0b",width:16},temp_pen:{color:"#38bdf8",width:3},laser:{color:"#ef4444",width:3},torch:{color:"#facc15",width:65},eraser:{color:"#ffffff",width:18},text:{color:"#ffffff",width:3},line:{color:"#6366f1",width:3},arrow:{color:"#6366f1",width:3},rect:{color:"#6366f1",width:3},circle:{color:"#6366f1",width:3},tree_node:{color:"#10b981",width:3},db_cylinder:{color:"#10b981",width:2.5},cloud:{color:"#38bdf8",width:2.5},load_balancer:{color:"#f59e0b",width:2.5},message_queue:{color:"#a855f7",width:2.5},server_box:{color:"#818cf8",width:2.5}},this.wbColor="#6366f1",this.wbWidth=3,this.wbTheme="grid",this.wbBgColor="#090d16",this.wbPrivacyMode="collaborative",this.wbStrokes=[],this.wbPersonalStrokes=[],this.wbRedoStack=[],this.isWbDrawing=!1,this.wbCurrentPoints=[],this.wbStartPoint=null,this.tempDisappearingStrokes=[],this.wbLaserTrails=[],this.wbTorchPos=null,this.wbEraserPos=null,this.init()}async init(){await this.loadIdentity(),await this.loadSettings(),this.detectCurrentPageProblem(),this.checkVisibilityAndRender(),this.listenToStorageChanges(),this.listenForRuntimeMessages()}async loadIdentity(){var e;if(typeof chrome<"u"&&((e=chrome.storage)!=null&&e.local)){const i=await chrome.storage.local.get(["synqto_identity","nerd_buddy_identity"]);(i.synqto_identity||i.nerd_buddy_identity)&&(this.myIdentity=i.synqto_identity||i.nerd_buddy_identity)}this.myIdentity||(this.myIdentity={peerId:"peer-"+Math.random().toString(36).slice(2,10),nickname:"Coder"+Math.floor(Math.random()*900+100),avatar:"⚡",color:"#6366f1"})}async loadSettings(){var e,i;if(typeof chrome<"u"&&((e=chrome.storage)!=null&&e.local)){const r=await chrome.storage.local.get([T,_,"synqto_active_problem","nerd_buddy_active_problem","synqto_live_stage","nerd_buddy_live_stage","nerd_buddy_sidepanel_open","nerd_buddy_peer_count"]);(r[_]||r[T])&&(this.settings={...E,...r[_]||r[T]}),this.settings.positionMode==="permanent"&&this.settings.savedPosition?this.currentPosition={...this.settings.savedPosition}:this.currentPosition={right:24,bottom:24};const t=r.synqto_active_problem||r.nerd_buddy_active_problem;t&&(this.currentProblem=t,this.currentRoomStorageKey=`synqto_chat_${((i=this.currentProblem)==null?void 0:i.roomId)||""}`,await this.loadMessages()),(r.synqto_live_stage||r.nerd_buddy_live_stage)&&(this.liveStage=r.synqto_live_stage||r.nerd_buddy_live_stage),typeof r.nerd_buddy_peer_count=="number"&&(this.peerCount=Math.max(1,r.nerd_buddy_peer_count))}}detectCurrentPageProblem(){const e=C(window.location.href,document.title);if(e){const i=O(e.slug,e.canonicalUrl);this.currentProblem={platform:e.platform,slug:e.slug,title:e.title,canonicalUrl:e.canonicalUrl,roomId:i},this.currentRoomStorageKey=`synqto_chat_${i}`,this.loadMessages()}}shouldShow(){if(this.settings.mode==="disabled"||this.settings.popupContentMode==="none")return!1;if(this.settings.mode==="all_sites")return!0;const e=window.location.hostname.toLowerCase();if(this.settings.mode==="custom_sites")return this.settings.customDomains.some(h=>e.includes(h.toLowerCase()));const r=["leetcode.com","neetcode.io","codeforces.com","hackerrank.com","geeksforgeeks.org","codechef.com","atcoder.jp","github.com","youtube.com","arxiv.org"].some(h=>e.includes(h)),t=!!(this.currentProblem||C(window.location.href));return r||t}checkVisibilityAndRender(){const e=this.shouldShow();e&&!this.hostElement?this.createWidgetDOM():!e&&this.hostElement&&this.destroyWidgetDOM()}destroyWidgetDOM(){this.hostElement&&(this.hostElement.remove(),this.hostElement=null,this.shadow=null)}createWidgetDOM(){if(document.getElementById("synqto-floating-host"))return;const e=document.createElement("div");e.id="synqto-floating-host",e.style.cssText=`
      position: fixed;
      bottom: ${this.currentPosition.bottom}px;
      right: ${this.currentPosition.right}px;
      z-index: 2147483640;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
      touch-action: none;
    `,document.body.appendChild(e),this.hostElement=e,this.shadow=e.attachShadow({mode:"open"}),this.render()}applyHostPosition(){if(!this.hostElement)return;const e=Math.max(10,Math.min(window.innerWidth-130,this.currentPosition.right)),i=Math.max(10,Math.min(window.innerHeight-55,this.currentPosition.bottom));this.hostElement.style.right=`${e}px`,this.hostElement.style.bottom=`${i}px`}render(){var u,g,w,n;if(!this.shadow)return;const e=this.settings.popupContentMode||(this.settings.enableWhiteboard?"both":"chat_only");if(e==="none"||this.settings.mode==="disabled"){this.destroyWidgetDOM();return}this.applyHostPosition();const i=!!(this.liveStage&&this.liveStage.isActive),r=((g=(u=this.liveStage)==null?void 0:u.tutorIdentity)==null?void 0:g.nickname)||"Tutor",t=((w=this.currentProblem)==null?void 0:w.title)||"Global Problem Lobby",h=((n=this.currentProblem)==null?void 0:n.platform)||"LeetCode",f=q(h),l=e==="whiteboard_only"||e==="both"&&this.activeTab==="whiteboard",c=e==="whiteboard_only"?"🎨":"⚡",s=i?`LIVE (${r})`:e==="whiteboard_only"?"Board":e==="chat_only"?`Chat (${this.peerCount})`:`Synqto (${this.peerCount})`,d=this.currentPosition.bottom>window.innerHeight-540,m=this.currentPosition.right>window.innerWidth-420;this.shadow.innerHTML=`
      <style>
        :host {
          --primary: #6366f1;
          --primary-hover: #4f46e5;
          --bg-card: rgba(15, 23, 42, 0.96);
          --bg-surface-elevated: rgba(30, 41, 59, 0.85);
          --border-subtle: rgba(255, 255, 255, 0.1);
          --text-primary: #f8fafc;
          --text-secondary: #94a3b8;
          --text-muted: #64748b;
          --text-dim: #475569;
          --font-mono: 'JetBrains Mono', 'Fira Code', monospace;
        }

        * {
          box-sizing: border-box;
          margin: 0;
          padding: 0;
        }

        /* Floating Action Button (FAB) */
        .fab-button {
          position: relative;
          display: flex;
          align-items: center;
          gap: 7px;
          padding: 10px 14px;
          border-radius: 9999px;
          background: linear-gradient(135deg, #4f46e5, #7c3aed);
          border: 1px solid rgba(255, 255, 255, 0.2);
          box-shadow: 0 10px 25px -5px rgba(99, 102, 241, 0.5), 0 0 15px rgba(124, 58, 237, 0.3);
          color: #ffffff;
          font-size: 12px;
          font-weight: 700;
          cursor: grab;
          transition: transform 0.15s cubic-bezier(0.16, 1, 0.3, 1), box-shadow 0.15s;
          user-select: none;
        }

        .fab-button:active {
          cursor: grabbing;
        }

        .fab-button:hover {
          transform: translateY(-2px) scale(1.02);
          box-shadow: 0 14px 28px -5px rgba(99, 102, 241, 0.65), 0 0 20px rgba(124, 58, 237, 0.4);
        }

        .drag-grip {
          opacity: 0.5;
          font-size: 11px;
          cursor: grab;
        }

        .live-dot {
          width: 8px;
          height: 8px;
          border-radius: 50%;
          background: #ef4444;
          box-shadow: 0 0 10px #ef4444;
          animation: livePulse 1.5s infinite;
        }

        @keyframes livePulse {
          0%, 100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.4; transform: scale(1.2); }
        }

        .fab-badge {
          position: absolute;
          top: -4px;
          right: -4px;
          background: #f59e0b;
          color: #ffffff;
          font-size: 10px;
          font-weight: 700;
          padding: 2px 6px;
          border-radius: 9999px;
        }

        /* In-Page Popup Card */
        .popup-card {
          display: ${this.isOpen?"flex":"none"};
          flex-direction: column;
          position: absolute;
          ${d?"top: 52px; bottom: auto;":"bottom: 52px; top: auto;"}
          ${m?"left: 0; right: auto;":"right: 0; left: auto;"}
          width: ${this.popupSize==="fullscreen"?"min(1180px, 95vw)":this.popupSize==="large"?"min(860px, 92vw)":this.popupSize==="medium"?"min(620px, 88vw)":"420px"};
          height: ${this.popupSize==="fullscreen"?"min(880px, 92vh)":this.popupSize==="large"?"min(740px, 88vh)":this.popupSize==="medium"?"min(640px, 84vh)":"540px"};
          max-height: 94vh;
          max-width: 96vw;
          background: rgba(15, 23, 42, 0.97);
          border: 1px solid ${i?"rgba(239, 68, 68, 0.45)":"rgba(99, 102, 241, 0.35)"};
          border-radius: 16px;
          box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.9), 0 0 28px ${i?"rgba(239, 68, 68, 0.25)":"rgba(99, 102, 241, 0.25)"};
          backdrop-filter: blur(24px);
          -webkit-backdrop-filter: blur(24px);
          overflow: hidden;
          animation: slideIn 0.2s cubic-bezier(0.16, 1, 0.3, 1);
          color: var(--text-primary);
          transition: width 0.2s cubic-bezier(0.16, 1, 0.3, 1), height 0.2s cubic-bezier(0.16, 1, 0.3, 1);
        }

        @keyframes slideIn {
          from { opacity: 0; transform: translateY(12px) scale(0.96); }
          to { opacity: 1; transform: translateY(0) scale(1); }
        }

        /* Room Header */
        .room-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 10px 12px;
          background: linear-gradient(135deg, rgba(30, 41, 59, 0.95), rgba(15, 23, 42, 0.95));
          border-bottom: 1px solid var(--border-subtle);
        }

        .room-info {
          display: flex;
          align-items: center;
          gap: 10px;
          overflow: hidden;
        }

        .platform-icon-box {
          width: 32px;
          height: 32px;
          border-radius: 8px;
          background: rgba(99, 102, 241, 0.15);
          border: 1px solid rgba(255, 255, 255, 0.1);
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 16px;
          flex-shrink: 0;
        }

        .problem-title {
          font-size: 13px;
          font-weight: 700;
          color: var(--text-primary);
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
          max-width: 170px;
        }

        .badges-row {
          display: flex;
          align-items: center;
          gap: 6px;
          margin-top: 2px;
        }

        .platform-pill {
          font-size: 9px;
          font-weight: 700;
          padding: 1px 6px;
          border-radius: 4px;
          background: ${f}20;
          border: 1px solid ${f}50;
          color: ${f};
          text-transform: uppercase;
        }

        .peer-count-pill {
          font-size: 10px;
          color: var(--text-secondary);
          display: flex;
          align-items: center;
          gap: 4px;
        }

        .header-actions {
          display: flex;
          align-items: center;
          gap: 4px;
        }

        .icon-btn {
          background: transparent;
          border: none;
          color: var(--text-secondary);
          cursor: pointer;
          padding: 5px;
          border-radius: 6px;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: all 0.15s;
        }

        .icon-btn:hover {
          background: rgba(255, 255, 255, 0.1);
          color: #ffffff;
        }

        /* Segmented View Switcher */
        .tab-switcher {
          display: flex;
          background: rgba(15, 23, 42, 0.9);
          padding: 3px 6px;
          border-bottom: 1px solid var(--border-subtle);
          gap: 4px;
        }

        .tab-btn {
          flex: 1;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 6px;
          padding: 5px 8px;
          font-size: 11px;
          font-weight: 600;
          border-radius: 6px;
          border: none;
          cursor: pointer;
          transition: all 0.15s;
          background: transparent;
          color: var(--text-muted);
        }

        .tab-btn.active {
          background: var(--primary);
          color: #ffffff;
        }

        /* Messages List */
        .message-list {
          flex: 1;
          overflow-y: auto;
          padding: 12px;
          display: flex;
          flex-direction: column;
          gap: 10px;
        }

        .chat-bubble {
          display: flex;
          flex-direction: column;
          max-width: 86%;
          padding: 8px 12px;
          border-radius: 14px;
          font-size: 12px;
          position: relative;
          word-break: break-word;
          line-height: 1.45;
        }

        .chat-bubble.self {
          align-self: flex-end;
          background: linear-gradient(135deg, rgba(99, 102, 241, 0.28), rgba(139, 92, 246, 0.22));
          border: 1px solid rgba(99, 102, 241, 0.35);
          border-bottom-right-radius: 4px;
          color: #ffffff;
        }

        .chat-bubble.other {
          align-self: flex-start;
          background: var(--bg-surface-elevated);
          border: 1px solid var(--border-subtle);
          border-bottom-left-radius: 4px;
          color: #f1f5f9;
        }

        .chat-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 8px;
          margin-bottom: 4px;
          font-size: 11px;
        }

        .chat-author {
          font-weight: 600;
          display: flex;
          align-items: center;
          gap: 4px;
        }

        .chat-timestamp {
          color: var(--text-dim);
          font-size: 10px;
        }

        .chat-footer {
          margin-top: 3px;
          display: flex;
          align-items: center;
          justify-content: flex-end;
          font-size: 10px;
        }

        .ack-read {
          color: #38bdf8;
          font-weight: 700;
        }

        /* Whiteboard Toolbar & Canvas */
        .whiteboard-container {
          flex: 1;
          display: flex;
          flex-direction: column;
          background: #090d16;
          overflow: hidden;
          position: relative;
        }

        .wb-toolbar {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 6px 8px;
          background: rgba(15, 23, 42, 0.95);
          border-bottom: 1px solid var(--border-subtle);
          flex-wrap: wrap;
          gap: 4px;
        }

        .wb-tool-group {
          display: flex;
          gap: 3px;
          align-items: center;
        }

        .wb-tool-btn {
          padding: 4px 6px;
          border-radius: 4px;
          border: 1px solid transparent;
          background: transparent;
          color: var(--text-muted);
          cursor: pointer;
          font-size: 11px;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .wb-tool-btn.active {
          border-color: var(--primary);
          background: rgba(99, 102, 241, 0.25);
          color: #c7d2fe;
        }

        .wb-palette-bar {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 3px 8px;
          background: rgba(0, 0, 0, 0.3);
          border-bottom: 1px solid var(--border-subtle);
        }

        .color-dot {
          width: 13px;
          height: 13px;
          border-radius: 50%;
          border: 1px solid rgba(255, 255, 255, 0.2);
          cursor: pointer;
        }

        .color-dot.active {
          border: 2px solid #ffffff;
          box-shadow: 0 0 6px rgba(255, 255, 255, 0.5);
        }

        .size-pill {
          font-size: 9px;
          font-weight: 700;
          padding: 1px 4px;
          border-radius: 3px;
          background: rgba(255, 255, 255, 0.05);
          border: 1px solid transparent;
          color: var(--text-dim);
          cursor: pointer;
        }

        .size-pill.active {
          background: rgba(99, 102, 241, 0.3);
          border-color: var(--primary);
          color: #ffffff;
        }

        #nb-whiteboard-canvas {
          flex-grow: 1;
          width: 100%;
          height: 100%;
          cursor: crosshair;
          touch-action: none;
        }

        /* Input Composer */
        .composer-box {
          display: flex;
          align-items: center;
          gap: 6px;
          padding: 8px 10px;
          background: rgba(15, 23, 42, 0.95);
          border-top: 1px solid var(--border-subtle);
        }

        .input-glass {
          flex: 1;
          background: rgba(0, 0, 0, 0.4);
          border: 1px solid var(--border-subtle);
          border-radius: 8px;
          padding: 7px 10px;
          color: #ffffff;
          font-size: 11px;
          outline: none;
        }

        .input-glass:focus {
          border-color: var(--primary);
        }

        .btn-send {
          background: var(--primary);
          border: none;
          color: #ffffff;
          padding: 6px 10px;
          border-radius: 8px;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .prompt-pills-row {
          display: flex;
          gap: 4px;
          padding: 4px 8px;
          overflow-x: auto;
          background: rgba(0, 0, 0, 0.3);
          border-top: 1px solid var(--border-subtle);
        }

        .prompt-pill {
          background: rgba(255, 255, 255, 0.06);
          border: 1px solid var(--border-subtle);
          color: var(--text-secondary);
          font-size: 9px;
          font-weight: 600;
          padding: 2px 6px;
          border-radius: 4px;
          cursor: pointer;
          white-space: nowrap;
        }

        .prompt-pill:hover {
          background: rgba(99, 102, 241, 0.2);
          color: #ffffff;
        }
      </style>

      <!-- In-Page Popup Card Window -->
      <div class="popup-card" id="nb-popup-card">
        <!-- Room Header Bar -->
        <div class="room-header">
          <div class="room-info">
            <div class="platform-icon-box">⚡</div>
            <div>
              <div class="problem-title">${this.escapeHtml(t)}</div>
              <div class="badges-row">
                <span class="platform-pill">${h}</span>
                <span class="peer-count-pill">
                  <span style="display:inline-block;width:6px;height:6px;border-radius:50%;background:#10b981;"></span>
                  <span>${this.peerCount} Online</span>
                </span>
              </div>
            </div>
          </div>

          <div class="header-actions">
            <!-- Popup Size Mode Switcher Pills -->
            <div class="popup-size-group" style="display:flex;gap:2px;align-items:center;background:rgba(0,0,0,0.35);padding:2px;border-radius:6px;border:1px solid rgba(255,255,255,0.08);margin-right:2px;">
              <button class="size-mode-pill ${this.popupSize==="compact"?"active":""}" data-popsize="compact" title="Compact Size (420x540)" style="font-size:9px;font-weight:700;padding:2px 5px;border-radius:4px;border:none;cursor:pointer;background:${this.popupSize==="compact"?"var(--primary)":"transparent"};color:${this.popupSize==="compact"?"#fff":"var(--text-muted)"};">📱 S</button>
              <button class="size-mode-pill ${this.popupSize==="medium"?"active":""}" data-popsize="medium" title="Medium Split Size (620x640)" style="font-size:9px;font-weight:700;padding:2px 5px;border-radius:4px;border:none;cursor:pointer;background:${this.popupSize==="medium"?"var(--primary)":"transparent"};color:${this.popupSize==="medium"?"#fff":"var(--text-muted)"};">🌗 M</button>
              <button class="size-mode-pill ${this.popupSize==="large"?"active":""}" data-popsize="large" title="Large Widescreen (860x740)" style="font-size:9px;font-weight:700;padding:2px 5px;border-radius:4px;border:none;cursor:pointer;background:${this.popupSize==="large"?"var(--primary)":"transparent"};color:${this.popupSize==="large"?"#fff":"var(--text-muted)"};">🖥️ L</button>
              <button class="size-mode-pill ${this.popupSize==="fullscreen"?"active":""}" data-popsize="fullscreen" title="Full Screen View (1180x880)" style="font-size:9px;font-weight:700;padding:2px 5px;border-radius:4px;border:none;cursor:pointer;background:${this.popupSize==="fullscreen"?"var(--primary)":"transparent"};color:${this.popupSize==="fullscreen"?"#fff":"var(--text-muted)"};">📺 XL</button>
            </div>

            <button class="icon-btn" id="nb-open-sidepanel" title="Open complete extension in side panel">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M15 3h6v6M10 14L21 3M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6"/>
              </svg>
            </button>
            <button class="icon-btn" id="nb-close-popup" title="Minimize">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M18 6L6 18M6 6l12 12"/>
              </svg>
            </button>
          </div>
        </div>

        <!-- Segmented Switcher when Both Chat and Whiteboard are Enabled -->
        ${e==="both"?`
          <div class="tab-switcher">
            <button class="tab-btn ${this.activeTab==="chat"?"active":""}" id="nb-tab-chat">
              <span>💬 Live Chat</span>
            </button>
            <button class="tab-btn ${this.activeTab==="whiteboard"?"active":""}" id="nb-tab-whiteboard">
              <span>🎨 Whiteboard</span>
            </button>
          </div>
        `:""}

        <!-- Multi-Broadcaster Live Streams List -->
        ${i?`
          <div style="background:linear-gradient(135deg, rgba(239, 68, 68, 0.22), rgba(139, 92, 246, 0.18));border-bottom:1px solid rgba(239, 68, 68, 0.35);padding:6px 10px;display:flex;flex-direction:column;gap:5px;">
            <div style="display:flex;align-items:center;justify-content:space-between;font-size:10px;color:#fca5a5;">
              <div style="display:flex;align-items:center;gap:5px;font-weight:700;">
                <span class="live-dot"></span>
                <span>LIVE STREAMS (${this.liveStage.activeStreams&&this.liveStage.activeStreams.length||1}):</span>
              </div>
              <button id="nb-live-tunein" style="background:#ef4444;color:#fff;border:none;padding:2px 8px;border-radius:4px;font-size:9px;font-weight:700;cursor:pointer;">
                Open Side Panel 📺
              </button>
            </div>

            <div style="display:flex;gap:4px;overflow-x:auto;padding-bottom:2px;">
              ${(this.liveStage.activeStreams&&this.liveStage.activeStreams.length>0?this.liveStage.activeStreams:[{broadcasterIdentity:this.liveStage.tutorIdentity||{nickname:r,avatar:"👑"},title:`${r}'s Walkthrough`,broadcastType:this.liveStage.broadcastType||"screen"}]).map(o=>{var a,b;return`
                <div style="display:flex;align-items:center;gap:4px;padding:3px 6px;border-radius:4px;background:rgba(0,0,0,0.4);border:1px solid rgba(255,255,255,0.1);font-size:10px;color:#f8fafc;white-space:nowrap;">
                  <span>${((a=o.broadcasterIdentity)==null?void 0:a.avatar)||"👤"}</span>
                  <span style="font-weight:600;">${((b=o.broadcasterIdentity)==null?void 0:b.nickname)||"Streamer"}:</span>
                  <span style="color:#c7d2fe;max-width:110px;overflow:hidden;text-overflow:ellipsis;">${this.escapeHtml(o.title||"Live Stream")}</span>
                  <span style="font-size:8px;padding:1px 4px;border-radius:3px;background:rgba(239,68,68,0.3);color:#fca5a5;text-transform:uppercase;">${o.broadcastType||"live"}</span>
                </div>
              `}).join("")}
            </div>
          </div>
        `:""}

        <!-- Main Body: Chat or Whiteboard -->
        ${l?`
          <!-- Whiteboard View -->
          <div class="whiteboard-container">
            <div class="wb-toolbar">
              <div class="wb-tool-group">
                <button class="wb-tool-btn ${this.wbTool==="pen"?"active":""}" data-wbtool="pen" title="Fine Pen">✏️</button>
                <button class="wb-tool-btn ${this.wbTool==="brush"?"active":""}" data-wbtool="brush" title="Brush Pen">✒️</button>
                <button class="wb-tool-btn ${this.wbTool==="highlighter"?"active":""}" data-wbtool="highlighter" title="Highlighter">🖍️</button>
                <button class="wb-tool-btn ${this.wbTool==="temp_pen"?"active":""}" data-wbtool="temp_pen" title="⏳ Disappearing Ink (Fades in 3s)">⏳</button>
                <button class="wb-tool-btn ${this.wbTool==="laser"?"active":""}" data-wbtool="laser" title="Laser Pointer">🔴</button>
                <button class="wb-tool-btn ${this.wbTool==="torch"?"active":""}" data-wbtool="torch" title="Spotlight Torch">🔦</button>
                <button class="wb-tool-btn ${this.wbTool==="eraser"?"active":""}" data-wbtool="eraser" title="Eraser">🧹</button>
                <button class="wb-tool-btn ${this.wbTool==="line"?"active":""}" data-wbtool="line" title="Line">📏</button>
                <button class="wb-tool-btn ${this.wbTool==="arrow"?"active":""}" data-wbtool="arrow" title="Arrow">➡️</button>
                <button class="wb-tool-btn ${this.wbTool==="rect"?"active":""}" data-wbtool="rect" title="Box">🔲</button>
                <button class="wb-tool-btn ${this.wbTool==="circle"?"active":""}" data-wbtool="circle" title="Node">⭕</button>
                <button class="wb-tool-btn ${this.wbTool==="tree_node"?"active":""}" data-wbtool="tree_node" title="Tree Node">🌳</button>
                <button class="wb-tool-btn ${this.wbTool==="db_cylinder"?"active":""}" data-wbtool="db_cylinder" title="Database Cylinder">🗄️</button>
                <button class="wb-tool-btn ${this.wbTool==="cloud"?"active":""}" data-wbtool="cloud" title="Cloud Gateway">☁️</button>
                <button class="wb-tool-btn ${this.wbTool==="load_balancer"?"active":""}" data-wbtool="load_balancer" title="Load Balancer">⚖️</button>
                <button class="wb-tool-btn ${this.wbTool==="message_queue"?"active":""}" data-wbtool="message_queue" title="Message Queue">📨</button>
                <button class="wb-tool-btn ${this.wbTool==="server_box"?"active":""}" data-wbtool="server_box" title="Server Box">📦</button>
              </div>

              <div class="wb-tool-group">
                <div style="display:flex;gap:2px;align-items:center;background:rgba(0,0,0,0.3);padding:2px 3px;border-radius:4px;">
                  <button class="wb-privacy-btn" data-wbprivacy="collaborative" style="font-size:9px;font-weight:700;padding:2px 4px;border-radius:3px;border:none;cursor:pointer;background:${this.wbPrivacyMode==="collaborative"?"var(--primary)":"transparent"};color:${this.wbPrivacyMode==="collaborative"?"#fff":"var(--text-muted)"};" title="👥 Collaborative with Room Peers">👥 Collab</button>
                  <button class="wb-privacy-btn" data-wbprivacy="personal" style="font-size:9px;font-weight:700;padding:2px 4px;border-radius:3px;border:none;cursor:pointer;background:${this.wbPrivacyMode==="personal"?"var(--primary)":"transparent"};color:${this.wbPrivacyMode==="personal"?"#fff":"var(--text-muted)"};" title="🔒 Personal Private Scratchpad">🔒 Personal</button>
                </div>
                <button class="wb-tool-btn" id="nb-wb-undo" title="Undo">↩️</button>
                <button class="wb-tool-btn" id="nb-wb-redo" title="Redo">↪️</button>
                <button class="wb-tool-btn" id="nb-wb-clear" title="Clear Canvas" style="color:#f87171;">🗑️</button>
                <button class="wb-tool-btn" id="nb-wb-save" title="Export PNG">💾</button>
              </div>
            </div>

            <!-- Color Palette, Widths, BG Colors & Background Patterns -->
            <div class="wb-palette-bar">
              <div style="display:flex;gap:2px;align-items:center;overflow-x:auto;">
                <button class="size-pill ${this.wbTheme==="grid"?"active":""}" data-wbtheme="grid" title="Square Graph Grid">⬛ Grid</button>
                <button class="size-pill ${this.wbTheme==="ruled"?"active":""}" data-wbtheme="ruled" title="Ruled Lined Paper">📏 Ruled</button>
                <button class="size-pill ${this.wbTheme==="plot"?"active":""}" data-wbtheme="plot" title="Coordinate Plot (X,Y)">📈 Plot</button>
                <button class="size-pill ${this.wbTheme==="dotted"?"active":""}" data-wbtheme="dotted" title="Dot Grid">🟦 Dots</button>
                <button class="size-pill ${this.wbTheme==="matrix"?"active":""}" data-wbtheme="matrix" title="Matrix Table">📐 Matrix</button>
              </div>

              <!-- BG Colors -->
              <div style="display:flex;gap:3px;align-items:center;">
                ${["#090d16","#0f172a","#062c24","#fef3c7","#ffffff","#f8fafc","#1e1035"].map(o=>`
                  <div class="bg-dot" data-wbbg="${o}" style="width:10px;height:10px;border-radius:2px;background:${o};border:${this.wbBgColor===o?"2px solid #6366f1":"1px solid rgba(255,255,255,0.2)"};cursor:pointer;" title="Background Color"></div>
                `).join("")}
              </div>

              <div style="display:flex;gap:4px;align-items:center;">
                ${["#6366f1","#06b6d4","#10b981","#f59e0b","#f43f5e","#ffffff"].map(o=>`
                  <div class="color-dot ${this.wbColor===o?"active":""}" data-color="${o}" style="background:${o};"></div>
                `).join("")}
              </div>

              <div style="display:flex;gap:2px;align-items:center;">
                <button class="size-pill ${this.wbWidth===2?"active":""}" data-size="2">S</button>
                <button class="size-pill ${this.wbWidth===4?"active":""}" data-size="4">M</button>
                <button class="size-pill ${this.wbWidth===8?"active":""}" data-size="8">L</button>
              </div>
            </div>

            <!-- HTML5 Interactive Canvas -->
            <canvas id="nb-whiteboard-canvas"></canvas>
          </div>
        `:`
          <!-- Chat Messages View -->
          <div class="message-list" id="nb-messages">
            ${this.messages.length===0?`
              <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:100%;color:var(--text-muted);gap:8px;padding:30px 10px;text-align:center;">
                <div style="font-size:28px;">💬</div>
                <div style="font-size:13px;font-weight:600;color:var(--text-secondary);">No messages yet</div>
                <div style="font-size:11px;max-width:220px;">Say hello or ask for a hint! Messages are synchronized P2P across all peers.</div>
              </div>
            `:this.messages.map((o,a)=>{var b,p,v,x;return`
              <div class="chat-bubble ${o.isSelf?"self":"other"}">
                ${o.replyPreview?`<div style="border-left:2px solid var(--primary);padding-left:6px;margin-bottom:4px;font-size:10px;color:var(--text-muted);">${this.escapeHtml(o.replyPreview)}</div>`:""}
                
                <div class="chat-header">
                  <div class="chat-author">
                    <span>${((b=o.from)==null?void 0:b.avatar)||"👤"}</span>
                    <span style="color:${o.isSelf?"#ffffff":((p=o.from)==null?void 0:p.color)||"#a5b4fc"}">
                      ${o.isSelf?"You":((v=o.from)==null?void 0:v.nickname)||"Buddy"}
                    </span>
                  </div>
                  <div style="display:flex;align-items:center;gap:4px;">
                    <span class="chat-timestamp">${this.formatTimestamp(o.timestamp)}</span>
                    <button class="icon-btn nb-reply-trigger" data-id="${o.id}" data-text="${this.escapeHtml(o.text.slice(0,35))}" data-nick="${this.escapeHtml(((x=o.from)==null?void 0:x.nickname)||"Buddy")}" style="padding:0;width:18px;height:18px;" title="Reply">
                      ↩
                    </button>
                  </div>
                </div>

                <div class="chat-body">${this.renderFormattedText(o.text,a)}</div>

                ${o.isSelf?`
                  <div class="chat-footer">
                    ${o.status==="pending"?"<span>⏳</span>":""}
                    ${o.status==="sent"?'<span style="color:var(--text-dim);">✓</span>':""}
                    ${o.status==="delivered"?'<span style="color:var(--text-secondary);">✓✓</span>':""}
                    ${o.status==="read"?'<span class="ack-read">✓✓</span>':""}
                  </div>
                `:""}
              </div>
            `}).join("")}
          </div>

          <!-- Quick Strategy Prompt Pills -->
          <div class="prompt-pills-row">
            <button class="prompt-pill" data-text="⚡ O(N) Time">⚡ O(N) Time</button>
            <button class="prompt-pill" data-text="💾 O(1) Space">💾 O(1) Space</button>
            <button class="prompt-pill" data-text="👉 Two Pointers">👉 Two Pointers</button>
            <button class="prompt-pill" data-text="🔍 Binary Search">🔍 Binary Search</button>
            <button class="prompt-pill" data-text="🧠 DP / Memo">🧠 DP / Memo</button>
            <button class="prompt-pill" data-text="💡 Sliding Window">💡 Sliding Window</button>
          </div>

          <!-- Input Box & Composer -->
          <form class="composer-box" id="nb-composer">
            <button type="button" class="icon-btn" id="nb-spoiler-insert" title="Insert Spoiler Blur ||text||" style="width:28px;height:28px;flex-shrink:0;">
              👁️
            </button>
            <input type="text" class="input-glass" id="nb-input" placeholder="Type a hint, code snippet, or ||spoiler||..." />
            <button type="submit" class="btn-send">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <line x1="22" y1="2" x2="11" y2="13"></line>
                <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
              </svg>
            </button>
          </form>
        `}
      </div>

      <!-- Draggable Floating Action Button (FAB) -->
      <button class="fab-button" id="nb-fab-trigger" title="Drag anywhere or click to open">
        <span class="drag-grip">⠿</span>
        ${i?'<span class="live-dot"></span>':`<span>${c}</span>`}
        <span>${s}</span>
        ${this.unreadCount>0?`<span class="fab-badge">${this.unreadCount}</span>`:""}
      </button>
    `,this.attachEventListeners(),l&&this.initWhiteboardCanvas()}attachEventListeners(){if(!this.shadow)return;const e=this.shadow.getElementById("nb-fab-trigger");if(e){let u=0,g=0,w=24,n=24;const o=p=>{if(!this.isDragging)return;const v="touches"in p?p.touches[0].clientX:p.clientX,x="touches"in p?p.touches[0].clientY:p.clientY,S=v-u,k=x-g;if(Math.hypot(S,k)>4){this.dragMoved=!0;const $=w-S,I=n-k;this.currentPosition={right:Math.max(10,Math.min(window.innerWidth-130,$)),bottom:Math.max(10,Math.min(window.innerHeight-55,I))},this.applyHostPosition()}},a=()=>{var p;if(this.isDragging&&(this.isDragging=!1,window.removeEventListener("mousemove",o),window.removeEventListener("mouseup",a),window.removeEventListener("touchmove",o),window.removeEventListener("touchend",a),this.dragMoved)){if(this.settings.positionMode==="permanent"){const v={...this.settings,savedPosition:{...this.currentPosition}};this.settings=v,typeof chrome<"u"&&((p=chrome.storage)!=null&&p.local)&&chrome.storage.local.set({[T]:v})}setTimeout(()=>{this.dragMoved=!1},60)}},b=p=>{this.isDragging=!0,this.dragMoved=!1,u="touches"in p?p.touches[0].clientX:p.clientX,g="touches"in p?p.touches[0].clientY:p.clientY,w=this.currentPosition.right,n=this.currentPosition.bottom,window.addEventListener("mousemove",o,{passive:!0}),window.addEventListener("mouseup",a),window.addEventListener("touchmove",o,{passive:!0}),window.addEventListener("touchend",a)};e.addEventListener("mousedown",b),e.addEventListener("touchstart",b,{passive:!0}),e.addEventListener("click",()=>{var p;if(!this.dragMoved){if(this.settings.clickAction==="open_extension"){typeof chrome<"u"&&((p=chrome.runtime)!=null&&p.sendMessage)&&chrome.runtime.sendMessage({type:"OPEN_SIDEPANEL"}).catch(()=>{});return}this.isOpen=!this.isOpen,this.unreadCount=0,this.render(),this.isOpen&&this.activeTab==="chat"&&this.scrollToBottom()}})}this.shadow.querySelectorAll(".size-mode-pill[data-popsize]").forEach(u=>{u.addEventListener("click",g=>{const w=g.currentTarget.getAttribute("data-popsize");w&&(this.popupSize=w,this.render())})});const r=this.shadow.getElementById("nb-close-popup");r==null||r.addEventListener("click",()=>{this.isOpen=!1,this.render()});const t=this.shadow.getElementById("nb-open-sidepanel");t==null||t.addEventListener("click",()=>{var u;this.isOpen=!1,this.render(),typeof chrome<"u"&&((u=chrome.runtime)!=null&&u.sendMessage)&&chrome.runtime.sendMessage({type:"OPEN_SIDEPANEL"}).catch(()=>{})});const h=this.shadow.getElementById("nb-tab-chat");h==null||h.addEventListener("click",()=>{this.activeTab="chat",this.render(),this.scrollToBottom()});const f=this.shadow.getElementById("nb-tab-whiteboard");f==null||f.addEventListener("click",()=>{this.activeTab="whiteboard",this.render()});const l=this.shadow.getElementById("nb-live-tunein");l==null||l.addEventListener("click",()=>{var u;this.isOpen=!1,this.render(),typeof chrome<"u"&&((u=chrome.runtime)!=null&&u.sendMessage)&&chrome.runtime.sendMessage({type:"OPEN_SIDEPANEL"}).catch(()=>{})}),this.shadow.querySelectorAll(".prompt-pill").forEach(u=>{u.addEventListener("click",g=>{const w=g.target.getAttribute("data-text");w&&this.sendMessage(w)})});const s=this.shadow.getElementById("nb-spoiler-insert"),d=this.shadow.getElementById("nb-input");if(s==null||s.addEventListener("click",()=>{d&&(d.value=`${d.value}||hint solution||`,d.focus())}),d){const u=g=>g.stopPropagation();d.addEventListener("keydown",u),d.addEventListener("keyup",u),d.addEventListener("keypress",u)}const m=this.shadow.getElementById("nb-composer");m==null||m.addEventListener("submit",u=>{u.preventDefault();const g=d==null?void 0:d.value.trim();g&&(this.sendMessage(g,this.replyingTo?{id:this.replyingTo.id,preview:`${this.replyingTo.from.nickname}: ${this.replyingTo.text.slice(0,30)}`}:void 0),d&&(d.value=""),this.replyingTo=null)})}initWhiteboardCanvas(){var m,u,g,w;if(!this.shadow)return;const e=this.shadow.getElementById("nb-whiteboard-canvas");if(!e)return;this.shadow.querySelectorAll(".wb-tool-btn[data-wbtool]").forEach(n=>{n.addEventListener("click",o=>{const a=o.currentTarget.getAttribute("data-wbtool");if(a){this.wbTool=a;const b=this.toolStyles[a]||{color:"#6366f1",width:3};this.wbColor=b.color,this.wbWidth=b.width,this.render()}})}),this.shadow.querySelectorAll(".wb-privacy-btn[data-wbprivacy]").forEach(n=>{n.addEventListener("click",o=>{const a=o.currentTarget.getAttribute("data-wbprivacy");a&&(this.wbPrivacyMode=a,this.render())})}),this.shadow.querySelectorAll(".size-pill[data-wbtheme]").forEach(n=>{n.addEventListener("click",o=>{const a=o.currentTarget.getAttribute("data-wbtheme");a&&(this.wbTheme=a,a==="clean_white"&&this.wbColor==="#ffffff"&&(this.wbColor="#0f172a"),this.render())})}),this.shadow.querySelectorAll(".bg-dot[data-wbbg]").forEach(n=>{n.addEventListener("click",o=>{const a=o.currentTarget.getAttribute("data-wbbg");a&&(this.wbBgColor=a,this.render())})}),this.shadow.querySelectorAll(".color-dot").forEach(n=>{n.addEventListener("click",o=>{const a=o.currentTarget.getAttribute("data-color");a&&(this.wbColor=a,this.toolStyles[this.wbTool]&&(this.toolStyles[this.wbTool].color=a),this.render())})}),this.shadow.querySelectorAll(".size-pill[data-size]").forEach(n=>{n.addEventListener("click",o=>{const a=Number(o.currentTarget.getAttribute("data-size"));a&&(this.wbWidth=a,this.toolStyles[this.wbTool]&&(this.toolStyles[this.wbTool].width=a),this.render())})}),(m=this.shadow.getElementById("nb-wb-undo"))==null||m.addEventListener("click",()=>{var o;const n=this.wbPrivacyMode==="personal"?this.wbPersonalStrokes:this.wbStrokes;if(n.length===0&&this.wbRedoStack.length>0){this.wbPrivacyMode==="personal"?this.wbPersonalStrokes=[...this.wbRedoStack]:(this.wbStrokes=[...this.wbRedoStack],this.wbStrokes.forEach(a=>{var b;typeof chrome<"u"&&((b=chrome.runtime)!=null&&b.sendMessage)&&chrome.runtime.sendMessage({type:"WHITEBOARD_STROKE_LOCAL",stroke:a}).catch(()=>{})})),this.wbRedoStack=[],this.drawWbCanvas();return}if(n.length>0){const a=n.pop();a&&(this.wbRedoStack.push(a),this.drawWbCanvas(),this.wbPrivacyMode==="collaborative"&&typeof chrome<"u"&&((o=chrome.runtime)!=null&&o.sendMessage)&&chrome.runtime.sendMessage({type:"WHITEBOARD_UNDO_LOCAL",strokeId:a.id}).catch(()=>{}))}}),(u=this.shadow.getElementById("nb-wb-redo"))==null||u.addEventListener("click",()=>{var n;if(this.wbRedoStack.length>0){const o=this.wbRedoStack.pop();o&&((this.wbPrivacyMode==="personal"?this.wbPersonalStrokes:this.wbStrokes).push(o),this.drawWbCanvas(),this.wbPrivacyMode==="collaborative"&&typeof chrome<"u"&&((n=chrome.runtime)!=null&&n.sendMessage)&&chrome.runtime.sendMessage({type:"WHITEBOARD_STROKE_LOCAL",stroke:o}).catch(()=>{}))}}),(g=this.shadow.getElementById("nb-wb-clear"))==null||g.addEventListener("click",()=>{var o;const n=this.wbPrivacyMode==="personal"?this.wbPersonalStrokes:this.wbStrokes;n.length!==0&&(this.wbRedoStack=[...n],this.wbPrivacyMode==="personal"?this.wbPersonalStrokes=[]:(this.wbStrokes=[],typeof chrome<"u"&&((o=chrome.runtime)!=null&&o.sendMessage)&&chrome.runtime.sendMessage({type:"WHITEBOARD_CLEAR_LOCAL"}).catch(()=>{})),this.drawWbCanvas())}),(w=this.shadow.getElementById("nb-wb-save"))==null||w.addEventListener("click",()=>{const n=e.toDataURL("image/png"),o=document.createElement("a");o.download=`synqto-whiteboard-${Date.now()}.png`,o.href=n,o.click()}),setTimeout(()=>{const n=e.getBoundingClientRect(),o=window.devicePixelRatio||1;e.width=(n.width||380)*o,e.height=(n.height||360)*o;const a=e.getContext("2d");a&&a.scale(o,o),this.drawWbCanvas()},30);const c=n=>{const o=e.getBoundingClientRect();let a=0,b=0;return"touches"in n&&n.touches.length>0?(a=n.touches[0].clientX,b=n.touches[0].clientY):"clientX"in n&&(a=n.clientX,b=n.clientY),{x:a-o.left,y:b-o.top}},s=(n,o,a)=>{if(n.geometry){const{x1:b,y1:p,x2:v,y2:x}=n.geometry,S=Math.min(b,v)-a,k=Math.max(b,v)+a,$=Math.min(p,x)-a,I=Math.max(p,x)+a;return o.x>=S&&o.x<=k&&o.y>=$&&o.y<=I}if(n.points&&n.points.length>0){const b=a+n.width/2;return n.points.some(p=>Math.hypot(p.x-o.x,p.y-o.y)<=b)}return!1};e.addEventListener("mousedown",n=>{const o=c(n);if(this.wbTool==="eraser"){this.isWbDrawing=!0,this.wbEraserPos=o;const a=(this.wbWidth||4)*3,b=this.wbPrivacyMode==="personal"?this.wbPersonalStrokes:this.wbStrokes,p=b.filter(v=>!s(v,o,a));if(p.length!==b.length){const v=b.filter(x=>s(x,o,a));this.wbRedoStack.push(...v),this.wbPrivacyMode==="personal"?this.wbPersonalStrokes=p:(this.wbStrokes=p,v.forEach(x=>{var S;typeof chrome<"u"&&((S=chrome.runtime)!=null&&S.sendMessage)&&chrome.runtime.sendMessage({type:"WHITEBOARD_UNDO_LOCAL",strokeId:x.id}).catch(()=>{})}))}this.drawWbCanvas();return}if(this.wbTool==="laser"){this.wbLaserTrails.push({x:o.x,y:o.y,alpha:1,timestamp:Date.now()}),this.drawWbCanvas();return}if(this.wbTool==="torch"){this.wbTorchPos=o,this.drawWbCanvas();return}this.isWbDrawing=!0,this.wbStartPoint=o,this.wbCurrentPoints=[o]}),e.addEventListener("mousemove",n=>{const o=c(n);if(this.wbTool==="eraser"){if(this.wbEraserPos=o,this.isWbDrawing){const b=(this.wbWidth||4)*3,p=this.wbPrivacyMode==="personal"?this.wbPersonalStrokes:this.wbStrokes,v=p.filter(x=>!s(x,o,b));if(v.length!==p.length){const x=p.filter(S=>s(S,o,b));this.wbRedoStack.push(...x),this.wbPrivacyMode==="personal"?this.wbPersonalStrokes=v:(this.wbStrokes=v,x.forEach(S=>{var k;typeof chrome<"u"&&((k=chrome.runtime)!=null&&k.sendMessage)&&chrome.runtime.sendMessage({type:"WHITEBOARD_UNDO_LOCAL",strokeId:S.id}).catch(()=>{})}))}}this.drawWbCanvas();return}if(this.wbTool==="laser"){this.wbLaserTrails.push({x:o.x,y:o.y,alpha:1,timestamp:Date.now()}),this.drawWbCanvas();return}if(this.wbTool==="torch"){this.wbTorchPos=o,this.drawWbCanvas();return}if(!this.isWbDrawing)return;["line","arrow","rect","circle","tree_node","db_cylinder","cloud","load_balancer","message_queue","server_box"].includes(this.wbTool)&&this.wbStartPoint?this.drawWbCanvas(void 0,{x1:this.wbStartPoint.x,y1:this.wbStartPoint.y,x2:o.x,y2:o.y}):(this.wbCurrentPoints.push(o),this.drawWbCanvas(this.wbCurrentPoints))});const d=n=>{var v;if(this.wbTool==="eraser"){this.isWbDrawing=!1,this.wbEraserPos=null,this.drawWbCanvas();return}if(this.wbTool==="torch"){this.wbTorchPos=null,this.drawWbCanvas();return}if(!this.isWbDrawing)return;this.isWbDrawing=!1;const o=c(n),a=["line","arrow","rect","circle","tree_node","db_cylinder","cloud","load_balancer","message_queue","server_box"].includes(this.wbTool),b=this.wbTool==="highlighter"?16:this.wbWidth,p={id:"stroke-"+Math.random().toString(36).slice(2,10),tool:this.wbTool,color:this.wbColor,width:b,opacity:this.wbTool==="highlighter"?.35:1,points:a?[]:[...this.wbCurrentPoints],geometry:a&&this.wbStartPoint?{x1:this.wbStartPoint.x,y1:this.wbStartPoint.y,x2:o.x,y2:o.y}:void 0};this.wbTool==="temp_pen"?this.tempDisappearingStrokes.push({stroke:p,createdAt:Date.now(),durationMs:3e3}):this.wbPrivacyMode==="personal"?this.wbPersonalStrokes.push(p):(this.wbStrokes.push(p),typeof chrome<"u"&&((v=chrome.runtime)!=null&&v.sendMessage)&&chrome.runtime.sendMessage({type:"WHITEBOARD_STROKE_LOCAL",stroke:p}).catch(()=>{})),this.wbRedoStack=[],this.wbCurrentPoints=[],this.wbStartPoint=null,this.drawWbCanvas()};e.addEventListener("mouseup",d),e.addEventListener("mouseleave",d)}drawWbCanvas(e,i){if(!this.shadow)return;const r=this.shadow.getElementById("nb-whiteboard-canvas");if(!r)return;const t=r.getContext("2d");if(!t)return;t.clearRect(0,0,r.width,r.height),t.save();const h=this.wbBgColor==="#ffffff"||this.wbBgColor==="#f8fafc"||this.wbBgColor==="#fef3c7";if(t.fillStyle=this.wbBgColor||(h?"#f8fafc":"#090d16"),t.fillRect(0,0,r.width,r.height),this.wbTheme==="ruled"){t.strokeStyle="rgba(99, 102, 241, 0.18)",t.lineWidth=1;for(let s=28;s<r.height;s+=24)t.beginPath(),t.moveTo(0,s),t.lineTo(r.width,s),t.stroke();t.strokeStyle="rgba(244, 63, 94, 0.4)",t.lineWidth=1.5,t.beginPath(),t.moveTo(40,0),t.lineTo(40,r.height),t.stroke()}else if(this.wbTheme==="plot"){const s=Math.floor(r.width/2),d=Math.floor(r.height/2);t.strokeStyle="#6366f1",t.lineWidth=1.5,t.beginPath(),t.moveTo(0,d),t.lineTo(r.width,d),t.moveTo(s,0),t.lineTo(s,r.height),t.stroke()}else if(this.wbTheme==="dotted"){t.fillStyle="rgba(255, 255, 255, 0.16)";for(let s=8;s<r.width;s+=18)for(let d=8;d<r.height;d+=18)t.beginPath(),t.arc(s,d,1.2,0,Math.PI*2),t.fill()}else if(this.wbTheme==="matrix"){t.strokeStyle="rgba(99, 102, 241, 0.15)",t.lineWidth=1;const s=26;for(let d=0;d<r.width;d+=s)t.beginPath(),t.moveTo(d,0),t.lineTo(d,r.height),t.stroke();for(let d=0;d<r.height;d+=s)t.beginPath(),t.moveTo(0,d),t.lineTo(r.width,d),t.stroke()}else if(this.wbTheme==="grid"){t.strokeStyle="rgba(255, 255, 255, 0.04)",t.lineWidth=1;const s=20;for(let d=0;d<r.width;d+=s)t.beginPath(),t.moveTo(d,0),t.lineTo(d,r.height),t.stroke();for(let d=0;d<r.height;d+=s)t.beginPath(),t.moveTo(0,d),t.lineTo(r.width,d),t.stroke()}if(t.restore(),this.wbTool==="eraser"&&this.wbEraserPos){t.save();const s=(this.wbWidth||4)*3;t.strokeStyle="#ef4444",t.lineWidth=1.5,t.setLineDash([3,3]),t.beginPath(),t.arc(this.wbEraserPos.x,this.wbEraserPos.y,s,0,Math.PI*2),t.stroke(),t.restore()}const f=s=>{if(s.tool==="eraser")return;t.save();let d=s.color;if(this.wbTheme==="white_blank"&&(d==="#ffffff"||d==="#fff")&&(d="#0f172a"),t.strokeStyle=d,t.fillStyle=d,t.lineWidth=s.width,t.lineCap="round",t.lineJoin="round",t.globalAlpha=s.opacity,s.geometry){const{x1:m,y1:u,x2:g,y2:w}=s.geometry;if(s.tool==="line")t.beginPath(),t.moveTo(m,u),t.lineTo(g,w),t.stroke();else if(s.tool==="arrow"){t.beginPath(),t.moveTo(m,u),t.lineTo(g,w),t.stroke();const n=Math.atan2(w-u,g-m),o=Math.max(10,s.width*3);t.beginPath(),t.moveTo(g,w),t.lineTo(g-o*Math.cos(n-Math.PI/6),w-o*Math.sin(n-Math.PI/6)),t.moveTo(g,w),t.lineTo(g-o*Math.cos(n+Math.PI/6),w-o*Math.sin(n+Math.PI/6)),t.stroke()}else if(s.tool==="rect")t.strokeRect(Math.min(m,g),Math.min(u,w),Math.abs(g-m),Math.abs(w-u));else if(s.tool==="circle"){const n=Math.abs(g-m)/2,o=Math.abs(w-u)/2;t.beginPath(),t.ellipse(Math.min(m,g)+n,Math.min(u,w)+o,n,o,0,0,Math.PI*2),t.stroke()}else if(s.tool==="tree_node"){const n=Math.max(16,s.width*3.5);t.beginPath(),t.arc(m,u,n,0,Math.PI*2),t.fillStyle="rgba(15, 23, 42, 0.9)",t.fill(),t.stroke(),s.geometry.label&&(t.fillStyle="#ffffff",t.font="bold 11px monospace",t.textAlign="center",t.textBaseline="middle",t.fillText(s.geometry.label,m,u))}else if(s.tool==="db_cylinder"){const n=Math.max(50,Math.abs(g-m)),o=Math.max(55,Math.abs(w-u)),a=Math.min(m,g),b=Math.min(u,w),p=Math.min(14,o*.2);t.fillStyle="rgba(15, 23, 42, 0.95)",t.beginPath(),t.ellipse(a+n/2,b+p,n/2,p,0,Math.PI,0),t.lineTo(a+n,b+o-p),t.ellipse(a+n/2,b+o-p,n/2,p,0,0,Math.PI),t.lineTo(a,b+p),t.fill(),t.stroke(),t.beginPath(),t.ellipse(a+n/2,b+p,n/2,p,0,0,Math.PI*2),t.stroke(),s.geometry.label&&(t.fillStyle="#ffffff",t.font="bold 10px sans-serif",t.textAlign="center",t.textBaseline="middle",t.fillText(s.geometry.label,a+n/2,b+o/2+4))}else if(s.tool==="cloud"){const n=Math.max(65,Math.abs(g-m)),o=Math.max(40,Math.abs(w-u)),a=Math.min(m,g),b=Math.min(u,w);t.fillStyle="rgba(15, 23, 42, 0.95)",t.beginPath(),t.roundRect(a,b,n,o,14),t.fill(),t.stroke(),s.geometry.label&&(t.fillStyle="#ffffff",t.font="bold 10px sans-serif",t.textAlign="center",t.textBaseline="middle",t.fillText(s.geometry.label,a+n/2,b+o/2))}else if(s.tool==="load_balancer"){const n=Math.max(55,Math.abs(g-m)),o=Math.max(55,Math.abs(w-u)),a=Math.min(m,g),b=Math.min(u,w),p=a+n/2,v=b+o/2;t.fillStyle="rgba(15, 23, 42, 0.95)",t.beginPath(),t.moveTo(p,b),t.lineTo(a+n,v),t.lineTo(p,b+o),t.lineTo(a,v),t.closePath(),t.fill(),t.stroke(),s.geometry.label&&(t.fillStyle="#ffffff",t.font="bold 10px sans-serif",t.textAlign="center",t.textBaseline="middle",t.fillText(s.geometry.label,p,v))}else if(s.tool==="message_queue"){const n=Math.max(70,Math.abs(g-m)),o=Math.max(34,Math.abs(w-u)),a=Math.min(m,g),b=Math.min(u,w);t.fillStyle="rgba(15, 23, 42, 0.95)",t.beginPath(),t.roundRect(a,b,n,o,6),t.fill(),t.stroke(),s.geometry.label&&(t.fillStyle="#ffffff",t.font="bold 9px sans-serif",t.textAlign="center",t.textBaseline="middle",t.fillText(s.geometry.label,a+n/2,b+o/2))}else if(s.tool==="server_box"){const n=Math.max(65,Math.abs(g-m)),o=Math.max(40,Math.abs(w-u)),a=Math.min(m,g),b=Math.min(u,w);t.fillStyle="rgba(15, 23, 42, 0.95)",t.beginPath(),t.roundRect(a,b,n,o,6),t.fill(),t.stroke(),t.fillStyle="#10b981",t.beginPath(),t.arc(a+10,b+10,3,0,Math.PI*2),t.fill(),s.geometry.label&&(t.fillStyle="#ffffff",t.font="bold 9px sans-serif",t.textAlign="center",t.textBaseline="middle",t.fillText(s.geometry.label,a+n/2,b+o/2+2))}}else if(s.points&&s.points.length>0)if(s.points.length===1)t.beginPath(),t.arc(s.points[0].x,s.points[0].y,s.width/2,0,Math.PI*2),t.fill();else{t.beginPath(),t.moveTo(s.points[0].x,s.points[0].y);for(let m=1;m<s.points.length-1;m++){const u=(s.points[m].x+s.points[m+1].x)/2,g=(s.points[m].y+s.points[m+1].y)/2;t.quadraticCurveTo(s.points[m].x,s.points[m].y,u,g)}t.lineTo(s.points[s.points.length-1].x,s.points[s.points.length-1].y),t.stroke()}t.restore()};(this.wbPrivacyMode==="personal"?this.wbPersonalStrokes:this.wbStrokes).forEach(f);const c=Date.now();this.tempDisappearingStrokes.forEach(s=>{const d=Math.max(0,1-(c-s.createdAt)/s.durationMs);f({...s.stroke,opacity:d})}),i?f({tool:this.wbTool,color:this.wbColor,width:this.wbTool==="highlighter"?14:this.wbWidth,opacity:this.wbTool==="highlighter"?.35:1,points:[],geometry:i}):e&&e.length>1&&f({tool:this.wbTool,color:this.wbColor,width:this.wbTool==="highlighter"?14:this.wbWidth,opacity:this.wbTool==="highlighter"?.35:1,points:e}),this.wbTool==="torch"&&this.wbTorchPos&&(t.save(),t.fillStyle="rgba(0, 0, 0, 0.75)",t.fillRect(0,0,r.width,r.height),t.globalCompositeOperation="destination-out",t.beginPath(),t.arc(this.wbTorchPos.x,this.wbTorchPos.y,55,0,Math.PI*2),t.fill(),t.globalCompositeOperation="source-over",t.strokeStyle="rgba(253, 224, 71, 0.85)",t.lineWidth=2.5,t.shadowColor="#fde047",t.shadowBlur=10,t.beginPath(),t.arc(this.wbTorchPos.x,this.wbTorchPos.y,55,0,Math.PI*2),t.stroke(),t.restore()),this.wbLaserTrails.forEach(s=>{t.save(),t.globalAlpha=s.alpha,t.fillStyle="#ef4444",t.shadowColor="#ef4444",t.shadowBlur=8,t.beginPath(),t.arc(s.x,s.y,4.5*s.alpha,0,Math.PI*2),t.fill(),t.restore()})}listenForRuntimeMessages(){var e;typeof chrome<"u"&&((e=chrome.runtime)!=null&&e.onMessage)&&chrome.runtime.onMessage.addListener(i=>{i.type==="WHITEBOARD_STROKE_LOCAL"&&i.stroke?this.wbStrokes.some(r=>r.id===i.stroke.id)||(this.wbStrokes.push(i.stroke),this.activeTab==="whiteboard"&&this.drawWbCanvas()):i.type==="WHITEBOARD_CLEAR_LOCAL"?(this.wbStrokes=[],this.wbRedoStack=[],this.activeTab==="whiteboard"&&this.drawWbCanvas()):i.type==="WHITEBOARD_UNDO_LOCAL"&&i.strokeId&&(this.wbStrokes=this.wbStrokes.filter(r=>r.id!==i.strokeId),this.activeTab==="whiteboard"&&this.drawWbCanvas())})}escapeHtml(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}formatTimestamp(e){return new Date(e).toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"})}renderFormattedText(e,i){return e.split(`
`).map((t,h)=>{if(t.startsWith("```")&&t.endsWith("```")&&t.length>6){const f=t.slice(3,-3);return`
          <div style="background:rgba(0,0,0,0.45);padding:6px 8px;border-radius:6px;margin:4px 0;font-family:var(--font-mono);font-size:11px;position:relative;">
            <pre style="margin:0;white-space:pre-wrap;word-break:break-all;">${this.escapeHtml(f)}</pre>
          </div>
        `}return t.includes("||")?`<p style="margin:2px 0;">${t.split(/(\|\|.*?\|\|)/g).map((c,s)=>{if(c.startsWith("||")&&c.endsWith("||")&&c.length>4){const d=c.slice(2,-2),m=`${i}-${h}-${s}`,u=!!this.revealedSpoilers[m];return`
              <span style="display:inline-block;padding:1px 6px;border-radius:4px;background:${u?"rgba(99, 102, 241, 0.25)":"rgba(255, 255, 255, 0.15)"};filter:${u?"none":"blur(4px)"};cursor:pointer;">
                ${this.escapeHtml(d)}
              </span>
            `}return this.escapeHtml(c)}).join("")}</p>`:`<p style="margin:2px 0;">${this.escapeHtml(t)}</p>`}).join("")}deduplicateMessages(e){var t,h;const i=new Set,r=[];for(const f of e)!f||!f.id||i.has(f.id)||(i.add(f.id),r.push({...f,isSelf:((t=f.from)==null?void 0:t.peerId)===((h=this.myIdentity)==null?void 0:h.peerId)||f.isSelf}));return r}async sendMessage(e,i){var f,l,c,s;if(!e.trim())return;!this.currentRoomStorageKey&&((f=this.currentProblem)!=null&&f.roomId)&&(this.currentRoomStorageKey=`synqto_chat_${this.currentProblem.roomId}`);const r=e.trim(),t="msg-"+Math.random().toString(36).slice(2,10)+Date.now(),h={id:t,from:this.myIdentity||{nickname:"You",avatar:"⚡",color:"#6366f1",peerId:"self"},text:r,timestamp:Date.now(),replyTo:i==null?void 0:i.id,replyPreview:i==null?void 0:i.preview,status:"sent",isSelf:!0};if(this.messages.push(h),this.messages=this.deduplicateMessages(this.messages),this.render(),this.scrollToBottom(),this.currentRoomStorageKey&&typeof chrome<"u"&&((l=chrome.storage)!=null&&l.local))try{const d=await chrome.storage.local.get([this.currentRoomStorageKey]),m=d[this.currentRoomStorageKey]&&Array.isArray(d[this.currentRoomStorageKey])?d[this.currentRoomStorageKey]:[],u=this.deduplicateMessages([...m,h]).slice(-150);await chrome.storage.local.set({[this.currentRoomStorageKey]:u})}catch{}typeof chrome<"u"&&((c=chrome.runtime)!=null&&c.sendMessage)&&chrome.runtime.sendMessage({type:"SEND_PAGE_CHAT_MESSAGE",messageId:t,text:h.text,replyTo:h.replyTo,replyPreview:h.replyPreview,roomId:(s=this.currentProblem)==null?void 0:s.roomId}).catch(()=>{})}async loadMessages(){var e;if(this.currentRoomStorageKey&&typeof chrome<"u"&&(e=chrome.storage)!=null&&e.local){const i=await chrome.storage.local.get([this.currentRoomStorageKey]);i[this.currentRoomStorageKey]&&Array.isArray(i[this.currentRoomStorageKey])&&(this.messages=this.deduplicateMessages(i[this.currentRoomStorageKey]),this.isOpen&&this.activeTab==="chat"&&(this.render(),this.scrollToBottom()))}}scrollToBottom(){setTimeout(()=>{var i;const e=(i=this.shadow)==null?void 0:i.getElementById("nb-messages");e&&(e.scrollTop=e.scrollHeight)},40)}listenToStorageChanges(){var e;typeof chrome<"u"&&((e=chrome.storage)!=null&&e.onChanged)&&chrome.storage.onChanged.addListener((i,r)=>{var t,h,f,l;if(r==="local"){if(i.nerd_buddy_sidepanel_open&&i.nerd_buddy_sidepanel_open.newValue===!0&&this.isOpen&&(this.isOpen=!1,this.render()),(i.synqto_live_stage||i.nerd_buddy_live_stage)&&(this.liveStage=(i.synqto_live_stage||i.nerd_buddy_live_stage).newValue,this.render()),(i.synqto_identity||i.nerd_buddy_identity)&&(this.myIdentity=(i.synqto_identity||i.nerd_buddy_identity).newValue),i[_]||i[T]){const c=(t=i[_]||i[T])==null?void 0:t.newValue;c&&(this.settings={...E,...c},this.settings.positionMode==="permanent"&&this.settings.savedPosition&&(this.currentPosition={...this.settings.savedPosition}),this.checkVisibilityAndRender(),this.hostElement&&this.render())}if((i.synqto_active_problem||i.nerd_buddy_active_problem)&&(this.currentProblem=(i.synqto_active_problem||i.nerd_buddy_active_problem).newValue,this.currentRoomStorageKey=`synqto_chat_${((h=this.currentProblem)==null?void 0:h.roomId)||""}`,this.loadMessages(),this.checkVisibilityAndRender()),i.nerd_buddy_peer_count&&(this.peerCount=Math.max(1,i.nerd_buddy_peer_count.newValue||1),this.render()),this.currentRoomStorageKey&&i[this.currentRoomStorageKey]){const c=i[this.currentRoomStorageKey].newValue||[];this.messages=this.deduplicateMessages(c),!this.isOpen&&((f=i[this.currentRoomStorageKey].newValue)==null?void 0:f.length)>(((l=i[this.currentRoomStorageKey].oldValue)==null?void 0:l.length)||0)&&this.unreadCount++,this.render(),this.isOpen&&this.activeTab==="chat"&&this.scrollToBottom()}}})}}console.log("[Nerd Buddy] Content script initialized on:",window.location.href),new D(y=>{var e;try{typeof chrome<"u"&&((e=chrome.runtime)!=null&&e.sendMessage)&&chrome.runtime.sendMessage({type:"PROBLEM_DETECTED",payload:y})}catch{}}),new W,new H})();
