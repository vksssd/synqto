const l = class l {
  constructor() {
    this.contexts = /* @__PURE__ */ new Map();
  }
  static getInstance() {
    return l.instance || (l.instance = new l()), l.instance;
  }
  register(e) {
    const r = this.contexts.get(e.tabId), o = {
      tabId: e.tabId,
      url: e.url ?? (r == null ? void 0 : r.url),
      roomId: e.roomId ?? (r == null ? void 0 : r.roomId),
      peerId: e.peerId ?? (r == null ? void 0 : r.peerId),
      sessionId: e.sessionId ?? (r == null ? void 0 : r.sessionId),
      contextType: e.contextType ?? (r == null ? void 0 : r.contextType) ?? "CONTENT_SCRIPT",
      capabilities: /* @__PURE__ */ new Set([
        ...r != null && r.capabilities ? Array.from(r.capabilities) : [],
        ...e.capabilities ?? ["cursor", "code", "whiteboard", "chat"]
      ]),
      isProblemTab: e.isProblemTab ?? (r == null ? void 0 : r.isProblemTab) ?? !1,
      registeredAt: (r == null ? void 0 : r.registeredAt) ?? Date.now(),
      lastActiveAt: Date.now()
    };
    return this.contexts.set(e.tabId, o), o;
  }
  unregister(e) {
    return this.contexts.delete(e);
  }
  getContext(e) {
    return this.contexts.get(e);
  }
  updateRoom(e, r) {
    const o = this.contexts.get(e);
    o ? (o.roomId = r, o.lastActiveAt = Date.now()) : this.register({ tabId: e, roomId: r });
  }
  updateUrl(e, r) {
    const o = this.contexts.get(e);
    o ? (o.url = r, o.lastActiveAt = Date.now()) : this.register({ tabId: e, url: r });
  }
  getTabsForRoom(e, r) {
    const o = [];
    return this.contexts.forEach((c, s) => {
      e && c.roomId !== e || r && !c.capabilities.has(r) || o.push(s);
    }), o;
  }
  getAllProblemTabs() {
    const e = [];
    return this.contexts.forEach((r, o) => {
      r.isProblemTab && e.push(o);
    }), e;
  }
  pruneStale(e = 1e3 * 60 * 60 * 24) {
    const r = Date.now();
    this.contexts.forEach((o, c) => {
      r - o.lastActiveAt > e && this.contexts.delete(c);
    });
  }
};
l.instance = null;
let p = l;
const I = "nerd_buddy_keepalive";
let d = null;
chrome.alarms.create(I, { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener((t) => {
  t.name === I && R();
});
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: !0 }).catch((t) => console.error(t));
const n = p.getInstance();
chrome.tabs.onRemoved.addListener((t) => {
  n.unregister(t);
});
chrome.tabs.onActivated.addListener(async (t) => {
  try {
    const e = await chrome.tabs.get(t.tabId);
    e.url && (n.updateUrl(t.tabId, e.url), chrome.storage.local.set({
      synqto_active_url: e.url,
      nerd_buddy_active_url: e.url
    }));
  } catch {
  }
});
chrome.tabs.onUpdated.addListener((t, e, r) => {
  e.url && n.updateUrl(t, e.url), r.active && e.url && chrome.storage.local.set({
    synqto_active_url: e.url,
    nerd_buddy_active_url: e.url
  });
});
function P(t) {
  if (t.startsWith("CODE_")) return "code";
  if (t.startsWith("WHITEBOARD_")) return "whiteboard";
  if (t.startsWith("LOCAL_CURSOR_") || t.startsWith("LOCAL_CLICK_")) return "cursor";
  if (t === "TIMER_STATE_SYNC") return "timer";
}
chrome.runtime.onMessage.addListener((t, e, r) => {
  var o, c, s, b, h, f, E, y, A, C, T, O;
  if (t.type === "PROBLEM_DETECTED")
    (o = e.tab) != null && o.id && n.register({
      tabId: e.tab.id,
      url: ((c = t.payload) == null ? void 0 : c.url) || e.tab.url,
      roomId: (s = t.payload) == null ? void 0 : s.roomId,
      isProblemTab: !0
    }), (b = e.tab) != null && b.active && chrome.storage.local.set({
      synqto_active_problem: t.payload,
      synqto_active_url: t.payload.url,
      nerd_buddy_active_problem: t.payload,
      nerd_buddy_active_url: t.payload.url
    });
  else if (t.type === "SET_TAB_ROOM_CONTEXT") {
    const a = t.tabId || ((h = e.tab) == null ? void 0 : h.id);
    a && t.roomId && n.updateRoom(a, t.roomId);
  } else if (t.type === "LOCAL_CURSOR_MOVE" || t.type === "LOCAL_CLICK_PULSE" || t.type === "WHITEBOARD_STROKE_LOCAL" || t.type === "WHITEBOARD_CLEAR_LOCAL" || t.type === "WHITEBOARD_UNDO_LOCAL" || t.type === "WHITEBOARD_BG_LOCAL" || t.type === "WHITEBOARD_PAGE_SYNC_LOCAL" || t.type === "TIMER_STATE_SYNC" || t.type === "CODE_DELTA_LOCAL" || t.type === "CODE_CURSOR_LOCAL" || t.type === "CODE_SYNC_LOCAL" || t.type === "CODE_DELTA_REMOTE" || t.type === "CODE_CURSOR_REMOTE" || t.type === "CODE_SYNC_REMOTE") {
    chrome.runtime.sendMessage(t).catch(() => {
    });
    const a = t.roomId || ((f = t.payload) == null ? void 0 : f.roomId) || ((E = e.tab) != null && E.id ? (y = n.getContext(e.tab.id)) == null ? void 0 : y.roomId : void 0), i = P(t.type);
    (a ? n.getTabsForRoom(a, i) : n.getAllProblemTabs()).forEach((u) => {
      var _;
      u !== ((_ = e.tab) == null ? void 0 : _.id) && chrome.tabs.sendMessage(u, t).catch(() => {
      });
    });
  } else if (t.type === "OPEN_SIDEPANEL") {
    const a = (A = e.tab) == null ? void 0 : A.id, i = (C = e.tab) == null ? void 0 : C.windowId;
    return a && ((T = chrome.sidePanel) != null && T.open) ? chrome.sidePanel.open({ tabId: a }).catch(() => {
      i && chrome.sidePanel.open({ windowId: i }).catch(() => {
      });
    }) : i && ((O = chrome.sidePanel) != null && O.open) && chrome.sidePanel.open({ windowId: i }).catch(() => {
    }), chrome.storage.local.set({
      synqto_sidepanel_open: !0,
      nerd_buddy_sidepanel_open: !0
    }), r({ success: !0 }), !0;
  } else if (t.type === "SEND_PAGE_CHAT_MESSAGE")
    chrome.runtime.sendMessage(t).catch(() => {
    });
  else if (t.type === "CAPTURE_ACTIVE_TAB")
    return chrome.windows.getLastFocused({ populate: !1 }, (a) => {
      const i = a == null ? void 0 : a.id;
      ((u) => {
        const _ = (m) => {
          var L;
          chrome.runtime.lastError || !m ? (console.warn("[ServiceWorker] captureVisibleTab failed:", chrome.runtime.lastError), r({ success: !1, error: ((L = chrome.runtime.lastError) == null ? void 0 : L.message) || "Capture failed" })) : r({ success: !0, dataUrl: m });
        };
        u !== void 0 ? chrome.tabs.captureVisibleTab(u, { format: "png" }, _) : chrome.tabs.captureVisibleTab({ format: "png" }, _);
      })(i);
    }), !0;
  return !0;
});
chrome.storage.onChanged.addListener((t, e) => {
  var r;
  if (e === "local" && (t.synqto_fab_settings || t.nerd_buddy_fab_settings)) {
    const o = (r = t.synqto_fab_settings || t.nerd_buddy_fab_settings) == null ? void 0 : r.newValue;
    o && chrome.tabs.query({}, (c) => {
      c.forEach((s) => {
        s.id && chrome.tabs.sendMessage(s.id, {
          type: "FAB_SETTINGS_UPDATED",
          payload: o
        }).catch(() => {
        });
      });
    });
  }
});
async function R() {
  var e;
  const t = "offscreen.html";
  try {
    if (typeof ((e = chrome.runtime) == null ? void 0 : e.getContexts) == "function" && (await chrome.runtime.getContexts({
      contextTypes: ["OFFSCREEN_DOCUMENT"],
      documentUrls: [chrome.runtime.getURL(t)]
    })).length > 0)
      return;
    if (d) {
      await d;
      return;
    }
    typeof chrome.offscreen < "u" && (d = chrome.offscreen.createDocument({
      url: t,
      reasons: ["WEB_RTC"],
      justification: "Maintain P2P presence and notifications when sidepanel is closed"
    }), await d, d = null);
  } catch (r) {
    console.debug("[ServiceWorker] Offscreen doc initialization bypassed:", r), d = null;
  }
}
R();
