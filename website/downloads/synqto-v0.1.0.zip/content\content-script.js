(function(){"use strict";function E(u){let t=2166136261,e=2166136261;for(let i=0;i<u.length;i++){const a=u.charCodeAt(i);t=Math.imul(t^a&255,16777619),e=Math.imul(e^a>>8,16777619)}return((t>>>0^e>>>0)>>>0).toString(16).padStart(8,"0")}function P(u,t){let e=null;return(...s)=>{e&&clearTimeout(e),e=setTimeout(()=>u(...s),t)}}function _(u,t){var e;try{const s=new URL(u),i=s.hostname.toLowerCase(),a=s.pathname;if(i.includes("leetcode.com")){const o=a.match(/\/problems\/([a-zA-Z0-9-_]+)/);if(o&&o[1]){const r=o[1],c=v(r);return{platform:"LeetCode",slug:r,title:c,url:u,canonicalUrl:`https://leetcode.com/problems/${r}/`}}}if(i.includes("neetcode.io")){const o=a.match(/\/problems\/([a-zA-Z0-9-_]+)/);if(o&&o[1]){const r=o[1],c=v(r);return{platform:"NeetCode",slug:r,title:c,url:u,canonicalUrl:`https://neetcode.io/problems/${r}`}}}if(i.includes("codeforces.com")){const o=a.match(/\/(?:contest|problemset\/problem)\/(\d+)\/([A-Z0-9]+)/i);if(o){const r=o[1],c=o[2].toUpperCase();return{platform:"Codeforces",slug:`cf-${r}-${c}`,title:`Codeforces ${r}${c}`,url:u,canonicalUrl:`https://codeforces.com/problemset/problem/${r}/${c}`}}}if(i.includes("hackerrank.com")){const o=a.match(/\/challenges\/([a-zA-Z0-9-_]+)/);if(o&&o[1]){const r=o[1];return{platform:"HackerRank",slug:r,title:v(r),url:u,canonicalUrl:`https://www.hackerrank.com/challenges/${r}/problem`}}}if(i.includes("codechef.com")){const o=a.match(/\/problems\/([a-zA-Z0-9-_]+)/);if(o&&o[1]){const r=o[1];return{platform:"CodeChef",slug:r,title:`CodeChef ${r}`,url:u,canonicalUrl:`https://www.codechef.com/problems/${r}`}}}if(i.includes("geeksforgeeks.org")){const o=a.match(/\/problems\/([a-zA-Z0-9-_]+)/);if(o&&o[1]){const r=o[1];return{platform:"GeeksforGeeks",slug:r,title:v(r),url:u,canonicalUrl:`https://www.geeksforgeeks.org/problems/${r}/1`}}}if(i.includes("youtube.com")||i.includes("youtu.be")){let o=s.searchParams.get("v");if(!o&&i.includes("youtu.be")&&(o=a.slice(1)),!o&&a.includes("/shorts/")&&(o=(e=a.split("/shorts/")[1])==null?void 0:e.split("/")[0]),o){const r=t?M(t):`YouTube Video (${o})`;return{platform:"YouTube",slug:`yt-${o}`,title:r,url:u,canonicalUrl:`https://www.youtube.com/watch?v=${o}`}}}if(i.includes("arxiv.org")){const o=a.match(/\/(?:abs|pdf)\/(\d+\.\d+(?:v\d+)?)/);if(o&&o[1]){const r=o[1];return{platform:"ArXiv",slug:`arxiv-${r.replace(/\./g,"-")}`,title:t?$(t):`ArXiv ${r}`,url:u,canonicalUrl:`https://arxiv.org/abs/${r}`}}}if(i.includes("github.com")){const o=a.match(/^\/([^\/]+)\/([^\/]+)\/(?:issues|pull)\/(\d+)/);if(o){const r=o[1],c=o[2],p=o[3];return{platform:"GitHub",slug:`gh-${r}-${c}-${p}`,title:`${r}/${c} #${p}`,url:u,canonicalUrl:`https://github.com/${r}/${c}/issues/${p}`}}}return{platform:"Web",slug:i.replace(/\./g,"-")||"general-study",title:t||i||"General Study Room",url:u,canonicalUrl:u}}catch{return null}}function v(u){return u.split(/[-_]/).map(t=>t.charAt(0).toUpperCase()+t.slice(1)).join(" ")}function M(u){return u.replace(/\s*-\s*YouTube\s*$/,"").trim()}function $(u){return u.replace(/^\[[^\]]+\]\s*/,"").replace(/\s*-\s*arXiv.*$/,"").trim()}function S(){try{return!!(typeof chrome<"u"&&chrome.runtime&&chrome.runtime.id)}catch{return!1}}class I{constructor(t){this.lastUrl="",this.lastTitle="",this.mutationObserver=null,this.pollTimer=null,this.debouncedCheck=P(()=>{if(!S()){this.destroy();return}this.checkCurrentPage()},250),this.callback=t,this.init()}init(){this.checkCurrentPage();const t=history.pushState,e=history.replaceState;history.pushState=(...i)=>{t.apply(history,i),this.debouncedCheck()},history.replaceState=(...i)=>{e.apply(history,i),this.debouncedCheck()},window.addEventListener("popstate",()=>this.debouncedCheck()),window.addEventListener("hashchange",()=>this.debouncedCheck()),window.addEventListener("yt-navigate-finish",()=>this.debouncedCheck()),this.mutationObserver=new MutationObserver(()=>{document.title!==this.lastTitle&&this.debouncedCheck()});const s=document.querySelector("title");s&&this.mutationObserver.observe(s,{subtree:!0,characterData:!0,childList:!0}),this.pollTimer=setInterval(()=>{if(!S()){this.destroy();return}window.location.href!==this.lastUrl&&this.checkCurrentPage()},350)}checkCurrentPage(){const t=window.location.href,e=document.title;if(t===this.lastUrl&&e===this.lastTitle)return;this.lastUrl=t,this.lastTitle=e;const s=_(t,e);s&&this.callback(s)}destroy(){this.mutationObserver&&(this.mutationObserver.disconnect(),this.mutationObserver=null),this.pollTimer&&(clearInterval(this.pollTimer),this.pollTimer=null)}}function x(){try{return!!(typeof chrome<"u"&&chrome.runtime&&chrome.runtime.id)}catch{return!1}}class L{constructor(){this.container=null,this.cursorElements=new Map,this.cursorTimeouts=new Map,this.myIdentity=null,this.liveStage=null,this.createContainer(),this.loadState(),this.listenToStorage(),this.listenForMessages(),this.setupLocalTrackers()}async loadState(){var t;if(typeof chrome<"u"&&((t=chrome.storage)!=null&&t.local))try{const e=await chrome.storage.local.get(["nerd_buddy_identity","synqme_identity","nerd_buddy_live_stage","synqme_live_stage"]);this.myIdentity=e.synqme_identity||e.nerd_buddy_identity||null,this.liveStage=e.synqme_live_stage||e.nerd_buddy_live_stage||null,(!this.liveStage||!this.liveStage.isActive)&&this.clearAllCursors()}catch{}}listenToStorage(){var t;typeof chrome<"u"&&((t=chrome.storage)!=null&&t.onChanged)&&chrome.storage.onChanged.addListener((e,s)=>{s==="local"&&((e.synqme_identity||e.nerd_buddy_identity)&&(this.myIdentity=(e.synqme_identity||e.nerd_buddy_identity).newValue),(e.synqme_live_stage||e.nerd_buddy_live_stage)&&(this.liveStage=(e.synqme_live_stage||e.nerd_buddy_live_stage).newValue,(!this.liveStage||!this.liveStage.isActive)&&this.clearAllCursors()))})}clearAllCursors(){this.cursorTimeouts.forEach(t=>clearTimeout(t)),this.cursorTimeouts.clear(),this.cursorElements.forEach(t=>{t.remove()}),this.cursorElements.clear(),this.container&&(this.container.innerHTML="")}isLocalUserOnStage(){var e,s;if(!this.liveStage||!this.liveStage.isActive)return!1;const t=(e=this.myIdentity)==null?void 0:e.peerId;return t?!!(((s=this.liveStage.tutorIdentity)==null?void 0:s.peerId)===t||this.liveStage.tutorPeerId===t||this.liveStage.myRole==="tutor"||Array.isArray(this.liveStage.guestSpeakers)&&this.liveStage.guestSpeakers.some(i=>i.peerId===t)):!1}createContainer(){if(document.getElementById("nerd-buddy-cursor-overlay"))return;const t=document.createElement("div");if(t.id="nerd-buddy-cursor-overlay",t.style.cssText=`
      position: fixed !important;
      top: 0 !important;
      left: 0 !important;
      width: 100vw !important;
      height: 100vh !important;
      pointer-events: none !important;
      z-index: 2147483645 !important;
      overflow: hidden !important;
      box-sizing: border-box !important;
    `,document.body.appendChild(t),this.container=t,!document.getElementById("nerd-buddy-cursor-styles")){const e=document.createElement("style");e.id="nerd-buddy-cursor-styles",e.textContent=`
        @keyframes nb-click-ripple {
          0% { transform: scale(0.15); opacity: 1; }
          40% { opacity: 0.9; }
          100% { transform: scale(2.8); opacity: 0; }
        }
      `,document.head.appendChild(e)}}listenForMessages(){var t;if(!(!x()||!((t=chrome.runtime)!=null&&t.onMessage)))try{chrome.runtime.onMessage.addListener(e=>{var s,i,a,h;if(x()){if(e.type==="NERD_BUDDY_STAGE_ENDED"||e.type==="NERD_BUDDY_STAGE_INACTIVE"){this.clearAllCursors();return}if(e.type==="NERD_BUDDY_CURSOR_UPDATE"&&e.cursor){const o=e.cursor;(o.isTutor||this.liveStage&&(((s=this.liveStage.tutorIdentity)==null?void 0:s.peerId)===o.peerId||this.liveStage.tutorPeerId===o.peerId||((i=this.liveStage.guestSpeakers)==null?void 0:i.some(c=>c.peerId===o.peerId)))||!this.liveStage)&&this.renderCursor(o)}else if(e.type==="NERD_BUDDY_CLICK_PULSE"&&e.click){const o=e.click;(o.isTutor||this.liveStage&&(((a=this.liveStage.tutorIdentity)==null?void 0:a.peerId)===o.peerId||this.liveStage.tutorPeerId===o.peerId||((h=this.liveStage.guestSpeakers)==null?void 0:h.some(c=>c.peerId===o.peerId)))||o.isTutor||!this.liveStage)&&this.renderClickPulse(o)}}})}catch{}}renderCursor(t){if(this.container||this.createContainer(),!this.container)return;let e=this.cursorElements.get(t.peerId);e||(e=document.createElement("div"),e.style.cssText=`
        position: fixed !important;
        pointer-events: none !important;
        transition: left 0.05s linear, top 0.05s linear, opacity 0.3s ease !important;
        display: flex !important;
        align-items: center !important;
        gap: 5px !important;
        opacity: 1 !important;
        z-index: 2147483646 !important;
      `,this.container.appendChild(e),this.cursorElements.set(t.peerId,e));const s=Math.max(0,Math.min(window.innerWidth-30,t.xPct/100*window.innerWidth)),i=Math.max(0,Math.min(window.innerHeight-30,t.yPct/100*window.innerHeight));e.style.left=`${s}px`,e.style.top=`${i}px`,e.style.opacity="1";const a=t.isTutor?"#8b5cf6":t.color||"#6366f1";e.innerHTML=`
      <div style="
        width: 18px;
        height: 18px;
        border-radius: 50%;
        background: ${a};
        box-shadow: 0 0 16px ${a}, 0 0 6px #ffffff;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 11px;
        color: #fff;
        border: 2px solid #ffffff;
      ">
        ${t.avatar||"👑"}
      </div>
      <div style="
        background: rgba(15, 23, 42, 0.92);
        border: 1px solid ${a};
        color: #f8fafc;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        font-size: 10px;
        font-weight: 600;
        padding: 2px 6px;
        border-radius: 4px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.6);
        white-space: nowrap;
      ">
        ${t.nickname} ${t.isTutor?"🎓 (Tutor)":"🎤 (Speaker)"}
      </div>
    `;const h=this.cursorTimeouts.get(t.peerId);h&&clearTimeout(h);const o=window.setTimeout(()=>{e&&(e.style.opacity="0")},4e3);this.cursorTimeouts.set(t.peerId,o)}renderClickPulse(t){if(this.container||this.createContainer(),!this.container)return;const e=t.xPct/100*window.innerWidth,s=t.yPct/100*window.innerHeight,i=document.createElement("div"),a=t.color||(t.isTutor?"#8b5cf6":"#6366f1");i.style.cssText=`
      position: fixed !important;
      left: ${e-22}px !important;
      top: ${s-22}px !important;
      width: 44px !important;
      height: 44px !important;
      border-radius: 50% !important;
      border: 3px solid ${a} !important;
      box-shadow: 0 0 16px ${a}, inset 0 0 8px ${a} !important;
      pointer-events: none !important;
      z-index: 2147483647 !important;
      box-sizing: border-box !important;
      animation: nb-click-ripple 0.85s cubic-bezier(0.1, 0.8, 0.3, 1) forwards !important;
    `,this.container.appendChild(i),setTimeout(()=>{i.remove()},900)}setupLocalTrackers(){let t=0;window.addEventListener("mousemove",e=>{if(!x()||!this.isLocalUserOnStage())return;const s=Date.now();if(s-t<40)return;t=s;const i=e.clientX/window.innerWidth*100,a=e.clientY/window.innerHeight*100;try{chrome.runtime.sendMessage({type:"LOCAL_CURSOR_MOVE",xPct:i,yPct:a}).catch(()=>{})}catch{}}),window.addEventListener("click",e=>{var a,h,o;if(!x()||!this.isLocalUserOnStage())return;const s=e.clientX/window.innerWidth*100,i=e.clientY/window.innerHeight*100;this.renderClickPulse({peerId:((a=this.myIdentity)==null?void 0:a.peerId)||"local",nickname:((h=this.myIdentity)==null?void 0:h.nickname)||"You",xPct:s,yPct:i,color:((o=this.myIdentity)==null?void 0:o.color)||"#8b5cf6",isTutor:!0,timestamp:Date.now()});try{chrome.runtime.sendMessage({type:"LOCAL_CLICK_PULSE",xPct:s,yPct:i}).catch(()=>{})}catch{}})}}const A={mode:"coding_sites",clickAction:"open_popup",customDomains:["leetcode.com","neetcode.io","codeforces.com","hackerrank.com","geeksforgeeks.org"],enableWhiteboard:!1,positionMode:"permanent",savedPosition:{right:24,bottom:24}},y="nerd_buddy_fab_settings";function B(u,t){const e=u.toLowerCase().replace(/[^a-z0-9-_]/g,"-").slice(0,24).replace(/-+$/,""),s=E(t);return`room:${e||"lobby"}-${s}`}function R(u){switch(u.toLowerCase()){case"leetcode":return"#FFA116";case"neetcode":return"#8B5CF6";case"codeforces":return"#318CE7";case"hackerrank":return"#2EC866";case"codechef":return"#5B4638";case"geeksforgeeks":return"#2F8D46";case"youtube":return"#FF0000";case"arxiv":return"#B31B1B";case"github":return"#24292F";case"group":return"#8B5CF6";default:return"#6366F1"}}class D{constructor(){this.hostElement=null,this.shadow=null,this.isOpen=!1,this.settings=A,this.currentProblem=null,this.messages=[],this.unreadCount=0,this.currentRoomStorageKey="",this.myIdentity=null,this.liveStage=null,this.peerCount=1,this.replyingTo=null,this.revealedSpoilers={},this.currentPosition={right:24,bottom:24},this.isDragging=!1,this.dragMoved=!1,this.activeTab="chat",this.wbTool="pen",this.wbColor="#6366f1",this.wbWidth=4,this.wbStrokes=[],this.wbRedoStack=[],this.isWbDrawing=!1,this.wbCurrentPoints=[],this.wbStartPoint=null,this.init()}async init(){await this.loadIdentity(),await this.loadSettings(),this.detectCurrentPageProblem(),this.checkVisibilityAndRender(),this.listenToStorageChanges(),this.listenForRuntimeMessages()}async loadIdentity(){var t;if(typeof chrome<"u"&&((t=chrome.storage)!=null&&t.local)){const e=await chrome.storage.local.get(["synqto_identity","nerd_buddy_identity"]);(e.synqto_identity||e.nerd_buddy_identity)&&(this.myIdentity=e.synqto_identity||e.nerd_buddy_identity)}this.myIdentity||(this.myIdentity={peerId:"peer-"+Math.random().toString(36).slice(2,10),nickname:"Coder"+Math.floor(Math.random()*900+100),avatar:"⚡",color:"#6366f1"})}async loadSettings(){var t,e;if(typeof chrome<"u"&&((t=chrome.storage)!=null&&t.local)){const s=await chrome.storage.local.get([y,"synqto_active_problem","nerd_buddy_active_problem","synqto_live_stage","nerd_buddy_live_stage","nerd_buddy_sidepanel_open","nerd_buddy_peer_count"]);s[y]&&(this.settings=s[y]),this.settings.positionMode==="permanent"&&this.settings.savedPosition?this.currentPosition={...this.settings.savedPosition}:this.currentPosition={right:24,bottom:24};const i=s.synqto_active_problem||s.nerd_buddy_active_problem;i&&(this.currentProblem=i,this.currentRoomStorageKey=`synqto_chat_${((e=this.currentProblem)==null?void 0:e.roomId)||""}`,await this.loadMessages()),(s.synqto_live_stage||s.nerd_buddy_live_stage)&&(this.liveStage=s.synqto_live_stage||s.nerd_buddy_live_stage),typeof s.nerd_buddy_peer_count=="number"&&(this.peerCount=Math.max(1,s.nerd_buddy_peer_count))}}detectCurrentPageProblem(){const t=_(window.location.href,document.title);if(t){const e=B(t.slug,t.canonicalUrl);this.currentProblem={platform:t.platform,slug:t.slug,title:t.title,canonicalUrl:t.canonicalUrl,roomId:e},this.currentRoomStorageKey=`synqto_chat_${e}`,this.loadMessages()}}shouldShow(){if(this.settings.mode==="disabled")return!1;if(this.settings.mode==="all_sites")return!0;const t=window.location.hostname.toLowerCase();if(this.settings.mode==="custom_sites")return this.settings.customDomains.some(a=>t.includes(a.toLowerCase()));const s=["leetcode.com","neetcode.io","codeforces.com","hackerrank.com","geeksforgeeks.org","codechef.com","atcoder.jp","github.com","youtube.com","arxiv.org"].some(a=>t.includes(a)),i=!!(this.currentProblem||_(window.location.href));return s||i}checkVisibilityAndRender(){const t=this.shouldShow();t&&!this.hostElement?this.createWidgetDOM():!t&&this.hostElement&&(this.hostElement.remove(),this.hostElement=null,this.shadow=null)}createWidgetDOM(){if(document.getElementById("synqto-floating-host"))return;const t=document.createElement("div");t.id="synqto-floating-host",t.style.cssText=`
      position: fixed;
      bottom: ${this.currentPosition.bottom}px;
      right: ${this.currentPosition.right}px;
      z-index: 2147483640;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
      touch-action: none;
    `,document.body.appendChild(t),this.hostElement=t,this.shadow=t.attachShadow({mode:"open"}),this.render()}applyHostPosition(){if(!this.hostElement)return;const t=Math.max(10,Math.min(window.innerWidth-130,this.currentPosition.right)),e=Math.max(10,Math.min(window.innerHeight-55,this.currentPosition.bottom));this.hostElement.style.right=`${t}px`,this.hostElement.style.bottom=`${e}px`}render(){var c,p,n,l;if(!this.shadow)return;this.applyHostPosition();const t=!!(this.liveStage&&this.liveStage.isActive),e=((p=(c=this.liveStage)==null?void 0:c.tutorIdentity)==null?void 0:p.nickname)||"Tutor",s=((n=this.currentProblem)==null?void 0:n.title)||"Global Problem Lobby",i=((l=this.currentProblem)==null?void 0:l.platform)||"LeetCode",a=R(i),h=this.settings.enableWhiteboard&&this.activeTab==="whiteboard",o=this.currentPosition.bottom>window.innerHeight-540,r=this.currentPosition.right>window.innerWidth-420;this.shadow.innerHTML=`
      <style>
        :host {
          --primary: #6366f1;
          --primary-hover: #4f46e5;
          --bg-card: rgba(15, 23, 42, 0.96);
          --bg-surface-elevated: rgba(30, 41, 59, 0.85);
          --border-subtle: rgba(255, 255, 255, 0.1);
          --text-primary: #f8fafc;
          --text-secondary: #94a3b8;
          --text-muted: #64748b;
          --text-dim: #475569;
          --font-mono: 'JetBrains Mono', 'Fira Code', monospace;
        }

        * {
          box-sizing: border-box;
          margin: 0;
          padding: 0;
        }

        /* Floating Action Button (FAB) */
        .fab-button {
          position: relative;
          display: flex;
          align-items: center;
          gap: 7px;
          padding: 10px 14px;
          border-radius: 9999px;
          background: linear-gradient(135deg, #4f46e5, #7c3aed);
          border: 1px solid rgba(255, 255, 255, 0.2);
          box-shadow: 0 10px 25px -5px rgba(99, 102, 241, 0.5), 0 0 15px rgba(124, 58, 237, 0.3);
          color: #ffffff;
          font-size: 12px;
          font-weight: 700;
          cursor: grab;
          transition: transform 0.15s cubic-bezier(0.16, 1, 0.3, 1), box-shadow 0.15s;
          user-select: none;
        }

        .fab-button:active {
          cursor: grabbing;
        }

        .fab-button:hover {
          transform: translateY(-2px) scale(1.02);
          box-shadow: 0 14px 28px -5px rgba(99, 102, 241, 0.65), 0 0 20px rgba(124, 58, 237, 0.4);
        }

        .drag-grip {
          opacity: 0.5;
          font-size: 11px;
          cursor: grab;
        }

        .live-dot {
          width: 8px;
          height: 8px;
          border-radius: 50%;
          background: #ef4444;
          box-shadow: 0 0 10px #ef4444;
          animation: livePulse 1.5s infinite;
        }

        @keyframes livePulse {
          0%, 100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.4; transform: scale(1.2); }
        }

        .fab-badge {
          position: absolute;
          top: -4px;
          right: -4px;
          background: #f59e0b;
          color: #ffffff;
          font-size: 10px;
          font-weight: 700;
          padding: 2px 6px;
          border-radius: 9999px;
        }

        /* In-Page Popup Card */
        .popup-card {
          display: ${this.isOpen?"flex":"none"};
          flex-direction: column;
          position: absolute;
          ${o?"top: 52px; bottom: auto;":"bottom: 52px; top: auto;"}
          ${r?"left: 0; right: auto;":"right: 0; left: auto;"}
          width: 400px;
          height: 540px;
          max-height: 84vh;
          background: rgba(15, 23, 42, 0.96);
          border: 1px solid ${t?"rgba(239, 68, 68, 0.45)":"rgba(99, 102, 241, 0.35)"};
          border-radius: 16px;
          box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.85), 0 0 24px ${t?"rgba(239, 68, 68, 0.25)":"rgba(99, 102, 241, 0.2)"};
          backdrop-filter: blur(20px);
          -webkit-backdrop-filter: blur(20px);
          overflow: hidden;
          animation: slideIn 0.2s cubic-bezier(0.16, 1, 0.3, 1);
          color: var(--text-primary);
        }

        @keyframes slideIn {
          from { opacity: 0; transform: translateY(12px) scale(0.96); }
          to { opacity: 1; transform: translateY(0) scale(1); }
        }

        /* Room Header */
        .room-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 10px 12px;
          background: linear-gradient(135deg, rgba(30, 41, 59, 0.95), rgba(15, 23, 42, 0.95));
          border-bottom: 1px solid var(--border-subtle);
        }

        .room-info {
          display: flex;
          align-items: center;
          gap: 10px;
          overflow: hidden;
        }

        .platform-icon-box {
          width: 32px;
          height: 32px;
          border-radius: 8px;
          background: rgba(99, 102, 241, 0.15);
          border: 1px solid rgba(255, 255, 255, 0.1);
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 16px;
          flex-shrink: 0;
        }

        .problem-title {
          font-size: 13px;
          font-weight: 700;
          color: var(--text-primary);
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
          max-width: 170px;
        }

        .badges-row {
          display: flex;
          align-items: center;
          gap: 6px;
          margin-top: 2px;
        }

        .platform-pill {
          font-size: 9px;
          font-weight: 700;
          padding: 1px 6px;
          border-radius: 4px;
          background: ${a}20;
          border: 1px solid ${a}50;
          color: ${a};
          text-transform: uppercase;
        }

        .peer-count-pill {
          font-size: 10px;
          color: var(--text-secondary);
          display: flex;
          align-items: center;
          gap: 4px;
        }

        .header-actions {
          display: flex;
          align-items: center;
          gap: 4px;
        }

        .icon-btn {
          background: transparent;
          border: none;
          color: var(--text-secondary);
          cursor: pointer;
          padding: 5px;
          border-radius: 6px;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: all 0.15s;
        }

        .icon-btn:hover {
          background: rgba(255, 255, 255, 0.1);
          color: #ffffff;
        }

        /* Segmented View Switcher */
        .tab-switcher {
          display: flex;
          background: rgba(15, 23, 42, 0.9);
          padding: 3px 6px;
          border-bottom: 1px solid var(--border-subtle);
          gap: 4px;
        }

        .tab-btn {
          flex: 1;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 6px;
          padding: 5px 8px;
          font-size: 11px;
          font-weight: 600;
          border-radius: 6px;
          border: none;
          cursor: pointer;
          transition: all 0.15s;
          background: transparent;
          color: var(--text-muted);
        }

        .tab-btn.active {
          background: var(--primary);
          color: #ffffff;
        }

        /* Messages List */
        .message-list {
          flex: 1;
          overflow-y: auto;
          padding: 12px;
          display: flex;
          flex-direction: column;
          gap: 10px;
        }

        .chat-bubble {
          display: flex;
          flex-direction: column;
          max-width: 86%;
          padding: 8px 12px;
          border-radius: 14px;
          font-size: 12px;
          position: relative;
          word-break: break-word;
          line-height: 1.45;
        }

        .chat-bubble.self {
          align-self: flex-end;
          background: linear-gradient(135deg, rgba(99, 102, 241, 0.28), rgba(139, 92, 246, 0.22));
          border: 1px solid rgba(99, 102, 241, 0.35);
          border-bottom-right-radius: 4px;
          color: #ffffff;
        }

        .chat-bubble.other {
          align-self: flex-start;
          background: var(--bg-surface-elevated);
          border: 1px solid var(--border-subtle);
          border-bottom-left-radius: 4px;
          color: #f1f5f9;
        }

        .chat-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 8px;
          margin-bottom: 4px;
          font-size: 11px;
        }

        .chat-author {
          font-weight: 600;
          display: flex;
          align-items: center;
          gap: 4px;
        }

        .chat-timestamp {
          color: var(--text-dim);
          font-size: 10px;
        }

        .chat-footer {
          margin-top: 3px;
          display: flex;
          align-items: center;
          justify-content: flex-end;
          font-size: 10px;
        }

        .ack-read {
          color: #38bdf8;
          font-weight: 700;
        }

        /* Whiteboard Toolbar & Canvas */
        .whiteboard-container {
          flex: 1;
          display: flex;
          flex-direction: column;
          background: #090d16;
          overflow: hidden;
          position: relative;
        }

        .wb-toolbar {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 6px 8px;
          background: rgba(15, 23, 42, 0.95);
          border-bottom: 1px solid var(--border-subtle);
          flex-wrap: wrap;
          gap: 4px;
        }

        .wb-tool-group {
          display: flex;
          gap: 3px;
          align-items: center;
        }

        .wb-tool-btn {
          padding: 4px 6px;
          border-radius: 4px;
          border: 1px solid transparent;
          background: transparent;
          color: var(--text-muted);
          cursor: pointer;
          font-size: 11px;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .wb-tool-btn.active {
          border-color: var(--primary);
          background: rgba(99, 102, 241, 0.25);
          color: #c7d2fe;
        }

        .wb-palette-bar {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 3px 8px;
          background: rgba(0, 0, 0, 0.3);
          border-bottom: 1px solid var(--border-subtle);
        }

        .color-dot {
          width: 13px;
          height: 13px;
          border-radius: 50%;
          border: 1px solid rgba(255, 255, 255, 0.2);
          cursor: pointer;
        }

        .color-dot.active {
          border: 2px solid #ffffff;
          box-shadow: 0 0 6px rgba(255, 255, 255, 0.5);
        }

        .size-pill {
          font-size: 9px;
          font-weight: 700;
          padding: 1px 4px;
          border-radius: 3px;
          background: rgba(255, 255, 255, 0.05);
          border: 1px solid transparent;
          color: var(--text-dim);
          cursor: pointer;
        }

        .size-pill.active {
          background: rgba(99, 102, 241, 0.3);
          border-color: var(--primary);
          color: #ffffff;
        }

        #nb-whiteboard-canvas {
          flex-grow: 1;
          width: 100%;
          height: 100%;
          cursor: crosshair;
          touch-action: none;
        }

        /* Input Composer */
        .composer-box {
          display: flex;
          align-items: center;
          gap: 6px;
          padding: 8px 10px;
          background: rgba(15, 23, 42, 0.95);
          border-top: 1px solid var(--border-subtle);
        }

        .input-glass {
          flex: 1;
          background: rgba(0, 0, 0, 0.4);
          border: 1px solid var(--border-subtle);
          border-radius: 8px;
          padding: 7px 10px;
          color: #ffffff;
          font-size: 11px;
          outline: none;
        }

        .input-glass:focus {
          border-color: var(--primary);
        }

        .btn-send {
          background: var(--primary);
          border: none;
          color: #ffffff;
          padding: 6px 10px;
          border-radius: 8px;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .prompt-pills-row {
          display: flex;
          gap: 4px;
          padding: 4px 8px;
          overflow-x: auto;
          background: rgba(0, 0, 0, 0.3);
          border-top: 1px solid var(--border-subtle);
        }

        .prompt-pill {
          background: rgba(255, 255, 255, 0.06);
          border: 1px solid var(--border-subtle);
          color: var(--text-secondary);
          font-size: 9px;
          font-weight: 600;
          padding: 2px 6px;
          border-radius: 4px;
          cursor: pointer;
          white-space: nowrap;
        }

        .prompt-pill:hover {
          background: rgba(99, 102, 241, 0.2);
          color: #ffffff;
        }
      </style>

      <!-- In-Page Popup Card Window -->
      <div class="popup-card" id="nb-popup-card">
        <!-- Room Header Bar -->
        <div class="room-header">
          <div class="room-info">
            <div class="platform-icon-box">⚡</div>
            <div>
              <div class="problem-title">${this.escapeHtml(s)}</div>
              <div class="badges-row">
                <span class="platform-pill">${i}</span>
                <span class="peer-count-pill">
                  <span style="display:inline-block;width:6px;height:6px;border-radius:50%;background:#10b981;"></span>
                  <span>${this.peerCount} Online</span>
                </span>
              </div>
            </div>
          </div>

          <div class="header-actions">
            <button class="icon-btn" id="nb-open-sidepanel" title="Open complete extension in side panel">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M15 3h6v6M10 14L21 3M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6"/>
              </svg>
            </button>
            <button class="icon-btn" id="nb-close-popup" title="Minimize">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M18 6L6 18M6 6l12 12"/>
              </svg>
            </button>
          </div>
        </div>

        <!-- Segmented Switcher when Whiteboard is Enabled in Settings -->
        ${this.settings.enableWhiteboard?`
          <div class="tab-switcher">
            <button class="tab-btn ${this.activeTab==="chat"?"active":""}" id="nb-tab-chat">
              <span>💬 Live Chat</span>
            </button>
            <button class="tab-btn ${this.activeTab==="whiteboard"?"active":""}" id="nb-tab-whiteboard">
              <span>🎨 Whiteboard</span>
            </button>
          </div>
        `:""}

        <!-- Multi-Broadcaster Live Streams List -->
        ${t?`
          <div style="background:linear-gradient(135deg, rgba(239, 68, 68, 0.22), rgba(139, 92, 246, 0.18));border-bottom:1px solid rgba(239, 68, 68, 0.35);padding:6px 10px;display:flex;flex-direction:column;gap:5px;">
            <div style="display:flex;align-items:center;justify-content:space-between;font-size:10px;color:#fca5a5;">
              <div style="display:flex;align-items:center;gap:5px;font-weight:700;">
                <span class="live-dot"></span>
                <span>LIVE STREAMS (${this.liveStage.activeStreams&&this.liveStage.activeStreams.length||1}):</span>
              </div>
              <button id="nb-live-tunein" style="background:#ef4444;color:#fff;border:none;padding:2px 8px;border-radius:4px;font-size:9px;font-weight:700;cursor:pointer;">
                Open Side Panel 📺
              </button>
            </div>

            <div style="display:flex;gap:4px;overflow-x:auto;padding-bottom:2px;">
              ${(this.liveStage.activeStreams&&this.liveStage.activeStreams.length>0?this.liveStage.activeStreams:[{broadcasterIdentity:this.liveStage.tutorIdentity||{nickname:e,avatar:"👑"},title:`${e}'s Walkthrough`,broadcastType:this.liveStage.broadcastType||"screen"}]).map(d=>{var m,g;return`
                <div style="display:flex;align-items:center;gap:4px;padding:3px 6px;border-radius:4px;background:rgba(0,0,0,0.4);border:1px solid rgba(255,255,255,0.1);font-size:10px;color:#f8fafc;white-space:nowrap;">
                  <span>${((m=d.broadcasterIdentity)==null?void 0:m.avatar)||"👤"}</span>
                  <span style="font-weight:600;">${((g=d.broadcasterIdentity)==null?void 0:g.nickname)||"Streamer"}:</span>
                  <span style="color:#c7d2fe;max-width:110px;overflow:hidden;text-overflow:ellipsis;">${this.escapeHtml(d.title||"Live Stream")}</span>
                  <span style="font-size:8px;padding:1px 4px;border-radius:3px;background:rgba(239,68,68,0.3);color:#fca5a5;text-transform:uppercase;">${d.broadcastType||"live"}</span>
                </div>
              `}).join("")}
            </div>
          </div>
        `:""}

        <!-- Main Body: Chat or Whiteboard -->
        ${h?`
          <!-- Whiteboard View -->
          <div class="whiteboard-container">
            <div class="wb-toolbar">
              <div class="wb-tool-group">
                <button class="wb-tool-btn ${this.wbTool==="pen"?"active":""}" data-wbtool="pen" title="Pen">✏️</button>
                <button class="wb-tool-btn ${this.wbTool==="highlighter"?"active":""}" data-wbtool="highlighter" title="Highlighter">🖍️</button>
                <button class="wb-tool-btn ${this.wbTool==="eraser"?"active":""}" data-wbtool="eraser" title="Eraser">🧹</button>
                <button class="wb-tool-btn ${this.wbTool==="line"?"active":""}" data-wbtool="line" title="Line">📏</button>
                <button class="wb-tool-btn ${this.wbTool==="arrow"?"active":""}" data-wbtool="arrow" title="Arrow">➡️</button>
                <button class="wb-tool-btn ${this.wbTool==="rect"?"active":""}" data-wbtool="rect" title="Box">🔲</button>
                <button class="wb-tool-btn ${this.wbTool==="circle"?"active":""}" data-wbtool="circle" title="Node">⭕</button>
                <button class="wb-tool-btn ${this.wbTool==="tree_node"?"active":""}" data-wbtool="tree_node" title="Tree Node">🌳</button>
              </div>

              <div class="wb-tool-group">
                <button class="wb-tool-btn" id="nb-wb-undo" title="Undo">↩️</button>
                <button class="wb-tool-btn" id="nb-wb-redo" title="Redo">↪️</button>
                <button class="wb-tool-btn" id="nb-wb-clear" title="Clear Canvas" style="color:#f87171;">🗑️</button>
                <button class="wb-tool-btn" id="nb-wb-save" title="Export PNG">💾</button>
              </div>
            </div>

            <!-- Color Palette & Widths -->
            <div class="wb-palette-bar">
              <div style="display:flex;gap:5px;align-items:center;">
                ${["#6366f1","#06b6d4","#10b981","#f59e0b","#f43f5e","#ffffff"].map(d=>`
                  <div class="color-dot ${this.wbColor===d?"active":""}" data-color="${d}" style="background:${d};"></div>
                `).join("")}
              </div>
              <div style="display:flex;gap:3px;align-items:center;">
                <button class="size-pill ${this.wbWidth===2?"active":""}" data-size="2">S</button>
                <button class="size-pill ${this.wbWidth===4?"active":""}" data-size="4">M</button>
                <button class="size-pill ${this.wbWidth===8?"active":""}" data-size="8">L</button>
              </div>
            </div>

            <!-- HTML5 Interactive Canvas -->
            <canvas id="nb-whiteboard-canvas"></canvas>
          </div>
        `:`
          <!-- Chat Messages View -->
          <div class="message-list" id="nb-messages">
            ${this.messages.length===0?`
              <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:100%;color:var(--text-muted);gap:8px;padding:30px 10px;text-align:center;">
                <div style="font-size:28px;">💬</div>
                <div style="font-size:13px;font-weight:600;color:var(--text-secondary);">No messages yet</div>
                <div style="font-size:11px;max-width:220px;">Say hello or ask for a hint! Messages are synchronized P2P across all peers.</div>
              </div>
            `:this.messages.map((d,m)=>{var g,f,w,b;return`
              <div class="chat-bubble ${d.isSelf?"self":"other"}">
                ${d.replyPreview?`<div style="border-left:2px solid var(--primary);padding-left:6px;margin-bottom:4px;font-size:10px;color:var(--text-muted);">${this.escapeHtml(d.replyPreview)}</div>`:""}
                
                <div class="chat-header">
                  <div class="chat-author">
                    <span>${((g=d.from)==null?void 0:g.avatar)||"👤"}</span>
                    <span style="color:${d.isSelf?"#ffffff":((f=d.from)==null?void 0:f.color)||"#a5b4fc"}">
                      ${d.isSelf?"You":((w=d.from)==null?void 0:w.nickname)||"Buddy"}
                    </span>
                  </div>
                  <div style="display:flex;align-items:center;gap:4px;">
                    <span class="chat-timestamp">${this.formatTimestamp(d.timestamp)}</span>
                    <button class="icon-btn nb-reply-trigger" data-id="${d.id}" data-text="${this.escapeHtml(d.text.slice(0,35))}" data-nick="${this.escapeHtml(((b=d.from)==null?void 0:b.nickname)||"Buddy")}" style="padding:0;width:18px;height:18px;" title="Reply">
                      ↩
                    </button>
                  </div>
                </div>

                <div class="chat-body">${this.renderFormattedText(d.text,m)}</div>

                ${d.isSelf?`
                  <div class="chat-footer">
                    ${d.status==="pending"?"<span>⏳</span>":""}
                    ${d.status==="sent"?'<span style="color:var(--text-dim);">✓</span>':""}
                    ${d.status==="delivered"?'<span style="color:var(--text-secondary);">✓✓</span>':""}
                    ${d.status==="read"?'<span class="ack-read">✓✓</span>':""}
                  </div>
                `:""}
              </div>
            `}).join("")}
          </div>

          <!-- Quick Strategy Prompt Pills -->
          <div class="prompt-pills-row">
            <button class="prompt-pill" data-text="⚡ O(N) Time">⚡ O(N) Time</button>
            <button class="prompt-pill" data-text="💾 O(1) Space">💾 O(1) Space</button>
            <button class="prompt-pill" data-text="👉 Two Pointers">👉 Two Pointers</button>
            <button class="prompt-pill" data-text="🔍 Binary Search">🔍 Binary Search</button>
            <button class="prompt-pill" data-text="🧠 DP / Memo">🧠 DP / Memo</button>
            <button class="prompt-pill" data-text="💡 Sliding Window">💡 Sliding Window</button>
          </div>

          <!-- Input Box & Composer -->
          <form class="composer-box" id="nb-composer">
            <button type="button" class="icon-btn" id="nb-spoiler-insert" title="Insert Spoiler Blur ||text||" style="width:28px;height:28px;flex-shrink:0;">
              👁️
            </button>
            <input type="text" class="input-glass" id="nb-input" placeholder="Type a hint, code snippet, or ||spoiler||..." />
            <button type="submit" class="btn-send">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <line x1="22" y1="2" x2="11" y2="13"></line>
                <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
              </svg>
            </button>
          </form>
        `}
      </div>

      <!-- Draggable Floating Action Button (FAB) -->
      <button class="fab-button" id="nb-fab-trigger" title="Drag anywhere or click to open">
        <span class="drag-grip">⠿</span>
        ${t?'<span class="live-dot"></span>':"<span>⚡</span>"}
        <span>${t?`LIVE (${e})`:"Synqto"}</span>
        ${this.unreadCount>0?`<span class="fab-badge">${this.unreadCount}</span>`:""}
      </button>
    `,this.attachEventListeners(),h&&this.initWhiteboardCanvas()}attachEventListeners(){if(!this.shadow)return;const t=this.shadow.getElementById("nb-fab-trigger");if(t){let n=0,l=0,d=24,m=24;const g=b=>{if(!this.isDragging)return;const k="touches"in b?b.touches[0].clientX:b.clientX,W="touches"in b?b.touches[0].clientY:b.clientY,T=k-n,C=W-l;if(Math.hypot(T,C)>4){this.dragMoved=!0;const O=d-T,z=m-C;this.currentPosition={right:Math.max(10,Math.min(window.innerWidth-130,O)),bottom:Math.max(10,Math.min(window.innerHeight-55,z))},this.applyHostPosition()}},f=()=>{var b;if(this.isDragging&&(this.isDragging=!1,window.removeEventListener("mousemove",g),window.removeEventListener("mouseup",f),window.removeEventListener("touchmove",g),window.removeEventListener("touchend",f),this.dragMoved)){if(this.settings.positionMode==="permanent"){const k={...this.settings,savedPosition:{...this.currentPosition}};this.settings=k,typeof chrome<"u"&&((b=chrome.storage)!=null&&b.local)&&chrome.storage.local.set({[y]:k})}setTimeout(()=>{this.dragMoved=!1},60)}},w=b=>{this.isDragging=!0,this.dragMoved=!1,n="touches"in b?b.touches[0].clientX:b.clientX,l="touches"in b?b.touches[0].clientY:b.clientY,d=this.currentPosition.right,m=this.currentPosition.bottom,window.addEventListener("mousemove",g,{passive:!0}),window.addEventListener("mouseup",f),window.addEventListener("touchmove",g,{passive:!0}),window.addEventListener("touchend",f)};t.addEventListener("mousedown",w),t.addEventListener("touchstart",w,{passive:!0}),t.addEventListener("click",()=>{var b;if(!this.dragMoved){if(this.settings.clickAction==="open_extension"){typeof chrome<"u"&&((b=chrome.runtime)!=null&&b.sendMessage)&&chrome.runtime.sendMessage({type:"OPEN_SIDEPANEL"}).catch(()=>{});return}this.isOpen=!this.isOpen,this.unreadCount=0,this.render(),this.isOpen&&this.activeTab==="chat"&&this.scrollToBottom()}})}const e=this.shadow.getElementById("nb-close-popup");e==null||e.addEventListener("click",()=>{this.isOpen=!1,this.render()});const s=this.shadow.getElementById("nb-open-sidepanel");s==null||s.addEventListener("click",()=>{var n;this.isOpen=!1,this.render(),typeof chrome<"u"&&((n=chrome.runtime)!=null&&n.sendMessage)&&chrome.runtime.sendMessage({type:"OPEN_SIDEPANEL"}).catch(()=>{})});const i=this.shadow.getElementById("nb-tab-chat");i==null||i.addEventListener("click",()=>{this.activeTab="chat",this.render(),this.scrollToBottom()});const a=this.shadow.getElementById("nb-tab-whiteboard");a==null||a.addEventListener("click",()=>{this.activeTab="whiteboard",this.render()});const h=this.shadow.getElementById("nb-live-tunein");h==null||h.addEventListener("click",()=>{var n;this.isOpen=!1,this.render(),typeof chrome<"u"&&((n=chrome.runtime)!=null&&n.sendMessage)&&chrome.runtime.sendMessage({type:"OPEN_SIDEPANEL"}).catch(()=>{})}),this.shadow.querySelectorAll(".prompt-pill").forEach(n=>{n.addEventListener("click",l=>{const d=l.target.getAttribute("data-text");d&&this.sendMessage(d)})});const r=this.shadow.getElementById("nb-spoiler-insert"),c=this.shadow.getElementById("nb-input");r==null||r.addEventListener("click",()=>{c&&(c.value=`${c.value}||hint solution||`,c.focus())});const p=this.shadow.getElementById("nb-composer");p==null||p.addEventListener("submit",n=>{n.preventDefault();const l=c==null?void 0:c.value.trim();l&&(this.sendMessage(l,this.replyingTo?{id:this.replyingTo.id,preview:`${this.replyingTo.from.nickname}: ${this.replyingTo.text.slice(0,30)}`}:void 0),c&&(c.value=""),this.replyingTo=null)})}initWhiteboardCanvas(){var o,r,c,p;if(!this.shadow)return;const t=this.shadow.getElementById("nb-whiteboard-canvas");if(!t)return;this.shadow.querySelectorAll(".wb-tool-btn[data-wbtool]").forEach(n=>{n.addEventListener("click",l=>{const d=l.currentTarget.getAttribute("data-wbtool");d&&(this.wbTool=d,this.render())})}),this.shadow.querySelectorAll(".color-dot").forEach(n=>{n.addEventListener("click",l=>{const d=l.currentTarget.getAttribute("data-color");d&&(this.wbColor=d,this.render())})}),this.shadow.querySelectorAll(".size-pill").forEach(n=>{n.addEventListener("click",l=>{const d=Number(l.currentTarget.getAttribute("data-size"));d&&(this.wbWidth=d,this.render())})}),(o=this.shadow.getElementById("nb-wb-undo"))==null||o.addEventListener("click",()=>{var n;if(this.wbStrokes.length>0){const l=this.wbStrokes.pop();l&&(this.wbRedoStack.push(l),this.drawWbCanvas(),typeof chrome<"u"&&((n=chrome.runtime)!=null&&n.sendMessage)&&chrome.runtime.sendMessage({type:"WHITEBOARD_UNDO_LOCAL",strokeId:l.id}).catch(()=>{}))}}),(r=this.shadow.getElementById("nb-wb-redo"))==null||r.addEventListener("click",()=>{var n;if(this.wbRedoStack.length>0){const l=this.wbRedoStack.pop();l&&(this.wbStrokes.push(l),this.drawWbCanvas(),typeof chrome<"u"&&((n=chrome.runtime)!=null&&n.sendMessage)&&chrome.runtime.sendMessage({type:"WHITEBOARD_STROKE_LOCAL",stroke:l}).catch(()=>{}))}}),(c=this.shadow.getElementById("nb-wb-clear"))==null||c.addEventListener("click",()=>{var n;confirm("Clear collaborative whiteboard canvas?")&&(this.wbStrokes=[],this.wbRedoStack=[],this.drawWbCanvas(),typeof chrome<"u"&&((n=chrome.runtime)!=null&&n.sendMessage)&&chrome.runtime.sendMessage({type:"WHITEBOARD_CLEAR_LOCAL"}).catch(()=>{}))}),(p=this.shadow.getElementById("nb-wb-save"))==null||p.addEventListener("click",()=>{const n=t.toDataURL("image/png"),l=document.createElement("a");l.download=`synqto-whiteboard-${Date.now()}.png`,l.href=n,l.click()}),setTimeout(()=>{const n=t.getBoundingClientRect(),l=window.devicePixelRatio||1;t.width=(n.width||380)*l,t.height=(n.height||360)*l;const d=t.getContext("2d");d&&d.scale(l,l),this.drawWbCanvas()},30);const a=n=>{const l=t.getBoundingClientRect();let d=0,m=0;return"touches"in n&&n.touches.length>0?(d=n.touches[0].clientX,m=n.touches[0].clientY):"clientX"in n&&(d=n.clientX,m=n.clientY),{x:d-l.left,y:m-l.top}};t.addEventListener("mousedown",n=>{const l=a(n);this.isWbDrawing=!0,this.wbStartPoint=l,this.wbCurrentPoints=[l]}),t.addEventListener("mousemove",n=>{if(!this.isWbDrawing)return;const l=a(n);["line","arrow","rect","circle","tree_node"].includes(this.wbTool)&&this.wbStartPoint?this.drawWbCanvas(void 0,{x1:this.wbStartPoint.x,y1:this.wbStartPoint.y,x2:l.x,y2:l.y,label:this.wbTool==="tree_node"?"val":void 0}):(this.wbCurrentPoints.push(l),this.drawWbCanvas(this.wbCurrentPoints))});const h=n=>{var f;if(!this.isWbDrawing)return;this.isWbDrawing=!1;const l=a(n),d=["line","arrow","rect","circle","tree_node"].includes(this.wbTool),m=this.wbTool==="highlighter"?14:this.wbWidth,g={id:"stroke-"+Math.random().toString(36).slice(2,10),tool:this.wbTool,color:this.wbColor,width:m,opacity:this.wbTool==="highlighter"?.35:1,points:d?[]:[...this.wbCurrentPoints],geometry:d&&this.wbStartPoint?{x1:this.wbStartPoint.x,y1:this.wbStartPoint.y,x2:l.x,y2:l.y,label:this.wbTool==="tree_node"?String(Math.floor(Math.random()*50)+1):void 0}:void 0};this.wbStrokes.push(g),this.wbRedoStack=[],this.wbCurrentPoints=[],this.wbStartPoint=null,this.drawWbCanvas(),typeof chrome<"u"&&((f=chrome.runtime)!=null&&f.sendMessage)&&chrome.runtime.sendMessage({type:"WHITEBOARD_STROKE_LOCAL",stroke:g}).catch(()=>{})};t.addEventListener("mouseup",h),t.addEventListener("mouseleave",h)}drawWbCanvas(t,e){if(!this.shadow)return;const s=this.shadow.getElementById("nb-whiteboard-canvas");if(!s)return;const i=s.getContext("2d");if(!i)return;i.clearRect(0,0,s.width,s.height),i.save(),i.strokeStyle="rgba(255, 255, 255, 0.04)",i.lineWidth=1;const a=20;for(let o=0;o<s.width;o+=a)i.beginPath(),i.moveTo(o,0),i.lineTo(o,s.height),i.stroke();for(let o=0;o<s.height;o+=a)i.beginPath(),i.moveTo(0,o),i.lineTo(s.width,o),i.stroke();i.restore();const h=o=>{if(i.save(),i.strokeStyle=o.color,i.fillStyle=o.color,i.lineWidth=o.width,i.lineCap="round",i.lineJoin="round",i.globalAlpha=o.opacity,o.tool==="eraser"&&(i.globalCompositeOperation="destination-out",i.lineWidth=o.width*3),o.geometry){const{x1:r,y1:c,x2:p,y2:n}=o.geometry;if(o.tool==="line")i.beginPath(),i.moveTo(r,c),i.lineTo(p,n),i.stroke();else if(o.tool==="arrow"){i.beginPath(),i.moveTo(r,c),i.lineTo(p,n),i.stroke();const l=Math.atan2(n-c,p-r),d=Math.max(10,o.width*3);i.beginPath(),i.moveTo(p,n),i.lineTo(p-d*Math.cos(l-Math.PI/6),n-d*Math.sin(l-Math.PI/6)),i.moveTo(p,n),i.lineTo(p-d*Math.cos(l+Math.PI/6),n-d*Math.sin(l+Math.PI/6)),i.stroke()}else if(o.tool==="rect")i.strokeRect(Math.min(r,p),Math.min(c,n),Math.abs(p-r),Math.abs(n-c));else if(o.tool==="circle"){const l=Math.abs(p-r)/2,d=Math.abs(n-c)/2;i.beginPath(),i.ellipse(Math.min(r,p)+l,Math.min(c,n)+d,l,d,0,0,Math.PI*2),i.stroke()}else if(o.tool==="tree_node"){const l=Math.max(16,o.width*3.5);i.beginPath(),i.arc(r,c,l,0,Math.PI*2),i.fillStyle="rgba(15, 23, 42, 0.9)",i.fill(),i.stroke(),i.fillStyle="#ffffff",i.font="bold 11px monospace",i.textAlign="center",i.textBaseline="middle",i.fillText(o.geometry.label||"N",r,c)}}else if(o.points&&o.points.length>1){i.beginPath(),i.moveTo(o.points[0].x,o.points[0].y);for(let r=1;r<o.points.length;r++)i.lineTo(o.points[r].x,o.points[r].y);i.stroke()}i.restore()};this.wbStrokes.forEach(h),e?h({tool:this.wbTool,color:this.wbColor,width:this.wbTool==="highlighter"?14:this.wbWidth,opacity:this.wbTool==="highlighter"?.35:1,points:[],geometry:e}):t&&t.length>1&&h({tool:this.wbTool,color:this.wbColor,width:this.wbTool==="highlighter"?14:this.wbWidth,opacity:this.wbTool==="highlighter"?.35:1,points:t})}listenForRuntimeMessages(){var t;typeof chrome<"u"&&((t=chrome.runtime)!=null&&t.onMessage)&&chrome.runtime.onMessage.addListener(e=>{e.type==="WHITEBOARD_STROKE_LOCAL"&&e.stroke?this.wbStrokes.some(s=>s.id===e.stroke.id)||(this.wbStrokes.push(e.stroke),this.activeTab==="whiteboard"&&this.drawWbCanvas()):e.type==="WHITEBOARD_CLEAR_LOCAL"?(this.wbStrokes=[],this.wbRedoStack=[],this.activeTab==="whiteboard"&&this.drawWbCanvas()):e.type==="WHITEBOARD_UNDO_LOCAL"&&e.strokeId&&(this.wbStrokes=this.wbStrokes.filter(s=>s.id!==e.strokeId),this.activeTab==="whiteboard"&&this.drawWbCanvas())})}escapeHtml(t){return t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}formatTimestamp(t){return new Date(t).toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"})}renderFormattedText(t,e){return t.split(`
`).map((i,a)=>{if(i.startsWith("```")&&i.endsWith("```")&&i.length>6){const h=i.slice(3,-3);return`
          <div style="background:rgba(0,0,0,0.45);padding:6px 8px;border-radius:6px;margin:4px 0;font-family:var(--font-mono);font-size:11px;position:relative;">
            <pre style="margin:0;white-space:pre-wrap;word-break:break-all;">${this.escapeHtml(h)}</pre>
          </div>
        `}return i.includes("||")?`<p style="margin:2px 0;">${i.split(/(\|\|.*?\|\|)/g).map((r,c)=>{if(r.startsWith("||")&&r.endsWith("||")&&r.length>4){const p=r.slice(2,-2),n=`${e}-${a}-${c}`,l=!!this.revealedSpoilers[n];return`
              <span style="display:inline-block;padding:1px 6px;border-radius:4px;background:${l?"rgba(99, 102, 241, 0.25)":"rgba(255, 255, 255, 0.15)"};filter:${l?"none":"blur(4px)"};cursor:pointer;">
                ${this.escapeHtml(p)}
              </span>
            `}return this.escapeHtml(r)}).join("")}</p>`:`<p style="margin:2px 0;">${this.escapeHtml(i)}</p>`}).join("")}deduplicateMessages(t){var i,a;const e=new Set,s=[];for(const h of t)!h||!h.id||e.has(h.id)||(e.add(h.id),s.push({...h,isSelf:((i=h.from)==null?void 0:i.peerId)===((a=this.myIdentity)==null?void 0:a.peerId)||h.isSelf}));return s}async sendMessage(t,e){var h,o,r,c;if(!t.trim())return;!this.currentRoomStorageKey&&((h=this.currentProblem)!=null&&h.roomId)&&(this.currentRoomStorageKey=`synqto_chat_${this.currentProblem.roomId}`);const s=t.trim(),i="msg-"+Math.random().toString(36).slice(2,10)+Date.now(),a={id:i,from:this.myIdentity||{nickname:"You",avatar:"⚡",color:"#6366f1",peerId:"self"},text:s,timestamp:Date.now(),replyTo:e==null?void 0:e.id,replyPreview:e==null?void 0:e.preview,status:"sent",isSelf:!0};if(this.messages.push(a),this.messages=this.deduplicateMessages(this.messages),this.render(),this.scrollToBottom(),this.currentRoomStorageKey&&typeof chrome<"u"&&((o=chrome.storage)!=null&&o.local))try{const p=await chrome.storage.local.get([this.currentRoomStorageKey]),n=p[this.currentRoomStorageKey]&&Array.isArray(p[this.currentRoomStorageKey])?p[this.currentRoomStorageKey]:[],l=this.deduplicateMessages([...n,a]).slice(-150);await chrome.storage.local.set({[this.currentRoomStorageKey]:l})}catch{}typeof chrome<"u"&&((r=chrome.runtime)!=null&&r.sendMessage)&&chrome.runtime.sendMessage({type:"SEND_PAGE_CHAT_MESSAGE",messageId:i,text:a.text,replyTo:a.replyTo,replyPreview:a.replyPreview,roomId:(c=this.currentProblem)==null?void 0:c.roomId}).catch(()=>{})}async loadMessages(){var t;if(this.currentRoomStorageKey&&typeof chrome<"u"&&(t=chrome.storage)!=null&&t.local){const e=await chrome.storage.local.get([this.currentRoomStorageKey]);e[this.currentRoomStorageKey]&&Array.isArray(e[this.currentRoomStorageKey])&&(this.messages=this.deduplicateMessages(e[this.currentRoomStorageKey]),this.isOpen&&this.activeTab==="chat"&&(this.render(),this.scrollToBottom()))}}scrollToBottom(){setTimeout(()=>{var e;const t=(e=this.shadow)==null?void 0:e.getElementById("nb-messages");t&&(t.scrollTop=t.scrollHeight)},40)}listenToStorageChanges(){var t;typeof chrome<"u"&&((t=chrome.storage)!=null&&t.onChanged)&&chrome.storage.onChanged.addListener((e,s)=>{var i,a,h;if(s==="local"&&(e.nerd_buddy_sidepanel_open&&e.nerd_buddy_sidepanel_open.newValue===!0&&this.isOpen&&(this.isOpen=!1,this.render()),(e.synqto_live_stage||e.nerd_buddy_live_stage)&&(this.liveStage=(e.synqto_live_stage||e.nerd_buddy_live_stage).newValue,this.render()),(e.synqto_identity||e.nerd_buddy_identity)&&(this.myIdentity=(e.synqto_identity||e.nerd_buddy_identity).newValue),e[y]&&(this.settings=e[y].newValue,this.settings.positionMode==="permanent"&&this.settings.savedPosition&&(this.currentPosition={...this.settings.savedPosition}),this.checkVisibilityAndRender()),(e.synqto_active_problem||e.nerd_buddy_active_problem)&&(this.currentProblem=(e.synqto_active_problem||e.nerd_buddy_active_problem).newValue,this.currentRoomStorageKey=`synqto_chat_${((i=this.currentProblem)==null?void 0:i.roomId)||""}`,this.loadMessages(),this.checkVisibilityAndRender()),e.nerd_buddy_peer_count&&(this.peerCount=Math.max(1,e.nerd_buddy_peer_count.newValue||1),this.render()),this.currentRoomStorageKey&&e[this.currentRoomStorageKey])){const o=e[this.currentRoomStorageKey].newValue||[];this.messages=this.deduplicateMessages(o),!this.isOpen&&((a=e[this.currentRoomStorageKey].newValue)==null?void 0:a.length)>(((h=e[this.currentRoomStorageKey].oldValue)==null?void 0:h.length)||0)&&this.unreadCount++,this.render(),this.isOpen&&this.activeTab==="chat"&&this.scrollToBottom()}})}}console.log("[Nerd Buddy] Content script initialized on:",window.location.href),new I(u=>{var t;try{typeof chrome<"u"&&((t=chrome.runtime)!=null&&t.sendMessage)&&chrome.runtime.sendMessage({type:"PROBLEM_DETECTED",payload:u})}catch{}}),new L,new D})();
