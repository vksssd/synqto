(function(){"use strict";function j(T){let i=2166136261,o=2166136261;for(let e=0;e<T.length;e++){const t=T.charCodeAt(e);i=Math.imul(i^t&255,16777619),o=Math.imul(o^t>>8,16777619)}return((i>>>0^o>>>0)>>>0).toString(16).padStart(8,"0")}function V(T,i){let o=null;return(...s)=>{o&&clearTimeout(o),o=setTimeout(()=>T(...s),i)}}function H(T,i){var o;try{const s=new URL(T),e=s.hostname.toLowerCase(),t=s.pathname;if(e.includes("leetcode.com")||e.includes("leetcode.cn")){const a=t.match(/\/problems\/([a-zA-Z0-9-_]+)/);if(a&&a[1]){const c=a[1],r=B(c),m=e.includes("leetcode.cn")?"leetcode.cn":"leetcode.com";return{platform:"LeetCode",slug:c,title:r,url:T,canonicalUrl:`https://${m}/problems/${c}/`}}}if(e.includes("neetcode.io")){const a=t.match(/\/problems\/([a-zA-Z0-9-_]+)/);if(a&&a[1]){const c=a[1],r=B(c);return{platform:"NeetCode",slug:c,title:r,url:T,canonicalUrl:`https://neetcode.io/problems/${c}`}}}if(e.includes("codeforces.com")||e.includes("codeforces.net")){const a=t.match(/\/(?:contest\/(\d+)\/problem|problemset\/problem\/(\d+)|gym\/(\d+)\/problem)\/([a-zA-Z0-9]+)/i);if(a){const c=a[1]||a[2]||a[3],r=a[4].toUpperCase();return{platform:"Codeforces",slug:`cf-${c}-${r}`,title:`Codeforces ${c}${r}`,url:T,canonicalUrl:`https://codeforces.com/problemset/problem/${c}/${r}`}}}if(e.includes("atcoder.jp")){const a=t.match(/\/contests\/([a-zA-Z0-9-_]+)\/tasks\/([a-zA-Z0-9-_]+)/);if(a){const c=a[1],r=a[2];return{platform:"AtCoder",slug:`atcoder-${r}`,title:B(r),url:T,canonicalUrl:`https://atcoder.jp/contests/${c}/tasks/${r}`}}}if(e.includes("hackerrank.com")){const a=t.match(/\/challenges\/([a-zA-Z0-9-_]+)/);if(a&&a[1]){const c=a[1];return{platform:"HackerRank",slug:c,title:B(c),url:T,canonicalUrl:`https://www.hackerrank.com/challenges/${c}/problem`}}}if(e.includes("codechef.com")){const a=t.match(/\/problems\/([a-zA-Z0-9-_]+)/);if(a&&a[1]){const c=a[1];return{platform:"CodeChef",slug:c,title:`CodeChef ${c}`,url:T,canonicalUrl:`https://www.codechef.com/problems/${c}`}}}if(e.includes("geeksforgeeks.org")){const a=t.match(/\/problems\/([a-zA-Z0-9-_]+)/);if(a&&a[1]){const c=a[1],r=c.replace(/-\d{6,}$/,"");return{platform:"GeeksforGeeks",slug:c,title:B(r),url:T,canonicalUrl:`https://www.geeksforgeeks.org/problems/${c}/1`}}}if(e.includes("youtube.com")||e.includes("youtu.be")){let a=s.searchParams.get("v");if(!a&&e.includes("youtu.be")&&(a=t.slice(1)),!a&&t.includes("/shorts/")&&(a=(o=t.split("/shorts/")[1])==null?void 0:o.split("/")[0]),a){const c=i?Y(i):`YouTube Video (${a})`;return{platform:"YouTube",slug:`yt-${a}`,title:c,url:T,canonicalUrl:`https://www.youtube.com/watch?v=${a}`}}}if(e.includes("arxiv.org")){const a=t.match(/\/(?:abs|pdf)\/(\d+\.\d+(?:v\d+)?)/);if(a&&a[1]){const c=a[1];return{platform:"ArXiv",slug:`arxiv-${c.replace(/\./g,"-")}`,title:i?G(i):`ArXiv ${c}`,url:T,canonicalUrl:`https://arxiv.org/abs/${c}`}}}if(e.includes("github.com")){const a=t.match(/^\/([^\/]+)\/([^\/]+)\/(?:issues|pull)\/(\d+)/);if(a){const c=a[1],r=a[2],m=a[3];return{platform:"GitHub",slug:`gh-${c}-${r}-${m}`,title:`${c}/${r} #${m}`,url:T,canonicalUrl:`https://github.com/${c}/${r}/issues/${m}`}}}return{platform:"Web",slug:e.replace(/\./g,"-")||"general-study",title:i||e||"General Study Room",url:T,canonicalUrl:T}}catch{return null}}function B(T){return T.split(/[-_]/).map(i=>i.charAt(0).toUpperCase()+i.slice(1)).join(" ")}function Y(T){return T.replace(/\s*-\s*YouTube\s*$/,"").trim()}function G(T){return T.replace(/^\[[^\]]+\]\s*/,"").replace(/\s*-\s*arXiv.*$/,"").trim()}function N(){try{return!!(typeof chrome<"u"&&chrome.runtime&&chrome.runtime.id)}catch{return!1}}class K{constructor(i){this.lastUrl="",this.lastTitle="",this.mutationObserver=null,this.pollTimer=null,this.debouncedCheck=V(()=>{if(!N()){this.destroy();return}this.checkCurrentPage()},250),this.callback=i,this.init()}init(){if(this.checkCurrentPage(),typeof window<"u"&&window.history){const i=window.history.pushState,o=window.history.replaceState;typeof i=="function"&&(window.history.pushState=(...s)=>{i.apply(window.history,s),this.debouncedCheck()}),typeof o=="function"&&(window.history.replaceState=(...s)=>{o.apply(window.history,s),this.debouncedCheck()})}if(typeof window<"u"&&(window.addEventListener("popstate",()=>this.debouncedCheck()),window.addEventListener("hashchange",()=>this.debouncedCheck()),window.addEventListener("yt-navigate-finish",()=>this.debouncedCheck())),typeof MutationObserver<"u"&&typeof document<"u"){this.mutationObserver=new MutationObserver(()=>{document.title!==this.lastTitle&&this.debouncedCheck()});const i=document.querySelector("title");i&&this.mutationObserver.observe(i,{subtree:!0,characterData:!0,childList:!0})}this.pollTimer=setInterval(()=>{if(!N()){this.destroy();return}window.location.href!==this.lastUrl&&this.checkCurrentPage()},350)}checkCurrentPage(){const i=window.location.href,o=document.title;if(i===this.lastUrl&&o===this.lastTitle)return;this.lastUrl=i,this.lastTitle=o;const s=H(i,o);s&&this.callback(s)}destroy(){this.mutationObserver&&(this.mutationObserver.disconnect(),this.mutationObserver=null),this.pollTimer&&(clearInterval(this.pollTimer),this.pollTimer=null)}}function W(){try{return!!(typeof chrome<"u"&&chrome.runtime&&chrome.runtime.id)}catch{return!1}}class X{constructor(){this.container=null,this.cursorElements=new Map,this.cursorTimeouts=new Map,this.myIdentity=null,this.liveStage=null,this.createContainer(),this.loadState(),this.listenToStorage(),this.listenForMessages(),this.setupLocalTrackers()}async loadState(){var i;if(typeof chrome<"u"&&((i=chrome.storage)!=null&&i.local))try{const o=await chrome.storage.local.get(["nerd_buddy_identity","synqme_identity","nerd_buddy_live_stage","synqme_live_stage"]);this.myIdentity=o.synqme_identity||o.nerd_buddy_identity||null,this.liveStage=o.synqme_live_stage||o.nerd_buddy_live_stage||null,(!this.liveStage||!this.liveStage.isActive)&&this.clearAllCursors()}catch{}}listenToStorage(){var i;typeof chrome<"u"&&((i=chrome.storage)!=null&&i.onChanged)&&chrome.storage.onChanged.addListener((o,s)=>{s==="local"&&((o.synqme_identity||o.nerd_buddy_identity)&&(this.myIdentity=(o.synqme_identity||o.nerd_buddy_identity).newValue),(o.synqme_live_stage||o.nerd_buddy_live_stage)&&(this.liveStage=(o.synqme_live_stage||o.nerd_buddy_live_stage).newValue,(!this.liveStage||!this.liveStage.isActive)&&this.clearAllCursors()))})}clearAllCursors(){this.cursorTimeouts.forEach(i=>clearTimeout(i)),this.cursorTimeouts.clear(),this.cursorElements.forEach(i=>{i.remove()}),this.cursorElements.clear(),this.container&&(this.container.innerHTML="")}isLocalUserOnStage(){var o,s;if(!this.liveStage||!this.liveStage.isActive)return!1;const i=(o=this.myIdentity)==null?void 0:o.peerId;return i?!!(((s=this.liveStage.tutorIdentity)==null?void 0:s.peerId)===i||this.liveStage.tutorPeerId===i||this.liveStage.myRole==="tutor"||Array.isArray(this.liveStage.guestSpeakers)&&this.liveStage.guestSpeakers.some(e=>e.peerId===i)):!1}createContainer(){var o;if(document.getElementById("nerd-buddy-cursor-overlay"))return;if(!document.body){document.readyState==="loading"?document.addEventListener("DOMContentLoaded",()=>this.createContainer(),{once:!0}):window.addEventListener("load",()=>this.createContainer(),{once:!0});return}const i=document.createElement("div");if(i.id="nerd-buddy-cursor-overlay",i.style.cssText=`
      position: fixed !important;
      top: 0 !important;
      left: 0 !important;
      width: 100vw !important;
      height: 100vh !important;
      pointer-events: none !important;
      z-index: 2147483645 !important;
      overflow: hidden !important;
      box-sizing: border-box !important;
    `,document.body.appendChild(i),this.container=i,!document.getElementById("nerd-buddy-cursor-styles")){const s=document.createElement("style");s.id="nerd-buddy-cursor-styles",s.textContent=`
        @keyframes nb-click-ripple {
          0% { transform: scale(0.15); opacity: 1; }
          40% { opacity: 0.9; }
          100% { transform: scale(2.8); opacity: 0; }
        }
      `,(o=document.head||document.documentElement||document.body)==null||o.appendChild(s)}}listenForMessages(){var i;if(!(!W()||!((i=chrome.runtime)!=null&&i.onMessage)))try{chrome.runtime.onMessage.addListener(o=>{var s,e,t,b;if(W()){if(o.type==="NERD_BUDDY_STAGE_ENDED"||o.type==="NERD_BUDDY_STAGE_INACTIVE"){this.clearAllCursors();return}if(o.type==="NERD_BUDDY_CURSOR_UPDATE"&&o.cursor){const a=o.cursor;(a.isTutor||this.liveStage&&(((s=this.liveStage.tutorIdentity)==null?void 0:s.peerId)===a.peerId||this.liveStage.tutorPeerId===a.peerId||((e=this.liveStage.guestSpeakers)==null?void 0:e.some(r=>r.peerId===a.peerId)))||!this.liveStage)&&this.renderCursor(a)}else if(o.type==="NERD_BUDDY_CLICK_PULSE"&&o.click){const a=o.click;(a.isTutor||this.liveStage&&(((t=this.liveStage.tutorIdentity)==null?void 0:t.peerId)===a.peerId||this.liveStage.tutorPeerId===a.peerId||((b=this.liveStage.guestSpeakers)==null?void 0:b.some(r=>r.peerId===a.peerId)))||a.isTutor||!this.liveStage)&&this.renderClickPulse(a)}}})}catch{}}renderCursor(i){if(this.container||this.createContainer(),!this.container)return;let o=this.cursorElements.get(i.peerId);o||(o=document.createElement("div"),o.style.cssText=`
        position: fixed !important;
        pointer-events: none !important;
        transition: left 0.05s linear, top 0.05s linear, opacity 0.3s ease !important;
        display: flex !important;
        align-items: center !important;
        gap: 5px !important;
        opacity: 1 !important;
        z-index: 2147483646 !important;
      `,this.container.appendChild(o),this.cursorElements.set(i.peerId,o));const s=Math.max(0,Math.min(window.innerWidth-30,i.xPct/100*window.innerWidth)),e=Math.max(0,Math.min(window.innerHeight-30,i.yPct/100*window.innerHeight));o.style.left=`${s}px`,o.style.top=`${e}px`,o.style.opacity="1";const t=i.isTutor?"#8b5cf6":i.color||"#6366f1";o.innerHTML=`
      <div style="
        width: 18px;
        height: 18px;
        border-radius: 50%;
        background: ${t};
        box-shadow: 0 0 16px ${t}, 0 0 6px #ffffff;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 11px;
        color: #fff;
        border: 2px solid #ffffff;
      ">
        ${i.avatar||"👑"}
      </div>
      <div style="
        background: rgba(15, 23, 42, 0.92);
        border: 1px solid ${t};
        color: #f8fafc;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        font-size: 10px;
        font-weight: 600;
        padding: 2px 6px;
        border-radius: 4px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.6);
        white-space: nowrap;
      ">
        ${i.nickname} ${i.isTutor?"🎓 (Tutor)":"🎤 (Speaker)"}
      </div>
    `;const b=this.cursorTimeouts.get(i.peerId);b&&clearTimeout(b);const a=window.setTimeout(()=>{o&&(o.style.opacity="0")},4e3);this.cursorTimeouts.set(i.peerId,a)}renderClickPulse(i){if(this.container||this.createContainer(),!this.container)return;const o=i.xPct/100*window.innerWidth,s=i.yPct/100*window.innerHeight,e=document.createElement("div"),t=i.color||(i.isTutor?"#8b5cf6":"#6366f1");e.style.cssText=`
      position: fixed !important;
      left: ${o-22}px !important;
      top: ${s-22}px !important;
      width: 44px !important;
      height: 44px !important;
      border-radius: 50% !important;
      border: 3px solid ${t} !important;
      box-shadow: 0 0 16px ${t}, inset 0 0 8px ${t} !important;
      pointer-events: none !important;
      z-index: 2147483647 !important;
      box-sizing: border-box !important;
      animation: nb-click-ripple 0.85s cubic-bezier(0.1, 0.8, 0.3, 1) forwards !important;
    `,this.container.appendChild(e),setTimeout(()=>{e.remove()},900)}setupLocalTrackers(){let i=0;window.addEventListener("mousemove",o=>{if(!W()||!this.isLocalUserOnStage())return;const s=Date.now();if(s-i<40)return;i=s;const e=o.clientX/window.innerWidth*100,t=o.clientY/window.innerHeight*100;try{chrome.runtime.sendMessage({type:"LOCAL_CURSOR_MOVE",xPct:e,yPct:t}).catch(()=>{})}catch{}}),window.addEventListener("click",o=>{var t,b,a;if(!W()||!this.isLocalUserOnStage())return;const s=o.clientX/window.innerWidth*100,e=o.clientY/window.innerHeight*100;this.renderClickPulse({peerId:((t=this.myIdentity)==null?void 0:t.peerId)||"local",nickname:((b=this.myIdentity)==null?void 0:b.nickname)||"You",xPct:s,yPct:e,color:((a=this.myIdentity)==null?void 0:a.color)||"#8b5cf6",isTutor:!0,timestamp:Date.now()});try{chrome.runtime.sendMessage({type:"LOCAL_CLICK_PULSE",xPct:s,yPct:e}).catch(()=>{})}catch{}})}}const q={mode:"all_sites",clickAction:"open_popup",customDomains:["leetcode.com","neetcode.io","codeforces.com","hackerrank.com","geeksforgeeks.org","codechef.com","atcoder.jp","localhost","127.0.0.1"],enableWhiteboard:!0,enableTimer:!0,popupContentMode:"both",positionMode:"permanent",savedPosition:{right:24,bottom:24},whiteboardPrefs:{defaultPrivacyMode:"collaborative",defaultBackgroundType:"grid",defaultBgColor:"#090d16",defaultPenColor:"#6366f1",defaultPenWidth:4,disappearingInkDurationSec:3,autoSavePersonalNotebook:!0}},A="nerd_buddy_fab_settings",z="synqto_fab_settings";function Q(T,i){const o=T.toLowerCase().replace(/[^a-z0-9-_]/g,"-").slice(0,24).replace(/-+$/,""),s=j(i);return`room:${o||"lobby"}-${s}`}function Z(T){switch(T.toLowerCase()){case"leetcode":return"#FFA116";case"neetcode":return"#8B5CF6";case"codeforces":return"#318CE7";case"hackerrank":return"#2EC866";case"codechef":return"#5B4638";case"geeksforgeeks":return"#2F8D46";case"youtube":return"#FF0000";case"arxiv":return"#B31B1B";case"github":return"#24292F";case"group":return"#8B5CF6";default:return"#6366F1"}}const F={enabled:!1,workDurationMin:25,shortBreakMin:5,longBreakMin:15,autoStartBreaks:!1,soundAlerts:!0},O="synqto_pomodoro_config",R="synqto_pomodoro_state";class J{constructor(){this.hostElement=null,this.shadow=null,this.isOpen=!1,this.settings=q,this.currentProblem=null,this.messages=[],this.unreadCount=0,this.currentRoomStorageKey="",this.myIdentity=null,this.liveStage=null,this.peerCount=1,this.isServerConnected=!0,this.serverToastMessage=null,this.replyingTo=null,this.revealedSpoilers={},this.currentPosition={right:24,bottom:24},this.isDragging=!1,this.dragMoved=!1,this.popupSize="compact",this.activeTab="chat",this.isTimerOpen=!1,this.timerConfig=F,this.timerState={mode:"pomodoro",timeLeftSec:1500,targetDurationSec:1500,isRunning:!1,sessionsCompleted:0,lastUpdated:Date.now()},this.timerInterval=null,this.wbTool="pen",this.wbShowShapesDrawer=!1,this.wbShowDsaDrawer=!1,this.wbShowArchDrawer=!1,this.wbShowPresetsDrawer=!1,this.wbShowThemesDrawer=!1,this.wbPresetTab="dsa",this.toolStyles={pen:{color:"#6366f1",width:3},brush:{color:"#06b6d4",width:6},highlighter:{color:"#f59e0b",width:16},temp_pen:{color:"#38bdf8",width:3},laser:{color:"#ef4444",width:3},torch:{color:"#facc15",width:65},eraser:{color:"#ffffff",width:18},text:{color:"#ffffff",width:3},code_box:{color:"#38bdf8",width:2},line:{color:"#6366f1",width:3},arrow:{color:"#6366f1",width:3},arrow_bi:{color:"#6366f1",width:3},rect:{color:"#6366f1",width:3},rounded_rect:{color:"#6366f1",width:3},circle:{color:"#6366f1",width:3},triangle:{color:"#10b981",width:3},star:{color:"#f59e0b",width:3},decision_diamond:{color:"#f59e0b",width:3},tree_node:{color:"#10b981",width:3},sticky_note:{color:"#fef3c7",width:2},db_cylinder:{color:"#10b981",width:2.5},db_nosql:{color:"#34d399",width:2.5},cloud:{color:"#38bdf8",width:2.5},load_balancer:{color:"#f59e0b",width:2.5},message_queue:{color:"#a855f7",width:2.5},server_box:{color:"#818cf8",width:2.5},cache_mem:{color:"#f43f5e",width:2.5},dns_router:{color:"#38bdf8",width:2.5},firewall:{color:"#f43f5e",width:2.5},user_client:{color:"#3b82f6",width:2.5},mobile_client:{color:"#06b6d4",width:2.5},array_cells:{color:"#38bdf8",width:2.5},stack_lifo:{color:"#f59e0b",width:2.5},queue_fifo:{color:"#10b981",width:2.5},hashmap_table:{color:"#a855f7",width:2.5},two_pointers:{color:"#ec4899",width:2},cdn_edge:{color:"#06b6d4",width:2.5},object_storage:{color:"#f97316",width:2.5},auth_jwt:{color:"#eab308",width:2.5},websocket_gw:{color:"#6366f1",width:2.5},elasticsearch:{color:"#14b8a6",width:2.5},async_arrow:{color:"#a855f7",width:2},tradeoff_note:{color:"#facc15",width:2}},this.wbColor="#6366f1",this.wbWidth=3,this.wbTheme="grid",this.wbBgColor="#090d16",this.wbPrivacyMode="collaborative",this.wbStrokes=[],this.wbPersonalStrokes=[],this.wbRedoStack=[],this.isWbDrawing=!1,this.wbCurrentPoints=[],this.wbStartPoint=null,this.tempDisappearingStrokes=[],this.wbLaserTrails=[],this.wbTorchPos=null,this.wbEraserPos=null,this.themeSettings=null,this.init()}async init(){await this.loadIdentity(),await this.loadSettings(),await this.loadServerConnectionStatus(),await this.loadTimerState(),this.startTimerTickLoop(),this.detectCurrentPageProblem(),this.checkVisibilityAndRender(),this.listenToStorageChanges(),this.listenForRuntimeMessages(),console.log("[Synqto] Floating widget initialized. State:",this.shouldShow()?"VISIBLE":"HIDDEN","Mode:",this.settings.mode)}async loadServerConnectionStatus(){var i;if(typeof chrome<"u"&&((i=chrome.storage)!=null&&i.local))try{const o=await chrome.storage.local.get(["synqto_server_connected","nerd_buddy_server_connected"]);this.isServerConnected=!!(o.synqto_server_connected??o.nerd_buddy_server_connected??!0)}catch{this.isServerConnected=!0}}async loadIdentity(){var i;if(typeof chrome<"u"&&((i=chrome.storage)!=null&&i.local)){const o=await chrome.storage.local.get(["synqto_identity","nerd_buddy_identity"]);this.myIdentity=o.synqto_identity||o.nerd_buddy_identity||null}}async loadSettings(){var i,o;if(typeof chrome<"u"&&((i=chrome.storage)!=null&&i.local)){const s=await chrome.storage.local.get([A,z,"synqto_theme_settings","synqto_collab_notebook","synqto_personal_notebook","synqto_active_problem","nerd_buddy_active_problem","synqto_live_stage","nerd_buddy_live_stage","nerd_buddy_sidepanel_open","nerd_buddy_peer_count"]);if(s.synqto_theme_settings&&(this.themeSettings=s.synqto_theme_settings),s.synqto_collab_notebook&&Array.isArray(s.synqto_collab_notebook.pages)){const t=s.synqto_collab_notebook,b=t.pages.find(a=>a.id===t.activePageId)||t.pages[0];b&&(this.wbStrokes=b.strokes||[],b.background&&(this.wbTheme=b.background),b.bgColor&&(this.wbBgColor=b.bgColor))}if(s.synqto_personal_notebook&&Array.isArray(s.synqto_personal_notebook.pages)){const t=s.synqto_personal_notebook,b=t.pages.find(a=>a.id===t.activePageId)||t.pages[0];b&&(this.wbPersonalStrokes=b.strokes||[])}(s[z]||s[A])&&(this.settings={...q,...s[z]||s[A]}),this.settings.positionMode==="permanent"&&this.settings.savedPosition?this.currentPosition={...this.settings.savedPosition}:this.currentPosition={right:24,bottom:24};const e=s.synqto_active_problem||s.nerd_buddy_active_problem;e&&(this.currentProblem=e,this.currentRoomStorageKey=`synqto_chat_${((o=this.currentProblem)==null?void 0:o.roomId)||""}`,await this.loadMessages()),(s.synqto_live_stage||s.nerd_buddy_live_stage)&&(this.liveStage=s.synqto_live_stage||s.nerd_buddy_live_stage),typeof s.nerd_buddy_peer_count=="number"&&(this.peerCount=Math.max(1,s.nerd_buddy_peer_count))}}detectCurrentPageProblem(){const i=H(window.location.href,document.title);if(i){const o=Q(i.slug,i.canonicalUrl);this.currentProblem={platform:i.platform,slug:i.slug,title:i.title,canonicalUrl:i.canonicalUrl,roomId:o},this.currentRoomStorageKey=`synqto_chat_${o}`,this.loadMessages()}}shouldShow(){if(this.settings.mode==="disabled"||this.settings.popupContentMode==="none")return!1;if(this.settings.mode==="all_sites")return!0;const i=window.location.hostname.toLowerCase();if(this.settings.mode==="custom_sites")return this.settings.customDomains.some(t=>i.includes(t.toLowerCase()));const s=["leetcode.com","leetcode.cn","neetcode.io","codeforces.com","codeforces.net","hackerrank.com","geeksforgeeks.org","codechef.com","atcoder.jp","hackerearth.com","topcoder.com","spoj.com","codewars.com","exercism.org","github.com","youtube.com","arxiv.org","localhost","127.0.0.1"].some(t=>i.includes(t)),e=!!(this.currentProblem||H(window.location.href,document.title));return s||e}checkVisibilityAndRender(){const i=this.shouldShow();i&&!this.hostElement?this.createWidgetDOM():!i&&this.hostElement&&this.destroyWidgetDOM()}destroyWidgetDOM(){this.hostElement&&(this.hostElement.remove(),this.hostElement=null,this.shadow=null)}createWidgetDOM(){var e,t;if(document.getElementById("synqto-floating-host"))return;if(!document.body){document.readyState==="loading"?document.addEventListener("DOMContentLoaded",()=>this.checkVisibilityAndRender(),{once:!0}):window.addEventListener("load",()=>this.checkVisibilityAndRender(),{once:!0});return}const i=document.createElement("div");i.id="synqto-floating-host";const o=Number.isFinite((e=this.currentPosition)==null?void 0:e.right)?this.currentPosition.right:24,s=Number.isFinite((t=this.currentPosition)==null?void 0:t.bottom)?this.currentPosition.bottom:24;i.style.cssText=`
      position: fixed !important;
      bottom: ${s}px !important;
      right: ${o}px !important;
      z-index: 2147483647 !important;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif !important;
      touch-action: none !important;
      pointer-events: auto !important;
      display: block !important;
      visibility: visible !important;
      opacity: 1 !important;
    `,document.body.appendChild(i),this.hostElement=i,this.shadow=i.attachShadow({mode:"open"}),this.render()}applyHostPosition(){var t,b;if(!this.hostElement)return;const i=Number.isFinite((t=this.currentPosition)==null?void 0:t.right)?this.currentPosition.right:24,o=Number.isFinite((b=this.currentPosition)==null?void 0:b.bottom)?this.currentPosition.bottom:24,s=Math.max(10,Math.min(window.innerWidth-130,i)),e=Math.max(10,Math.min(window.innerHeight-55,o));this.hostElement.style.setProperty("right",`${s}px`,"important"),this.hostElement.style.setProperty("bottom",`${e}px`,"important")}render(){var S,y,v,p;if(!this.shadow)return;const i=this.settings.popupContentMode||(this.settings.enableWhiteboard?"both":"chat_only");if(i==="none"||this.settings.mode==="disabled"){this.destroyWidgetDOM();return}this.applyHostPosition();const o=!!(this.liveStage&&this.liveStage.isActive),s=((y=(S=this.liveStage)==null?void 0:S.tutorIdentity)==null?void 0:y.nickname)||"Tutor",e=((v=this.currentProblem)==null?void 0:v.title)||"Global Problem Lobby",t=((p=this.currentProblem)==null?void 0:p.platform)||"LeetCode",b=Z(t),a=i==="whiteboard_only"||i==="both"&&this.activeTab==="whiteboard",c=i==="whiteboard_only"?"🎨":"⚡",r="synqto",m=this.currentPosition.bottom>window.innerHeight-540,g=this.currentPosition.right>window.innerWidth-420;this.shadow.innerHTML=`
      <style>
        :host {
          ${this.getThemeCSS()}
          --font-mono: 'JetBrains Mono', 'Fira Code', monospace;
        }

        * {
          box-sizing: border-box;
          margin: 0;
          padding: 0;
        }

        /* Floating Action Button (FAB) */
        .fab-button {
          position: relative;
          display: flex;
          align-items: center;
          gap: 7px;
          padding: 10px 14px;
          border-radius: 9999px;
          background: linear-gradient(135deg, #4f46e5, #7c3aed);
          border: 1px solid rgba(255, 255, 255, 0.2);
          box-shadow: 0 10px 25px -5px rgba(99, 102, 241, 0.5), 0 0 15px rgba(124, 58, 237, 0.3);
          color: #ffffff;
          font-size: 12px;
          font-weight: 700;
          cursor: grab;
          transition: transform 0.15s cubic-bezier(0.16, 1, 0.3, 1), box-shadow 0.15s;
          user-select: none;
        }

        .fab-button:active {
          cursor: grabbing;
        }

        .fab-button:hover {
          transform: translateY(-2px) scale(1.02);
          box-shadow: 0 14px 28px -5px rgba(99, 102, 241, 0.65), 0 0 20px rgba(124, 58, 237, 0.4);
        }

        .drag-grip {
          opacity: 0.5;
          font-size: 11px;
          cursor: grab;
        }

        .live-dot {
          width: 8px;
          height: 8px;
          border-radius: 50%;
          background: #ef4444;
          box-shadow: 0 0 10px #ef4444;
          animation: livePulse 1.5s infinite;
        }

        .timer-dot {
          width: 7px;
          height: 7px;
          border-radius: 50%;
          background: #f43f5e;
          box-shadow: 0 0 8px #f43f5e;
          animation: livePulse 1.2s infinite;
        }

        @keyframes livePulse {
          0%, 100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.4; transform: scale(1.2); }
        }

        @keyframes rocketThrust {
          0% { transform: translateY(0px) rotate(45deg); }
          100% { transform: translateY(-2px) rotate(52deg); }
        }

        @keyframes flameFlicker {
          0% { opacity: 0.7; transform: scale(0.85); }
          100% { opacity: 1; transform: scale(1.25); }
        }

        @keyframes neonTrackGlow {
          0% { box-shadow: 0 0 5px rgba(244, 63, 94, 0.4); }
          100% { box-shadow: 0 0 15px rgba(244, 63, 94, 0.8), 0 0 25px rgba(99, 102, 241, 0.5); }
        }

        /* Standalone Rocket Racing Focus Timer FAB */
        .timer-fab-button {
          position: relative;
          display: flex;
          align-items: center;
          gap: 8px;
          padding: 8px 14px;
          border-radius: 9999px;
          background: linear-gradient(135deg, #1e1035 0%, #0f172a 100%);
          border: 1px solid rgba(244, 63, 94, 0.55);
          box-shadow: 0 10px 25px -5px rgba(244, 63, 94, 0.45), 0 0 18px rgba(99, 102, 241, 0.3);
          color: #ffffff;
          font-size: 12px;
          font-weight: 700;
          cursor: pointer;
          transition: transform 0.15s cubic-bezier(0.16, 1, 0.3, 1), box-shadow 0.2s, border-color 0.2s;
          user-select: none;
          backdrop-filter: blur(16px);
        }

        .timer-fab-button:hover {
          transform: translateY(-2px) scale(1.03);
          box-shadow: 0 14px 28px -5px rgba(244, 63, 94, 0.65), 0 0 25px rgba(244, 63, 94, 0.5);
          border-color: rgba(244, 63, 94, 0.85);
        }

        .timer-fab-track {
          width: 52px;
          height: 6px;
          border-radius: 3px;
          background: rgba(255, 255, 255, 0.12);
          position: relative;
          overflow: hidden;
        }

        .timer-fab-fill {
          height: 100%;
          background: linear-gradient(90deg, #6366f1, #f43f5e);
          box-shadow: 0 0 8px rgba(244, 63, 94, 0.8);
          transition: width 0.4s ease;
        }

        .timer-fab-rocket {
          font-size: 13px;
          display: inline-block;
          filter: drop-shadow(0 0 6px rgba(244, 63, 94, 0.9));
        }

        .fab-badge {
          position: absolute;
          top: -4px;
          right: -4px;
          background: #f59e0b;
          color: #ffffff;
          font-size: 10px;
          font-weight: 700;
          padding: 2px 6px;
          border-radius: 9999px;
        }

        /* In-Page Popup Card */
        .popup-card {
          display: ${this.isOpen?"flex":"none"};
          flex-direction: column;
          position: absolute;
          ${m?"top: 52px; bottom: auto;":"bottom: 52px; top: auto;"}
          ${g?"left: 0; right: auto;":"right: 0; left: auto;"}
          width: ${this.popupSize==="fullscreen"?"min(1180px, 95vw)":this.popupSize==="large"?"min(860px, 92vw)":this.popupSize==="medium"?"min(620px, 88vw)":"420px"};
          height: ${this.popupSize==="fullscreen"?"min(880px, 92vh)":this.popupSize==="large"?"min(740px, 88vh)":this.popupSize==="medium"?"min(640px, 84vh)":"540px"};
          max-height: 94vh;
          max-width: 96vw;
          background: rgba(15, 23, 42, 0.97);
          border: 1px solid ${o?"rgba(239, 68, 68, 0.45)":"rgba(99, 102, 241, 0.35)"};
          border-radius: 16px;
          box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.9), 0 0 28px ${o?"rgba(239, 68, 68, 0.25)":"rgba(99, 102, 241, 0.25)"};
          backdrop-filter: blur(24px);
          -webkit-backdrop-filter: blur(24px);
          overflow: hidden;
          animation: slideIn 0.2s cubic-bezier(0.16, 1, 0.3, 1);
          color: var(--text-primary);
          transition: width 0.2s cubic-bezier(0.16, 1, 0.3, 1), height 0.2s cubic-bezier(0.16, 1, 0.3, 1);
        }

        /* Dedicated Standalone Timer & Pomodoro Popup Window */
        .timer-popup-card {
          display: ${this.isTimerOpen?"flex":"none"};
          flex-direction: column;
          position: absolute;
          ${m?"top: 52px; bottom: auto;":"bottom: 52px; top: auto;"}
          ${g?"left: 0; right: auto;":"right: 0; left: auto;"}
          width: 320px;
          background: rgba(15, 23, 42, 0.98);
          border: 1px solid rgba(244, 63, 94, 0.5);
          border-radius: 16px;
          box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.95), 0 0 28px rgba(244, 63, 94, 0.3);
          backdrop-filter: blur(24px);
          -webkit-backdrop-filter: blur(24px);
          z-index: 100;
          overflow: hidden;
          animation: slideIn 0.2s cubic-bezier(0.16, 1, 0.3, 1);
          color: var(--text-primary);
        }

        @keyframes slideIn {
          from { opacity: 0; transform: translateY(12px) scale(0.96); }
          to { opacity: 1; transform: translateY(0) scale(1); }
        }

        /* Room Header */
        .room-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 10px 12px;
          background: linear-gradient(135deg, rgba(30, 41, 59, 0.95), rgba(15, 23, 42, 0.95));
          border-bottom: 1px solid var(--border-subtle);
        }

        .room-info {
          display: flex;
          align-items: center;
          gap: 10px;
          overflow: hidden;
        }

        .platform-icon-box {
          width: 32px;
          height: 32px;
          border-radius: 8px;
          background: rgba(99, 102, 241, 0.15);
          border: 1px solid rgba(255, 255, 255, 0.1);
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 16px;
          flex-shrink: 0;
        }

        .problem-title {
          font-size: 13px;
          font-weight: 700;
          color: var(--text-primary);
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
          max-width: 170px;
        }

        .badges-row {
          display: flex;
          align-items: center;
          gap: 6px;
          margin-top: 2px;
        }

        .platform-pill {
          font-size: 9px;
          font-weight: 700;
          padding: 1px 6px;
          border-radius: 4px;
          background: ${b}20;
          border: 1px solid ${b}50;
          color: ${b};
          text-transform: uppercase;
        }

        .peer-count-pill {
          font-size: 10px;
          color: var(--text-secondary);
          display: flex;
          align-items: center;
          gap: 4px;
        }

        .header-actions {
          display: flex;
          align-items: center;
          gap: 4px;
        }

        .icon-btn {
          background: transparent;
          border: none;
          color: var(--text-secondary);
          cursor: pointer;
          padding: 5px;
          border-radius: 6px;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: all 0.15s;
        }

        .icon-btn:hover {
          background: rgba(255, 255, 255, 0.1);
          color: #ffffff;
        }

        /* Segmented View Switcher */
        .tab-switcher {
          display: flex;
          background: rgba(15, 23, 42, 0.9);
          padding: 3px 6px;
          border-bottom: 1px solid var(--border-subtle);
          gap: 4px;
        }

        .tab-btn {
          flex: 1;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 6px;
          padding: 5px 8px;
          font-size: 11px;
          font-weight: 600;
          border-radius: 6px;
          border: none;
          cursor: pointer;
          transition: all 0.15s;
          background: transparent;
          color: var(--text-muted);
        }

        .tab-btn.active {
          background: var(--primary);
          color: #ffffff;
        }

        /* Messages List */
        .message-list {
          flex: 1;
          overflow-y: auto;
          padding: 12px;
          display: flex;
          flex-direction: column;
          gap: 10px;
        }

        .chat-bubble {
          display: flex;
          flex-direction: column;
          max-width: 86%;
          padding: 8px 12px;
          border-radius: 14px;
          font-size: 12px;
          position: relative;
          word-break: break-word;
          line-height: 1.45;
        }

        .chat-bubble.self {
          align-self: flex-end;
          background: linear-gradient(135deg, rgba(99, 102, 241, 0.28), rgba(139, 92, 246, 0.22));
          border: 1px solid rgba(99, 102, 241, 0.35);
          border-bottom-right-radius: 4px;
          color: #ffffff;
        }

        .chat-bubble.other {
          align-self: flex-start;
          background: var(--bg-surface-elevated);
          border: 1px solid var(--border-subtle);
          border-bottom-left-radius: 4px;
          color: #f1f5f9;
        }

        .chat-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 8px;
          margin-bottom: 4px;
          font-size: 11px;
        }

        .chat-author {
          font-weight: 600;
          display: flex;
          align-items: center;
          gap: 4px;
        }

        .chat-timestamp {
          color: var(--text-dim);
          font-size: 10px;
        }

        .chat-footer {
          margin-top: 3px;
          display: flex;
          align-items: center;
          justify-content: flex-end;
          font-size: 10px;
        }

        .ack-read {
          color: #38bdf8;
          font-weight: 700;
        }

        /* Whiteboard Toolbar & Canvas */
        .whiteboard-container {
          flex: 1;
          display: flex;
          flex-direction: column;
          background: #090d16;
          overflow: hidden;
          position: relative;
        }

        .wb-toolbar {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 6px 8px;
          background: rgba(15, 23, 42, 0.95);
          border-bottom: 1px solid var(--border-subtle);
          flex-wrap: wrap;
          gap: 4px;
        }

        .wb-tool-group {
          display: flex;
          gap: 3px;
          align-items: center;
        }

        .wb-tool-btn {
          padding: 4px 6px;
          border-radius: 4px;
          border: 1px solid transparent;
          background: transparent;
          color: var(--text-muted);
          cursor: pointer;
          font-size: 11px;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .wb-tool-btn.active {
          border-color: var(--primary);
          background: rgba(99, 102, 241, 0.25);
          color: #c7d2fe;
        }

        .wb-palette-bar {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 3px 8px;
          background: rgba(0, 0, 0, 0.3);
          border-bottom: 1px solid var(--border-subtle);
        }

        .color-dot {
          width: 13px;
          height: 13px;
          border-radius: 50%;
          border: 1px solid rgba(255, 255, 255, 0.2);
          cursor: pointer;
        }

        .color-dot.active {
          border: 2px solid #ffffff;
          box-shadow: 0 0 6px rgba(255, 255, 255, 0.5);
        }

        .size-pill {
          font-size: 9px;
          font-weight: 700;
          padding: 1px 4px;
          border-radius: 3px;
          background: rgba(255, 255, 255, 0.05);
          border: 1px solid transparent;
          color: var(--text-dim);
          cursor: pointer;
        }

        .size-pill.active {
          background: rgba(99, 102, 241, 0.3);
          border-color: var(--primary);
          color: #ffffff;
        }

        #nb-whiteboard-canvas {
          flex-grow: 1;
          width: 100%;
          height: 100%;
          cursor: crosshair;
          touch-action: none;
        }

        /* Input Composer */
        .composer-box {
          display: flex;
          align-items: center;
          gap: 6px;
          padding: 8px 10px;
          background: rgba(15, 23, 42, 0.95);
          border-top: 1px solid var(--border-subtle);
        }

        .input-glass {
          flex: 1;
          background: rgba(0, 0, 0, 0.4);
          border: 1px solid var(--border-subtle);
          border-radius: 8px;
          padding: 7px 10px;
          color: #ffffff;
          font-size: 11px;
          outline: none;
        }

        .input-glass:focus {
          border-color: var(--primary);
        }

        .btn-send {
          background: var(--primary);
          border: none;
          color: #ffffff;
          padding: 6px 10px;
          border-radius: 8px;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .prompt-pills-row {
          display: flex;
          gap: 4px;
          padding: 4px 8px;
          overflow-x: auto;
          background: rgba(0, 0, 0, 0.3);
          border-top: 1px solid var(--border-subtle);
        }

        .prompt-pill {
          background: rgba(255, 255, 255, 0.06);
          border: 1px solid var(--border-subtle);
          color: var(--text-secondary);
          font-size: 9px;
          font-weight: 600;
          padding: 2px 6px;
          border-radius: 4px;
          cursor: pointer;
          white-space: nowrap;
        }

        .prompt-pill:hover {
          background: rgba(99, 102, 241, 0.2);
          color: #ffffff;
        }
      </style>

      <!-- In-Page Popup Card Window -->
      <div class="popup-card" id="nb-popup-card">
        <!-- Room Header Bar -->
        <div class="room-header">
          <div class="room-info">
            <div class="platform-icon-box">⚡</div>
            <div>
              <div class="problem-title">${this.escapeHtml(e)}</div>
              <div class="badges-row">
                <span class="platform-pill">${t}</span>
                <span class="peer-count-pill" title="${this.isServerConnected?"Signaling Server: Connected (wss://synqto-server.onrender.com/ws/)":"Signaling Server: Disconnected (Offline Mode)"}">
                  <span style="display:inline-block;width:6px;height:6px;border-radius:50%;background:${this.isServerConnected?"#10b981":"#ef4444"};box-shadow:0 0 6px ${this.isServerConnected?"#10b981":"#ef4444"};"></span>
                  <span>${this.peerCount} Online ${this.isServerConnected?"":"(Offline)"}</span>
                </span>
              </div>
            </div>
          </div>

          <div class="header-actions">
            <!-- Popup Size Mode Switcher Pills -->
            <div class="popup-size-group" style="display:flex;gap:2px;align-items:center;background:rgba(0,0,0,0.35);padding:2px;border-radius:6px;border:1px solid rgba(255,255,255,0.08);margin-right:2px;">
              <button class="size-mode-pill ${this.popupSize==="compact"?"active":""}" data-popsize="compact" title="Compact Size (420x540)" style="font-size:9px;font-weight:700;padding:2px 5px;border-radius:4px;border:none;cursor:pointer;background:${this.popupSize==="compact"?"var(--primary)":"transparent"};color:${this.popupSize==="compact"?"#fff":"var(--text-muted)"};">📱 S</button>
              <button class="size-mode-pill ${this.popupSize==="medium"?"active":""}" data-popsize="medium" title="Medium Split Size (620x640)" style="font-size:9px;font-weight:700;padding:2px 5px;border-radius:4px;border:none;cursor:pointer;background:${this.popupSize==="medium"?"var(--primary)":"transparent"};color:${this.popupSize==="medium"?"#fff":"var(--text-muted)"};">🌗 M</button>
              <button class="size-mode-pill ${this.popupSize==="large"?"active":""}" data-popsize="large" title="Large Widescreen (860x740)" style="font-size:9px;font-weight:700;padding:2px 5px;border-radius:4px;border:none;cursor:pointer;background:${this.popupSize==="large"?"var(--primary)":"transparent"};color:${this.popupSize==="large"?"#fff":"var(--text-muted)"};">🖥️ L</button>
              <button class="size-mode-pill ${this.popupSize==="fullscreen"?"active":""}" data-popsize="fullscreen" title="Full Screen View (1180x880)" style="font-size:9px;font-weight:700;padding:2px 5px;border-radius:4px;border:none;cursor:pointer;background:${this.popupSize==="fullscreen"?"var(--primary)":"transparent"};color:${this.popupSize==="fullscreen"?"#fff":"var(--text-muted)"};">📺 XL</button>
            </div>

            <button class="icon-btn" id="nb-open-sidepanel" title="Open complete extension in side panel">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M15 3h6v6M10 14L21 3M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6"/>
              </svg>
            </button>
            <button class="icon-btn" id="nb-close-popup" title="Minimize">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M18 6L6 18M6 6l12 12"/>
              </svg>
            </button>
          </div>
        </div>

        <!-- Green Vanishing Toast on Server Connection Established -->
        ${this.serverToastMessage?`
          <div style="background:linear-gradient(135deg, rgba(16, 185, 129, 0.96), rgba(5, 150, 105, 0.96));color:#fff;padding:6px 10px;font-size:10.5px;font-weight:600;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid rgba(255,255,255,0.2);box-shadow:0 4px 12px rgba(16, 185, 129, 0.4);">
            <div style="display:flex;align-items:center;gap:6px;">
              <span>⚡</span>
              <span>${this.escapeHtml(this.serverToastMessage)}</span>
            </div>
            <span style="font-size:8.5px;background:rgba(0,0,0,0.25);padding:1px 5px;border-radius:3px;">P2P Active</span>
          </div>
        `:""}

        <!-- Red Offline Notice Banner when Server is Unreachable -->
        ${this.isServerConnected?"":`
          <div style="background:linear-gradient(135deg, #ef4444, #dc2626);color:#fff;padding:5px 10px;font-size:10px;font-weight:600;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid rgba(255,255,255,0.2);">
            <div style="display:flex;align-items:center;gap:5px;">
              <span>⚠️</span>
              <span>Server Offline (Local Mode)</span>
            </div>
            <button id="nb-offline-sidepanel-reconnect" style="background:rgba(0,0,0,0.3);color:#fff;border:1px solid rgba(255,255,255,0.25);padding:2px 6px;border-radius:4px;font-size:9px;font-weight:700;cursor:pointer;">
              Reconnect in Side Panel ⚡
            </button>
          </div>
        `}

        <!-- Segmented Switcher for Chat and Whiteboard -->
        <div class="tab-switcher" style="display:flex;border-bottom:1px solid var(--border-subtle);background:rgba(0,0,0,0.25);">
          <button class="tab-btn ${this.activeTab==="chat"?"active":""}" id="nb-tab-chat" style="flex:1;display:flex;align-items:center;justify-content:center;gap:5px;padding:8px 4px;font-size:11px;font-weight:600;background:transparent;border:none;border-bottom:2px solid ${this.activeTab==="chat"?"var(--primary)":"transparent"};color:${this.activeTab==="chat"?"#fff":"var(--text-muted)"};cursor:pointer;">
            <span>💬 Live Chat</span>
          </button>
          ${this.settings.enableWhiteboard?`
            <button class="tab-btn ${this.activeTab==="whiteboard"?"active":""}" id="nb-tab-whiteboard" style="flex:1;display:flex;align-items:center;justify-content:center;gap:5px;padding:8px 4px;font-size:11px;font-weight:600;background:transparent;border:none;border-bottom:2px solid ${this.activeTab==="whiteboard"?"var(--primary)":"transparent"};color:${this.activeTab==="whiteboard"?"#fff":"var(--text-muted)"};cursor:pointer;">
              <span>🎨 Whiteboard</span>
            </button>
          `:""}
        </div>

        <!-- Multi-Broadcaster Live Streams List -->
        ${o?`
          <div style="background:linear-gradient(135deg, rgba(239, 68, 68, 0.22), rgba(139, 92, 246, 0.18));border-bottom:1px solid rgba(239, 68, 68, 0.35);padding:6px 10px;display:flex;flex-direction:column;gap:5px;">
            <div style="display:flex;align-items:center;justify-content:space-between;font-size:10px;color:#fca5a5;">
              <div style="display:flex;align-items:center;gap:5px;font-weight:700;">
                <span class="live-dot"></span>
                <span>LIVE STREAMS (${this.liveStage.activeStreams&&this.liveStage.activeStreams.length||1}):</span>
              </div>
              <button id="nb-live-tunein" style="background:#ef4444;color:#fff;border:none;padding:2px 8px;border-radius:4px;font-size:9px;font-weight:700;cursor:pointer;">
                Open Side Panel 📺
              </button>
            </div>

            <div style="display:flex;gap:4px;overflow-x:auto;padding-bottom:2px;">
              ${(this.liveStage.activeStreams&&this.liveStage.activeStreams.length>0?this.liveStage.activeStreams:[{broadcasterIdentity:this.liveStage.tutorIdentity||{nickname:s,avatar:"👑"},title:`${s}'s Walkthrough`,broadcastType:this.liveStage.broadcastType||"screen"}]).map(n=>{var k,w;return`
                <div style="display:flex;align-items:center;gap:4px;padding:3px 6px;border-radius:4px;background:rgba(0,0,0,0.4);border:1px solid rgba(255,255,255,0.1);font-size:10px;color:#f8fafc;white-space:nowrap;">
                  <span>${((k=n.broadcasterIdentity)==null?void 0:k.avatar)||"👤"}</span>
                  <span style="font-weight:600;">${((w=n.broadcasterIdentity)==null?void 0:w.nickname)||"Streamer"}:</span>
                  <span style="color:#c7d2fe;max-width:110px;overflow:hidden;text-overflow:ellipsis;">${this.escapeHtml(n.title||"Live Stream")}</span>
                  <span style="font-size:8px;padding:1px 4px;border-radius:3px;background:rgba(239,68,68,0.3);color:#fca5a5;text-transform:uppercase;">${n.broadcastType||"live"}</span>
                </div>
              `}).join("")}
            </div>
          </div>
        `:""}

        <!-- Main Body: Whiteboard or Problem Chat Stream -->
        ${a?`
          <!-- Whiteboard View -->
          <div class="whiteboard-container">
            <div class="wb-toolbar">
              <div class="wb-tool-group" style="flex-wrap:wrap;gap:2px;">
                <button class="wb-tool-btn ${this.wbTool==="pen"?"active":""}" data-wbtool="pen" title="Fine Pen">✏️</button>
                <button class="wb-tool-btn ${this.wbTool==="brush"?"active":""}" data-wbtool="brush" title="Brush Pen">✒️</button>
                <button class="wb-tool-btn ${this.wbTool==="highlighter"?"active":""}" data-wbtool="highlighter" title="Highlighter">🖍️</button>
                <button class="wb-tool-btn ${this.wbTool==="temp_pen"?"active":""}" data-wbtool="temp_pen" title="⏳ Disappearing Ink (3s)">⏳</button>
                <button class="wb-tool-btn ${this.wbTool==="laser"?"active":""}" data-wbtool="laser" title="Laser Pointer">🔴</button>
                <button class="wb-tool-btn ${this.wbTool==="torch"?"active":""}" data-wbtool="torch" title="Spotlight Torch">🔦</button>
                <button class="wb-tool-btn ${this.wbTool==="eraser"?"active":""}" data-wbtool="eraser" title="Eraser">🧹</button>
                <button class="wb-tool-btn ${this.wbTool==="text"?"active":""}" data-wbtool="text" title="Text Label">T</button>

                <div style="width:1px;height:12px;background:var(--border-subtle);margin:0 1px;"></div>

                <!-- Drawer Toggles -->
                <button class="wb-drawer-toggle ${this.wbShowShapesDrawer?"active":""}" id="nb-wb-toggle-shapes" style="font-size:9px;padding:2px 4px;border-radius:4px;border:1px solid var(--border-subtle);background:${this.wbShowShapesDrawer?"rgba(99,102,241,0.25)":"transparent"};color:${this.wbShowShapesDrawer?"#fff":"var(--text-muted)"};cursor:pointer;">
                  🔷 Shapes ${this.wbShowShapesDrawer?"▲":"▼"}
                </button>

                <button class="wb-drawer-toggle ${this.wbShowDsaDrawer?"active":""}" id="nb-wb-toggle-dsa" style="font-size:9px;padding:2px 4px;border-radius:4px;border:1px solid rgba(56,189,248,0.3);background:${this.wbShowDsaDrawer?"rgba(56,189,248,0.2)":"transparent"};color:${this.wbShowDsaDrawer?"#38bdf8":"var(--text-muted)"};cursor:pointer;">
                  🔲 DSA ${this.wbShowDsaDrawer?"▲":"▼"}
                </button>

                <button class="wb-drawer-toggle ${this.wbShowArchDrawer?"active":""}" id="nb-wb-toggle-arch" style="font-size:9px;padding:2px 4px;border-radius:4px;border:1px solid var(--border-subtle);background:${this.wbShowArchDrawer?"rgba(99,102,241,0.25)":"transparent"};color:${this.wbShowArchDrawer?"#fff":"var(--text-muted)"};cursor:pointer;">
                  🏛️ Arch ${this.wbShowArchDrawer?"▲":"▼"}
                </button>

                <button class="wb-drawer-toggle ${this.wbShowPresetsDrawer?"active":""}" id="nb-wb-toggle-presets" style="font-size:9px;padding:2px 4px;border-radius:4px;border:1px solid rgba(16,185,129,0.35);background:${this.wbShowPresetsDrawer?"rgba(16,185,129,0.2)":"transparent"};color:${this.wbShowPresetsDrawer?"#34d399":"var(--text-muted)"};cursor:pointer;">
                  ⚡ Presets ${this.wbShowPresetsDrawer?"▲":"▼"}
                </button>

                <button class="wb-drawer-toggle ${this.wbShowThemesDrawer?"active":""}" id="nb-wb-toggle-themes" style="font-size:9px;padding:2px 4px;border-radius:4px;border:1px solid var(--border-subtle);background:${this.wbShowThemesDrawer?"rgba(99,102,241,0.25)":"transparent"};color:${this.wbShowThemesDrawer?"#fff":"var(--text-muted)"};cursor:pointer;">
                  🎨 Style ${this.wbShowThemesDrawer?"▲":"▼"}
                </button>
              </div>

              <!-- Right Controls -->
              <div class="wb-tool-group">
                <div style="display:flex;gap:2px;align-items:center;background:rgba(0,0,0,0.3);padding:2px 3px;border-radius:4px;">
                  <button class="wb-privacy-btn" data-wbprivacy="collaborative" style="font-size:9px;font-weight:700;padding:2px 4px;border-radius:3px;border:none;cursor:pointer;background:${this.wbPrivacyMode==="collaborative"?"var(--primary)":"transparent"};color:${this.wbPrivacyMode==="collaborative"?"#fff":"var(--text-muted)"};" title="👥 Collaborative with Room Peers">👥 Collab</button>
                  <button class="wb-privacy-btn" data-wbprivacy="personal" style="font-size:9px;font-weight:700;padding:2px 4px;border-radius:3px;border:none;cursor:pointer;background:${this.wbPrivacyMode==="personal"?"var(--primary)":"transparent"};color:${this.wbPrivacyMode==="personal"?"#fff":"var(--text-muted)"};" title="🔒 Personal Private Scratchpad">🔒 Personal</button>
                </div>
                <button class="wb-tool-btn" id="nb-wb-undo" title="Undo">↩️</button>
                <button class="wb-tool-btn" id="nb-wb-redo" title="Redo">↪️</button>
                <button class="wb-tool-btn" id="nb-wb-clear" title="Clear Canvas" style="color:#f87171;">🗑️</button>
                <button class="wb-tool-btn" id="nb-wb-save" title="Export PNG">💾</button>
                <button class="wb-tool-btn" id="nb-wb-popout" title="Open Standalone Popup Window">↗️</button>
              </div>
            </div>

            <!-- Drawer: Shapes -->
            ${this.wbShowShapesDrawer?`
              <div style="display:flex;align-items:center;gap:3px;padding:3px 6px;background:rgba(0,0,0,0.85);border-bottom:1px solid var(--border-subtle);overflow-x:auto;">
                <span style="font-size:8.5px;color:var(--text-muted);font-weight:600;">Shapes:</span>
                ${[{id:"line",label:"Line 📏"},{id:"arrow",label:"Arrow ➡️"},{id:"arrow_bi",label:"Bi-Arrow ↔️"},{id:"rect",label:"Rect 🔲"},{id:"rounded_rect",label:"Rounded ▢"},{id:"circle",label:"Circle ⭕"},{id:"triangle",label:"Triangle ▲"},{id:"star",label:"Star ⭐"},{id:"decision_diamond",label:"Diamond 💎"},{id:"sticky_note",label:"Sticky 📝"},{id:"code_box",label:"Code &lt;/&gt;"}].map(n=>`
                  <button class="wb-tool-btn ${this.wbTool===n.id?"active":""}" data-wbtool="${n.id}" style="font-size:9px;padding:2px 5px;white-space:nowrap;">${n.label}</button>
                `).join("")}
              </div>
            `:""}

            <!-- Drawer: DSA Visualizers -->
            ${this.wbShowDsaDrawer?`
              <div style="display:flex;align-items:center;gap:3px;padding:3px 6px;background:rgba(8,28,44,0.95);border-bottom:1px solid rgba(56,189,248,0.3);overflow-x:auto;">
                <span style="font-size:8.5px;color:#7dd3fc;font-weight:700;">🔲 DSA:</span>
                ${[{id:"array_cells",label:"Array [0..N]"},{id:"two_pointers",label:"Two Pointers (L/R)"},{id:"stack_lifo",label:"Stack (LIFO)"},{id:"queue_fifo",label:"Queue (FIFO)"},{id:"tree_node",label:"Tree Node"},{id:"hashmap_table",label:"HashMap Bucket"},{id:"decision_diamond",label:"Branch Diamond"},{id:"code_box",label:"Pseudocode Box"}].map(n=>`
                  <button class="wb-tool-btn ${this.wbTool===n.id?"active":""}" data-wbtool="${n.id}" style="font-size:9px;padding:2px 5px;white-space:nowrap;color:#7dd3fc;">${n.label}</button>
                `).join("")}
              </div>
            `:""}

            <!-- Drawer: Architecture Shapes -->
            ${this.wbShowArchDrawer?`
              <div style="display:flex;align-items:center;gap:3px;padding:3px 6px;background:rgba(0,0,0,0.9);border-bottom:1px solid var(--border-subtle);overflow-x:auto;">
                <span style="font-size:8.5px;color:var(--text-muted);font-weight:600;">Arch:</span>
                ${[{id:"db_cylinder",label:"SQL DB"},{id:"db_nosql",label:"NoSQL"},{id:"cache_mem",label:"Redis"},{id:"message_queue",label:"Kafka"},{id:"load_balancer",label:"LB"},{id:"server_box",label:"App Server"},{id:"cloud",label:"API GW"},{id:"cdn_edge",label:"CDN Edge"},{id:"object_storage",label:"S3 Bucket"},{id:"auth_jwt",label:"Auth Shield"},{id:"websocket_gw",label:"WS Gateway"},{id:"elasticsearch",label:"ES Search"},{id:"dns_router",label:"DNS"},{id:"firewall",label:"Firewall"},{id:"user_client",label:"Client"},{id:"mobile_client",label:"Mobile"},{id:"async_arrow",label:"Async ⇢"},{id:"tradeoff_note",label:"⚖️ CAP Card"}].map(n=>`
                  <button class="wb-tool-btn ${this.wbTool===n.id?"active":""}" data-wbtool="${n.id}" style="font-size:9px;padding:2px 5px;white-space:nowrap;">${n.label}</button>
                `).join("")}
              </div>
            `:""}

            <!-- Drawer: 1-Click Blueprints Presets -->
            ${this.wbShowPresetsDrawer?`
              <div style="display:flex;flex-direction:column;gap:3px;padding:4px 6px;background:rgba(6,44,36,0.96);border-bottom:1px solid rgba(16,185,129,0.35);">
                <div style="display:flex;gap:3px;align-items:center;">
                  <button class="wb-preset-tab-btn" data-presettab="dsa" style="font-size:9px;font-weight:700;padding:2px 6px;border-radius:3px;border:none;background:${this.wbPresetTab==="dsa"?"#10b981":"rgba(255,255,255,0.08)"};color:${this.wbPresetTab==="dsa"?"#fff":"#a7f3d0"};cursor:pointer;">🔲 DSA Presets (10)</button>
                  <button class="wb-preset-tab-btn" data-presettab="arch" style="font-size:9px;font-weight:700;padding:2px 6px;border-radius:3px;border:none;background:${this.wbPresetTab==="arch"?"#10b981":"rgba(255,255,255,0.08)"};color:${this.wbPresetTab==="arch"?"#fff":"#a7f3d0"};cursor:pointer;">🏛️ System Design (8)</button>
                </div>
                <div style="display:flex;gap:3px;overflow-x:auto;padding-bottom:2px;">
                  ${this.wbPresetTab==="dsa"?[{id:"two_pointers",label:"👆 Two Pointers"},{id:"bst",label:"🌲 BST Tree"},{id:"floyd_cycle",label:"🐢 Floyd Cycle"},{id:"mono_stack",label:"📥 Monotonic Stack"},{id:"dp_table",label:"📊 2D DP Table"},{id:"trie",label:"🌳 Prefix Trie"},{id:"graph_bfs",label:"🔵 Graph BFS"},{id:"min_heap",label:"🏔️ Min-Heap"},{id:"intervals",label:"📏 Intervals"},{id:"recursion_tree",label:"🌿 Recursion"}].map(n=>`
                    <button class="wb-stamp-preset-btn" data-preset="${n.id}" style="font-size:9px;padding:2px 5px;border-radius:3px;background:rgba(16,185,129,0.25);border:1px solid rgba(16,185,129,0.4);color:#fff;cursor:pointer;white-space:nowrap;">${n.label}</button>
                  `).join(""):[{id:"url_shortener",label:"🔗 TinyURL"},{id:"rate_limiter",label:"🚦 Rate Limiter"},{id:"chat_system",label:"💬 Chat System"},{id:"distributed_cache",label:"⚡ Dist. Cache"},{id:"ecommerce_saga",label:"🛒 Order Saga"},{id:"web_crawler",label:"🕷️ Web Crawler"},{id:"microservices_3tier",label:"🏛️ 3-Tier App"},{id:"search_analytics",label:"🔍 ES Cluster"}].map(n=>`
                    <button class="wb-stamp-preset-btn" data-preset="${n.id}" style="font-size:9px;padding:2px 5px;border-radius:3px;background:rgba(16,185,129,0.25);border:1px solid rgba(16,185,129,0.4);color:#fff;cursor:pointer;white-space:nowrap;">${n.label}</button>
                  `).join("")}
                </div>
              </div>
            `:""}

            <!-- Drawer: Style & Themes -->
            ${this.wbShowThemesDrawer?`
              <div class="wb-palette-bar" style="flex-wrap:wrap;gap:4px;">
                <div style="display:flex;gap:2px;align-items:center;overflow-x:auto;">
                  <button class="size-pill ${this.wbTheme==="grid"?"active":""}" data-wbtheme="grid">⬛ Grid</button>
                  <button class="size-pill ${this.wbTheme==="isometric"?"active":""}" data-wbtheme="isometric">📐 3D Iso</button>
                  <button class="size-pill ${this.wbTheme==="ruled"?"active":""}" data-wbtheme="ruled">📏 Ruled</button>
                  <button class="size-pill ${this.wbTheme==="plot"?"active":""}" data-wbtheme="plot">📈 Plot</button>
                  <button class="size-pill ${this.wbTheme==="matrix"?"active":""}" data-wbtheme="matrix">📊 Matrix</button>
                  <button class="size-pill ${this.wbTheme==="dotted"?"active":""}" data-wbtheme="dotted">🟦 Dots</button>
                  <button class="size-pill ${this.wbTheme==="blank"?"active":""}" data-wbtheme="blank">Blank</button>
                </div>

                <div style="display:flex;gap:3px;align-items:center;">
                  ${["#090d16","#0f172a","#062c24","#fef3c7","#ffffff","#1e1035"].map(n=>`
                    <div class="bg-dot" data-wbbg="${n}" style="width:10px;height:10px;border-radius:2px;background:${n};border:${this.wbBgColor===n?"2px solid #6366f1":"1px solid rgba(255,255,255,0.2)"};cursor:pointer;" title="Background Color"></div>
                  `).join("")}
                </div>

                <div style="display:flex;gap:4px;align-items:center;">
                  ${["#6366f1","#06b6d4","#10b981","#f59e0b","#f43f5e","#ffffff"].map(n=>`
                    <div class="color-dot ${this.wbColor===n?"active":""}" data-color="${n}" style="background:${n};"></div>
                  `).join("")}
                </div>

                <div style="display:flex;gap:2px;align-items:center;">
                  <button class="size-pill ${this.wbWidth===2?"active":""}" data-size="2">S</button>
                  <button class="size-pill ${this.wbWidth===4?"active":""}" data-size="4">M</button>
                  <button class="size-pill ${this.wbWidth===8?"active":""}" data-size="8">L</button>
                </div>
              </div>
            `:""}

            <!-- HTML5 Interactive Canvas -->
            <canvas id="nb-whiteboard-canvas"></canvas>
          </div>
        `:`
          <!-- Chat Messages View -->
          <div class="message-list" id="nb-messages">
            ${this.messages.length===0?`
              <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:100%;color:var(--text-muted);gap:8px;padding:30px 10px;text-align:center;">
                <div style="font-size:28px;">💬</div>
                <div style="font-size:13px;font-weight:600;color:var(--text-secondary);">No messages yet</div>
                <div style="font-size:11px;max-width:220px;">Say hello or ask for a hint! Messages are synchronized P2P across all peers.</div>
              </div>
            `:this.messages.map((n,k)=>{var w,P,E,l;return`
              <div class="chat-bubble ${n.isSelf?"self":"other"}">
                ${n.replyPreview?`<div style="border-left:2px solid var(--primary);padding-left:6px;margin-bottom:4px;font-size:10px;color:var(--text-muted);">${this.escapeHtml(n.replyPreview)}</div>`:""}
                
                <div class="chat-header">
                  <div class="chat-author">
                    <span>${((w=n.from)==null?void 0:w.avatar)||"👤"}</span>
                    <span style="color:${n.isSelf?"#ffffff":((P=n.from)==null?void 0:P.color)||"#a5b4fc"}">
                      ${n.isSelf?"You":((E=n.from)==null?void 0:E.nickname)||"Buddy"}
                    </span>
                  </div>
                  <div style="display:flex;align-items:center;gap:4px;">
                    <span class="chat-timestamp">${this.formatTimestamp(n.timestamp)}</span>
                    <button class="icon-btn nb-reply-trigger" data-id="${n.id}" data-text="${this.escapeHtml(n.text.slice(0,35))}" data-nick="${this.escapeHtml(((l=n.from)==null?void 0:l.nickname)||"Buddy")}" style="padding:0;width:18px;height:18px;" title="Reply">
                      ↩
                    </button>
                  </div>
                </div>

                <div class="chat-body">${this.renderFormattedText(n.text,k,n)}</div>

                ${n.isSelf?`
                  <div class="chat-footer">
                    ${n.status==="pending"?"<span>⏳</span>":""}
                    ${n.status==="sent"?'<span style="color:var(--text-dim);">✓</span>':""}
                    ${n.status==="delivered"?'<span style="color:var(--text-secondary);">✓✓</span>':""}
                    ${n.status==="read"?'<span class="ack-read">✓✓</span>':""}
                  </div>
                `:""}
              </div>
            `}).join("")}
          </div>

          <!-- Quick Strategy Prompt Pills -->
          <div class="prompt-pills-row">
            <button class="prompt-pill" data-text="⚡ O(N) Time">⚡ O(N) Time</button>
            <button class="prompt-pill" data-text="💾 O(1) Space">💾 O(1) Space</button>
            <button class="prompt-pill" data-text="👉 Two Pointers">👉 Two Pointers</button>
            <button class="prompt-pill" data-text="🔍 Binary Search">🔍 Binary Search</button>
            <button class="prompt-pill" data-text="🧠 DP / Memo">🧠 DP / Memo</button>
            <button class="prompt-pill" data-text="💡 Sliding Window">💡 Sliding Window</button>
          </div>

          <!-- Input Box & Composer -->
          <form class="composer-box" id="nb-composer">
            <button type="button" class="icon-btn" id="nb-spoiler-insert" title="Insert Spoiler Blur ||text||" style="width:28px;height:28px;flex-shrink:0;">
              👁️
            </button>
            <input type="text" class="input-glass" id="nb-input" placeholder="Type a hint, code snippet, or ||spoiler||..." />
            <button type="submit" class="btn-send">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <line x1="22" y1="2" x2="11" y2="13"></line>
                <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
              </svg>
            </button>
          </form>
        `}
      </div>

      <!-- Dedicated Standalone Focus Timer & Pomodoro Popup Window -->
      <div class="timer-popup-card" id="nb-timer-popup-card">
        <!-- Timer Header Bar -->
        <div style="display:flex;align-items:center;justify-content:space-between;padding:10px 14px;border-bottom:1px solid rgba(255,255,255,0.08);background:linear-gradient(135deg, rgba(30, 16, 53, 0.95), rgba(15, 23, 42, 0.95));">
          <div style="display:flex;align-items:center;gap:7px;">
            <span style="font-size:16px;">🍅</span>
            <div>
              <div style="font-size:12px;font-weight:700;color:#ffffff;line-height:1.2;">Focus Timer & Pomodoro</div>
              <div style="font-size:9.5px;color:#fca5a5;font-weight:600;text-transform:uppercase;">
                ${this.timerState.mode==="pomodoro"?"Deep Focus Session":this.timerState.mode==="short_break"?"Short Refresh Break":this.timerState.mode==="long_break"?"Extended Rest":"Open Stopwatch"}
              </div>
            </div>
          </div>
          <button class="icon-btn" id="nb-close-timer-popup" title="Minimize Timer" style="width:24px;height:24px;border-radius:6px;background:rgba(255,255,255,0.06);border:none;color:#94a3b8;cursor:pointer;display:flex;align-items:center;justify-content:center;">
            ✕
          </button>
        </div>

        <!-- Timer Body -->
        <div style="padding:16px 14px;display:flex;flex-direction:column;gap:14px;align-items:center;">
          <!-- Mode Switcher Pills -->
          <div style="display:flex;gap:4px;background:rgba(0,0,0,0.4);padding:3px;border-radius:8px;border:1px solid rgba(255,255,255,0.08);width:100%;justify-content:space-between;">
            <button class="timer-mode-btn ${this.timerState.mode==="pomodoro"?"active":""}" data-tmode="pomodoro" style="flex:1;font-size:10px;font-weight:700;padding:6px 2px;border-radius:6px;border:none;cursor:pointer;background:${this.timerState.mode==="pomodoro"?"#f43f5e":"transparent"};color:${this.timerState.mode==="pomodoro"?"#fff":"var(--text-muted)"};">🍅 Focus</button>
            <button class="timer-mode-btn ${this.timerState.mode==="short_break"?"active":""}" data-tmode="short_break" style="flex:1;font-size:10px;font-weight:700;padding:6px 2px;border-radius:6px;border:none;cursor:pointer;background:${this.timerState.mode==="short_break"?"#10b981":"transparent"};color:${this.timerState.mode==="short_break"?"#fff":"var(--text-muted)"};">☕ Break</button>
            <button class="timer-mode-btn ${this.timerState.mode==="long_break"?"active":""}" data-tmode="long_break" style="flex:1;font-size:10px;font-weight:700;padding:6px 2px;border-radius:6px;border:none;cursor:pointer;background:${this.timerState.mode==="long_break"?"#06b6d4":"transparent"};color:${this.timerState.mode==="long_break"?"#fff":"var(--text-muted)"};">🌴 Long</button>
            <button class="timer-mode-btn ${this.timerState.mode==="stopwatch"?"active":""}" data-tmode="stopwatch" style="flex:1;font-size:10px;font-weight:700;padding:6px 2px;border-radius:6px;border:none;cursor:pointer;background:${this.timerState.mode==="stopwatch"?"#8b5cf6":"transparent"};color:${this.timerState.mode==="stopwatch"?"#fff":"var(--text-muted)"};">⏱️ Clock</button>
          </div>

          <!-- Digital Clock Display & Rocket Racing Track -->
          <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;width:100%;padding:18px 12px;background:rgba(255,255,255,0.02);border:1px solid ${this.timerState.isRunning?this.timerState.mode==="pomodoro"?"#f43f5e50":this.timerState.mode==="short_break"?"#10b98150":this.timerState.mode==="long_break"?"#06b6d450":"#8b5cf650":"rgba(255,255,255,0.08)"};border-radius:14px;box-shadow:${this.timerState.isRunning?"0 10px 30px -10px rgba(0,0,0,0.8)":"none"};position:relative;overflow:hidden;box-sizing:border-box;">
            
            <!-- 🚀 Rocket Racing Progress Track -->
            <div style="width:100%;height:8px;background:rgba(255,255,255,0.08);position:relative;overflow:hidden;border-radius:4px;">
              <div id="nb-timer-progress-fill" style="height:100%;width:${this.getTimerProgressPct()}%;background:linear-gradient(90deg, #6366f1, ${this.timerState.mode==="pomodoro"?"#f43f5e":this.timerState.mode==="short_break"?"#10b981":this.timerState.mode==="long_break"?"#06b6d4":"#8b5cf6"});transition:width 0.4s ease;box-shadow:${this.timerState.isRunning?"0 0 10px rgba(244,63,94,0.8)":"none"};"></div>
              <div style="position:absolute;top:-4px;left:calc(${Math.min(94,Math.max(2,this.getTimerProgressPct()))}% - 8px);font-size:11px;pointer-events:none;transition:left 0.4s ease;">
                <span style="display:inline-block;animation:${this.timerState.isRunning?"rocketThrust 0.8s ease-in-out infinite alternate":"none"};">🚀</span>
              </div>
            </div>

            <div id="nb-timer-time" style="font-family:var(--font-mono);font-size:42px;font-weight:800;color:#ffffff;letter-spacing:-1px;line-height:1;margin-top:12px;">
              ${this.formatTimerTime(this.timerState.timeLeftSec)}
            </div>

            <!-- Racing Track Waypoints -->
            <div style="display:flex;justify-content:space-between;width:100%;font-size:9px;color:var(--text-muted);margin-top:8px;padding:0 2px;">
              <span>🛫 Launchpad</span>
              <span style="font-weight:700;color:#fca5a5;">${Math.round(this.getTimerProgressPct())}% Completed</span>
              <span>🏁 Goal</span>
            </div>

            ${this.timerState.sessionsCompleted>0?`
              <div style="display:flex;align-items:center;gap:4px;margin-top:8px;font-size:10px;padding:2px 8px;border-radius:10px;background:rgba(244,63,94,0.15);color:#f43f5e;font-weight:600;">
                <span>🎯</span>
                <span>${this.timerState.sessionsCompleted} Sessions Done</span>
              </div>
            `:""}
          </div>

          <!-- Timer Action Buttons -->
          <div style="display:flex;align-items:center;gap:8px;width:100%;">
            <button id="nb-timer-toggle" style="flex:2;display:flex;align-items:center;justify-content:center;gap:6px;padding:10px;border-radius:8px;border:none;background:${this.timerState.isRunning?"#ef4444":"linear-gradient(135deg, #4f46e5, #7c3aed)"};color:#ffffff;font-size:12px;font-weight:700;cursor:pointer;box-shadow:0 4px 15px rgba(99,102,241,0.4);">
              <span>${this.timerState.isRunning?"⏸ Pause":"▶ Start Focus"}</span>
            </button>
            <button id="nb-timer-add-1m" style="flex:1;padding:10px 4px;border-radius:8px;border:1px solid rgba(255,255,255,0.1);background:rgba(255,255,255,0.06);color:#f8fafc;font-size:11px;font-weight:600;cursor:pointer;" title="Add 1 minute">+1m</button>
            <button id="nb-timer-add-5m" style="flex:1;padding:10px 4px;border-radius:8px;border:1px solid rgba(255,255,255,0.1);background:rgba(255,255,255,0.06);color:#f8fafc;font-size:11px;font-weight:600;cursor:pointer;" title="Add 5 minutes">+5m</button>
            <button id="nb-timer-reset" style="padding:10px 12px;border-radius:8px;border:1px solid rgba(255,255,255,0.1);background:rgba(255,255,255,0.06);color:#f8fafc;font-size:12px;font-weight:600;cursor:pointer;" title="Reset Timer">🔄</button>
          </div>
        </div>
      </div>

      <!-- FAB Controls Row: Standalone Rocket Racing Timer FAB + Main Synqto FAB -->
      <div class="fab-row" style="display:flex;align-items:center;gap:8px;position:relative;">
        <!-- 1. Separate Standalone Rocket Racing Focus Timer FAB (Shown when timer is on/enabled) -->
        ${this.timerConfig.enabled||this.timerState.isRunning?`
          <button class="timer-fab-button" id="nb-timer-fab-trigger" title="Focus Timer (Click to open, click play icon to toggle)">
            <span style="font-size:13px;">${this.timerState.mode==="pomodoro"?"🍅":this.timerState.mode==="short_break"?"☕":this.timerState.mode==="long_break"?"🌴":"⏱️"}</span>
            <span class="timer-fab-rocket" style="animation:${this.timerState.isRunning?"rocketThrust 0.8s ease-in-out infinite alternate":"none"};">🚀</span>
            ${this.timerState.isRunning?'<span style="font-size:10px;margin-left:-5px;animation:flameFlicker 0.3s ease-in-out infinite alternate;">🔥</span>':""}
            <div class="timer-fab-track">
              <div id="nb-timer-fab-fill" class="timer-fab-fill" style="width:${this.getTimerProgressPct()}%;"></div>
            </div>
            <span id="nb-timer-fab-time" style="font-family:var(--font-mono);font-size:11px;font-weight:800;color:#ffffff;min-width:38px;">
              ${this.formatTimerTime(this.timerState.timeLeftSec)}
            </span>
            <span id="nb-timer-fab-toggle-btn" style="display:inline-flex;align-items:center;justify-content:center;width:22px;height:22px;border-radius:50%;background:${this.timerState.isRunning?"#ef4444":"rgba(255,255,255,0.15)"};color:#ffffff;font-size:9px;margin-left:2px;cursor:pointer;box-shadow:0 2px 6px rgba(0,0,0,0.3);" title="${this.timerState.isRunning?"Pause Timer":"Start Timer"}">
              ${this.timerState.isRunning?"⏸":"▶"}
            </span>
          </button>
        `:""}

        <!-- 2. Main Synqto App FAB -->
        <button class="fab-button" id="nb-fab-trigger" title="Drag anywhere or click to open Synqto">
          <span class="drag-grip">⠿</span>
          ${o?'<span class="live-dot"></span>':`<span>${c}</span>`}
          <span>${r}</span>
          ${this.unreadCount>0?`<span class="fab-badge">${this.unreadCount}</span>`:""}
        </button>
      </div>
    `,this.attachEventListeners(),a&&this.initWhiteboardCanvas()}attachEventListeners(){if(!this.shadow)return;const i=this.shadow.getElementById("nb-fab-trigger");if(i){let l=0,d=0,_=24,M=24;const h=x=>{if(!this.isDragging)return;const C="touches"in x?x.touches[0].clientX:x.clientX,$="touches"in x?x.touches[0].clientY:x.clientY,L=C-l,D=$-d;if(Math.hypot(L,D)>4){this.dragMoved=!0;const I=_-L,U=M-D;this.currentPosition={right:Math.max(10,Math.min(window.innerWidth-130,I)),bottom:Math.max(10,Math.min(window.innerHeight-55,U))},this.applyHostPosition()}},f=()=>{var x;if(this.isDragging&&(this.isDragging=!1,window.removeEventListener("mousemove",h),window.removeEventListener("mouseup",f),window.removeEventListener("touchmove",h),window.removeEventListener("touchend",f),this.dragMoved)){if(this.settings.positionMode==="permanent"){const C={...this.settings,savedPosition:{...this.currentPosition}};this.settings=C,typeof chrome<"u"&&((x=chrome.storage)!=null&&x.local)&&chrome.storage.local.set({[A]:C})}setTimeout(()=>{this.dragMoved=!1},60)}},u=x=>{this.isDragging=!0,this.dragMoved=!1,l="touches"in x?x.touches[0].clientX:x.clientX,d="touches"in x?x.touches[0].clientY:x.clientY,_=this.currentPosition.right,M=this.currentPosition.bottom,window.addEventListener("mousemove",h,{passive:!0}),window.addEventListener("mouseup",f),window.addEventListener("touchmove",h,{passive:!0}),window.addEventListener("touchend",f)};i.addEventListener("mousedown",u),i.addEventListener("touchstart",u,{passive:!0}),i.addEventListener("click",()=>{var x;if(!this.dragMoved){if(this.settings.clickAction==="open_extension"){typeof chrome<"u"&&((x=chrome.runtime)!=null&&x.sendMessage)&&chrome.runtime.sendMessage({type:"OPEN_SIDEPANEL"}).catch(()=>{});return}this.isOpen=!this.isOpen,this.unreadCount=0,this.render(),this.isOpen&&this.activeTab==="chat"&&this.scrollToBottom()}})}const o=this.shadow.getElementById("nb-timer-fab-trigger"),s=this.shadow.getElementById("nb-timer-fab-toggle-btn");s==null||s.addEventListener("click",l=>{l.stopPropagation(),this.toggleTimer()}),o==null||o.addEventListener("click",()=>{this.isTimerOpen=!this.isTimerOpen,this.render()});const e=this.shadow.getElementById("nb-close-timer-popup");e==null||e.addEventListener("click",()=>{this.isTimerOpen=!1,this.render()}),this.shadow.querySelectorAll(".size-mode-pill[data-popsize]").forEach(l=>{l.addEventListener("click",d=>{const _=d.currentTarget.getAttribute("data-popsize");_&&(this.popupSize=_,this.render())})});const b=this.shadow.getElementById("nb-close-popup");b==null||b.addEventListener("click",()=>{this.isOpen=!1,this.render()});const a=this.shadow.getElementById("nb-open-sidepanel");a==null||a.addEventListener("click",()=>{var l;this.isOpen=!1,this.render(),typeof chrome<"u"&&((l=chrome.runtime)!=null&&l.sendMessage)&&chrome.runtime.sendMessage({type:"OPEN_SIDEPANEL"}).catch(()=>{})});const c=this.shadow.getElementById("nb-tab-chat");c==null||c.addEventListener("click",()=>{this.activeTab="chat",this.render(),this.scrollToBottom()});const r=this.shadow.getElementById("nb-tab-whiteboard");r==null||r.addEventListener("click",()=>{this.activeTab="whiteboard",this.render()});const m=this.shadow.getElementById("nb-timer-toggle");m==null||m.addEventListener("click",()=>{this.toggleTimer()});const g=this.shadow.getElementById("nb-timer-reset");g==null||g.addEventListener("click",()=>{this.resetTimer()});const S=this.shadow.getElementById("nb-timer-add-1m");S==null||S.addEventListener("click",()=>{this.addTimerTime(60)});const y=this.shadow.getElementById("nb-timer-add-5m");y==null||y.addEventListener("click",()=>{this.addTimerTime(300)}),this.shadow.querySelectorAll(".timer-mode-btn[data-tmode]").forEach(l=>{l.addEventListener("click",d=>{const _=d.currentTarget.getAttribute("data-tmode");_&&this.setTimerMode(_)})});const p=this.shadow.getElementById("nb-live-tunein");p==null||p.addEventListener("click",()=>{var l;this.isOpen=!1,this.render(),typeof chrome<"u"&&((l=chrome.runtime)!=null&&l.sendMessage)&&chrome.runtime.sendMessage({type:"OPEN_SIDEPANEL"}).catch(()=>{})});const n=this.shadow.getElementById("nb-offline-sidepanel-reconnect");n==null||n.addEventListener("click",()=>{var l;this.isOpen=!1,this.render(),typeof chrome<"u"&&((l=chrome.runtime)!=null&&l.sendMessage)&&chrome.runtime.sendMessage({type:"OPEN_SIDEPANEL"}).catch(()=>{})}),this.shadow.querySelectorAll(".prompt-pill").forEach(l=>{l.addEventListener("click",d=>{const _=d.target.getAttribute("data-text");_&&this.sendMessage(_)})});const w=this.shadow.getElementById("nb-spoiler-insert"),P=this.shadow.getElementById("nb-input");if(w==null||w.addEventListener("click",()=>{P&&(P.value=`${P.value}||hint solution||`,P.focus())}),P){const l=d=>d.stopPropagation();P.addEventListener("keydown",l),P.addEventListener("keyup",l),P.addEventListener("keypress",l)}const E=this.shadow.getElementById("nb-composer");E==null||E.addEventListener("submit",l=>{l.preventDefault();const d=P==null?void 0:P.value.trim();d&&(this.sendMessage(d,this.replyingTo?{id:this.replyingTo.id,preview:`${this.replyingTo.from.nickname}: ${this.replyingTo.text.slice(0,30)}`}:void 0),P&&(P.value=""),this.replyingTo=null)})}initWhiteboardCanvas(){var p,n,k,w,P,E,l,d,_,M;if(!this.shadow)return;const i=this.shadow.getElementById("nb-whiteboard-canvas");if(!i)return;this.shadow.querySelectorAll(".wb-tool-btn[data-wbtool]").forEach(h=>{h.addEventListener("click",f=>{const u=f.currentTarget.getAttribute("data-wbtool");if(u){this.wbTool=u;const x=this.toolStyles[u]||{color:"#6366f1",width:3};this.wbColor=x.color,this.wbWidth=x.width,this.render()}})});const s=h=>{this.wbShowShapesDrawer=h==="shapes"?!this.wbShowShapesDrawer:!1,this.wbShowDsaDrawer=h==="dsa"?!this.wbShowDsaDrawer:!1,this.wbShowArchDrawer=h==="arch"?!this.wbShowArchDrawer:!1,this.wbShowPresetsDrawer=h==="presets"?!this.wbShowPresetsDrawer:!1,this.wbShowThemesDrawer=h==="themes"?!this.wbShowThemesDrawer:!1,this.render()};(p=this.shadow.getElementById("nb-wb-toggle-shapes"))==null||p.addEventListener("click",()=>s("shapes")),(n=this.shadow.getElementById("nb-wb-toggle-dsa"))==null||n.addEventListener("click",()=>s("dsa")),(k=this.shadow.getElementById("nb-wb-toggle-arch"))==null||k.addEventListener("click",()=>s("arch")),(w=this.shadow.getElementById("nb-wb-toggle-presets"))==null||w.addEventListener("click",()=>s("presets")),(P=this.shadow.getElementById("nb-wb-toggle-themes"))==null||P.addEventListener("click",()=>s("themes")),this.shadow.querySelectorAll(".wb-preset-tab-btn[data-presettab]").forEach(h=>{h.addEventListener("click",f=>{const u=f.currentTarget.getAttribute("data-presettab");u&&(this.wbPresetTab=u,this.render())})}),this.shadow.querySelectorAll(".wb-stamp-preset-btn[data-preset]").forEach(h=>{h.addEventListener("click",f=>{const u=f.currentTarget.getAttribute("data-preset");u&&this.handleStampPreset(u)})}),(E=this.shadow.getElementById("nb-wb-popout"))==null||E.addEventListener("click",()=>{var h,f;typeof chrome<"u"&&((h=chrome.windows)!=null&&h.create)?chrome.windows.create({url:chrome.runtime.getURL("sidepanel.html?view=whiteboard"),type:"popup",width:900,height:650}):typeof chrome<"u"&&((f=chrome.runtime)!=null&&f.sendMessage)&&chrome.runtime.sendMessage({type:"OPEN_STANDALONE_WHITEBOARD"}).catch(()=>{})}),this.shadow.querySelectorAll(".wb-privacy-btn[data-wbprivacy]").forEach(h=>{h.addEventListener("click",f=>{const u=f.currentTarget.getAttribute("data-wbprivacy");u&&(this.wbPrivacyMode=u,this.render())})}),this.shadow.querySelectorAll(".size-pill[data-wbtheme]").forEach(h=>{h.addEventListener("click",f=>{var x;const u=f.currentTarget.getAttribute("data-wbtheme");u&&(this.wbTheme=u,u==="clean_white"&&this.wbColor==="#ffffff"&&(this.wbColor="#0f172a"),typeof chrome<"u"&&((x=chrome.runtime)!=null&&x.sendMessage)&&this.wbPrivacyMode==="collaborative"&&chrome.runtime.sendMessage({type:"WHITEBOARD_BG_LOCAL",background:u,bgColor:this.wbBgColor}).catch(()=>{}),this.render())})}),this.shadow.querySelectorAll(".bg-dot[data-wbbg]").forEach(h=>{h.addEventListener("click",f=>{var x;const u=f.currentTarget.getAttribute("data-wbbg");u&&(this.wbBgColor=u,typeof chrome<"u"&&((x=chrome.runtime)!=null&&x.sendMessage)&&this.wbPrivacyMode==="collaborative"&&chrome.runtime.sendMessage({type:"WHITEBOARD_BG_LOCAL",background:this.wbTheme,bgColor:u}).catch(()=>{}),this.render())})}),this.shadow.querySelectorAll(".color-dot").forEach(h=>{h.addEventListener("click",f=>{const u=f.currentTarget.getAttribute("data-color");u&&(this.wbColor=u,this.toolStyles[this.wbTool]&&(this.toolStyles[this.wbTool].color=u),this.render())})}),this.shadow.querySelectorAll(".size-pill[data-size]").forEach(h=>{h.addEventListener("click",f=>{const u=Number(f.currentTarget.getAttribute("data-size"));u&&(this.wbWidth=u,this.toolStyles[this.wbTool]&&(this.toolStyles[this.wbTool].width=u),this.render())})}),(l=this.shadow.getElementById("nb-wb-undo"))==null||l.addEventListener("click",()=>{var f;const h=this.wbPrivacyMode==="personal"?this.wbPersonalStrokes:this.wbStrokes;if(h.length===0&&this.wbRedoStack.length>0){this.wbPrivacyMode==="personal"?this.wbPersonalStrokes=[...this.wbRedoStack]:(this.wbStrokes=[...this.wbRedoStack],this.wbStrokes.forEach(u=>{var x;typeof chrome<"u"&&((x=chrome.runtime)!=null&&x.sendMessage)&&chrome.runtime.sendMessage({type:"WHITEBOARD_STROKE_LOCAL",stroke:u}).catch(()=>{})})),this.wbRedoStack=[],this.drawWbCanvas();return}if(h.length>0){const u=h.pop();u&&(this.wbRedoStack.push(u),this.drawWbCanvas(),this.wbPrivacyMode==="collaborative"&&typeof chrome<"u"&&((f=chrome.runtime)!=null&&f.sendMessage)&&chrome.runtime.sendMessage({type:"WHITEBOARD_UNDO_LOCAL",strokeId:u.id}).catch(()=>{}))}}),(d=this.shadow.getElementById("nb-wb-redo"))==null||d.addEventListener("click",()=>{var h;if(this.wbRedoStack.length>0){const f=this.wbRedoStack.pop();f&&((this.wbPrivacyMode==="personal"?this.wbPersonalStrokes:this.wbStrokes).push(f),this.drawWbCanvas(),this.wbPrivacyMode==="collaborative"&&typeof chrome<"u"&&((h=chrome.runtime)!=null&&h.sendMessage)&&chrome.runtime.sendMessage({type:"WHITEBOARD_STROKE_LOCAL",stroke:f}).catch(()=>{}))}}),(_=this.shadow.getElementById("nb-wb-clear"))==null||_.addEventListener("click",()=>{var f;const h=this.wbPrivacyMode==="personal"?this.wbPersonalStrokes:this.wbStrokes;h.length!==0&&(this.wbRedoStack=[...h],this.wbPrivacyMode==="personal"?this.wbPersonalStrokes=[]:(this.wbStrokes=[],typeof chrome<"u"&&((f=chrome.runtime)!=null&&f.sendMessage)&&chrome.runtime.sendMessage({type:"WHITEBOARD_CLEAR_LOCAL"}).catch(()=>{})),this.drawWbCanvas())}),(M=this.shadow.getElementById("nb-wb-save"))==null||M.addEventListener("click",()=>{const h=i.toDataURL("image/png"),f=document.createElement("a");f.download=`synqto-whiteboard-${Date.now()}.png`,f.href=h,f.click()}),setTimeout(()=>{const h=i.getBoundingClientRect(),f=window.devicePixelRatio||1;i.width=(h.width||380)*f,i.height=(h.height||360)*f;const u=i.getContext("2d");u&&u.scale(f,f),this.drawWbCanvas()},30);const g=h=>{const f=i.getBoundingClientRect();let u=0,x=0;return"touches"in h&&h.touches.length>0?(u=h.touches[0].clientX,x=h.touches[0].clientY):"clientX"in h&&(u=h.clientX,x=h.clientY),{x:u-f.left,y:x-f.top}},S=h=>["line","arrow","arrow_bi","rect","rounded_rect","circle","triangle","star","decision_diamond","tree_node","sticky_note","text","code_box","db_cylinder","db_nosql","cloud","cdn_edge","object_storage","auth_jwt","websocket_gw","elasticsearch","load_balancer","message_queue","server_box","cache_mem","dns_router","firewall","user_client","mobile_client","async_arrow","tradeoff_note","array_cells","two_pointers","stack_lifo","queue_fifo","hashmap_table"].includes(h),y=(h,f,u)=>{if(h.geometry){const{x1:x,y1:C,x2:$,y2:L}=h.geometry,D=Math.min(x,$)-u,I=Math.max(x,$)+u,U=Math.min(C,L)-u,te=Math.max(C,L)+u;return f.x>=D&&f.x<=I&&f.y>=U&&f.y<=te}if(h.points&&h.points.length>0){const x=u+h.width/2;return h.points.some(C=>Math.hypot(C.x-f.x,C.y-f.y)<=x)}return!1};i.addEventListener("mousedown",h=>{const f=g(h);if(this.wbTool==="eraser"){this.isWbDrawing=!0,this.wbEraserPos=f;const u=(this.wbWidth||4)*3,x=this.wbPrivacyMode==="personal"?this.wbPersonalStrokes:this.wbStrokes,C=x.filter($=>!y($,f,u));if(C.length!==x.length){const $=x.filter(L=>y(L,f,u));this.wbRedoStack.push(...$),this.wbPrivacyMode==="personal"?this.wbPersonalStrokes=C:(this.wbStrokes=C,$.forEach(L=>{var D;typeof chrome<"u"&&((D=chrome.runtime)!=null&&D.sendMessage)&&chrome.runtime.sendMessage({type:"WHITEBOARD_UNDO_LOCAL",strokeId:L.id}).catch(()=>{})}))}this.drawWbCanvas();return}if(this.wbTool==="laser"){this.wbLaserTrails.push({x:f.x,y:f.y,alpha:1,timestamp:Date.now()}),this.drawWbCanvas();return}if(this.wbTool==="torch"){this.wbTorchPos=f,this.drawWbCanvas();return}this.isWbDrawing=!0,this.wbStartPoint=f,this.wbCurrentPoints=[f]}),i.addEventListener("mousemove",h=>{const f=g(h);if(this.wbTool==="eraser"){if(this.wbEraserPos=f,this.isWbDrawing){const x=(this.wbWidth||4)*3,C=this.wbPrivacyMode==="personal"?this.wbPersonalStrokes:this.wbStrokes,$=C.filter(L=>!y(L,f,x));if($.length!==C.length){const L=C.filter(D=>y(D,f,x));this.wbRedoStack.push(...L),this.wbPrivacyMode==="personal"?this.wbPersonalStrokes=$:(this.wbStrokes=$,L.forEach(D=>{var I;typeof chrome<"u"&&((I=chrome.runtime)!=null&&I.sendMessage)&&chrome.runtime.sendMessage({type:"WHITEBOARD_UNDO_LOCAL",strokeId:D.id}).catch(()=>{})}))}}this.drawWbCanvas();return}if(this.wbTool==="laser"){this.wbLaserTrails.push({x:f.x,y:f.y,alpha:1,timestamp:Date.now()}),this.drawWbCanvas();return}if(this.wbTool==="torch"){this.wbTorchPos=f,this.drawWbCanvas();return}if(!this.isWbDrawing)return;S(this.wbTool)&&this.wbStartPoint?this.drawWbCanvas(void 0,{x1:this.wbStartPoint.x,y1:this.wbStartPoint.y,x2:f.x,y2:f.y}):(this.wbCurrentPoints.push(f),this.drawWbCanvas(this.wbCurrentPoints))});const v=h=>{var $;if(this.wbTool==="eraser"){this.isWbDrawing=!1,this.wbEraserPos=null,this.drawWbCanvas();return}if(this.wbTool==="torch"){this.wbTorchPos=null,this.drawWbCanvas();return}if(!this.isWbDrawing)return;this.isWbDrawing=!1;const f=g(h),u=S(this.wbTool),x=this.wbTool==="highlighter"?16:this.wbWidth,C={id:"stroke-"+Math.random().toString(36).slice(2,10),tool:this.wbTool,color:this.wbColor,width:x,opacity:this.wbTool==="highlighter"?.35:1,points:u?[]:[...this.wbCurrentPoints],geometry:u&&this.wbStartPoint?{x1:this.wbStartPoint.x,y1:this.wbStartPoint.y,x2:f.x,y2:f.y}:void 0};this.wbTool==="temp_pen"?this.tempDisappearingStrokes.push({stroke:C,createdAt:Date.now(),durationMs:3e3}):this.wbPrivacyMode==="personal"?this.wbPersonalStrokes.push(C):(this.wbStrokes.push(C),typeof chrome<"u"&&(($=chrome.runtime)!=null&&$.sendMessage)&&chrome.runtime.sendMessage({type:"WHITEBOARD_STROKE_LOCAL",stroke:C}).catch(()=>{})),this.wbRedoStack=[],this.wbCurrentPoints=[],this.wbStartPoint=null,this.drawWbCanvas()};i.addEventListener("mouseup",v),i.addEventListener("mouseleave",v)}handleStampPreset(i){const e=[],t=(b,a,c,r,m)=>{const g={id:"stroke-"+Math.random().toString(36).slice(2,10),tool:b,color:a,width:c,opacity:1,points:[],geometry:r?{...r,label:m}:void 0};e.push(g)};if(i==="two_pointers")t("array_cells","#38bdf8",2.5,{x1:80,y1:160,x2:300,y2:194}),t("two_pointers","#ec4899",2,{x1:100,y1:198,x2:100,y2:218},"L (left=0)"),t("two_pointers","#10b981",2,{x1:260,y1:198,x2:260,y2:218},"R (right=4)"),t("text","#f59e0b",3,{x1:90,y1:135,x2:90,y2:135},"Target = nums[L] + nums[R]");else if(i==="bst")t("tree_node","#10b981",3,{x1:190,y1:160,x2:190,y2:160},"50"),t("tree_node","#06b6d4",3,{x1:130,y1:215,x2:130,y2:215},"30"),t("tree_node","#06b6d4",3,{x1:250,y1:215,x2:250,y2:215},"70"),t("arrow","#6366f1",2,{x1:180,y1:170,x2:145,y2:205}),t("arrow","#6366f1",2,{x1:200,y1:170,x2:235,y2:205}),t("text","#34d399",2.5,{x1:110,y1:140,x2:110,y2:140},"BST: Left < Root < Right");else if(i==="floyd_cycle"){for(let a=0;a<3;a++){const c=80+a*55;t("rounded_rect","#38bdf8",2.5,{x1:c,y1:160,x2:c+38,y2:184},`N${a+1}`),t("arrow","#f59e0b",2,{x1:c+38,y1:172,x2:c+55,y2:172})}t("rounded_rect","#ec4899",2.5,{x1:245,y1:195,x2:283,y2:219},"N4"),t("rounded_rect","#ec4899",2.5,{x1:190,y1:210,x2:228,y2:234},"N5"),t("arrow","#ec4899",2,{x1:228,y1:184,x2:245,y2:195}),t("arrow","#ec4899",2,{x1:245,y1:215,x2:228,y2:222}),t("arrow","#ec4899",2,{x1:190,y1:218,x2:190,y2:184}),t("two_pointers","#10b981",2,{x1:150,y1:140,x2:150,y2:156},"🐢 Slow"),t("two_pointers","#f59e0b",2,{x1:245,y1:140,x2:245,y2:156},"🐇 Fast")}else i==="mono_stack"?(t("array_cells","#38bdf8",2.5,{x1:80,y1:170,x2:180,y2:200}),t("stack_lifo","#f59e0b",2.5,{x1:215,y1:150,x2:265,y2:230}),t("arrow","#ec4899",2,{x1:175,y1:175,x2:210,y2:185}),t("text","#f59e0b",2.5,{x1:100,y1:140,x2:100,y2:140},"Monotonic Stack (NGE)")):i==="dp_table"?(this.wbTheme="matrix",t("text","#38bdf8",3,{x1:100,y1:135,x2:100,y2:135},"DP[i][j] = DP[i-1][j] + DP[i][j-1]"),t("tradeoff_note","#facc15",2,{x1:110,y1:180,x2:270,y2:230},"Base Case: DP[0][j]=1")):i==="trie"?(t("tree_node","#10b981",3,{x1:190,y1:160,x2:190,y2:160},"*"),t("tree_node","#38bdf8",2.5,{x1:140,y1:210,x2:140,y2:210},"c"),t("tree_node","#38bdf8",2.5,{x1:140,y1:260,x2:140,y2:260},"a"),t("tree_node","#ec4899",2.5,{x1:110,y1:305,x2:110,y2:305},"t (end)"),t("tree_node","#ec4899",2.5,{x1:170,y1:305,x2:170,y2:305},"r (end)"),t("arrow","#6366f1",2,{x1:182,y1:168,x2:148,y2:202}),t("arrow","#6366f1",2,{x1:140,y1:222,x2:140,y2:248}),t("arrow","#6366f1",2,{x1:135,y1:272,x2:118,y2:295}),t("arrow","#6366f1",2,{x1:145,y1:272,x2:162,y2:295})):i==="graph_bfs"?(t("tree_node","#10b981",3,{x1:120,y1:160,x2:120,y2:160},"1"),t("tree_node","#38bdf8",3,{x1:160,y1:200,x2:160,y2:200},"2"),t("tree_node","#38bdf8",3,{x1:160,y1:120,x2:160,y2:120},"3"),t("tree_node","#818cf8",3,{x1:210,y1:200,x2:210,y2:200},"4"),t("arrow","#6366f1",2,{x1:132,y1:168,x2:152,y2:190}),t("arrow","#6366f1",2,{x1:132,y1:152,x2:152,y2:130}),t("arrow","#6366f1",2,{x1:172,y1:200,x2:198,y2:200}),t("queue_fifo","#10b981",2,{x1:245,y1:145,x2:320,y2:175},"Queue")):i==="min_heap"?(t("tree_node","#10b981",3,{x1:190,y1:160,x2:190,y2:160},"10"),t("tree_node","#38bdf8",2.5,{x1:150,y1:200,x2:150,y2:200},"15"),t("tree_node","#38bdf8",2.5,{x1:230,y1:200,x2:230,y2:200},"20"),t("arrow","#6366f1",2,{x1:182,y1:168,x2:158,y2:192}),t("arrow","#6366f1",2,{x1:198,y1:168,x2:222,y2:192}),t("array_cells","#f59e0b",2.5,{x1:125,y1:235,x2:255,y2:260})):i==="intervals"?(t("line","#38bdf8",4,{x1:90,y1:160,x2:160,y2:160},"[1, 4]"),t("line","#ec4899",4,{x1:130,y1:180,x2:210,y2:180},"[2, 6]"),t("line","#10b981",4,{x1:230,y1:160,x2:290,y2:160},"[8, 10]"),t("arrow","#f59e0b",2,{x1:170,y1:195,x2:170,y2:215}),t("line","#10b981",6,{x1:90,y1:230,x2:210,y2:230},"Merged: [1, 6]")):i==="recursion_tree"?(t("code_box","#818cf8",2,{x1:155,y1:160,x2:225,y2:185},"solve(N)"),t("code_box","#38bdf8",2,{x1:105,y1:210,x2:165,y2:235},"solve(N/2)"),t("code_box","#38bdf8",2,{x1:215,y1:210,x2:275,y2:235},"solve(N/2)"),t("arrow","#6366f1",2,{x1:175,y1:185,x2:140,y2:210}),t("arrow","#6366f1",2,{x1:205,y1:185,x2:240,y2:210})):i==="url_shortener"?(t("user_client","#3b82f6",2.5,{x1:70,y1:160,x2:105,y2:195},"Client"),t("arrow","#6366f1",2,{x1:105,y1:177,x2:130,y2:177}),t("load_balancer","#f59e0b",2.5,{x1:130,y1:155,x2:175,y2:198},"LB"),t("arrow","#6366f1",2,{x1:175,y1:177,x2:200,y2:177}),t("server_box","#818cf8",2.5,{x1:200,y1:155,x2:255,y2:195},"App Srv"),t("arrow","#10b981",2,{x1:255,y1:168,x2:280,y2:145}),t("cache_mem","#f43f5e",2.5,{x1:280,y1:125,x2:335,y2:155},"Redis"),t("arrow","#10b981",2,{x1:255,y1:184,x2:280,y2:200}),t("db_cylinder","#10b981",2.5,{x1:280,y1:185,x2:335,y2:230},"SQL DB")):i==="rate_limiter"?(t("user_client","#3b82f6",2.5,{x1:70,y1:160,x2:105,y2:195},"Client"),t("arrow","#6366f1",2,{x1:105,y1:177,x2:140,y2:177}),t("cloud","#38bdf8",2.5,{x1:140,y1:150,x2:200,y2:200},"API GW"),t("arrow","#f59e0b",2,{x1:170,y1:200,x2:170,y2:225}),t("cache_mem","#f43f5e",2.5,{x1:140,y1:225,x2:200,y2:260},"Token Redis"),t("arrow","#10b981",2,{x1:200,y1:177,x2:235,y2:177}),t("server_box","#818cf8",2.5,{x1:235,y1:155,x2:300,y2:195},"Microservices")):i==="chat_system"?(t("user_client","#3b82f6",2.5,{x1:70,y1:135,x2:105,y2:170},"User A"),t("user_client","#3b82f6",2.5,{x1:70,y1:190,x2:105,y2:225},"User B"),t("arrow_bi","#6366f1",2,{x1:105,y1:152,x2:150,y2:168}),t("arrow_bi","#6366f1",2,{x1:105,y1:205,x2:150,y2:185}),t("websocket_gw","#6366f1",2.5,{x1:150,y1:160,x2:205,y2:200},"WS GW"),t("arrow","#a855f7",2,{x1:205,y1:180,x2:240,y2:180}),t("message_queue","#a855f7",2.5,{x1:240,y1:165,x2:305,y2:198},"Redis PubSub"),t("db_nosql","#34d399",2.5,{x1:250,y1:220,x2:300,y2:265},"Cassandra")):i==="distributed_cache"?(t("server_box","#818cf8",2.5,{x1:90,y1:160,x2:150,y2:198},"App Srv"),t("arrow","#f43f5e",2,{x1:150,y1:178,x2:195,y2:178}),t("cache_mem","#f43f5e",2.5,{x1:195,y1:160,x2:255,y2:198},"Redis"),t("async_arrow","#10b981",2,{x1:255,y1:178,x2:290,y2:178}),t("db_cylinder","#10b981",2.5,{x1:290,y1:150,x2:340,y2:205},"Postgres")):i==="ecommerce_saga"?(t("server_box","#818cf8",2.5,{x1:80,y1:160,x2:140,y2:195},"Order API"),t("arrow","#a855f7",2,{x1:140,y1:177,x2:180,y2:177}),t("message_queue","#a855f7",2.5,{x1:180,y1:160,x2:245,y2:195},"Kafka Bus"),t("arrow","#10b981",2,{x1:245,y1:168,x2:275,y2:145}),t("server_box","#10b981",2,{x1:275,y1:130,x2:330,y2:158},"Payment"),t("arrow","#10b981",2,{x1:245,y1:185,x2:275,y2:205}),t("server_box","#10b981",2,{x1:275,y1:195,x2:330,y2:223},"Inventory")):i==="web_crawler"?(t("message_queue","#a855f7",2.5,{x1:80,y1:160,x2:145,y2:195},"URL Queue"),t("arrow","#6366f1",2,{x1:145,y1:177,x2:180,y2:177}),t("server_box","#818cf8",2.5,{x1:180,y1:160,x2:235,y2:195},"Fetchers"),t("arrow","#f59e0b",2,{x1:235,y1:177,x2:265,y2:177}),t("object_storage","#f97316",2.5,{x1:265,y1:150,x2:315,y2:200},"S3 Storage")):i==="microservices_3tier"?(t("cdn_edge","#06b6d4",2.5,{x1:70,y1:150,x2:115,y2:190},"CDN Edge"),t("arrow","#6366f1",2,{x1:115,y1:172,x2:145,y2:172}),t("load_balancer","#f59e0b",2.5,{x1:145,y1:150,x2:195,y2:190},"ALB"),t("arrow","#6366f1",2,{x1:195,y1:172,x2:220,y2:172}),t("server_box","#818cf8",2.5,{x1:220,y1:150,x2:280,y2:188},"Services"),t("arrow","#10b981",2,{x1:280,y1:172,x2:300,y2:172}),t("db_cylinder","#10b981",2.5,{x1:300,y1:142,x2:345,y2:195},"SQL Master")):i==="search_analytics"&&(t("server_box","#818cf8",2.5,{x1:70,y1:160,x2:125,y2:195},"Logs"),t("arrow","#a855f7",2,{x1:125,y1:177,x2:160,y2:177}),t("message_queue","#a855f7",2.5,{x1:160,y1:160,x2:220,y2:195},"Kafka"),t("arrow","#14b8a6",2,{x1:220,y1:177,x2:255,y2:177}),t("elasticsearch","#14b8a6",2.5,{x1:255,y1:155,x2:315,y2:195},"Elasticsearch"));this.wbPrivacyMode==="personal"?this.wbPersonalStrokes.push(...e):(this.wbStrokes.push(...e),e.forEach(b=>{var a;typeof chrome<"u"&&((a=chrome.runtime)!=null&&a.sendMessage)&&chrome.runtime.sendMessage({type:"WHITEBOARD_STROKE_LOCAL",stroke:b}).catch(()=>{})})),this.wbShowPresetsDrawer=!1,this.render()}drawWbCanvas(i,o){if(!this.shadow)return;const s=this.shadow.getElementById("nb-whiteboard-canvas");if(!s)return;const e=s.getContext("2d");if(!e)return;e.clearRect(0,0,s.width,s.height),e.save();const t=this.wbBgColor==="#ffffff"||this.wbBgColor==="#f8fafc"||this.wbBgColor==="#fef3c7";if(e.fillStyle=this.wbBgColor||(t?"#f8fafc":"#090d16"),e.fillRect(0,0,s.width,s.height),this.wbTheme==="ruled"){e.strokeStyle=t?"rgba(99, 102, 241, 0.25)":"rgba(99, 102, 241, 0.18)",e.lineWidth=1;for(let r=28;r<s.height;r+=24)e.beginPath(),e.moveTo(0,r),e.lineTo(s.width,r),e.stroke();e.strokeStyle="rgba(244, 63, 94, 0.4)",e.lineWidth=1.5,e.beginPath(),e.moveTo(40,0),e.lineTo(40,s.height),e.stroke()}else if(this.wbTheme==="plot"){const r=Math.floor(s.width/2),m=Math.floor(s.height/2);e.strokeStyle="#6366f1",e.lineWidth=1.5,e.beginPath(),e.moveTo(0,m),e.lineTo(s.width,m),e.moveTo(r,0),e.lineTo(r,s.height),e.stroke()}else if(this.wbTheme==="dotted"){e.fillStyle=t?"rgba(0, 0, 0, 0.25)":"rgba(255, 255, 255, 0.16)";for(let r=8;r<s.width;r+=18)for(let m=8;m<s.height;m+=18)e.beginPath(),e.arc(r,m,1.2,0,Math.PI*2),e.fill()}else if(this.wbTheme==="matrix"){e.strokeStyle=t?"rgba(99, 102, 241, 0.22)":"rgba(99, 102, 241, 0.15)",e.lineWidth=1;const r=26;for(let m=0;m<s.width;m+=r)e.beginPath(),e.moveTo(m,0),e.lineTo(m,s.height),e.stroke();for(let m=0;m<s.height;m+=r)e.beginPath(),e.moveTo(0,m),e.lineTo(s.width,m),e.stroke()}else if(this.wbTheme==="isometric"){e.strokeStyle=t?"rgba(0, 0, 0, 0.1)":"rgba(255, 255, 255, 0.08)",e.lineWidth=1;const r=24,m=Math.tan(30*Math.PI/180);for(let g=-s.width;g<s.width*2;g+=r*2)e.beginPath(),e.moveTo(g,0),e.lineTo(g+s.height/m,s.height),e.stroke(),e.beginPath(),e.moveTo(g,0),e.lineTo(g-s.height/m,s.height),e.stroke()}else if(this.wbTheme==="grid"){e.strokeStyle=t?"rgba(0, 0, 0, 0.07)":"rgba(255, 255, 255, 0.04)",e.lineWidth=1;const r=20;for(let m=0;m<s.width;m+=r)e.beginPath(),e.moveTo(m,0),e.lineTo(m,s.height),e.stroke();for(let m=0;m<s.height;m+=r)e.beginPath(),e.moveTo(0,m),e.lineTo(s.width,m),e.stroke()}if(e.restore(),this.wbTool==="eraser"&&this.wbEraserPos){e.save();const r=(this.wbWidth||4)*3;e.strokeStyle="#ef4444",e.lineWidth=1.5,e.setLineDash([3,3]),e.beginPath(),e.arc(this.wbEraserPos.x,this.wbEraserPos.y,r,0,Math.PI*2),e.stroke(),e.restore()}const b=r=>{if(r.tool==="eraser")return;e.save();let m=r.color;if(t&&(m==="#ffffff"||m==="#fff")&&(m="#0f172a"),e.strokeStyle=m,e.fillStyle=m,e.lineWidth=r.width,e.lineCap="round",e.lineJoin="round",e.globalAlpha=r.opacity,r.geometry){const{x1:g,y1:S,x2:y,y2:v}=r.geometry,p=Math.min(g,y),n=Math.min(S,v),k=Math.abs(y-g),w=Math.abs(v-S),P=p+k/2,E=n+w/2;if(r.tool==="line")e.beginPath(),e.moveTo(g,S),e.lineTo(y,v),e.stroke(),r.geometry.label&&(e.fillStyle="#ffffff",e.font="bold 10px monospace",e.fillText(r.geometry.label,(g+y)/2,(S+v)/2-6));else if(r.tool==="arrow"){e.beginPath(),e.moveTo(g,S),e.lineTo(y,v),e.stroke();const l=Math.atan2(v-S,y-g),d=Math.max(10,r.width*3);e.beginPath(),e.moveTo(y,v),e.lineTo(y-d*Math.cos(l-Math.PI/6),v-d*Math.sin(l-Math.PI/6)),e.moveTo(y,v),e.lineTo(y-d*Math.cos(l+Math.PI/6),v-d*Math.sin(l+Math.PI/6)),e.stroke()}else if(r.tool==="arrow_bi"){e.beginPath(),e.moveTo(g,S),e.lineTo(y,v),e.stroke();const l=Math.atan2(v-S,y-g),d=Math.max(10,r.width*3);e.beginPath(),e.moveTo(y,v),e.lineTo(y-d*Math.cos(l-Math.PI/6),v-d*Math.sin(l-Math.PI/6)),e.moveTo(y,v),e.lineTo(y-d*Math.cos(l+Math.PI/6),v-d*Math.sin(l+Math.PI/6)),e.moveTo(g,S),e.lineTo(g+d*Math.cos(l-Math.PI/6),S+d*Math.sin(l-Math.PI/6)),e.moveTo(g,S),e.lineTo(g+d*Math.cos(l+Math.PI/6),S+d*Math.sin(l+Math.PI/6)),e.stroke()}else if(r.tool==="rect")e.strokeRect(p,n,k,w),r.geometry.label&&(e.fillStyle="#ffffff",e.font="bold 10px sans-serif",e.textAlign="center",e.textBaseline="middle",e.fillText(r.geometry.label,P,E));else if(r.tool==="rounded_rect")e.beginPath(),e.roundRect(p,n,Math.max(20,k),Math.max(20,w),8),e.stroke(),r.geometry.label&&(e.fillStyle="#ffffff",e.font="bold 10px sans-serif",e.textAlign="center",e.textBaseline="middle",e.fillText(r.geometry.label,P,E));else if(r.tool==="circle"){const l=k/2,d=w/2;e.beginPath(),e.ellipse(p+l,n+d,l,d,0,0,Math.PI*2),e.stroke(),r.geometry.label&&(e.fillStyle="#ffffff",e.font="bold 10px sans-serif",e.textAlign="center",e.textBaseline="middle",e.fillText(r.geometry.label,P,E))}else if(r.tool==="triangle")e.beginPath(),e.moveTo(P,n),e.lineTo(p+k,n+w),e.lineTo(p,n+w),e.closePath(),e.stroke();else if(r.tool==="decision_diamond")e.beginPath(),e.moveTo(P,n),e.lineTo(p+k,E),e.lineTo(P,n+w),e.lineTo(p,E),e.closePath(),e.stroke(),r.geometry.label&&(e.fillStyle="#ffffff",e.font="bold 10px sans-serif",e.textAlign="center",e.textBaseline="middle",e.fillText(r.geometry.label,P,E));else if(r.tool==="tree_node"){const l=Math.max(16,r.width*3.5);e.beginPath(),e.arc(g,S,l,0,Math.PI*2),e.fillStyle=t?"rgba(255, 255, 255, 0.95)":"rgba(15, 23, 42, 0.9)",e.fill(),e.stroke(),r.geometry.label&&(e.fillStyle=t?"#0f172a":"#ffffff",e.font="bold 11px monospace",e.textAlign="center",e.textBaseline="middle",e.fillText(r.geometry.label,g,S))}else if(r.tool==="sticky_note"){const l=Math.max(80,k),d=Math.max(60,w);e.fillStyle="#fef3c7",e.strokeStyle="#f59e0b",e.beginPath(),e.roundRect(p,n,l,d,6),e.fill(),e.stroke(),r.geometry.label&&(e.fillStyle="#78350f",e.font="10px sans-serif",e.textAlign="left",e.textBaseline="top",e.fillText(r.geometry.label,p+6,n+6))}else if(r.tool==="text")e.fillStyle=m,e.font="bold 12px sans-serif",e.textAlign="left",e.textBaseline="top",e.fillText(r.geometry.label||"Label",g,S);else if(r.tool==="code_box"){const l=Math.max(80,k),d=Math.max(32,w);e.fillStyle="rgba(15, 23, 42, 0.95)",e.strokeStyle="#38bdf8",e.lineWidth=1.5,e.beginPath(),e.roundRect(p,n,l,d,4),e.fill(),e.stroke(),r.geometry.label&&(e.fillStyle="#38bdf8",e.font="bold 10px monospace",e.textAlign="center",e.textBaseline="middle",e.fillText(r.geometry.label,p+l/2,n+d/2))}else if(r.tool==="array_cells"){const d=Math.max(22,Math.floor(Math.max(100,k)/5)),_=Math.max(24,Math.min(40,w||28));e.fillStyle=t?"rgba(255, 255, 255, 0.95)":"rgba(15, 23, 42, 0.9)";for(let M=0;M<5;M++){const h=p+M*d;e.fillRect(h,n,d,_),e.strokeRect(h,n,d,_),e.fillStyle=t?"#64748b":"#94a3b8",e.font="9px monospace",e.textAlign="center",e.textBaseline="bottom",e.fillText(`[${M}]`,h+d/2,n-2),e.fillStyle=t?"#0f172a":"#ffffff",e.font="bold 11px monospace",e.textBaseline="middle",e.fillText(`${M*2+1}`,h+d/2,n+_/2),e.fillStyle=t?"rgba(255, 255, 255, 0.95)":"rgba(15, 23, 42, 0.9)"}}else if(r.tool==="stack_lifo"){const l=Math.max(45,k),d=Math.max(70,w);e.beginPath(),e.moveTo(p,n),e.lineTo(p,n+d),e.lineTo(p+l,n+d),e.lineTo(p+l,n),e.stroke();const _=3,M=Math.floor((d-8)/_);for(let h=0;h<_;h++){const f=n+d-(h+1)*M;e.fillStyle=t?"rgba(245, 158, 11, 0.15)":"rgba(245, 158, 11, 0.25)",e.fillRect(p+3,f,l-6,M-2),e.strokeRect(p+3,f,l-6,M-2),e.fillStyle=t?"#0f172a":"#ffffff",e.font="bold 9px monospace",e.textAlign="center",e.textBaseline="middle",e.fillText(h===_-1?"TOP":`val_${h+1}`,p+l/2,f+M/2)}}else if(r.tool==="queue_fifo"){const l=Math.max(75,k),d=Math.max(28,w);e.beginPath(),e.moveTo(p,n),e.lineTo(p+l,n),e.moveTo(p,n+d),e.lineTo(p+l,n+d),e.stroke();const _=3,M=Math.floor((l-8)/_);for(let h=0;h<_;h++){const f=p+4+h*M;e.fillStyle=t?"rgba(16, 185, 129, 0.15)":"rgba(16, 185, 129, 0.25)",e.fillRect(f,n+3,M-2,d-6),e.strokeRect(f,n+3,M-2,d-6),e.fillStyle=t?"#0f172a":"#ffffff",e.font="bold 9px monospace",e.textAlign="center",e.textBaseline="middle",e.fillText(`e${h+1}`,f+M/2,n+d/2)}}else if(r.tool==="hashmap_table"){const l=Math.max(75,k),d=Math.max(50,w);e.strokeRect(p,n,l,d);const _=3,M=d/_;for(let h=1;h<_;h++)e.beginPath(),e.moveTo(p,n+h*M),e.lineTo(p+l,n+h*M),e.stroke();e.beginPath(),e.moveTo(p+22,n),e.lineTo(p+22,n+d),e.stroke();for(let h=0;h<_;h++)e.fillStyle=t?"#64748b":"#94a3b8",e.font="bold 9px monospace",e.textAlign="center",e.textBaseline="middle",e.fillText(`${h}`,p+11,n+h*M+M/2),e.fillStyle=t?"#0f172a":"#ffffff",e.fillText(`k${h+1} ➔ v${h+1}`,p+26+(l-26)/2,n+h*M+M/2)}else if(r.tool==="two_pointers"){e.beginPath(),e.moveTo(g,S),e.lineTo(y,v),e.stroke();const l=Math.atan2(v-S,y-g),d=Math.max(8,r.width*2.5);e.beginPath(),e.moveTo(y,v),e.lineTo(y-d*Math.cos(l-Math.PI/6),v-d*Math.sin(l-Math.PI/6)),e.moveTo(y,v),e.lineTo(y-d*Math.cos(l+Math.PI/6),v-d*Math.sin(l+Math.PI/6)),e.stroke(),r.geometry.label&&(e.fillStyle=m,e.font="bold 10px monospace",e.textAlign="center",e.fillText(r.geometry.label,g,S-4))}else if(r.tool==="db_cylinder"||r.tool==="db_nosql"){const l=Math.max(50,k),d=Math.max(55,w),_=Math.min(14,d*.2);e.fillStyle=t?"rgba(255, 255, 255, 0.95)":"rgba(15, 23, 42, 0.95)",e.beginPath(),e.ellipse(p+l/2,n+_,l/2,_,0,Math.PI,0),e.lineTo(p+l,n+d-_),e.ellipse(p+l/2,n+d-_,l/2,_,0,0,Math.PI),e.lineTo(p,n+_),e.fill(),e.stroke(),e.beginPath(),e.ellipse(p+l/2,n+_,l/2,_,0,0,Math.PI*2),e.stroke(),r.geometry.label&&(e.fillStyle=t?"#0f172a":"#ffffff",e.font="bold 10px sans-serif",e.textAlign="center",e.textBaseline="middle",e.fillText(r.geometry.label,p+l/2,n+d/2+4))}else if(r.tool==="cloud"){const l=Math.max(65,k),d=Math.max(40,w);e.fillStyle=t?"rgba(255, 255, 255, 0.95)":"rgba(15, 23, 42, 0.95)",e.beginPath(),e.roundRect(p,n,l,d,14),e.fill(),e.stroke(),r.geometry.label&&(e.fillStyle=t?"#0f172a":"#ffffff",e.font="bold 10px sans-serif",e.textAlign="center",e.textBaseline="middle",e.fillText(r.geometry.label,p+l/2,n+d/2))}else if(r.tool==="load_balancer"){const l=Math.max(55,k),d=Math.max(55,w);e.fillStyle=t?"rgba(255, 255, 255, 0.95)":"rgba(15, 23, 42, 0.95)",e.beginPath(),e.moveTo(p+l/2,n),e.lineTo(p+l,n+d/2),e.lineTo(p+l/2,n+d),e.lineTo(p,n+d/2),e.closePath(),e.fill(),e.stroke(),r.geometry.label&&(e.fillStyle=t?"#0f172a":"#ffffff",e.font="bold 10px sans-serif",e.textAlign="center",e.textBaseline="middle",e.fillText(r.geometry.label,p+l/2,n+d/2))}else if(r.tool==="message_queue"){const l=Math.max(70,k),d=Math.max(34,w);e.fillStyle=t?"rgba(255, 255, 255, 0.95)":"rgba(15, 23, 42, 0.95)",e.beginPath(),e.roundRect(p,n,l,d,6),e.fill(),e.stroke(),r.geometry.label&&(e.fillStyle=t?"#0f172a":"#ffffff",e.font="bold 9px sans-serif",e.textAlign="center",e.textBaseline="middle",e.fillText(r.geometry.label,p+l/2,n+d/2))}else if(r.tool==="server_box"){const l=Math.max(65,k),d=Math.max(40,w);e.fillStyle=t?"rgba(255, 255, 255, 0.95)":"rgba(15, 23, 42, 0.95)",e.beginPath(),e.roundRect(p,n,l,d,6),e.fill(),e.stroke(),e.fillStyle="#10b981",e.beginPath(),e.arc(p+10,n+10,3,0,Math.PI*2),e.fill(),r.geometry.label&&(e.fillStyle=t?"#0f172a":"#ffffff",e.font="bold 9px sans-serif",e.textAlign="center",e.textBaseline="middle",e.fillText(r.geometry.label,p+l/2,n+d/2+2))}else if(r.tool==="cache_mem"){const l=Math.max(65,k),d=Math.max(32,w);e.fillStyle=t?"rgba(244, 63, 94, 0.1)":"rgba(244, 63, 94, 0.2)",e.beginPath(),e.roundRect(p,n,l,d,5),e.fill(),e.stroke(),e.fillStyle=t?"#0f172a":"#ffffff",e.font="bold 9px sans-serif",e.textAlign="center",e.textBaseline="middle",e.fillText(r.geometry.label||"⚡ Redis Cache",p+l/2,n+d/2)}else if(r.tool==="cdn_edge"){const l=Math.max(65,k),d=Math.max(36,w);e.fillStyle=t?"rgba(6, 182, 212, 0.1)":"rgba(6, 182, 212, 0.2)",e.beginPath(),e.roundRect(p,n,l,d,12),e.fill(),e.stroke(),e.fillStyle=t?"#0f172a":"#ffffff",e.font="bold 9px sans-serif",e.textAlign="center",e.textBaseline="middle",e.fillText(r.geometry.label||"🌐 CDN Edge",p+l/2,n+d/2)}else if(r.tool==="object_storage"){const l=Math.max(65,k),d=Math.max(45,w);e.fillStyle=t?"rgba(249, 115, 22, 0.1)":"rgba(249, 115, 22, 0.2)",e.beginPath(),e.roundRect(p,n,l,d,6),e.fill(),e.stroke(),e.fillStyle=t?"#0f172a":"#ffffff",e.font="bold 9px sans-serif",e.textAlign="center",e.textBaseline="middle",e.fillText(r.geometry.label||"📦 S3 Storage",p+l/2,n+d/2)}else if(r.tool==="auth_jwt"){const l=Math.max(60,k),d=Math.max(40,w);e.beginPath(),e.moveTo(p+l/2,n),e.lineTo(p+l,n+d*.3),e.lineTo(p+l/2,n+d),e.lineTo(p,n+d*.3),e.closePath(),e.fillStyle=t?"rgba(234, 179, 8, 0.15)":"rgba(234, 179, 8, 0.25)",e.fill(),e.stroke(),e.fillStyle=t?"#0f172a":"#ffffff",e.font="bold 9px sans-serif",e.textAlign="center",e.textBaseline="middle",e.fillText(r.geometry.label||"🛡️ JWT Auth",p+l/2,n+d/2)}else if(r.tool==="websocket_gw"){const l=Math.max(65,k),d=Math.max(36,w);e.fillStyle=t?"rgba(99, 102, 241, 0.15)":"rgba(99, 102, 241, 0.25)",e.beginPath(),e.roundRect(p,n,l,d,6),e.fill(),e.stroke(),e.fillStyle=t?"#0f172a":"#ffffff",e.font="bold 9px sans-serif",e.textAlign="center",e.textBaseline="middle",e.fillText(r.geometry.label||"⚡ WS Gateway",p+l/2,n+d/2)}else if(r.tool==="elasticsearch"){const l=Math.max(65,k),d=Math.max(36,w);e.fillStyle=t?"rgba(20, 184, 166, 0.15)":"rgba(20, 184, 166, 0.25)",e.beginPath(),e.roundRect(p,n,l,d,6),e.fill(),e.stroke(),e.fillStyle=t?"#0f172a":"#ffffff",e.font="bold 9px sans-serif",e.textAlign="center",e.textBaseline="middle",e.fillText(r.geometry.label||"🔍 Search / ES",p+l/2,n+d/2)}else if(r.tool==="user_client"||r.tool==="mobile_client"){const l=Math.max(50,k),d=Math.max(34,w);e.fillStyle=t?"rgba(59, 130, 246, 0.15)":"rgba(59, 130, 246, 0.25)",e.beginPath(),e.roundRect(p,n,l,d,6),e.fill(),e.stroke(),e.fillStyle=t?"#0f172a":"#ffffff",e.font="bold 9px sans-serif",e.textAlign="center",e.textBaseline="middle",e.fillText(r.geometry.label||(r.tool==="mobile_client"?"📱 Mobile":"💻 Client"),p+l/2,n+d/2)}else if(r.tool==="async_arrow"){e.setLineDash([4,4]),e.beginPath(),e.moveTo(g,S),e.lineTo(y,v),e.stroke(),e.setLineDash([]);const l=Math.atan2(v-S,y-g),d=Math.max(10,r.width*3);e.beginPath(),e.moveTo(y,v),e.lineTo(y-d*Math.cos(l-Math.PI/6),v-d*Math.sin(l-Math.PI/6)),e.moveTo(y,v),e.lineTo(y-d*Math.cos(l+Math.PI/6),v-d*Math.sin(l+Math.PI/6)),e.stroke()}else if(r.tool==="tradeoff_note"){const l=Math.max(90,k),d=Math.max(45,w);e.fillStyle="rgba(250, 204, 21, 0.18)",e.strokeStyle="#facc15",e.beginPath(),e.roundRect(p,n,l,d,4),e.fill(),e.stroke(),e.fillStyle=t?"#78350f":"#fef08a",e.font="bold 9px sans-serif",e.textAlign="center",e.textBaseline="middle",e.fillText(r.geometry.label||"⚖️ Trade-off / CAP Analysis",p+l/2,n+d/2)}}else if(r.points&&r.points.length>0)if(r.points.length===1)e.beginPath(),e.arc(r.points[0].x,r.points[0].y,r.width/2,0,Math.PI*2),e.fill();else{e.beginPath(),e.moveTo(r.points[0].x,r.points[0].y);for(let g=1;g<r.points.length-1;g++){const S=(r.points[g].x+r.points[g+1].x)/2,y=(r.points[g].y+r.points[g+1].y)/2;e.quadraticCurveTo(r.points[g].x,r.points[g].y,S,y)}e.lineTo(r.points[r.points.length-1].x,r.points[r.points.length-1].y),e.stroke()}e.restore()};(this.wbPrivacyMode==="personal"?this.wbPersonalStrokes:this.wbStrokes).forEach(b);const c=Date.now();this.tempDisappearingStrokes.forEach(r=>{const m=Math.max(0,1-(c-r.createdAt)/r.durationMs);b({...r.stroke,opacity:m})}),o?b({tool:this.wbTool,color:this.wbColor,width:this.wbTool==="highlighter"?14:this.wbWidth,opacity:this.wbTool==="highlighter"?.35:1,points:[],geometry:o}):i&&i.length>1&&b({tool:this.wbTool,color:this.wbColor,width:this.wbTool==="highlighter"?14:this.wbWidth,opacity:this.wbTool==="highlighter"?.35:1,points:i}),this.wbTool==="torch"&&this.wbTorchPos&&(e.save(),e.fillStyle="rgba(0, 0, 0, 0.75)",e.fillRect(0,0,s.width,s.height),e.globalCompositeOperation="destination-out",e.beginPath(),e.arc(this.wbTorchPos.x,this.wbTorchPos.y,55,0,Math.PI*2),e.fill(),e.globalCompositeOperation="source-over",e.strokeStyle="rgba(253, 224, 71, 0.85)",e.lineWidth=2.5,e.shadowColor="#fde047",e.shadowBlur=10,e.beginPath(),e.arc(this.wbTorchPos.x,this.wbTorchPos.y,55,0,Math.PI*2),e.stroke(),e.restore()),this.wbLaserTrails.forEach(r=>{e.save(),e.globalAlpha=r.alpha,e.fillStyle="#ef4444",e.shadowColor="#ef4444",e.shadowBlur=8,e.beginPath(),e.arc(r.x,r.y,4.5*r.alpha,0,Math.PI*2),e.fill(),e.restore()})}listenForRuntimeMessages(){var i;typeof chrome<"u"&&((i=chrome.runtime)!=null&&i.onMessage)&&chrome.runtime.onMessage.addListener(o=>{var s;if(o.type==="FAB_SETTINGS_UPDATED"&&o.payload)this.settings={...q,...o.payload},this.settings.positionMode==="permanent"&&this.settings.savedPosition&&(this.currentPosition={...this.settings.savedPosition}),this.checkVisibilityAndRender(),this.hostElement&&this.render();else if(o.type==="WHITEBOARD_STROKE_LOCAL"&&o.stroke)this.wbStrokes.some(e=>e.id===o.stroke.id)||(this.wbStrokes.push(o.stroke),this.activeTab==="whiteboard"&&this.drawWbCanvas());else if(o.type==="WHITEBOARD_TEMP_STROKE_LOCAL"&&o.stroke)this.tempDisappearingStrokes.push({stroke:o.stroke,createdAt:Date.now(),durationMs:o.durationMs||3e3}),this.activeTab==="whiteboard"&&this.drawWbCanvas();else if(o.type==="WHITEBOARD_CLEAR_LOCAL")this.wbStrokes=[],this.wbRedoStack=[],this.activeTab==="whiteboard"&&this.drawWbCanvas();else if(o.type==="WHITEBOARD_UNDO_LOCAL"&&o.strokeId)this.wbStrokes=this.wbStrokes.filter(e=>e.id!==o.strokeId),this.activeTab==="whiteboard"&&this.drawWbCanvas();else if(o.type==="WHITEBOARD_BG_LOCAL")o.background&&(this.wbTheme=o.background),o.bgColor&&(this.wbBgColor=o.bgColor),this.activeTab==="whiteboard"&&this.drawWbCanvas();else if(o.type==="WHITEBOARD_SNAPSHOT"&&((s=o.notebook)!=null&&s.pages)){const e=o.notebook.pages.find(t=>t.id===o.notebook.activePageId)||o.notebook.pages[0];e&&(this.wbStrokes=e.strokes||[],e.background&&(this.wbTheme=e.background),e.bgColor&&(this.wbBgColor=e.bgColor),this.activeTab==="whiteboard"&&this.drawWbCanvas())}})}escapeHtml(i){return i.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}formatTimestamp(i){return new Date(i).toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"})}renderFormattedText(i,o,s){let e="";s!=null&&s.imageUrl&&(e+=`
        <div style="margin:4px 0;border-radius:6px;overflow:hidden;border:1px solid rgba(255,255,255,0.1);">
          <img src="${s.imageUrl}" alt="Shared image" style="width:100%;max-height:180px;object-fit:cover;display:block;" />
        </div>
      `);const b=i.split(`
`).map((a,c)=>{if(a.startsWith("```")&&a.endsWith("```")&&a.length>6){const r=a.slice(3,-3);return`
          <div style="background:rgba(0,0,0,0.45);padding:6px 8px;border-radius:6px;margin:4px 0;font-family:var(--font-mono);font-size:11px;position:relative;">
            <pre style="margin:0;white-space:pre-wrap;word-break:break-all;">${this.escapeHtml(r)}</pre>
          </div>
        `}return a.includes("||")?`<p style="margin:2px 0;">${a.split(/(\|\|.*?\|\|)/g).map((g,S)=>{if(g.startsWith("||")&&g.endsWith("||")&&g.length>4){const y=g.slice(2,-2),v=`${o}-${c}-${S}`,p=!!this.revealedSpoilers[v];return`
              <span style="display:inline-block;padding:1px 6px;border-radius:4px;background:${p?"rgba(99, 102, 241, 0.25)":"rgba(255, 255, 255, 0.15)"};filter:${p?"none":"blur(4px)"};cursor:pointer;">
                ${this.escapeHtml(y)}
              </span>
            `}return this.renderMentionsHtml(this.escapeHtml(g))}).join("")}</p>`:`<p style="margin:2px 0;">${this.renderMentionsHtml(this.escapeHtml(a))}</p>`}).join("");return e+b}renderMentionsHtml(i){return i.includes("@")?i.replace(/(@everyone|@all)/g,'<span style="background:rgba(245,158,11,0.25);border:1px solid rgba(245,158,11,0.5);color:#fbbf24;padding:1px 4px;border-radius:3px;font-weight:700;font-size:10px;">📣 $1</span>').replace(/(@[a-zA-Z0-9_-]+)/g,'<span style="background:rgba(99,102,241,0.25);border:1px solid rgba(99,102,241,0.4);color:#c7d2fe;padding:1px 4px;border-radius:3px;font-weight:600;font-size:10px;">$1</span>'):i}deduplicateMessages(i){var e,t;const o=new Set,s=[];for(const b of i)!b||!b.id||o.has(b.id)||(o.add(b.id),s.push({...b,isSelf:((e=b.from)==null?void 0:e.peerId)===((t=this.myIdentity)==null?void 0:t.peerId)||b.isSelf}));return s}async sendMessage(i,o){var b,a,c,r;if(!i.trim())return;!this.currentRoomStorageKey&&((b=this.currentProblem)!=null&&b.roomId)&&(this.currentRoomStorageKey=`synqto_chat_${this.currentProblem.roomId}`);const s=i.trim(),e="msg-"+Math.random().toString(36).slice(2,10)+Date.now(),t={id:e,from:this.myIdentity||{nickname:"You",avatar:"⚡",color:"#6366f1",peerId:"self"},text:s,timestamp:Date.now(),replyTo:o==null?void 0:o.id,replyPreview:o==null?void 0:o.preview,status:"sent",isSelf:!0};if(this.messages.push(t),this.messages=this.deduplicateMessages(this.messages),this.render(),this.scrollToBottom(),this.currentRoomStorageKey&&typeof chrome<"u"&&((a=chrome.storage)!=null&&a.local))try{const m=await chrome.storage.local.get([this.currentRoomStorageKey]),g=m[this.currentRoomStorageKey]&&Array.isArray(m[this.currentRoomStorageKey])?m[this.currentRoomStorageKey]:[],S=this.deduplicateMessages([...g,t]).slice(-150);await chrome.storage.local.set({[this.currentRoomStorageKey]:S})}catch{}typeof chrome<"u"&&((c=chrome.runtime)!=null&&c.sendMessage)&&chrome.runtime.sendMessage({type:"SEND_PAGE_CHAT_MESSAGE",messageId:e,text:t.text,replyTo:t.replyTo,replyPreview:t.replyPreview,roomId:(r=this.currentProblem)==null?void 0:r.roomId}).catch(()=>{})}async loadMessages(){var i;if(this.currentRoomStorageKey&&typeof chrome<"u"&&(i=chrome.storage)!=null&&i.local){const o=await chrome.storage.local.get([this.currentRoomStorageKey]);o[this.currentRoomStorageKey]&&Array.isArray(o[this.currentRoomStorageKey])&&(this.messages=this.deduplicateMessages(o[this.currentRoomStorageKey]),this.isOpen&&this.activeTab==="chat"&&(this.render(),this.scrollToBottom()))}}scrollToBottom(){setTimeout(()=>{var o;const i=(o=this.shadow)==null?void 0:o.getElementById("nb-messages");i&&(i.scrollTop=i.scrollHeight)},40)}listenToStorageChanges(){var i;typeof chrome<"u"&&((i=chrome.storage)!=null&&i.onChanged)&&chrome.storage.onChanged.addListener((o,s)=>{var e,t,b,a;if(s==="local"){if(o.nerd_buddy_sidepanel_open&&o.nerd_buddy_sidepanel_open.newValue===!0&&this.isOpen&&(this.isOpen=!1,this.render()),(o.synqto_live_stage||o.nerd_buddy_live_stage)&&(this.liveStage=(o.synqto_live_stage||o.nerd_buddy_live_stage).newValue,this.render()),(o.synqto_identity||o.nerd_buddy_identity)&&(this.myIdentity=(o.synqto_identity||o.nerd_buddy_identity).newValue),o[z]||o[A]){const c=(e=o[z]||o[A])==null?void 0:e.newValue;c&&(this.settings={...q,...c},this.settings.positionMode==="permanent"&&this.settings.savedPosition&&(this.currentPosition={...this.settings.savedPosition}),this.checkVisibilityAndRender(),this.hostElement&&this.render())}if((o.synqto_active_problem||o.nerd_buddy_active_problem)&&(this.currentProblem=(o.synqto_active_problem||o.nerd_buddy_active_problem).newValue,this.currentRoomStorageKey=`synqto_chat_${((t=this.currentProblem)==null?void 0:t.roomId)||""}`,this.loadMessages(),this.checkVisibilityAndRender()),o.nerd_buddy_peer_count&&(this.peerCount=Math.max(1,o.nerd_buddy_peer_count.newValue||1),this.render()),this.currentRoomStorageKey&&o[this.currentRoomStorageKey]){const c=o[this.currentRoomStorageKey].newValue||[];this.messages=this.deduplicateMessages(c),!this.isOpen&&((b=o[this.currentRoomStorageKey].newValue)==null?void 0:b.length)>(((a=o[this.currentRoomStorageKey].oldValue)==null?void 0:a.length)||0)&&this.unreadCount++,this.render(),this.isOpen&&this.activeTab==="chat"&&this.scrollToBottom()}if(o.synqto_server_connected||o.nerd_buddy_server_connected){const c=o.synqto_server_connected||o.nerd_buddy_server_connected,r=!!c.newValue,m=!!c.oldValue;this.isServerConnected=r,r&&!m&&this.showServerConnectedToast("⚡ Connected to Synqto Server"),this.render()}if(o.synqto_theme_settings&&(this.themeSettings=o.synqto_theme_settings.newValue,this.render()),o.synqto_collab_notebook){const c=o.synqto_collab_notebook.newValue;if(c&&Array.isArray(c.pages)){const r=c.pages.find(m=>m.id===c.activePageId)||c.pages[0];r&&(this.wbStrokes=r.strokes||[],r.background&&(this.wbTheme=r.background),r.bgColor&&(this.wbBgColor=r.bgColor),this.activeTab==="whiteboard"&&this.drawWbCanvas())}}if(o.synqto_personal_notebook){const c=o.synqto_personal_notebook.newValue;if(c&&Array.isArray(c.pages)){const r=c.pages.find(m=>m.id===c.activePageId)||c.pages[0];r&&(this.wbPersonalStrokes=r.strokes||[],this.wbPrivacyMode==="personal"&&(r.background&&(this.wbTheme=r.background),r.bgColor&&(this.wbBgColor=r.bgColor),this.activeTab==="whiteboard"&&this.drawWbCanvas()))}}if(o[O]){const c=o[O].newValue;c&&(this.timerConfig={...F,...c},this.render())}if(o[R]){const c=o[R].newValue;c&&(this.timerState=c,this.updateTimerDisplay(),this.isOpen&&this.render())}}})}showServerConnectedToast(i){this.serverToastMessage=i,this.render(),setTimeout(()=>{this.serverToastMessage=null,this.render()},3200)}async loadTimerState(){var i;if(typeof chrome<"u"&&((i=chrome.storage)!=null&&i.local))try{const o=await chrome.storage.local.get([O,R]);if(o[O]&&(this.timerConfig={...F,...o[O]}),o[R]){const s=o[R];if(s.isRunning){const e=Math.floor((Date.now()-s.lastUpdated)/1e3);s.mode==="stopwatch"?s.timeLeftSec+=e:(s.timeLeftSec=Math.max(0,s.timeLeftSec-e),s.timeLeftSec===0&&(s.isRunning=!1))}this.timerState=s}}catch{}}saveTimerState(){var i;typeof chrome<"u"&&((i=chrome.storage)!=null&&i.local)&&chrome.storage.local.set({[R]:this.timerState})}startTimerTickLoop(){this.timerInterval&&clearInterval(this.timerInterval),this.timerInterval=setInterval(()=>{this.timerState.isRunning&&(this.timerState.mode==="stopwatch"?(this.timerState.timeLeftSec+=1,this.timerState.lastUpdated=Date.now(),this.updateTimerDisplay()):this.timerState.timeLeftSec>0&&(this.timerState.timeLeftSec-=1,this.timerState.lastUpdated=Date.now(),this.updateTimerDisplay(),this.timerState.timeLeftSec===0?this.handleTimerSessionComplete():this.timerState.timeLeftSec%5===0&&this.saveTimerState()))},1e3)}updateTimerDisplay(){if(!this.shadow)return;const i=this.shadow.getElementById("nb-timer-time");i&&(i.textContent=this.formatTimerTime(this.timerState.timeLeftSec));const o=this.shadow.getElementById("nb-timer-fab-time");o&&(o.textContent=this.formatTimerTime(this.timerState.timeLeftSec));const s=this.shadow.getElementById("nb-timer-fab-fill");if(s){const t=this.getTimerProgressPct();s.style.width=`${t}%`}const e=this.shadow.getElementById("nb-timer-progress-fill");if(e){const t=this.getTimerProgressPct();e.style.width=`${t}%`}}getTimerProgressPct(){if(this.timerState.mode==="stopwatch"||this.timerState.targetDurationSec===0)return 100;const i=1-this.timerState.timeLeftSec/this.timerState.targetDurationSec;return Math.min(100,Math.max(0,i*100))}handleTimerSessionComplete(){if(this.timerState.isRunning=!1,this.timerState.lastUpdated=Date.now(),this.timerConfig.soundAlerts&&this.playTimerChime(),this.timerState.mode==="pomodoro"){this.timerState.sessionsCompleted+=1;const o=this.timerState.sessionsCompleted%4===0?"long_break":"short_break";this.resetTimerToMode(o),this.timerConfig.autoStartBreaks&&(this.timerState.isRunning=!0)}else this.resetTimerToMode("pomodoro");this.saveTimerState(),this.render()}resetTimerToMode(i){this.timerState.mode=i;let o=1500;i==="pomodoro"?o=(this.timerConfig.workDurationMin||25)*60:i==="short_break"?o=(this.timerConfig.shortBreakMin||5)*60:i==="long_break"?o=(this.timerConfig.longBreakMin||15)*60:i==="stopwatch"&&(o=0),this.timerState.timeLeftSec=o,this.timerState.targetDurationSec=o,this.timerState.lastUpdated=Date.now()}toggleTimer(){this.timerState.isRunning=!this.timerState.isRunning,this.timerState.lastUpdated=Date.now(),this.saveTimerState(),this.render()}resetTimer(){this.timerState.isRunning=!1,this.resetTimerToMode(this.timerState.mode),this.saveTimerState(),this.render()}setTimerMode(i){this.timerState.isRunning=!1,this.resetTimerToMode(i),this.saveTimerState(),this.render()}addTimerTime(i){this.timerState.mode!=="stopwatch"?(this.timerState.timeLeftSec=Math.max(0,this.timerState.timeLeftSec+i),this.timerState.targetDurationSec=Math.max(this.timerState.timeLeftSec,this.timerState.targetDurationSec+i)):this.timerState.timeLeftSec=Math.max(0,this.timerState.timeLeftSec+i),this.saveTimerState(),this.render()}formatTimerTime(i){const o=Math.floor(i/60),s=i%60;return`${o.toString().padStart(2,"0")}:${s.toString().padStart(2,"0")}`}playTimerChime(){try{const i=window.AudioContext||window.webkitAudioContext;if(!i)return;const o=new i,s=(e,t,b)=>{const a=o.createOscillator(),c=o.createGain();a.type="sine",a.frequency.setValueAtTime(e,o.currentTime+t),c.gain.setValueAtTime(0,o.currentTime+t),c.gain.linearRampToValueAtTime(.2,o.currentTime+t+.05),c.gain.exponentialRampToValueAtTime(.001,o.currentTime+t+b),a.connect(c),c.connect(o.destination),a.start(o.currentTime+t),a.stop(o.currentTime+t+b)};s(523.25,0,1.2),s(659.25,.15,1.2),s(783.99,.3,1.5),s(1046.5,.45,2)}catch{}}getThemeCSS(){var m,g,S,y,v,p,n,k,w,P;const i=((m=this.themeSettings)==null?void 0:m.mode)||"system",o=i==="day"||i==="light"||i==="leetcode_light"||i==="solarized_light"||i==="sakura"||i==="system"&&typeof window<"u"&&((g=window.matchMedia)==null?void 0:g.call(window,"(prefers-color-scheme: light)").matches);let s="rgba(26, 38, 41, 0.96)",e="rgba(38, 55, 59, 0.95)",t="rgba(45, 212, 191, 0.18)",b="#ecfdf5",a="#a7f3d0",c="#2dd4bf",r="#14b8a6";return(S=this.themeSettings)!=null&&S.customPaletteEnabled?(s=this.themeSettings.customBgSurface||"#1e2b2f",e=this.themeSettings.customBgSurface||"#26373b",c=this.themeSettings.customPrimary||"#2dd4bf",r=this.themeSettings.customPrimary||"#14b8a6",b=this.themeSettings.customTextPrimary||"#ecfdf5",a=this.themeSettings.customTextSecondary||"#94a3b8",t=`${a}33`):i==="nordic_forest"?(s="rgba(26, 38, 41, 0.96)",e="rgba(38, 55, 59, 0.95)",t="rgba(45, 212, 191, 0.22)",b="#ecfdf5",a="#a7f3d0",c="#2dd4bf",r="#14b8a6"):i==="leetcode_dark"?(s="rgba(38, 38, 38, 0.96)",e="rgba(48, 48, 48, 0.95)",t="rgba(255, 161, 22, 0.25)",b="#eff1f6",a="#abb2bf",c="#FFA116",r="#f59e0b"):i==="leetcode_light"?(s="#ffffff",e="#f7f7f8",t="rgba(230, 138, 0, 0.25)",b="#262626",a="#595959",c="#e68a00",r="#cc7a00"):i==="oled"?(s="rgba(10, 10, 10, 0.98)",e="rgba(24, 24, 24, 0.95)",t="rgba(255, 255, 255, 0.18)",b="#ffffff",a="#e2e8f0"):i==="espresso"?(s="rgba(32, 21, 14, 0.96)",e="rgba(48, 32, 22, 0.95)",t="rgba(245, 158, 11, 0.2)",b="#fef3c7",a="#fde68a",c="#f59e0b",r="#d97706"):i==="forest"?(s="rgba(8, 28, 17, 0.96)",e="rgba(14, 42, 27, 0.95)",t="rgba(16, 185, 129, 0.2)",b="#ecfdf5",a="#a7f3d0",c="#10b981",r="#059669"):i==="nord"?(s="rgba(46, 52, 64, 0.96)",e="rgba(59, 66, 82, 0.95)",t="rgba(136, 192, 208, 0.2)",b="#eceff4",a="#e5e9f0",c="#88c0d0",r="#81a1c1"):i==="dracula"?(s="rgba(40, 42, 54, 0.96)",e="rgba(68, 71, 90, 0.95)",t="rgba(189, 147, 249, 0.2)",b="#f8f8f2",a="#bd93f9",c="#bd93f9",r="#a855f7"):i==="synthwave"?(s="rgba(38, 20, 71, 0.96)",e="rgba(54, 28, 102, 0.95)",t="rgba(244, 114, 182, 0.25)",b="#fff0f5",a="#f472b6",c="#f472b6",r="#ec4899"):i==="solarized_dark"?(s="rgba(0, 43, 54, 0.96)",e="rgba(7, 54, 66, 0.95)",t="rgba(42, 161, 152, 0.25)",b="#fdf6e3",a="#eee8d5",c="#2aa198",r="#268bd2"):i==="solarized_light"?(s="#fdf6e3",e="#eee8d5",t="rgba(7, 54, 66, 0.2)",b="#073642",a="#586e75",c="#268bd2",r="#1e6ea8"):i==="sakura"?(s="#ffffff",e="#fff0f3",t="rgba(244, 63, 94, 0.2)",b="#4c0519",a="#881337",c="#f43f5e",r="#e11d48"):o?(s="#ffffff",e="#f6f8fa",t="rgba(31, 35, 40, 0.15)",b="#1f2328",a="#4b5563",c="#4f46e5",r="#4338ca"):i==="night"&&(s="rgba(22, 27, 34, 0.96)",e="rgba(33, 38, 45, 0.95)",t="rgba(255, 255, 255, 0.12)",b="#f0f6fc",a="#c9d1d9",c="#6366f1",r="#4f46e5"),(y=this.themeSettings)!=null&&y.customPaletteEnabled||(((v=this.themeSettings)==null?void 0:v.accent)==="leetcode"?(c="#FFA116",r="#f59e0b"):((p=this.themeSettings)==null?void 0:p.accent)==="emerald"?(c="#10b981",r="#059669"):((n=this.themeSettings)==null?void 0:n.accent)==="cyan"?(c="#06b6d4",r="#0891b2"):((k=this.themeSettings)==null?void 0:k.accent)==="rose"?(c="#f43f5e",r="#e11d48"):((w=this.themeSettings)==null?void 0:w.accent)==="amber"?(c="#f59e0b",r="#d97706"):((P=this.themeSettings)==null?void 0:P.accent)==="purple"&&(c="#a855f7",r="#9333ea")),`
      --primary: ${c};
      --primary-hover: ${r};
      --bg-card: ${s};
      --bg-surface-elevated: ${e};
      --border-subtle: ${t};
      --text-primary: ${b};
      --text-secondary: ${a};
      --text-muted: ${o?"#6b7280":"#8b949e"};
      --text-dim: ${o?"#9ca3af":"#6e7681"};
    `}}class ee{constructor(){this.isEnabled=!0,this.activePeers=new Map,this.containerEl=null,this.lastSentCode="",this.lastSentCursor={line:1,ch:1},this.cleanupInterval=null,this.init()}async init(){var i,o;if(typeof chrome<"u"&&((i=chrome.storage)!=null&&i.local)){const s=await chrome.storage.local.get(["synqto_code_together_enabled"]);this.isEnabled=s.synqto_code_together_enabled!==!1}this.injectMainWorldBridge(),this.setupPageMessageListeners(),this.setupRuntimeListeners(),this.renderFloatingDock(),this.startCursorCleanup(),typeof chrome<"u"&&((o=chrome.runtime)!=null&&o.sendMessage)&&chrome.runtime.sendMessage({type:"CODE_GET_STATE"},s=>{s&&s.code&&this.isEnabled&&this.applyRemoteCodeToPage(s.code,s.language||"python",s.lastEditedBy,1,1)})}injectMainWorldBridge(){var i,o;if(!(typeof document>"u")&&((i=document.documentElement)==null?void 0:i.getAttribute("data-synqto-bridge"))!=="active"&&!document.getElementById("synqto-inpage-editor-bridge"))try{if(typeof chrome<"u"&&((o=chrome.runtime)!=null&&o.getURL)){const s=document.createElement("script");s.id="synqto-inpage-editor-bridge",s.src=chrome.runtime.getURL("content/in-page-bridge.js"),s.async=!0,(document.head||document.documentElement).appendChild(s)}}catch(s){console.warn("[Synqto] Could not inject in-page editor bridge:",s)}}setupPageMessageListeners(){window.addEventListener("message",i=>{var e,t;if(!i.data||i.data.source!=="SYNQTO_EDITOR_BRIDGE")return;const{type:o,payload:s}=i.data;if(this.isEnabled){if(o==="LOCAL_CODE_CHANGED"){const{code:b,line:a,col:c,language:r}=s;b!==this.lastSentCode&&(this.lastSentCode=b,this.lastSentCursor={line:a,ch:c},typeof chrome<"u"&&((e=chrome.runtime)!=null&&e.sendMessage)&&chrome.runtime.sendMessage({type:"CODE_DELTA_LOCAL",payload:{code:b,cursorLine:a,cursorCol:c,language:r||"python"}}).catch(()=>{}))}else if(o==="LOCAL_CURSOR_MOVED"){const{line:b,ch:a}=s;(b!==this.lastSentCursor.line||a!==this.lastSentCursor.ch)&&(this.lastSentCursor={line:b,ch:a},typeof chrome<"u"&&((t=chrome.runtime)!=null&&t.sendMessage)&&chrome.runtime.sendMessage({type:"CODE_CURSOR_LOCAL",payload:{line:b,ch:a}}).catch(()=>{}))}}})}setupRuntimeListeners(){var i;typeof chrome>"u"||!((i=chrome.runtime)!=null&&i.onMessage)||chrome.runtime.onMessage.addListener(o=>{if(this.isEnabled){if(o.type==="CODE_DELTA_REMOTE"||o.type==="CODE_SYNC_REMOTE"){const{code:s,language:e,cursorLine:t,cursorCol:b,sender:a,lastEditedBy:c}=o.payload;this.applyRemoteCodeToPage(s,e,(a==null?void 0:a.nickname)||c||"Peer",t||1,b||1),a&&(this.activePeers.set(a.peerId,{peerId:a.peerId,nickname:a.nickname,color:a.color||"#3b82f6",line:t||1,ch:b||1,lastActive:Date.now()}),this.updateFloatingDock())}else if(o.type==="CODE_CURSOR_REMOTE"){const{peerId:s,nickname:e,color:t,line:b,ch:a}=o.payload;this.applyRemoteCursorToPage(s,e,t,b,a),this.activePeers.set(s,{peerId:s,nickname:e,color:t||"#3b82f6",line:b,ch:a,lastActive:Date.now()}),this.updateFloatingDock()}}})}applyRemoteCodeToPage(i,o,s,e,t){this.lastSentCode=i,window.postMessage({source:"SYNQTO_CONTENT_SCRIPT",type:"APPLY_REMOTE_CODE",payload:{code:i,language:o,cursorLine:e,cursorCol:t,sender:s}},"*")}applyRemoteCursorToPage(i,o,s,e,t){window.postMessage({source:"SYNQTO_CONTENT_SCRIPT",type:"APPLY_REMOTE_CURSOR",payload:{peerId:i,nickname:o,color:s,line:e,ch:t}},"*")}renderFloatingDock(){this.containerEl&&this.containerEl.remove();const i=document.createElement("div");i.id="synqto-code-together-dock",i.style.cssText=`
      position: fixed !important;
      top: 16px !important;
      right: 90px !important;
      z-index: 2147483640 !important;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, monospace !important;
      display: flex !important;
      align-items: center !important;
      gap: 6px !important;
      padding: 5px 10px !important;
      border-radius: 9999px !important;
      background: linear-gradient(135deg, rgba(15, 23, 42, 0.95), rgba(30, 41, 59, 0.95)) !important;
      border: 1px solid ${this.isEnabled?"rgba(99, 102, 241, 0.45)":"rgba(255, 255, 255, 0.12)"} !important;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.4) !important;
      color: #ffffff !important;
      font-size: 11px !important;
      font-weight: 700 !important;
      cursor: pointer !important;
      backdrop-filter: blur(16px) !important;
      user-select: none !important;
      transition: all 0.2s ease !important;
    `,document.body.appendChild(i),this.containerEl=i,i.addEventListener("click",()=>{this.toggleCodeTogether()}),this.updateFloatingDock()}updateFloatingDock(){if(!this.containerEl)return;const i=this.activePeers.size;this.containerEl.innerHTML=`
      <span style="font-size: 13px;">${this.isEnabled?"👥":"🔒"}</span>
      <span style="color: ${this.isEnabled?"#818cf8":"#94a3b8"};">Code Together:</span>
      <span style="padding: 1px 6px; border-radius: 10px; font-size: 10px; background: ${this.isEnabled?"rgba(16, 185, 129, 0.2)":"rgba(255, 255, 255, 0.08)"}; color: ${this.isEnabled?"#34d399":"#94a3b8"};">
        ${this.isEnabled?i>0?`Synced (${i+1})`:"Active ⚡":"Solo"}
      </span>
      ${this.isEnabled&&i>0?`
        <div style="display:flex;align-items:center;gap:2px;margin-left:4px;">
          ${Array.from(this.activePeers.values()).map(o=>`
            <span style="display:inline-block;width:7px;height:7px;border-radius:50%;background:${o.color||"#3b82f6"};box-shadow:0 0 6px ${o.color||"#3b82f6"};" title="${o.nickname} (line ${o.line}, col ${o.ch})"></span>
          `).join("")}
        </div>
      `:""}
    `,this.containerEl.style.borderColor=this.isEnabled?"rgba(99, 102, 241, 0.5)":"rgba(255, 255, 255, 0.12)"}toggleCodeTogether(){var i;this.isEnabled=!this.isEnabled,typeof chrome<"u"&&((i=chrome.storage)!=null&&i.local)&&chrome.storage.local.set({synqto_code_together_enabled:this.isEnabled}),this.updateFloatingDock()}startCursorCleanup(){this.cleanupInterval&&clearInterval(this.cleanupInterval),this.cleanupInterval=setInterval(()=>{const i=Date.now();let o=!1;this.activePeers.forEach((s,e)=>{i-s.lastActive>15e3&&(this.activePeers.delete(e),window.postMessage({source:"SYNQTO_CONTENT_SCRIPT",type:"REMOVE_PEER_CURSOR",payload:{peerId:e}},"*"),o=!0)}),o&&this.updateFloatingDock()},4e3)}}console.log("[Synqto] Content script initialized on:",window.location.href),new K(T=>{var i;try{typeof chrome<"u"&&((i=chrome.runtime)!=null&&i.sendMessage)&&chrome.runtime.sendMessage({type:"PROBLEM_DETECTED",payload:T})}catch{}}),new X,new J,new ee})();
