const _ = "nerd_buddy_keepalive";
let a = null;
chrome.alarms.create(_, { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener((e) => {
  e.name === _ && u();
});
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: !0 }).catch((e) => console.error(e));
chrome.tabs.onActivated.addListener(async (e) => {
  try {
    const t = await chrome.tabs.get(e.tabId);
    t.url && chrome.storage.local.set({ nerd_buddy_active_url: t.url });
  } catch {
  }
});
chrome.tabs.onUpdated.addListener((e, t, n) => {
  n.active && t.url && chrome.storage.local.set({ nerd_buddy_active_url: t.url });
});
chrome.runtime.onMessage.addListener((e, t, n) => {
  var r, c, o, d, s;
  if (e.type === "PROBLEM_DETECTED")
    (r = t.tab) != null && r.active && chrome.storage.local.set({
      nerd_buddy_active_problem: e.payload,
      nerd_buddy_active_url: e.payload.url
    });
  else if (e.type === "LOCAL_CURSOR_MOVE" || e.type === "LOCAL_CLICK_PULSE" || e.type === "WHITEBOARD_STROKE_LOCAL" || e.type === "WHITEBOARD_CLEAR_LOCAL" || e.type === "WHITEBOARD_UNDO_LOCAL")
    chrome.runtime.sendMessage(e).catch(() => {
    });
  else if (e.type === "OPEN_SIDEPANEL") {
    const l = (c = t.tab) == null ? void 0 : c.id, i = (o = t.tab) == null ? void 0 : o.windowId;
    return l && ((d = chrome.sidePanel) != null && d.open) ? chrome.sidePanel.open({ tabId: l }).catch(() => {
      i && chrome.sidePanel.open({ windowId: i }).catch(() => {
      });
    }) : i && ((s = chrome.sidePanel) != null && s.open) && chrome.sidePanel.open({ windowId: i }).catch(() => {
    }), chrome.storage.local.set({ nerd_buddy_sidepanel_open: !0 }), n({ success: !0 }), !0;
  } else e.type === "SEND_PAGE_CHAT_MESSAGE" && chrome.runtime.sendMessage(e).catch(() => {
  });
  return !0;
});
chrome.storage.onChanged.addListener((e, t) => {
  var n;
  if (t === "local" && (e.synqto_fab_settings || e.nerd_buddy_fab_settings)) {
    const r = (n = e.synqto_fab_settings || e.nerd_buddy_fab_settings) == null ? void 0 : n.newValue;
    r && chrome.tabs.query({}, (c) => {
      c.forEach((o) => {
        o.id && chrome.tabs.sendMessage(o.id, {
          type: "FAB_SETTINGS_UPDATED",
          payload: r
        }).catch(() => {
        });
      });
    });
  }
});
async function u() {
  const e = "offscreen.html";
  if (!((await chrome.runtime.getContexts({
    contextTypes: ["OFFSCREEN_DOCUMENT"],
    documentUrls: [chrome.runtime.getURL(e)]
  })).length > 0)) {
    if (a) {
      await a;
      return;
    }
    a = chrome.offscreen.createDocument({
      url: e,
      reasons: ["WEB_RTC"],
      justification: "Maintain P2P presence and notifications when sidepanel is closed"
    }), await a, a = null;
  }
}
u();
