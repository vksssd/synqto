(function(){"use strict";function Z(S){let i=2166136261,t=2166136261;for(let e=0;e<S.length;e++){const a=S.charCodeAt(e);i=Math.imul(i^a&255,16777619),t=Math.imul(t^a>>8,16777619)}return((i>>>0^t>>>0)>>>0).toString(16).padStart(8,"0")}function J(S,i){let t=null;return(...o)=>{t&&clearTimeout(t),t=setTimeout(()=>S(...o),i)}}function j(S,i){var t;try{const o=new URL(S),e=o.hostname.toLowerCase(),a=o.pathname;if(e.includes("leetcode.com")||e.includes("leetcode.cn")){const r=a.match(/\/problems\/([a-zA-Z0-9-_]+)/);if(r&&r[1]){const c=r[1],u=W(c),M=e.includes("leetcode.cn")?"leetcode.cn":"leetcode.com";return{platform:"LeetCode",slug:c,title:u,url:S,canonicalUrl:`https://${M}/problems/${c}/`}}}if(e.includes("neetcode.io")){const r=a.match(/\/problems\/([a-zA-Z0-9-_]+)/);if(r&&r[1]){const c=r[1],u=W(c);return{platform:"NeetCode",slug:c,title:u,url:S,canonicalUrl:`https://neetcode.io/problems/${c}`}}}if(e.includes("codeforces.com")||e.includes("codeforces.net")){const r=a.match(/\/(?:contest\/(\d+)\/problem|problemset\/problem\/(\d+)|gym\/(\d+)\/problem)\/([a-zA-Z0-9]+)/i);if(r){const c=r[1]||r[2]||r[3],u=r[4].toUpperCase();return{platform:"Codeforces",slug:`cf-${c}-${u}`,title:`Codeforces ${c}${u}`,url:S,canonicalUrl:`https://codeforces.com/problemset/problem/${c}/${u}`}}}if(e.includes("atcoder.jp")){const r=a.match(/\/contests\/([a-zA-Z0-9-_]+)\/tasks\/([a-zA-Z0-9-_]+)/);if(r){const c=r[1],u=r[2];return{platform:"AtCoder",slug:`atcoder-${u}`,title:W(u),url:S,canonicalUrl:`https://atcoder.jp/contests/${c}/tasks/${u}`}}}if(e.includes("hackerrank.com")){const r=a.match(/\/challenges\/([a-zA-Z0-9-_]+)/);if(r&&r[1]){const c=r[1];return{platform:"HackerRank",slug:c,title:W(c),url:S,canonicalUrl:`https://www.hackerrank.com/challenges/${c}/problem`}}}if(e.includes("codechef.com")){const r=a.match(/\/problems\/([a-zA-Z0-9-_]+)/);if(r&&r[1]){const c=r[1];return{platform:"CodeChef",slug:c,title:`CodeChef ${c}`,url:S,canonicalUrl:`https://www.codechef.com/problems/${c}`}}}if(e.includes("geeksforgeeks.org")){const r=a.match(/\/problems\/([a-zA-Z0-9-_]+)/);if(r&&r[1]){const c=r[1],u=c.replace(/-\d{6,}$/,"");return{platform:"GeeksforGeeks",slug:c,title:W(u),url:S,canonicalUrl:`https://www.geeksforgeeks.org/problems/${c}/1`}}}if(e.includes("youtube.com")||e.includes("youtu.be")){let r=o.searchParams.get("v");if(!r&&e.includes("youtu.be")&&(r=a.slice(1)),!r&&a.includes("/shorts/")&&(r=(t=a.split("/shorts/")[1])==null?void 0:t.split("/")[0]),r){const c=i?ee(i):`YouTube Video (${r})`;return{platform:"YouTube",slug:`yt-${r}`,title:c,url:S,canonicalUrl:`https://www.youtube.com/watch?v=${r}`}}}if(e.includes("arxiv.org")){const r=a.match(/\/(?:abs|pdf)\/(\d+\.\d+(?:v\d+)?)/);if(r&&r[1]){const c=r[1];return{platform:"ArXiv",slug:`arxiv-${c.replace(/\./g,"-")}`,title:i?te(i):`ArXiv ${c}`,url:S,canonicalUrl:`https://arxiv.org/abs/${c}`}}}if(e.includes("github.com")){const r=a.match(/^\/([^\/]+)\/([^\/]+)\/(?:issues|pull)\/(\d+)/);if(r){const c=r[1],u=r[2],M=r[3];return{platform:"GitHub",slug:`gh-${c}-${u}-${M}`,title:`${c}/${u} #${M}`,url:S,canonicalUrl:`https://github.com/${c}/${u}/issues/${M}`}}}return{platform:"Web",slug:e.replace(/\./g,"-")||"general-study",title:i||e||"General Study Room",url:S,canonicalUrl:S}}catch{return null}}function W(S){return S.split(/[-_]/).map(i=>i.charAt(0).toUpperCase()+i.slice(1)).join(" ")}function ee(S){return S.replace(/\s*-\s*YouTube\s*$/,"").trim()}function te(S){return S.replace(/^\[[^\]]+\]\s*/,"").replace(/\s*-\s*arXiv.*$/,"").trim()}function G(){try{return!!(typeof chrome<"u"&&chrome.runtime&&chrome.runtime.id)}catch{return!1}}class ie{constructor(i){this.lastUrl="",this.lastTitle="",this.mutationObserver=null,this.pollTimer=null,this.debouncedCheck=J(()=>{if(!G()){this.destroy();return}this.checkCurrentPage()},250),this.callback=i,this.init()}init(){if(this.checkCurrentPage(),typeof window<"u"&&window.history){const i=window.history.pushState,t=window.history.replaceState;typeof i=="function"&&(window.history.pushState=(...o)=>{i.apply(window.history,o),this.debouncedCheck()}),typeof t=="function"&&(window.history.replaceState=(...o)=>{t.apply(window.history,o),this.debouncedCheck()})}if(typeof window<"u"&&(window.addEventListener("popstate",()=>this.debouncedCheck()),window.addEventListener("hashchange",()=>this.debouncedCheck()),window.addEventListener("yt-navigate-finish",()=>this.debouncedCheck())),typeof MutationObserver<"u"&&typeof document<"u"){this.mutationObserver=new MutationObserver(()=>{document.title!==this.lastTitle&&this.debouncedCheck()});const i=document.querySelector("title");i&&this.mutationObserver.observe(i,{subtree:!0,characterData:!0,childList:!0})}this.pollTimer=setInterval(()=>{if(!G()){this.destroy();return}window.location.href!==this.lastUrl&&this.checkCurrentPage()},1500)}checkCurrentPage(){const i=window.location.href,t=document.title;if(i===this.lastUrl&&t===this.lastTitle)return;this.lastUrl=i,this.lastTitle=t;const o=j(i,t);o&&this.callback(o)}destroy(){this.mutationObserver&&(this.mutationObserver.disconnect(),this.mutationObserver=null),this.pollTimer&&(clearInterval(this.pollTimer),this.pollTimer=null)}}function F(){try{return!!(typeof chrome<"u"&&chrome.runtime&&chrome.runtime.id)}catch{return!1}}class oe{constructor(){this.container=null,this.cursorElements=new Map,this.cursorTimeouts=new Map,this.myIdentity=null,this.liveStage=null,this.createContainer(),this.loadState(),this.listenToStorage(),this.listenForMessages(),this.setupLocalTrackers()}async loadState(){var i;if(typeof chrome<"u"&&((i=chrome.storage)!=null&&i.local))try{const t=await chrome.storage.local.get(["nerd_buddy_identity","synqme_identity","nerd_buddy_live_stage","synqme_live_stage"]);this.myIdentity=t.synqme_identity||t.nerd_buddy_identity||null,this.liveStage=t.synqme_live_stage||t.nerd_buddy_live_stage||null,(!this.liveStage||!this.liveStage.isActive)&&this.clearAllCursors()}catch{}}listenToStorage(){var i;typeof chrome<"u"&&((i=chrome.storage)!=null&&i.onChanged)&&chrome.storage.onChanged.addListener((t,o)=>{o==="local"&&((t.synqme_identity||t.nerd_buddy_identity)&&(this.myIdentity=(t.synqme_identity||t.nerd_buddy_identity).newValue),(t.synqme_live_stage||t.nerd_buddy_live_stage)&&(this.liveStage=(t.synqme_live_stage||t.nerd_buddy_live_stage).newValue,(!this.liveStage||!this.liveStage.isActive)&&this.clearAllCursors()))})}clearAllCursors(){this.cursorTimeouts.forEach(i=>clearTimeout(i)),this.cursorTimeouts.clear(),this.cursorElements.forEach(i=>{i.remove()}),this.cursorElements.clear(),this.container&&(this.container.innerHTML="")}isLocalUserOnStage(){var t,o;if(!this.liveStage||!this.liveStage.isActive)return!1;const i=(t=this.myIdentity)==null?void 0:t.peerId;return i?!!(((o=this.liveStage.tutorIdentity)==null?void 0:o.peerId)===i||this.liveStage.tutorPeerId===i||this.liveStage.myRole==="tutor"||Array.isArray(this.liveStage.guestSpeakers)&&this.liveStage.guestSpeakers.some(e=>e.peerId===i)):!1}createContainer(){var t;if(document.getElementById("nerd-buddy-cursor-overlay"))return;if(!document.body){document.readyState==="loading"?document.addEventListener("DOMContentLoaded",()=>this.createContainer(),{once:!0}):window.addEventListener("load",()=>this.createContainer(),{once:!0});return}const i=document.createElement("div");if(i.id="nerd-buddy-cursor-overlay",i.style.cssText=`
      position: fixed !important;
      top: 0 !important;
      left: 0 !important;
      width: 100vw !important;
      height: 100vh !important;
      pointer-events: none !important;
      z-index: 2147483645 !important;
      overflow: hidden !important;
      box-sizing: border-box !important;
    `,document.body.appendChild(i),this.container=i,!document.getElementById("nerd-buddy-cursor-styles")){const o=document.createElement("style");o.id="nerd-buddy-cursor-styles",o.textContent=`
        @keyframes nb-click-ripple {
          0% { transform: scale(0.15); opacity: 1; }
          40% { opacity: 0.9; }
          100% { transform: scale(2.8); opacity: 0; }
        }
      `,(t=document.head||document.documentElement||document.body)==null||t.appendChild(o)}}listenForMessages(){var i;if(!(!F()||!((i=chrome.runtime)!=null&&i.onMessage)))try{chrome.runtime.onMessage.addListener(t=>{var o,e,a,d;if(F()){if(t.type==="NERD_BUDDY_STAGE_ENDED"||t.type==="NERD_BUDDY_STAGE_INACTIVE"){this.clearAllCursors();return}if(t.type==="NERD_BUDDY_CURSOR_UPDATE"&&t.cursor){const r=t.cursor;(r.isTutor||this.liveStage&&(((o=this.liveStage.tutorIdentity)==null?void 0:o.peerId)===r.peerId||this.liveStage.tutorPeerId===r.peerId||((e=this.liveStage.guestSpeakers)==null?void 0:e.some(u=>u.peerId===r.peerId)))||!this.liveStage)&&this.renderCursor(r)}else if(t.type==="NERD_BUDDY_CLICK_PULSE"&&t.click){const r=t.click;(r.isTutor||this.liveStage&&(((a=this.liveStage.tutorIdentity)==null?void 0:a.peerId)===r.peerId||this.liveStage.tutorPeerId===r.peerId||((d=this.liveStage.guestSpeakers)==null?void 0:d.some(u=>u.peerId===r.peerId)))||r.isTutor||!this.liveStage)&&this.renderClickPulse(r)}}})}catch{}}renderCursor(i){if(this.container||this.createContainer(),!this.container)return;let t=this.cursorElements.get(i.peerId);if(!t){t=document.createElement("div"),t.style.cssText=`
        position: fixed !important;
        left: 0 !important;
        top: 0 !important;
        pointer-events: none !important;
        transform: translate3d(0px, 0px, 0) !important;
        will-change: transform !important;
        transition: transform 0.05s linear, opacity 0.3s ease !important;
        display: flex !important;
        align-items: center !important;
        gap: 5px !important;
        opacity: 1 !important;
        z-index: 2147483646 !important;
      `;const M=document.createElement("div"),w=document.createElement("div");t.appendChild(M),t.appendChild(w),this.container.appendChild(t),this.cursorElements.set(i.peerId,t)}const o=Math.max(0,Math.min(window.innerWidth-30,i.xPct/100*window.innerWidth)),e=Math.max(0,Math.min(window.innerHeight-30,i.yPct/100*window.innerHeight));t.style.transform=`translate3d(${o}px, ${e}px, 0)`,t.style.opacity="1";const a=i.isTutor?"#8b5cf6":i.color||"#6366f1",d=t.firstElementChild,r=t.lastElementChild;d&&t._lastColor!==a&&(t._lastColor=a,d.style.cssText=`
        width: 18px;
        height: 18px;
        border-radius: 50%;
        background: ${a};
        box-shadow: 0 0 16px ${a}, 0 0 6px #ffffff;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 11px;
        color: #fff;
        border: 2px solid #ffffff;
      `,r.style.cssText=`
        background: rgba(15, 23, 42, 0.92);
        border: 1px solid ${a};
        color: #f8fafc;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        font-size: 10px;
        font-weight: 600;
        padding: 2px 6px;
        border-radius: 4px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.6);
        white-space: nowrap;
      `),d&&(d.textContent=i.avatar||"👑"),r&&(r.textContent=`${i.nickname} ${i.isTutor?"🎓 (Tutor)":"🎤 (Speaker)"}`);const c=this.cursorTimeouts.get(i.peerId);c&&clearTimeout(c);const u=window.setTimeout(()=>{t&&(t.style.opacity="0")},4e3);this.cursorTimeouts.set(i.peerId,u)}renderClickPulse(i){if(this.container||this.createContainer(),!this.container)return;const t=i.xPct/100*window.innerWidth,o=i.yPct/100*window.innerHeight,e=document.createElement("div"),a=i.color||(i.isTutor?"#8b5cf6":"#6366f1");e.style.cssText=`
      position: fixed !important;
      left: ${t-22}px !important;
      top: ${o-22}px !important;
      width: 44px !important;
      height: 44px !important;
      border-radius: 50% !important;
      border: 3px solid ${a} !important;
      box-shadow: 0 0 16px ${a}, inset 0 0 8px ${a} !important;
      pointer-events: none !important;
      z-index: 2147483647 !important;
      box-sizing: border-box !important;
      animation: nb-click-ripple 0.85s cubic-bezier(0.1, 0.8, 0.3, 1) forwards !important;
    `,this.container.appendChild(e),setTimeout(()=>{e.remove()},900)}setupLocalTrackers(){let i=0;window.addEventListener("mousemove",t=>{if(!F()||!this.isLocalUserOnStage())return;const o=Date.now();if(o-i<40)return;i=o;const e=t.clientX/window.innerWidth*100,a=t.clientY/window.innerHeight*100;try{chrome.runtime.sendMessage({type:"LOCAL_CURSOR_MOVE",xPct:e,yPct:a}).catch(()=>{})}catch{}}),window.addEventListener("click",t=>{var a,d,r;if(!F()||!this.isLocalUserOnStage())return;const o=t.clientX/window.innerWidth*100,e=t.clientY/window.innerHeight*100;this.renderClickPulse({peerId:((a=this.myIdentity)==null?void 0:a.peerId)||"local",nickname:((d=this.myIdentity)==null?void 0:d.nickname)||"You",xPct:o,yPct:e,color:((r=this.myIdentity)==null?void 0:r.color)||"#8b5cf6",isTutor:!0,timestamp:Date.now()});try{chrome.runtime.sendMessage({type:"LOCAL_CLICK_PULSE",xPct:o,yPct:e}).catch(()=>{})}catch{}})}}const U={mode:"all_sites",showMainFab:!0,showTimerFab:!0,showCodeTogetherDock:!1,clickAction:"open_popup",customDomains:["leetcode.com","neetcode.io","codeforces.com","hackerrank.com","geeksforgeeks.org","codechef.com","atcoder.jp","localhost","127.0.0.1"],enableWhiteboard:!0,enableTimer:!0,popupContentMode:"both",positionMode:"permanent",savedPosition:{right:24,bottom:24},savedMainPosition:{right:24,bottom:24},savedTimerPosition:{right:140,bottom:24},savedCodeTogetherPosition:{top:16,right:90},whiteboardPrefs:{defaultPrivacyMode:"personal",defaultBackgroundType:"grid",defaultBgColor:"#090d16",defaultPenColor:"#6366f1",defaultPenWidth:4,disappearingInkDurationSec:3,autoSavePersonalNotebook:!0}},z="nerd_buddy_fab_settings",q="synqto_fab_settings";function se(S,i){const t=S.toLowerCase().replace(/[^a-z0-9-_]/g,"-").slice(0,24).replace(/-+$/,""),o=(i||"").trim().toLowerCase().replace(/\/+$/,""),e=Z(o||i||"lobby");return`room:${t||"lobby"}-${e}`}function re(S){switch(S.toLowerCase()){case"leetcode":return"#FFA116";case"neetcode":return"#8B5CF6";case"codeforces":return"#318CE7";case"hackerrank":return"#2EC866";case"codechef":return"#5B4638";case"geeksforgeeks":return"#2F8D46";case"youtube":return"#FF0000";case"arxiv":return"#B31B1B";case"github":return"#24292F";case"group":return"#8B5CF6";default:return"#6366F1"}}const K={enabled:!1,workDurationMin:25,shortBreakMin:5,longBreakMin:15,autoStartBreaks:!1,soundAlerts:!0},H="synqto_pomodoro_config",O="synqto_pomodoro_state";function Y(S){if(S.geometry){const i=Math.min(S.geometry.x1,S.geometry.x2),t=Math.max(S.geometry.x1,S.geometry.x2),o=Math.min(S.geometry.y1,S.geometry.y2),e=Math.max(S.geometry.y1,S.geometry.y2);return{minX:i,minY:o,maxX:t,maxY:e}}if(S.points&&S.points.length>0){let i=1/0,t=1/0,o=-1/0,e=-1/0;for(const a of S.points)a.x<i&&(i=a.x),a.x>o&&(o=a.x),a.y<t&&(t=a.y),a.y>e&&(e=a.y);return{minX:i,minY:t,maxX:o,maxY:e}}return{minX:0,minY:0,maxX:0,maxY:0}}function ae(S,i){const t=Math.min(i.x1,i.x2),o=Math.max(i.x1,i.x2),e=Math.min(i.y1,i.y2),a=Math.max(i.y1,i.y2),d=Y(S);return!(d.maxX<t||d.minX>o||d.maxY<e||d.minY>a)}function N(S,i,t){const o={...S};return o.geometry&&(o.geometry={...o.geometry,x1:o.geometry.x1+i,y1:o.geometry.y1+t,x2:o.geometry.x2+i,y2:o.geometry.y2+t}),o.points&&o.points.length>0&&(o.points=o.points.map(e=>({x:e.x+i,y:e.y+t}))),o}class ne{constructor(){this.hostElement=null,this.shadow=null,this.isOpen=!1,this.settings=U,this.currentProblem=null,this.messages=[],this.unreadCount=0,this.currentRoomStorageKey="",this.myIdentity=null,this.liveStage=null,this.peerCount=1,this.isServerConnected=!0,this.serverToastMessage=null,this.replyingTo=null,this.revealedSpoilers={},this.currentPosition={right:24,bottom:24},this.isDragging=!1,this.dragMoved=!1,this.popupSize="compact",this.activeTab="chat",this.isTimerOpen=!1,this.timerConfig=K,this.timerState={mode:"pomodoro",timeLeftSec:1500,targetDurationSec:1500,isRunning:!1,sessionsCompleted:0,lastUpdated:Date.now()},this.timerInterval=null,this.wbTool="pen",this.wbShowShapesDrawer=!1,this.wbShowDsaDrawer=!1,this.wbShowArchDrawer=!1,this.wbShowThemesDrawer=!1,this.toolStyles={select:{color:"#6366f1",width:3},hand:{color:"#6366f1",width:3},pen:{color:"#6366f1",width:3},brush:{color:"#06b6d4",width:6},highlighter:{color:"#f59e0b",width:16},temp_pen:{color:"#38bdf8",width:3},laser:{color:"#ef4444",width:3},torch:{color:"#facc15",width:65},eraser:{color:"#ffffff",width:18},text:{color:"#ffffff",width:3},code_box:{color:"#38bdf8",width:2},line:{color:"#6366f1",width:3},arrow:{color:"#6366f1",width:3},arrow_bi:{color:"#6366f1",width:3},rect:{color:"#6366f1",width:3},rounded_rect:{color:"#6366f1",width:3},circle:{color:"#6366f1",width:3},triangle:{color:"#10b981",width:3},star:{color:"#f59e0b",width:3},decision_diamond:{color:"#f59e0b",width:3},tree_node:{color:"#10b981",width:3},sticky_note:{color:"#fef3c7",width:2},db_cylinder:{color:"#10b981",width:2.5},db_nosql:{color:"#34d399",width:2.5},cloud:{color:"#38bdf8",width:2.5},load_balancer:{color:"#f59e0b",width:2.5},message_queue:{color:"#a855f7",width:2.5},server_box:{color:"#818cf8",width:2.5},cache_mem:{color:"#f43f5e",width:2.5},dns_router:{color:"#38bdf8",width:2.5},firewall:{color:"#f43f5e",width:2.5},user_client:{color:"#3b82f6",width:2.5},mobile_client:{color:"#06b6d4",width:2.5},array_cells:{color:"#38bdf8",width:2.5},stack_lifo:{color:"#f59e0b",width:2.5},queue_fifo:{color:"#10b981",width:2.5},hashmap_table:{color:"#a855f7",width:2.5},two_pointers:{color:"#ec4899",width:2},cdn_edge:{color:"#06b6d4",width:2.5},object_storage:{color:"#f97316",width:2.5},auth_jwt:{color:"#eab308",width:2.5},websocket_gw:{color:"#6366f1",width:2.5},elasticsearch:{color:"#14b8a6",width:2.5},async_arrow:{color:"#a855f7",width:2},tradeoff_note:{color:"#facc15",width:2}},this.wbColor="#6366f1",this.wbWidth=3,this.wbTheme="grid",this.wbBgColor="#090d16",this.wbPrivacyMode="personal",this.wbStrokes=[],this.wbPersonalStrokes=[],this.wbPersonalTheme="grid",this.wbPersonalBgColor="#090d16",this.wbRedoStack=[],this.isWbDrawing=!1,this.wbCurrentPoints=[],this.wbStartPoint=null,this.tempDisappearingStrokes=[],this.wbLaserTrails=[],this.wbTorchPos=null,this.wbEraserPos=null,this.wbSelectedStrokeIds=[],this.wbSelectionBox=null,this.wbClipboardStrokes=[],this.wbIsMovingSelection=!1,this.wbDragStartCoords=null,this.wbIsMarqueeSelecting=!1,this.wbAnimationRafId=null,this.wbDrawRafScheduled=!1,this.wbPatternCache=new Map,this.themeSettings=null,this.init()}async init(){await this.loadIdentity(),await this.loadSettings(),await this.loadInPagePersonalBoard(),await this.loadServerConnectionStatus(),await this.loadTimerState(),this.startTimerTickLoop(),this.detectCurrentPageProblem(),this.checkVisibilityAndRender(),this.listenToStorageChanges(),this.listenForRuntimeMessages(),console.log("[Synqto] Floating widget initialized. State:",this.shouldShow()?"VISIBLE":"HIDDEN","Mode:",this.settings.mode)}async loadServerConnectionStatus(){var i;if(typeof chrome<"u"&&((i=chrome.storage)!=null&&i.local))try{const t=await chrome.storage.local.get(["synqto_server_connected","nerd_buddy_server_connected"]);this.isServerConnected=!!(t.synqto_server_connected??t.nerd_buddy_server_connected??!0)}catch{this.isServerConnected=!0}}async loadIdentity(){var i;if(typeof chrome<"u"&&((i=chrome.storage)!=null&&i.local)){const t=await chrome.storage.local.get(["synqto_identity","nerd_buddy_identity"]);this.myIdentity=t.synqto_identity||t.nerd_buddy_identity||null}}async loadInPagePersonalBoard(){var i;if(typeof chrome<"u"&&((i=chrome.storage)!=null&&i.local))try{const t=await chrome.storage.local.get(["synqto_inpage_personal_board","synqto_wb_privacy_mode"]);if(t.synqto_inpage_personal_board){const o=t.synqto_inpage_personal_board;Array.isArray(o.strokes)&&(this.wbPersonalStrokes=o.strokes),o.theme&&(this.wbPersonalTheme=o.theme),o.bgColor&&(this.wbPersonalBgColor=o.bgColor)}t.synqto_wb_privacy_mode&&(this.wbPrivacyMode=t.synqto_wb_privacy_mode)}catch{}}saveInPagePersonalBoard(){var i;if(typeof chrome<"u"&&((i=chrome.storage)!=null&&i.local))try{chrome.storage.local.set({synqto_inpage_personal_board:{strokes:this.wbPersonalStrokes,theme:this.wbPersonalTheme,bgColor:this.wbPersonalBgColor},synqto_wb_privacy_mode:this.wbPrivacyMode})}catch{}}async loadSettings(){var i,t;if(typeof chrome<"u"&&((i=chrome.storage)!=null&&i.local)){const o=await chrome.storage.local.get([z,q,"synqto_theme_settings","synqto_collab_notebook","synqto_active_problem","nerd_buddy_active_problem","synqto_live_stage","nerd_buddy_live_stage","nerd_buddy_sidepanel_open","nerd_buddy_peer_count"]);if(o.synqto_theme_settings&&(this.themeSettings=o.synqto_theme_settings),o.synqto_collab_notebook&&Array.isArray(o.synqto_collab_notebook.pages)){const a=o.synqto_collab_notebook,d=a.pages.find(r=>r.id===a.activePageId)||a.pages[0];d&&(this.wbStrokes=d.strokes||[],d.background&&(this.wbTheme=d.background),d.bgColor&&(this.wbBgColor=d.bgColor))}(o[q]||o[z])&&(this.settings={...U,...o[q]||o[z]}),this.settings.positionMode==="permanent"&&this.settings.savedPosition?this.currentPosition={...this.settings.savedPosition}:this.currentPosition={right:24,bottom:24};const e=o.synqto_active_problem||o.nerd_buddy_active_problem;e&&(this.currentProblem=e,this.currentRoomStorageKey=`synqto_chat_${((t=this.currentProblem)==null?void 0:t.roomId)||""}`,await this.loadMessages()),(o.synqto_live_stage||o.nerd_buddy_live_stage)&&(this.liveStage=o.synqto_live_stage||o.nerd_buddy_live_stage),typeof o.nerd_buddy_peer_count=="number"&&(this.peerCount=Math.max(1,o.nerd_buddy_peer_count))}}detectCurrentPageProblem(){const i=j(window.location.href,document.title);if(i){const t=se(i.slug,i.canonicalUrl);this.currentProblem={platform:i.platform,slug:i.slug,title:i.title,canonicalUrl:i.canonicalUrl,roomId:t},this.currentRoomStorageKey=`synqto_chat_${t}`,this.loadMessages()}}shouldShow(){if(this.settings.mode==="disabled"||this.settings.popupContentMode==="none")return!1;if(this.settings.mode==="all_sites")return!0;const i=window.location.hostname.toLowerCase();if(this.settings.mode==="custom_sites")return this.settings.customDomains.some(a=>i.includes(a.toLowerCase()));const o=["leetcode.com","leetcode.cn","neetcode.io","codeforces.com","codeforces.net","hackerrank.com","geeksforgeeks.org","codechef.com","atcoder.jp","hackerearth.com","topcoder.com","spoj.com","codewars.com","exercism.org","github.com","youtube.com","arxiv.org","localhost","127.0.0.1"].some(a=>i.includes(a)),e=!!(this.currentProblem||j(window.location.href,document.title));return o||e}checkVisibilityAndRender(){const i=this.shouldShow();i&&!this.hostElement?this.createWidgetDOM():!i&&this.hostElement&&this.destroyWidgetDOM()}destroyWidgetDOM(){this.hostElement&&(this.hostElement.remove(),this.hostElement=null,this.shadow=null)}createWidgetDOM(){var e,a;if(document.getElementById("synqto-floating-host"))return;if(!document.body){document.readyState==="loading"?document.addEventListener("DOMContentLoaded",()=>this.checkVisibilityAndRender(),{once:!0}):window.addEventListener("load",()=>this.checkVisibilityAndRender(),{once:!0});return}const i=document.createElement("div");i.id="synqto-floating-host";const t=Number.isFinite((e=this.currentPosition)==null?void 0:e.right)?this.currentPosition.right:24,o=Number.isFinite((a=this.currentPosition)==null?void 0:a.bottom)?this.currentPosition.bottom:24;i.style.cssText=`
      position: fixed !important;
      bottom: ${o}px !important;
      right: ${t}px !important;
      z-index: 2147483647 !important;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif !important;
      touch-action: none !important;
      pointer-events: auto !important;
      display: block !important;
      visibility: visible !important;
      opacity: 1 !important;
    `,document.body.appendChild(i),this.hostElement=i,this.shadow=i.attachShadow({mode:"open"}),this.render()}applyHostPosition(){var a,d;if(!this.hostElement)return;const i=Number.isFinite((a=this.currentPosition)==null?void 0:a.right)?this.currentPosition.right:24,t=Number.isFinite((d=this.currentPosition)==null?void 0:d.bottom)?this.currentPosition.bottom:24,o=Math.max(10,Math.min(window.innerWidth-130,i)),e=Math.max(10,Math.min(window.innerHeight-55,t));this.hostElement.style.setProperty("right",`${o}px`,"important"),this.hostElement.style.setProperty("bottom",`${e}px`,"important")}render(){var D,E,R,n;if(!this.shadow)return;const i=this.settings.popupContentMode||(this.settings.enableWhiteboard?"both":"chat_only");if(i==="none"||this.settings.mode==="disabled"){this.destroyWidgetDOM();return}this.applyHostPosition();const t=!!(this.liveStage&&this.liveStage.isActive),o=((E=(D=this.liveStage)==null?void 0:D.tutorIdentity)==null?void 0:E.nickname)||"Tutor",e=((R=this.currentProblem)==null?void 0:R.title)||"Global Problem Lobby",a=((n=this.currentProblem)==null?void 0:n.platform)||"LeetCode",d=re(a),r=i==="whiteboard_only"||i==="both"&&this.activeTab==="whiteboard",c=i==="whiteboard_only"?"🎨":"⚡",u="synqto",M=this.currentPosition.bottom>window.innerHeight-540,w=this.currentPosition.right>window.innerWidth-420;this.shadow.innerHTML=`
      <style>
        :host {
          ${this.getThemeCSS()}
          --font-mono: 'JetBrains Mono', 'Fira Code', monospace;
        }

        * {
          box-sizing: border-box;
          margin: 0;
          padding: 0;
        }

        /* Floating Action Button (FAB) */
        .fab-button {
          position: relative;
          display: flex;
          align-items: center;
          gap: 7px;
          padding: 10px 14px;
          border-radius: 9999px;
          background: linear-gradient(135deg, #4f46e5, #7c3aed);
          border: 1px solid rgba(255, 255, 255, 0.2);
          box-shadow: 0 10px 25px -5px rgba(99, 102, 241, 0.5), 0 0 15px rgba(124, 58, 237, 0.3);
          color: #ffffff;
          font-size: 12px;
          font-weight: 700;
          cursor: grab;
          transition: transform 0.15s cubic-bezier(0.16, 1, 0.3, 1), box-shadow 0.15s;
          user-select: none;
        }

        .fab-button:active {
          cursor: grabbing;
        }

        .fab-button:hover {
          transform: translateY(-2px) scale(1.02);
          box-shadow: 0 14px 28px -5px rgba(99, 102, 241, 0.65), 0 0 20px rgba(124, 58, 237, 0.4);
        }

        .drag-grip {
          opacity: 0.5;
          font-size: 11px;
          cursor: grab;
        }

        .live-dot {
          width: 8px;
          height: 8px;
          border-radius: 50%;
          background: #ef4444;
          box-shadow: 0 0 10px #ef4444;
          animation: livePulse 1.5s infinite;
        }

        .timer-dot {
          width: 7px;
          height: 7px;
          border-radius: 50%;
          background: #f43f5e;
          box-shadow: 0 0 8px #f43f5e;
          animation: livePulse 1.2s infinite;
        }

        @keyframes livePulse {
          0%, 100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.4; transform: scale(1.2); }
        }

        @keyframes rocketThrust {
          0% { transform: translateY(0px) rotate(45deg); }
          100% { transform: translateY(-2px) rotate(52deg); }
        }

        @keyframes flameFlicker {
          0% { opacity: 0.7; transform: scale(0.85); }
          100% { opacity: 1; transform: scale(1.25); }
        }

        @keyframes neonTrackGlow {
          0% { box-shadow: 0 0 5px rgba(244, 63, 94, 0.4); }
          100% { box-shadow: 0 0 15px rgba(244, 63, 94, 0.8), 0 0 25px rgba(99, 102, 241, 0.5); }
        }

        /* Standalone Rocket Racing Focus Timer FAB */
        .timer-fab-button {
          position: relative;
          display: flex;
          align-items: center;
          gap: 8px;
          padding: 8px 14px;
          border-radius: 9999px;
          background: linear-gradient(135deg, #1e1035 0%, #0f172a 100%);
          border: 1px solid rgba(244, 63, 94, 0.55);
          box-shadow: 0 10px 25px -5px rgba(244, 63, 94, 0.45), 0 0 18px rgba(99, 102, 241, 0.3);
          color: #ffffff;
          font-size: 12px;
          font-weight: 700;
          cursor: pointer;
          transition: transform 0.15s cubic-bezier(0.16, 1, 0.3, 1), box-shadow 0.2s, border-color 0.2s;
          user-select: none;
          backdrop-filter: blur(16px);
        }

        .timer-fab-button:hover {
          transform: translateY(-2px) scale(1.03);
          box-shadow: 0 14px 28px -5px rgba(244, 63, 94, 0.65), 0 0 25px rgba(244, 63, 94, 0.5);
          border-color: rgba(244, 63, 94, 0.85);
        }

        .timer-fab-track {
          width: 52px;
          height: 6px;
          border-radius: 3px;
          background: rgba(255, 255, 255, 0.12);
          position: relative;
          overflow: hidden;
        }

        .timer-fab-fill {
          height: 100%;
          background: linear-gradient(90deg, #6366f1, #f43f5e);
          box-shadow: 0 0 8px rgba(244, 63, 94, 0.8);
          transition: width 0.4s ease;
        }

        .timer-fab-rocket {
          font-size: 13px;
          display: inline-block;
          filter: drop-shadow(0 0 6px rgba(244, 63, 94, 0.9));
        }

        .fab-badge {
          position: absolute;
          top: -4px;
          right: -4px;
          background: #f59e0b;
          color: #ffffff;
          font-size: 10px;
          font-weight: 700;
          padding: 2px 6px;
          border-radius: 9999px;
        }

        /* In-Page Popup Card */
        .popup-card {
          display: ${this.isOpen?"flex":"none"};
          flex-direction: column;
          position: absolute;
          ${M?"top: 52px; bottom: auto;":"bottom: 52px; top: auto;"}
          ${w?"left: 0; right: auto;":"right: 0; left: auto;"}
          width: ${this.popupSize==="fullscreen"?"min(1180px, 95vw)":this.popupSize==="large"?"min(860px, 92vw)":this.popupSize==="medium"?"min(620px, 88vw)":"420px"};
          height: ${this.popupSize==="fullscreen"?"min(880px, 92vh)":this.popupSize==="large"?"min(740px, 88vh)":this.popupSize==="medium"?"min(640px, 84vh)":"540px"};
          max-height: 94vh;
          max-width: 96vw;
          background: rgba(15, 23, 42, 0.97);
          border: 1px solid ${t?"rgba(239, 68, 68, 0.45)":"rgba(99, 102, 241, 0.35)"};
          border-radius: 16px;
          box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.9), 0 0 28px ${t?"rgba(239, 68, 68, 0.25)":"rgba(99, 102, 241, 0.25)"};
          backdrop-filter: blur(24px);
          -webkit-backdrop-filter: blur(24px);
          overflow: hidden;
          animation: slideIn 0.2s cubic-bezier(0.16, 1, 0.3, 1);
          color: var(--text-primary);
          transition: width 0.2s cubic-bezier(0.16, 1, 0.3, 1), height 0.2s cubic-bezier(0.16, 1, 0.3, 1);
        }

        /* Dedicated Standalone Timer & Pomodoro Popup Window */
        .timer-popup-card {
          display: ${this.isTimerOpen?"flex":"none"};
          flex-direction: column;
          position: absolute;
          ${M?"top: 52px; bottom: auto;":"bottom: 52px; top: auto;"}
          ${w?"left: 0; right: auto;":"right: 0; left: auto;"}
          width: 320px;
          background: rgba(15, 23, 42, 0.98);
          border: 1px solid rgba(244, 63, 94, 0.5);
          border-radius: 16px;
          box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.95), 0 0 28px rgba(244, 63, 94, 0.3);
          backdrop-filter: blur(24px);
          -webkit-backdrop-filter: blur(24px);
          z-index: 100;
          overflow: hidden;
          animation: slideIn 0.2s cubic-bezier(0.16, 1, 0.3, 1);
          color: var(--text-primary);
        }

        @keyframes slideIn {
          from { opacity: 0; transform: translateY(12px) scale(0.96); }
          to { opacity: 1; transform: translateY(0) scale(1); }
        }

        /* Room Header */
        .room-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 10px 12px;
          background: linear-gradient(135deg, rgba(30, 41, 59, 0.95), rgba(15, 23, 42, 0.95));
          border-bottom: 1px solid var(--border-subtle);
        }

        .room-info {
          display: flex;
          align-items: center;
          gap: 10px;
          overflow: hidden;
        }

        .platform-icon-box {
          width: 32px;
          height: 32px;
          border-radius: 8px;
          background: rgba(99, 102, 241, 0.15);
          border: 1px solid rgba(255, 255, 255, 0.1);
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 16px;
          flex-shrink: 0;
        }

        .problem-title {
          font-size: 13px;
          font-weight: 700;
          color: var(--text-primary);
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
          max-width: 170px;
        }

        .badges-row {
          display: flex;
          align-items: center;
          gap: 6px;
          margin-top: 2px;
        }

        .platform-pill {
          font-size: 9px;
          font-weight: 700;
          padding: 1px 6px;
          border-radius: 4px;
          background: ${d}20;
          border: 1px solid ${d}50;
          color: ${d};
          text-transform: uppercase;
        }

        .peer-count-pill {
          font-size: 10px;
          color: var(--text-secondary);
          display: flex;
          align-items: center;
          gap: 4px;
        }

        .header-actions {
          display: flex;
          align-items: center;
          gap: 4px;
        }

        .icon-btn {
          background: transparent;
          border: none;
          color: var(--text-secondary);
          cursor: pointer;
          padding: 5px;
          border-radius: 6px;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: all 0.15s;
        }

        .icon-btn:hover {
          background: rgba(255, 255, 255, 0.1);
          color: #ffffff;
        }

        /* Segmented View Switcher */
        .tab-switcher {
          display: flex;
          background: rgba(15, 23, 42, 0.9);
          padding: 3px 6px;
          border-bottom: 1px solid var(--border-subtle);
          gap: 4px;
        }

        .tab-btn {
          flex: 1;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 6px;
          padding: 5px 8px;
          font-size: 11px;
          font-weight: 600;
          border-radius: 6px;
          border: none;
          cursor: pointer;
          transition: all 0.15s;
          background: transparent;
          color: var(--text-muted);
        }

        .tab-btn.active {
          background: var(--primary);
          color: #ffffff;
        }

        /* Messages List */
        .message-list {
          flex: 1;
          overflow-y: auto;
          padding: 12px;
          display: flex;
          flex-direction: column;
          gap: 10px;
        }

        .chat-bubble {
          display: flex;
          flex-direction: column;
          max-width: 82%;
          min-width: 80px;
          padding: 6px 9px 4px 10px;
          border-radius: 9px;
          font-size: 12px;
          position: relative;
          word-break: break-word;
          line-height: 1.42;
          box-shadow: 0 1px 2px rgba(0, 0, 0, 0.16);
        }

        .chat-bubble.self {
          align-self: flex-end;
          background: linear-gradient(135deg, rgba(45, 212, 191, 0.18), rgba(20, 184, 166, 0.24));
          border: 1px solid rgba(45, 212, 191, 0.32);
          border-top-right-radius: 2px;
          color: var(--text-primary, #ffffff);
        }

        .chat-bubble.other {
          align-self: flex-start;
          background: var(--bg-surface-elevated, #1e2b2f);
          border: 1px solid var(--border-subtle);
          border-top-left-radius: 2px;
          color: var(--text-primary, #f1f5f9);
        }

        .wa-quote-box {
          background: rgba(0, 0, 0, 0.22);
          border-left: 3px solid var(--primary);
          border-radius: 4px;
          padding: 3px 6px;
          margin-bottom: 4px;
          font-size: 10px;
        }

        .chat-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 6px;
          margin-bottom: 2px;
          font-size: 10.5px;
        }

        .chat-author {
          font-weight: 700;
          display: flex;
          align-items: center;
          gap: 4px;
        }

        .chat-meta {
          display: inline-flex;
          align-items: center;
          gap: 3px;
          float: right;
          margin-left: 8px;
          margin-top: 3px;
          font-size: 9.5px;
          color: var(--text-dim, #94a3b8);
          user-select: none;
        }

        .ack-read {
          color: #38bdf8;
          font-weight: 700;
        }

        /* Whiteboard Toolbar & Canvas */
        .whiteboard-container {
          flex: 1;
          display: flex;
          flex-direction: column;
          background: #090d16;
          overflow: hidden;
          position: relative;
        }

        .wb-toolbar {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 6px 8px;
          background: rgba(15, 23, 42, 0.95);
          border-bottom: 1px solid var(--border-subtle);
          flex-wrap: wrap;
          gap: 4px;
        }

        .wb-tool-group {
          display: flex;
          gap: 3px;
          align-items: center;
        }

        .wb-tool-btn {
          padding: 4px 6px;
          border-radius: 4px;
          border: 1px solid transparent;
          background: transparent;
          color: var(--text-muted);
          cursor: pointer;
          font-size: 11px;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .wb-tool-btn.active {
          border-color: var(--primary);
          background: rgba(99, 102, 241, 0.25);
          color: #c7d2fe;
        }

        .wb-palette-bar {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 3px 8px;
          background: rgba(0, 0, 0, 0.3);
          border-bottom: 1px solid var(--border-subtle);
        }

        .color-dot {
          width: 13px;
          height: 13px;
          border-radius: 50%;
          border: 1px solid rgba(255, 255, 255, 0.2);
          cursor: pointer;
        }

        .color-dot.active {
          border: 2px solid #ffffff;
          box-shadow: 0 0 6px rgba(255, 255, 255, 0.5);
        }

        .size-pill {
          font-size: 9px;
          font-weight: 700;
          padding: 1px 4px;
          border-radius: 3px;
          background: rgba(255, 255, 255, 0.05);
          border: 1px solid transparent;
          color: var(--text-dim);
          cursor: pointer;
        }

        .size-pill.active {
          background: rgba(99, 102, 241, 0.3);
          border-color: var(--primary);
          color: #ffffff;
        }

        #nb-whiteboard-canvas {
          flex-grow: 1;
          width: 100%;
          height: 100%;
          cursor: crosshair;
          touch-action: none;
        }

        /* Input Composer */
        .composer-box {
          display: flex;
          align-items: center;
          gap: 6px;
          padding: 8px 10px;
          background: rgba(15, 23, 42, 0.95);
          border-top: 1px solid var(--border-subtle);
        }

        .input-glass {
          flex: 1;
          background: rgba(0, 0, 0, 0.4);
          border: 1px solid var(--border-subtle);
          border-radius: 8px;
          padding: 7px 10px;
          color: #ffffff;
          font-size: 11px;
          outline: none;
        }

        .input-glass:focus {
          border-color: var(--primary);
        }

        .btn-send {
          background: var(--primary);
          border: none;
          color: #ffffff;
          padding: 6px 10px;
          border-radius: 8px;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .prompt-pills-row {
          display: flex;
          gap: 4px;
          padding: 4px 8px;
          overflow-x: auto;
          background: rgba(0, 0, 0, 0.3);
          border-top: 1px solid var(--border-subtle);
        }

        .prompt-pill {
          background: rgba(255, 255, 255, 0.06);
          border: 1px solid var(--border-subtle);
          color: var(--text-secondary);
          font-size: 9px;
          font-weight: 600;
          padding: 2px 6px;
          border-radius: 4px;
          cursor: pointer;
          white-space: nowrap;
        }

        .prompt-pill:hover {
          background: rgba(99, 102, 241, 0.2);
          color: #ffffff;
        }
      </style>

      <!-- In-Page Popup Card Window -->
      <div class="popup-card" id="nb-popup-card">
        <!-- Room Header Bar -->
        <div class="room-header">
          <div class="room-info">
            <div class="platform-icon-box">⚡</div>
            <div>
              <div class="problem-title">${this.escapeHtml(e)}</div>
              <div class="badges-row">
                <span class="platform-pill">${a}</span>
                <span class="peer-count-pill" title="${this.isServerConnected?"Signaling Server: Connected (wss://synqto-server.onrender.com/ws/)":"Signaling Server: Disconnected (Offline Mode)"}">
                  <span style="display:inline-block;width:6px;height:6px;border-radius:50%;background:${this.isServerConnected?"#10b981":"#ef4444"};box-shadow:0 0 6px ${this.isServerConnected?"#10b981":"#ef4444"};"></span>
                  <span>${this.peerCount} Online ${this.isServerConnected?"":"(Offline)"}</span>
                </span>
              </div>
            </div>
          </div>

          <div class="header-actions">
            <!-- Popup Size Mode Switcher Pills -->
            <div class="popup-size-group" style="display:flex;gap:2px;align-items:center;background:rgba(0,0,0,0.35);padding:2px;border-radius:6px;border:1px solid rgba(255,255,255,0.08);margin-right:2px;">
              <button class="size-mode-pill ${this.popupSize==="compact"?"active":""}" data-popsize="compact" title="Compact Size (420x540)" style="font-size:9px;font-weight:700;padding:2px 5px;border-radius:4px;border:none;cursor:pointer;background:${this.popupSize==="compact"?"var(--primary)":"transparent"};color:${this.popupSize==="compact"?"#fff":"var(--text-muted)"};">📱 S</button>
              <button class="size-mode-pill ${this.popupSize==="medium"?"active":""}" data-popsize="medium" title="Medium Split Size (620x640)" style="font-size:9px;font-weight:700;padding:2px 5px;border-radius:4px;border:none;cursor:pointer;background:${this.popupSize==="medium"?"var(--primary)":"transparent"};color:${this.popupSize==="medium"?"#fff":"var(--text-muted)"};">🌗 M</button>
              <button class="size-mode-pill ${this.popupSize==="large"?"active":""}" data-popsize="large" title="Large Widescreen (860x740)" style="font-size:9px;font-weight:700;padding:2px 5px;border-radius:4px;border:none;cursor:pointer;background:${this.popupSize==="large"?"var(--primary)":"transparent"};color:${this.popupSize==="large"?"#fff":"var(--text-muted)"};">🖥️ L</button>
              <button class="size-mode-pill ${this.popupSize==="fullscreen"?"active":""}" data-popsize="fullscreen" title="Full Screen View (1180x880)" style="font-size:9px;font-weight:700;padding:2px 5px;border-radius:4px;border:none;cursor:pointer;background:${this.popupSize==="fullscreen"?"var(--primary)":"transparent"};color:${this.popupSize==="fullscreen"?"#fff":"var(--text-muted)"};">📺 XL</button>
            </div>

            <button class="icon-btn" id="nb-open-sidepanel" title="Open complete extension in side panel">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M15 3h6v6M10 14L21 3M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6"/>
              </svg>
            </button>
            <button class="icon-btn" id="nb-close-popup" title="Minimize">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M18 6L6 18M6 6l12 12"/>
              </svg>
            </button>
          </div>
        </div>

        <!-- Green Vanishing Toast on Server Connection Established -->
        ${this.serverToastMessage?`
          <div style="background:linear-gradient(135deg, rgba(16, 185, 129, 0.96), rgba(5, 150, 105, 0.96));color:#fff;padding:6px 10px;font-size:10.5px;font-weight:600;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid rgba(255,255,255,0.2);box-shadow:0 4px 12px rgba(16, 185, 129, 0.4);">
            <div style="display:flex;align-items:center;gap:6px;">
              <span>⚡</span>
              <span>${this.escapeHtml(this.serverToastMessage)}</span>
            </div>
            <span style="font-size:8.5px;background:rgba(0,0,0,0.25);padding:1px 5px;border-radius:3px;">P2P Active</span>
          </div>
        `:""}

        <!-- Red Offline Notice Banner when Server is Unreachable -->
        ${this.isServerConnected?"":`
          <div style="background:linear-gradient(135deg, #ef4444, #dc2626);color:#fff;padding:5px 10px;font-size:10px;font-weight:600;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid rgba(255,255,255,0.2);">
            <div style="display:flex;align-items:center;gap:5px;">
              <span>⚠️</span>
              <span>Server Offline (Local Mode)</span>
            </div>
            <button id="nb-offline-sidepanel-reconnect" style="background:rgba(0,0,0,0.3);color:#fff;border:1px solid rgba(255,255,255,0.25);padding:2px 6px;border-radius:4px;font-size:9px;font-weight:700;cursor:pointer;">
              Reconnect in Side Panel ⚡
            </button>
          </div>
        `}

        <!-- Segmented Switcher for Chat and Whiteboard -->
        <div class="tab-switcher" style="display:flex;border-bottom:1px solid var(--border-subtle);background:rgba(0,0,0,0.25);">
          <button class="tab-btn ${this.activeTab==="chat"?"active":""}" id="nb-tab-chat" style="flex:1;display:flex;align-items:center;justify-content:center;gap:5px;padding:8px 4px;font-size:11px;font-weight:600;background:transparent;border:none;border-bottom:2px solid ${this.activeTab==="chat"?"var(--primary)":"transparent"};color:${this.activeTab==="chat"?"#fff":"var(--text-muted)"};cursor:pointer;">
            <span>💬 Live Chat</span>
          </button>
          ${this.settings.enableWhiteboard?`
            <button class="tab-btn ${this.activeTab==="whiteboard"?"active":""}" id="nb-tab-whiteboard" style="flex:1;display:flex;align-items:center;justify-content:center;gap:5px;padding:8px 4px;font-size:11px;font-weight:600;background:transparent;border:none;border-bottom:2px solid ${this.activeTab==="whiteboard"?"var(--primary)":"transparent"};color:${this.activeTab==="whiteboard"?"#fff":"var(--text-muted)"};cursor:pointer;">
              <span>🎨 Whiteboard</span>
            </button>
          `:""}
        </div>

        <!-- Multi-Broadcaster Live Streams List -->
        ${t?`
          <div style="background:linear-gradient(135deg, rgba(239, 68, 68, 0.22), rgba(139, 92, 246, 0.18));border-bottom:1px solid rgba(239, 68, 68, 0.35);padding:6px 10px;display:flex;flex-direction:column;gap:5px;">
            <div style="display:flex;align-items:center;justify-content:space-between;font-size:10px;color:#fca5a5;">
              <div style="display:flex;align-items:center;gap:5px;font-weight:700;">
                <span class="live-dot"></span>
                <span>LIVE STREAMS (${this.liveStage.activeStreams&&this.liveStage.activeStreams.length||1}):</span>
              </div>
              <button id="nb-live-tunein" style="background:#ef4444;color:#fff;border:none;padding:2px 8px;border-radius:4px;font-size:9px;font-weight:700;cursor:pointer;">
                Open Side Panel 📺
              </button>
            </div>

            <div style="display:flex;gap:4px;overflow-x:auto;padding-bottom:2px;">
              ${(this.liveStage.activeStreams&&this.liveStage.activeStreams.length>0?this.liveStage.activeStreams:[{broadcasterIdentity:this.liveStage.tutorIdentity||{nickname:o,avatar:"👑"},title:`${o}'s Walkthrough`,broadcastType:this.liveStage.broadcastType||"screen"}]).map(g=>{var v,k;return`
                <div style="display:flex;align-items:center;gap:4px;padding:3px 6px;border-radius:4px;background:rgba(0,0,0,0.4);border:1px solid rgba(255,255,255,0.1);font-size:10px;color:#f8fafc;white-space:nowrap;">
                  <span>${((v=g.broadcasterIdentity)==null?void 0:v.avatar)||"👤"}</span>
                  <span style="font-weight:600;">${((k=g.broadcasterIdentity)==null?void 0:k.nickname)||"Streamer"}:</span>
                  <span style="color:#c7d2fe;max-width:110px;overflow:hidden;text-overflow:ellipsis;">${this.escapeHtml(g.title||"Live Stream")}</span>
                  <span style="font-size:8px;padding:1px 4px;border-radius:3px;background:rgba(239,68,68,0.3);color:#fca5a5;text-transform:uppercase;">${g.broadcastType||"live"}</span>
                </div>
              `}).join("")}
            </div>
          </div>
        `:""}

        <!-- Main Body: Whiteboard or Problem Chat Stream -->
        ${r?`
          <!-- Whiteboard View -->
          <div class="whiteboard-container">
            <div class="wb-toolbar">
              <div class="wb-tool-group" style="flex-wrap:wrap;gap:2px;">
                <button class="wb-tool-btn ${this.wbTool==="select"?"active":""}" data-wbtool="select" title="Select & Move (↖️)">↖️</button>
                <button class="wb-tool-btn ${this.wbTool==="hand"?"active":""}" data-wbtool="hand" title="Pan Canvas (✋)">✋</button>
                <button class="wb-tool-btn ${this.wbTool==="pen"?"active":""}" data-wbtool="pen" title="Fine Pen (✏️)">✏️</button>
                <button class="wb-tool-btn ${this.wbTool==="brush"?"active":""}" data-wbtool="brush" title="Brush Pen (✒️)">✒️</button>
                <button class="wb-tool-btn ${this.wbTool==="highlighter"?"active":""}" data-wbtool="highlighter" title="Translucent Highlighter (🖍️)">🖍️</button>
                <button class="wb-tool-btn ${this.wbTool==="temp_pen"?"active":""}" data-wbtool="temp_pen" title="⏳ Disappearing Ink (3s Fade)">⏳</button>
                <button class="wb-tool-btn ${this.wbTool==="laser"?"active":""}" data-wbtool="laser" title="Live Laser Pointer (🔴)">🔴</button>
                <button class="wb-tool-btn ${this.wbTool==="torch"?"active":""}" data-wbtool="torch" title="Spotlight Torch (🔦)">🔦</button>
                <button class="wb-tool-btn ${this.wbTool==="eraser"?"active":""}" data-wbtool="eraser" title="Precision Eraser (🧹)">🧹</button>
                <button class="wb-tool-btn ${this.wbTool==="text"?"active":""}" data-wbtool="text" title="Text Label (🔤)">🔤</button>

                <div style="width:1px;height:12px;background:var(--border-subtle);margin:0 1px;"></div>

                <!-- Drawer Toggles -->
                <button class="wb-drawer-toggle ${this.wbShowShapesDrawer?"active":""}" id="nb-wb-toggle-shapes" style="font-size:9px;padding:2px 4px;border-radius:4px;border:1px solid var(--border-subtle);background:${this.wbShowShapesDrawer?"rgba(99,102,241,0.25)":"transparent"};color:${this.wbShowShapesDrawer?"#fff":"var(--text-muted)"};cursor:pointer;">
                  🔷 Shapes ${this.wbShowShapesDrawer?"▲":"▼"}
                </button>

                <button class="wb-drawer-toggle ${this.wbShowDsaDrawer?"active":""}" id="nb-wb-toggle-dsa" style="font-size:9px;padding:2px 4px;border-radius:4px;border:1px solid rgba(56,189,248,0.3);background:${this.wbShowDsaDrawer?"rgba(56,189,248,0.2)":"transparent"};color:${this.wbShowDsaDrawer?"#38bdf8":"var(--text-muted)"};cursor:pointer;">
                  🔲 DSA ${this.wbShowDsaDrawer?"▲":"▼"}
                </button>

                <button class="wb-drawer-toggle ${this.wbShowArchDrawer?"active":""}" id="nb-wb-toggle-arch" style="font-size:9px;padding:2px 4px;border-radius:4px;border:1px solid var(--border-subtle);background:${this.wbShowArchDrawer?"rgba(99,102,241,0.25)":"transparent"};color:${this.wbShowArchDrawer?"#fff":"var(--text-muted)"};cursor:pointer;">
                  🏛️ Arch ${this.wbShowArchDrawer?"▲":"▼"}
                </button>

                <button class="wb-drawer-toggle ${this.wbShowThemesDrawer?"active":""}" id="nb-wb-toggle-themes" style="font-size:9px;padding:2px 4px;border-radius:4px;border:1px solid var(--border-subtle);background:${this.wbShowThemesDrawer?"rgba(99,102,241,0.25)":"transparent"};color:${this.wbShowThemesDrawer?"#fff":"var(--text-muted)"};cursor:pointer;">
                  🎨 Style ${this.wbShowThemesDrawer?"▲":"▼"}
                </button>
              </div>

              <!-- Right Controls -->
              <div class="wb-tool-group">
                <div style="display:flex;gap:2px;align-items:center;background:rgba(0,0,0,0.4);padding:2px 4px;border-radius:5px;border:1px solid var(--border-subtle);">
                  <button class="wb-privacy-btn" data-wbprivacy="personal" style="font-size:9px;font-weight:700;padding:2px 5px;border-radius:3px;border:none;cursor:pointer;background:${this.wbPrivacyMode==="personal"?"linear-gradient(135deg, #f59e0b, #f43f5e)":"transparent"};color:${this.wbPrivacyMode==="personal"?"#fff":"var(--text-muted)"};" title="🔒 Personal Private Scratchpad (Offline, Independent)">🔒 Private</button>
                  <button class="wb-privacy-btn" data-wbprivacy="collaborative" style="font-size:9px;font-weight:700;padding:2px 5px;border-radius:3px;border:none;cursor:pointer;background:${this.wbPrivacyMode==="collaborative"?"linear-gradient(135deg, #10b981, #06b6d4)":"transparent"};color:${this.wbPrivacyMode==="collaborative"?"#fff":"var(--text-muted)"};" title="👥 Collaborative Room Board (Synced across all peers)">👥 Collab</button>
                </div>
                <button class="wb-tool-btn" id="nb-wb-undo" title="Undo">↩️</button>
                <button class="wb-tool-btn" id="nb-wb-redo" title="Redo">↪️</button>
                <button class="wb-tool-btn" id="nb-wb-clear" title="Clear Canvas" style="color:#f87171;">🗑️</button>
                <button class="wb-tool-btn" id="nb-wb-save" title="Export PNG">💾</button>
                <button class="wb-tool-btn" id="nb-wb-popout" title="Open Standalone Popup Window">↗️</button>
              </div>
            </div>

            <!-- Floating Selection Action Bar -->
            <div id="nb-wb-selection-floating-bar" style="display:${this.wbSelectedStrokeIds.length>0?"flex":"none"};align-items:center;gap:4px;padding:3px 8px;background:rgba(15,23,42,0.95);border-bottom:1px solid #6366f1;box-shadow:0 4px 12px rgba(0,0,0,0.5);font-size:10px;">
              <span style="color:#818cf8;font-weight:700;margin-right:2px;">Selected (${this.wbSelectedStrokeIds.length}):</span>
              <button id="nb-wb-sel-copy" style="background:rgba(99,102,241,0.2);border:1px solid rgba(99,102,241,0.4);color:#fff;border-radius:3px;padding:2px 6px;cursor:pointer;font-size:9.5px;" title="Copy (Ctrl+C)">📋 Copy</button>
              <button id="nb-wb-sel-dup" style="background:rgba(16,185,129,0.2);border:1px solid rgba(16,185,129,0.4);color:#fff;border-radius:3px;padding:2px 6px;cursor:pointer;font-size:9.5px;" title="Duplicate (Ctrl+D)">✨ Dup</button>
              <button id="nb-wb-sel-paste" style="background:rgba(56,189,248,0.2);border:1px solid rgba(56,189,248,0.4);color:#fff;border-radius:3px;padding:2px 6px;cursor:pointer;font-size:9.5px;" title="Paste (Ctrl+V)">📥 Paste</button>
              <button id="nb-wb-sel-del" style="background:rgba(239,68,68,0.2);border:1px solid rgba(239,68,68,0.4);color:#fca5a5;border-radius:3px;padding:2px 6px;cursor:pointer;font-size:9.5px;" title="Delete (Del)">🗑️ Delete</button>
              <button id="nb-wb-sel-clear" style="background:transparent;border:1px solid var(--border-subtle);color:var(--text-muted);border-radius:3px;padding:2px 6px;cursor:pointer;font-size:9.5px;" title="Deselect (Esc)">✕</button>
            </div>

            <!-- Drawer: Shapes -->
            <div id="nb-wb-drawer-shapes" style="display:${this.wbShowShapesDrawer?"flex":"none"};align-items:center;gap:3px;padding:3px 6px;background:rgba(0,0,0,0.85);border-bottom:1px solid var(--border-subtle);overflow-x:auto;">
              <span style="font-size:8.5px;color:var(--text-muted);font-weight:600;">Shapes:</span>
              ${[{id:"line",label:"Line 📏"},{id:"arrow",label:"Arrow ➡️"},{id:"arrow_bi",label:"Bi-Arrow ↔️"},{id:"rect",label:"Rect 🔲"},{id:"rounded_rect",label:"Rounded ▢"},{id:"circle",label:"Circle ⭕"},{id:"triangle",label:"Triangle ▲"},{id:"star",label:"Star ⭐"},{id:"decision_diamond",label:"Diamond 💎"},{id:"sticky_note",label:"Sticky 📝"},{id:"code_box",label:"Code &lt;/&gt;"}].map(g=>`
                <button class="wb-tool-btn ${this.wbTool===g.id?"active":""}" data-wbtool="${g.id}" style="font-size:9px;padding:2px 5px;white-space:nowrap;">${g.label}</button>
              `).join("")}
            </div>

            <!-- Drawer: DSA Visualizers -->
            <div id="nb-wb-drawer-dsa" style="display:${this.wbShowDsaDrawer?"flex":"none"};align-items:center;gap:3px;padding:3px 6px;background:rgba(8,28,44,0.95);border-bottom:1px solid rgba(56,189,248,0.3);overflow-x:auto;">
              <span style="font-size:8.5px;color:#7dd3fc;font-weight:700;">🔲 DSA:</span>
              ${[{id:"array_cells",label:"Array [0..N]"},{id:"two_pointers",label:"Two Pointers (L/R)"},{id:"stack_lifo",label:"Stack (LIFO)"},{id:"queue_fifo",label:"Queue (FIFO)"},{id:"tree_node",label:"Tree Node"},{id:"hashmap_table",label:"HashMap Bucket"},{id:"decision_diamond",label:"Branch Diamond"},{id:"code_box",label:"Pseudocode Box"}].map(g=>`
                <button class="wb-tool-btn ${this.wbTool===g.id?"active":""}" data-wbtool="${g.id}" style="font-size:9px;padding:2px 5px;white-space:nowrap;color:#7dd3fc;">${g.label}</button>
              `).join("")}
            </div>

            <!-- Drawer: Architecture Shapes -->
            <div id="nb-wb-drawer-arch" style="display:${this.wbShowArchDrawer?"flex":"none"};align-items:center;gap:3px;padding:3px 6px;background:rgba(0,0,0,0.9);border-bottom:1px solid var(--border-subtle);overflow-x:auto;">
              <span style="font-size:8.5px;color:var(--text-muted);font-weight:600;">Arch:</span>
              ${[{id:"db_cylinder",label:"SQL DB"},{id:"db_nosql",label:"NoSQL"},{id:"cache_mem",label:"Redis"},{id:"message_queue",label:"Kafka"},{id:"load_balancer",label:"LB"},{id:"server_box",label:"App Server"},{id:"cloud",label:"API GW"},{id:"cdn_edge",label:"CDN Edge"},{id:"object_storage",label:"S3 Bucket"},{id:"auth_jwt",label:"Auth Shield"},{id:"websocket_gw",label:"WS Gateway"},{id:"elasticsearch",label:"ES Search"},{id:"dns_router",label:"DNS"},{id:"firewall",label:"Firewall"},{id:"user_client",label:"Client"},{id:"mobile_client",label:"Mobile"},{id:"async_arrow",label:"Async ⇢"},{id:"tradeoff_note",label:"⚖️ CAP Card"}].map(g=>`
                <button class="wb-tool-btn ${this.wbTool===g.id?"active":""}" data-wbtool="${g.id}" style="font-size:9px;padding:2px 5px;white-space:nowrap;">${g.label}</button>
              `).join("")}
            </div>

            <!-- Drawer: Style & Themes -->
            <div id="nb-wb-drawer-themes" class="wb-palette-bar" style="display:${this.wbShowThemesDrawer?"flex":"none"};flex-wrap:wrap;gap:4px;">
              <div style="display:flex;gap:2px;align-items:center;overflow-x:auto;">
                <button class="size-pill ${this.wbTheme==="grid"?"active":""}" data-wbtheme="grid">⬛ Grid</button>
                <button class="size-pill ${this.wbTheme==="isometric"?"active":""}" data-wbtheme="isometric">📐 3D Iso</button>
                <button class="size-pill ${this.wbTheme==="ruled"?"active":""}" data-wbtheme="ruled">📏 Ruled</button>
                <button class="size-pill ${this.wbTheme==="plot"?"active":""}" data-wbtheme="plot">📈 Plot</button>
                <button class="size-pill ${this.wbTheme==="matrix"?"active":""}" data-wbtheme="matrix">📊 Matrix</button>
                <button class="size-pill ${this.wbTheme==="dotted"?"active":""}" data-wbtheme="dotted">🟦 Dots</button>
                <button class="size-pill ${this.wbTheme==="blank"?"active":""}" data-wbtheme="blank">Blank</button>
              </div>

              <div style="display:flex;gap:3px;align-items:center;">
                ${["#090d16","#0f172a","#062c24","#fef3c7","#ffffff","#f8fafc","#1e1035"].map(g=>`
                  <div class="bg-dot" data-wbbg="${g}" style="width:12px;height:12px;border-radius:3px;background:${g};border:${this.wbBgColor===g?"2px solid #6366f1":"1px solid rgba(255,255,255,0.25)"};cursor:pointer;" title="Background: ${g}"></div>
                `).join("")}
              </div>

              <div style="display:flex;gap:4px;align-items:center;">
                ${["#6366f1","#06b6d4","#10b981","#f59e0b","#f43f5e","#a855f7","#ffffff","#0f172a"].map(g=>`
                  <div class="color-dot ${this.wbColor===g?"active":""}" data-color="${g}" style="background:${g};"></div>
                `).join("")}
              </div>

              <div style="display:flex;gap:2px;align-items:center;">
                <button class="size-pill ${this.wbWidth===3?"active":""}" data-size="3">S</button>
                <button class="size-pill ${this.wbWidth===5?"active":""}" data-size="5">M</button>
                <button class="size-pill ${this.wbWidth===9?"active":""}" data-size="9">L</button>
                <button class="size-pill ${this.wbWidth===18?"active":""}" data-size="18">XL</button>
              </div>
            </div>

            <!-- HTML5 Interactive Canvas -->
            <canvas id="nb-whiteboard-canvas"></canvas>
          </div>
        `:`
          <!-- Chat Messages View -->
          <div class="message-list" id="nb-messages">
            ${this.messages.length===0?`
              <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:100%;color:var(--text-muted);gap:8px;padding:30px 10px;text-align:center;">
                <div style="font-size:28px;">💬</div>
                <div style="font-size:13px;font-weight:600;color:var(--text-secondary);">No messages yet</div>
                <div style="font-size:11px;max-width:220px;">Say hello or ask for a hint! Messages are synchronized P2P across all peers.</div>
              </div>
            `:this.messages.map((g,v)=>{var k,x,P,b;return`
              <div class="chat-bubble ${g.isSelf?"self":"other"}" id="nb-msg-${g.id}">
                ${g.replyPreview?`
                  <div class="wa-quote-box">
                    <div style="font-weight:700;color:var(--primary);">${this.escapeHtml(g.replyPreview.split(":")[0]||"Reply")}</div>
                    <div style="color:var(--text-secondary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${this.escapeHtml(g.replyPreview)}</div>
                  </div>
                `:""}
                
                ${g.isSelf?"":`
                  <div class="chat-header">
                    <div class="chat-author">
                      <span>${((k=g.from)==null?void 0:k.avatar)||"👤"}</span>
                      <span style="color:${((x=g.from)==null?void 0:x.color)||"var(--primary)"};">
                        ${this.escapeHtml(((P=g.from)==null?void 0:P.nickname)||"Buddy")}
                      </span>
                    </div>
                    <button class="icon-btn nb-reply-trigger" data-id="${g.id}" data-text="${this.escapeHtml(g.text.slice(0,35))}" data-nick="${this.escapeHtml(((b=g.from)==null?void 0:b.nickname)||"Buddy")}" style="padding:0;width:18px;height:18px;" title="Reply">
                      ↩
                    </button>
                  </div>
                `}

                <div class="chat-body">
                  ${this.renderFormattedText(g.text,v,g)}
                  
                  <span class="chat-meta">
                    <span>${this.formatTimestamp(g.timestamp)}</span>
                    ${g.isSelf?`
                      <span class="ack-icon">
                        ${g.status==="pending"?"⏳":""}
                        ${g.status==="sent"?'<span style="color:var(--text-dim);">✓</span>':""}
                        ${g.status==="delivered"?'<span style="color:var(--text-secondary);">✓✓</span>':""}
                        ${g.status==="read"?'<span class="ack-read">✓✓</span>':""}
                      </span>
                    `:""}
                  </span>
                </div>
              </div>
            `}).join("")}
          </div>

          <!-- Quick Strategy Prompt Pills -->
          <div class="prompt-pills-row">
            <button class="prompt-pill" data-text="⚡ O(N) Time">⚡ O(N) Time</button>
            <button class="prompt-pill" data-text="💾 O(1) Space">💾 O(1) Space</button>
            <button class="prompt-pill" data-text="👉 Two Pointers">👉 Two Pointers</button>
            <button class="prompt-pill" data-text="🔍 Binary Search">🔍 Binary Search</button>
            <button class="prompt-pill" data-text="🧠 DP / Memo">🧠 DP / Memo</button>
            <button class="prompt-pill" data-text="💡 Sliding Window">💡 Sliding Window</button>
          </div>

          <!-- Input Box & Composer -->
          <form class="composer-box" id="nb-composer">
            <button type="button" class="icon-btn" id="nb-spoiler-insert" title="Insert Spoiler Blur ||text||" style="width:28px;height:28px;flex-shrink:0;">
              👁️
            </button>
            <input type="text" class="input-glass" id="nb-input" placeholder="Type a hint, code snippet, or ||spoiler||..." />
            <button type="submit" class="btn-send">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <line x1="22" y1="2" x2="11" y2="13"></line>
                <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
              </svg>
            </button>
          </form>
        `}
      </div>

      <!-- Dedicated Standalone Focus Timer & Pomodoro Popup Window -->
      <div class="timer-popup-card" id="nb-timer-popup-card">
        <!-- Timer Header Bar -->
        <div style="display:flex;align-items:center;justify-content:space-between;padding:10px 14px;border-bottom:1px solid rgba(255,255,255,0.08);background:linear-gradient(135deg, rgba(30, 16, 53, 0.95), rgba(15, 23, 42, 0.95));">
          <div style="display:flex;align-items:center;gap:7px;">
            <span style="font-size:16px;">🍅</span>
            <div>
              <div style="font-size:12px;font-weight:700;color:#ffffff;line-height:1.2;">Focus Timer & Pomodoro</div>
              <div style="font-size:9.5px;color:#fca5a5;font-weight:600;text-transform:uppercase;">
                ${this.timerState.mode==="pomodoro"?"Deep Focus Session":this.timerState.mode==="short_break"?"Short Refresh Break":this.timerState.mode==="long_break"?"Extended Rest":"Open Stopwatch"}
              </div>
            </div>
          </div>
          <button class="icon-btn" id="nb-close-timer-popup" title="Minimize Timer" style="width:24px;height:24px;border-radius:6px;background:rgba(255,255,255,0.06);border:none;color:#94a3b8;cursor:pointer;display:flex;align-items:center;justify-content:center;">
            ✕
          </button>
        </div>

        <!-- Timer Body -->
        <div style="padding:16px 14px;display:flex;flex-direction:column;gap:14px;align-items:center;">
          <!-- Mode Switcher Pills -->
          <div style="display:flex;gap:4px;background:rgba(0,0,0,0.4);padding:3px;border-radius:8px;border:1px solid rgba(255,255,255,0.08);width:100%;justify-content:space-between;">
            <button class="timer-mode-btn ${this.timerState.mode==="pomodoro"?"active":""}" data-tmode="pomodoro" style="flex:1;font-size:10px;font-weight:700;padding:6px 2px;border-radius:6px;border:none;cursor:pointer;background:${this.timerState.mode==="pomodoro"?"#f43f5e":"transparent"};color:${this.timerState.mode==="pomodoro"?"#fff":"var(--text-muted)"};">🍅 Focus</button>
            <button class="timer-mode-btn ${this.timerState.mode==="short_break"?"active":""}" data-tmode="short_break" style="flex:1;font-size:10px;font-weight:700;padding:6px 2px;border-radius:6px;border:none;cursor:pointer;background:${this.timerState.mode==="short_break"?"#10b981":"transparent"};color:${this.timerState.mode==="short_break"?"#fff":"var(--text-muted)"};">☕ Break</button>
            <button class="timer-mode-btn ${this.timerState.mode==="long_break"?"active":""}" data-tmode="long_break" style="flex:1;font-size:10px;font-weight:700;padding:6px 2px;border-radius:6px;border:none;cursor:pointer;background:${this.timerState.mode==="long_break"?"#06b6d4":"transparent"};color:${this.timerState.mode==="long_break"?"#fff":"var(--text-muted)"};">🌴 Long</button>
            <button class="timer-mode-btn ${this.timerState.mode==="stopwatch"?"active":""}" data-tmode="stopwatch" style="flex:1;font-size:10px;font-weight:700;padding:6px 2px;border-radius:6px;border:none;cursor:pointer;background:${this.timerState.mode==="stopwatch"?"#8b5cf6":"transparent"};color:${this.timerState.mode==="stopwatch"?"#fff":"var(--text-muted)"};">⏱️ Clock</button>
          </div>

          <!-- Digital Clock Display & Rocket Racing Track -->
          <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;width:100%;padding:18px 12px;background:rgba(255,255,255,0.02);border:1px solid ${this.timerState.isRunning?this.timerState.mode==="pomodoro"?"#f43f5e50":this.timerState.mode==="short_break"?"#10b98150":this.timerState.mode==="long_break"?"#06b6d450":"#8b5cf650":"rgba(255,255,255,0.08)"};border-radius:14px;box-shadow:${this.timerState.isRunning?"0 10px 30px -10px rgba(0,0,0,0.8)":"none"};position:relative;overflow:hidden;box-sizing:border-box;">
            
            <!-- 🚀 Rocket Racing Progress Track -->
            <div style="width:100%;height:8px;background:rgba(255,255,255,0.08);position:relative;overflow:hidden;border-radius:4px;">
              <div id="nb-timer-progress-fill" style="height:100%;width:${this.getTimerProgressPct()}%;background:linear-gradient(90deg, #6366f1, ${this.timerState.mode==="pomodoro"?"#f43f5e":this.timerState.mode==="short_break"?"#10b981":this.timerState.mode==="long_break"?"#06b6d4":"#8b5cf6"});transition:width 0.4s ease;box-shadow:${this.timerState.isRunning?"0 0 10px rgba(244,63,94,0.8)":"none"};"></div>
              <div style="position:absolute;top:-4px;left:calc(${Math.min(94,Math.max(2,this.getTimerProgressPct()))}% - 8px);font-size:11px;pointer-events:none;transition:left 0.4s ease;">
                <span style="display:inline-block;animation:${this.timerState.isRunning?"rocketThrust 0.8s ease-in-out infinite alternate":"none"};">🚀</span>
              </div>
            </div>

            <div id="nb-timer-time" style="font-family:var(--font-mono);font-size:42px;font-weight:800;color:#ffffff;letter-spacing:-1px;line-height:1;margin-top:12px;">
              ${this.formatTimerTime(this.timerState.timeLeftSec)}
            </div>

            <!-- Racing Track Waypoints -->
            <div style="display:flex;justify-content:space-between;width:100%;font-size:9px;color:var(--text-muted);margin-top:8px;padding:0 2px;">
              <span>🛫 Launchpad</span>
              <span style="font-weight:700;color:#fca5a5;">${Math.round(this.getTimerProgressPct())}% Completed</span>
              <span>🏁 Goal</span>
            </div>

            ${this.timerState.sessionsCompleted>0?`
              <div style="display:flex;align-items:center;gap:4px;margin-top:8px;font-size:10px;padding:2px 8px;border-radius:10px;background:rgba(244,63,94,0.15);color:#f43f5e;font-weight:600;">
                <span>🎯</span>
                <span>${this.timerState.sessionsCompleted} Sessions Done</span>
              </div>
            `:""}
          </div>

          <!-- Timer Action Buttons -->
          <div style="display:flex;align-items:center;gap:8px;width:100%;">
            <button id="nb-timer-toggle" style="flex:2;display:flex;align-items:center;justify-content:center;gap:6px;padding:10px;border-radius:8px;border:none;background:${this.timerState.isRunning?"#ef4444":"linear-gradient(135deg, #4f46e5, #7c3aed)"};color:#ffffff;font-size:12px;font-weight:700;cursor:pointer;box-shadow:0 4px 15px rgba(99,102,241,0.4);">
              <span>${this.timerState.isRunning?"⏸ Pause":"▶ Start Focus"}</span>
            </button>
            <button id="nb-timer-add-1m" style="flex:1;padding:10px 4px;border-radius:8px;border:1px solid rgba(255,255,255,0.1);background:rgba(255,255,255,0.06);color:#f8fafc;font-size:11px;font-weight:600;cursor:pointer;" title="Add 1 minute">+1m</button>
            <button id="nb-timer-add-5m" style="flex:1;padding:10px 4px;border-radius:8px;border:1px solid rgba(255,255,255,0.1);background:rgba(255,255,255,0.06);color:#f8fafc;font-size:11px;font-weight:600;cursor:pointer;" title="Add 5 minutes">+5m</button>
            <button id="nb-timer-reset" style="padding:10px 12px;border-radius:8px;border:1px solid rgba(255,255,255,0.1);background:rgba(255,255,255,0.06);color:#f8fafc;font-size:12px;font-weight:600;cursor:pointer;" title="Reset Timer">🔄</button>
          </div>
        </div>
      </div>

      <!-- FAB Controls Row: Standalone Rocket Racing Timer FAB + Main Synqto FAB -->
      <div class="fab-row" style="display:flex;align-items:center;gap:8px;position:relative;">
        <!-- 1. Separate Standalone Rocket Racing Focus Timer FAB (Shown when timer is on/enabled) -->
        ${this.timerConfig.enabled||this.timerState.isRunning?`
          <button class="timer-fab-button" id="nb-timer-fab-trigger" title="Focus Timer (Click to open, click play icon to toggle)">
            <span style="font-size:13px;">${this.timerState.mode==="pomodoro"?"🍅":this.timerState.mode==="short_break"?"☕":this.timerState.mode==="long_break"?"🌴":"⏱️"}</span>
            <span class="timer-fab-rocket" style="animation:${this.timerState.isRunning?"rocketThrust 0.8s ease-in-out infinite alternate":"none"};">🚀</span>
            ${this.timerState.isRunning?'<span style="font-size:10px;margin-left:-5px;animation:flameFlicker 0.3s ease-in-out infinite alternate;">🔥</span>':""}
            <div class="timer-fab-track">
              <div id="nb-timer-fab-fill" class="timer-fab-fill" style="width:${this.getTimerProgressPct()}%;"></div>
            </div>
            <span id="nb-timer-fab-time" style="font-family:var(--font-mono);font-size:11px;font-weight:800;color:#ffffff;min-width:38px;">
              ${this.formatTimerTime(this.timerState.timeLeftSec)}
            </span>
            <span id="nb-timer-fab-toggle-btn" style="display:inline-flex;align-items:center;justify-content:center;width:22px;height:22px;border-radius:50%;background:${this.timerState.isRunning?"#ef4444":"rgba(255,255,255,0.15)"};color:#ffffff;font-size:9px;margin-left:2px;cursor:pointer;box-shadow:0 2px 6px rgba(0,0,0,0.3);" title="${this.timerState.isRunning?"Pause Timer":"Start Timer"}">
              ${this.timerState.isRunning?"⏸":"▶"}
            </span>
          </button>
        `:""}

        <!-- 2. Main Synqto App FAB -->
        <button class="fab-button" id="nb-fab-trigger" title="Drag anywhere or click to open Synqto">
          <span class="drag-grip">⠿</span>
          ${t?'<span class="live-dot"></span>':`<span>${c}</span>`}
          <span>${u}</span>
          ${this.unreadCount>0?`<span class="fab-badge">${this.unreadCount}</span>`:""}
        </button>
      </div>
    `,this.attachEventListeners(),r&&this.initWhiteboardCanvas()}attachEventListeners(){if(!this.shadow)return;const i=this.shadow.getElementById("nb-fab-trigger");if(i){let b=0,m=0,_=24,C=24;const L=s=>{if(!this.isDragging)return;const l="touches"in s?s.touches[0].clientX:s.clientX,h="touches"in s?s.touches[0].clientY:s.clientY,f=l-b,y=h-m;if(Math.hypot(f,y)>4){this.dragMoved=!0;const T=_-f,I=C-y;this.currentPosition={right:Math.max(10,Math.min(window.innerWidth-130,T)),bottom:Math.max(10,Math.min(window.innerHeight-55,I))},this.applyHostPosition()}},$=()=>{var s;if(this.isDragging&&(this.isDragging=!1,window.removeEventListener("mousemove",L),window.removeEventListener("mouseup",$),window.removeEventListener("touchmove",L),window.removeEventListener("touchend",$),this.dragMoved)){if(this.settings.positionMode==="permanent"){const l={...this.settings,savedPosition:{...this.currentPosition}};this.settings=l,typeof chrome<"u"&&((s=chrome.storage)!=null&&s.local)&&chrome.storage.local.set({[z]:l})}setTimeout(()=>{this.dragMoved=!1},60)}},p=s=>{this.isDragging=!0,this.dragMoved=!1,b="touches"in s?s.touches[0].clientX:s.clientX,m="touches"in s?s.touches[0].clientY:s.clientY,_=this.currentPosition.right,C=this.currentPosition.bottom,window.addEventListener("mousemove",L,{passive:!0}),window.addEventListener("mouseup",$),window.addEventListener("touchmove",L,{passive:!0}),window.addEventListener("touchend",$)};i.addEventListener("mousedown",p),i.addEventListener("touchstart",p,{passive:!0}),i.addEventListener("click",()=>{var s;if(!this.dragMoved){if(this.settings.clickAction==="open_extension"){typeof chrome<"u"&&((s=chrome.runtime)!=null&&s.sendMessage)&&chrome.runtime.sendMessage({type:"OPEN_SIDEPANEL"}).catch(()=>{});return}this.isOpen=!this.isOpen,this.unreadCount=0,this.render(),this.isOpen&&this.activeTab==="chat"&&this.scrollToBottom()}})}const t=this.shadow.getElementById("nb-timer-fab-trigger"),o=this.shadow.getElementById("nb-timer-fab-toggle-btn");o==null||o.addEventListener("click",b=>{b.stopPropagation(),this.toggleTimer()}),t==null||t.addEventListener("click",()=>{this.isTimerOpen=!this.isTimerOpen,this.render()});const e=this.shadow.getElementById("nb-close-timer-popup");e==null||e.addEventListener("click",()=>{this.isTimerOpen=!1,this.render()}),this.shadow.querySelectorAll(".size-mode-pill[data-popsize]").forEach(b=>{b.addEventListener("click",m=>{const _=m.currentTarget.getAttribute("data-popsize");_&&(this.popupSize=_,this.render())})});const d=this.shadow.getElementById("nb-close-popup");d==null||d.addEventListener("click",()=>{this.isOpen=!1,this.render()});const r=this.shadow.getElementById("nb-open-sidepanel");r==null||r.addEventListener("click",()=>{var b;this.isOpen=!1,this.render(),typeof chrome<"u"&&((b=chrome.runtime)!=null&&b.sendMessage)&&chrome.runtime.sendMessage({type:"OPEN_SIDEPANEL"}).catch(()=>{})});const c=this.shadow.getElementById("nb-tab-chat");c==null||c.addEventListener("click",()=>{this.activeTab="chat",this.render(),this.scrollToBottom()});const u=this.shadow.getElementById("nb-tab-whiteboard");u==null||u.addEventListener("click",()=>{this.activeTab="whiteboard",this.render()});const M=this.shadow.getElementById("nb-timer-toggle");M==null||M.addEventListener("click",()=>{this.toggleTimer()});const w=this.shadow.getElementById("nb-timer-reset");w==null||w.addEventListener("click",()=>{this.resetTimer()});const D=this.shadow.getElementById("nb-timer-add-1m");D==null||D.addEventListener("click",()=>{this.addTimerTime(60)});const E=this.shadow.getElementById("nb-timer-add-5m");E==null||E.addEventListener("click",()=>{this.addTimerTime(300)}),this.shadow.querySelectorAll(".timer-mode-btn[data-tmode]").forEach(b=>{b.addEventListener("click",m=>{const _=m.currentTarget.getAttribute("data-tmode");_&&this.setTimerMode(_)})});const n=this.shadow.getElementById("nb-live-tunein");n==null||n.addEventListener("click",()=>{var b;this.isOpen=!1,this.render(),typeof chrome<"u"&&((b=chrome.runtime)!=null&&b.sendMessage)&&chrome.runtime.sendMessage({type:"OPEN_SIDEPANEL"}).catch(()=>{})});const g=this.shadow.getElementById("nb-offline-sidepanel-reconnect");g==null||g.addEventListener("click",()=>{var b;this.isOpen=!1,this.render(),typeof chrome<"u"&&((b=chrome.runtime)!=null&&b.sendMessage)&&chrome.runtime.sendMessage({type:"OPEN_SIDEPANEL"}).catch(()=>{})}),this.shadow.querySelectorAll(".prompt-pill").forEach(b=>{b.addEventListener("click",m=>{const _=m.target.getAttribute("data-text");_&&this.sendMessage(_)})});const k=this.shadow.getElementById("nb-spoiler-insert"),x=this.shadow.getElementById("nb-input");if(k==null||k.addEventListener("click",()=>{x&&(x.value=`${x.value}||hint solution||`,x.focus())}),x){const b=m=>m.stopPropagation();x.addEventListener("keydown",b),x.addEventListener("keyup",b),x.addEventListener("keypress",b)}const P=this.shadow.getElementById("nb-composer");P==null||P.addEventListener("submit",b=>{b.preventDefault();const m=x==null?void 0:x.value.trim();m&&(this.sendMessage(m,this.replyingTo?{id:this.replyingTo.id,preview:`${this.replyingTo.from.nickname}: ${this.replyingTo.text.slice(0,30)}`}:void 0),x&&(x.value=""),this.replyingTo=null)})}initWhiteboardCanvas(){var R,n,g,v,k,x,P,b,m,_,C,L,$,p;if(!this.shadow)return;const i=this.shadow.getElementById("nb-whiteboard-canvas");if(!i)return;this.triggerWbAnimationLoop();const t=this.shadow.querySelectorAll(".wb-tool-btn[data-wbtool]");t.forEach(s=>{s.addEventListener("click",l=>{var f,y;const h=l.currentTarget.getAttribute("data-wbtool");if(h){this.wbTool=h;const T=this.toolStyles[h]||{color:"#6366f1",width:3};this.wbColor=T.color,this.wbWidth=T.width,t.forEach(B=>B.classList.remove("active")),l.currentTarget.classList.add("active");const I=(f=this.shadow)==null?void 0:f.querySelectorAll(".color-dot");I==null||I.forEach(B=>B.classList.toggle("active",B.getAttribute("data-color")===this.wbColor));const A=(y=this.shadow)==null?void 0:y.querySelectorAll(".size-pill[data-size]");A==null||A.forEach(B=>B.classList.toggle("active",Number(B.getAttribute("data-size"))===this.wbWidth)),h!=="select"&&(this.wbSelectedStrokeIds=[],this.updateSelectionBar()),this.drawWbCanvas()}})});const o=s=>{var y,T,I,A,B,V,X,Q;const l=s==="shapes"?this.wbShowShapesDrawer:s==="dsa"?this.wbShowDsaDrawer:s==="arch"?this.wbShowArchDrawer:this.wbShowThemesDrawer;this.wbShowShapesDrawer=!1,this.wbShowDsaDrawer=!1,this.wbShowArchDrawer=!1,this.wbShowThemesDrawer=!1,l||(s==="shapes"&&(this.wbShowShapesDrawer=!0),s==="dsa"&&(this.wbShowDsaDrawer=!0),s==="arch"&&(this.wbShowArchDrawer=!0),s==="themes"&&(this.wbShowThemesDrawer=!0));const h={shapes:(y=this.shadow)==null?void 0:y.getElementById("nb-wb-drawer-shapes"),dsa:(T=this.shadow)==null?void 0:T.getElementById("nb-wb-drawer-dsa"),arch:(I=this.shadow)==null?void 0:I.getElementById("nb-wb-drawer-arch"),themes:(A=this.shadow)==null?void 0:A.getElementById("nb-wb-drawer-themes")},f={shapes:(B=this.shadow)==null?void 0:B.getElementById("nb-wb-toggle-shapes"),dsa:(V=this.shadow)==null?void 0:V.getElementById("nb-wb-toggle-dsa"),arch:(X=this.shadow)==null?void 0:X.getElementById("nb-wb-toggle-arch"),themes:(Q=this.shadow)==null?void 0:Q.getElementById("nb-wb-toggle-themes")};h.shapes&&(h.shapes.style.display=this.wbShowShapesDrawer?"flex":"none"),h.dsa&&(h.dsa.style.display=this.wbShowDsaDrawer?"flex":"none"),h.arch&&(h.arch.style.display=this.wbShowArchDrawer?"flex":"none"),h.themes&&(h.themes.style.display=this.wbShowThemesDrawer?"flex":"none"),f.shapes&&(f.shapes.classList.toggle("active",this.wbShowShapesDrawer),f.shapes.textContent=`🔷 Shapes ${this.wbShowShapesDrawer?"▲":"▼"}`),f.dsa&&(f.dsa.classList.toggle("active",this.wbShowDsaDrawer),f.dsa.textContent=`🔲 DSA ${this.wbShowDsaDrawer?"▲":"▼"}`),f.arch&&(f.arch.classList.toggle("active",this.wbShowArchDrawer),f.arch.textContent=`🏛️ Arch ${this.wbShowArchDrawer?"▲":"▼"}`),f.themes&&(f.themes.classList.toggle("active",this.wbShowThemesDrawer),f.themes.textContent=`🎨 Style ${this.wbShowThemesDrawer?"▲":"▼"}`)};(R=this.shadow.getElementById("nb-wb-toggle-shapes"))==null||R.addEventListener("click",()=>o("shapes")),(n=this.shadow.getElementById("nb-wb-toggle-dsa"))==null||n.addEventListener("click",()=>o("dsa")),(g=this.shadow.getElementById("nb-wb-toggle-arch"))==null||g.addEventListener("click",()=>o("arch")),(v=this.shadow.getElementById("nb-wb-toggle-themes"))==null||v.addEventListener("click",()=>o("themes")),(k=this.shadow.getElementById("nb-wb-popout"))==null||k.addEventListener("click",()=>{var s,l;typeof chrome<"u"&&((s=chrome.windows)!=null&&s.create)?chrome.windows.create({url:chrome.runtime.getURL("sidepanel.html?view=whiteboard"),type:"popup",width:900,height:650}):typeof chrome<"u"&&((l=chrome.runtime)!=null&&l.sendMessage)&&chrome.runtime.sendMessage({type:"OPEN_STANDALONE_WHITEBOARD"}).catch(()=>{})});const e=this.shadow.querySelectorAll(".wb-privacy-btn[data-wbprivacy]");e.forEach(s=>{s.addEventListener("click",l=>{const h=l.currentTarget.getAttribute("data-wbprivacy");h&&(this.wbPrivacyMode=h,this.saveInPagePersonalBoard(),e.forEach(f=>{const y=f.getAttribute("data-wbprivacy");f.style.background=y===h?y==="personal"?"linear-gradient(135deg, #f59e0b, #f43f5e)":"linear-gradient(135deg, #10b981, #06b6d4)":"transparent",f.style.color=y===h?"#fff":"var(--text-muted)"}),this.wbSelectedStrokeIds=[],this.updateSelectionBar(),this.drawWbCanvas())})});const a=this.shadow.querySelectorAll(".size-pill[data-wbtheme]");a.forEach(s=>{s.addEventListener("click",l=>{var f;const h=l.currentTarget.getAttribute("data-wbtheme");h&&(this.wbPrivacyMode==="personal"?(this.wbPersonalTheme=h,this.saveInPagePersonalBoard()):(this.wbTheme=h,typeof chrome<"u"&&((f=chrome.runtime)!=null&&f.sendMessage)&&chrome.runtime.sendMessage({type:"WHITEBOARD_BG_LOCAL",background:h,bgColor:this.wbBgColor}).catch(()=>{})),a.forEach(y=>y.classList.toggle("active",y.getAttribute("data-wbtheme")===h)),this.drawWbCanvas())})});const d=this.shadow.querySelectorAll(".bg-dot[data-wbbg]");d.forEach(s=>{s.addEventListener("click",l=>{var f;const h=l.currentTarget.getAttribute("data-wbbg");h&&(this.wbPrivacyMode==="personal"?(this.wbPersonalBgColor=h,this.saveInPagePersonalBoard()):(this.wbBgColor=h,typeof chrome<"u"&&((f=chrome.runtime)!=null&&f.sendMessage)&&chrome.runtime.sendMessage({type:"WHITEBOARD_BG_LOCAL",background:this.wbTheme,bgColor:h}).catch(()=>{})),d.forEach(y=>{const T=y.getAttribute("data-wbbg");y.style.border=T===h?"2px solid #6366f1":"1px solid rgba(255,255,255,0.25)"}),this.drawWbCanvas())})});const r=this.shadow.querySelectorAll(".color-dot");r.forEach(s=>{s.addEventListener("click",l=>{const h=l.currentTarget.getAttribute("data-color");h&&(this.wbColor=h,this.toolStyles[this.wbTool]&&(this.toolStyles[this.wbTool].color=h),r.forEach(f=>f.classList.toggle("active",f.getAttribute("data-color")===h)),this.drawWbCanvas())})});const c=this.shadow.querySelectorAll(".size-pill[data-size]");c.forEach(s=>{s.addEventListener("click",l=>{const h=Number(l.currentTarget.getAttribute("data-size"));h&&(this.wbWidth=h,this.toolStyles[this.wbTool]&&(this.toolStyles[this.wbTool].width=h),c.forEach(f=>f.classList.toggle("active",Number(f.getAttribute("data-size"))===h)),this.drawWbCanvas())})}),(x=this.shadow.getElementById("nb-wb-sel-copy"))==null||x.addEventListener("click",()=>{const s=this.wbPrivacyMode==="personal"?this.wbPersonalStrokes:this.wbStrokes;this.wbClipboardStrokes=s.filter(l=>this.wbSelectedStrokeIds.includes(l.id))}),(P=this.shadow.getElementById("nb-wb-sel-dup"))==null||P.addEventListener("click",()=>{const l=(this.wbPrivacyMode==="personal"?this.wbPersonalStrokes:this.wbStrokes).filter(h=>this.wbSelectedStrokeIds.includes(h.id));if(l.length>0){const h=l.map(f=>({...N(f,20,20),id:"stroke-"+Math.random().toString(36).slice(2,10)}));this.wbPrivacyMode==="personal"?(this.wbPersonalStrokes.push(...h),this.saveInPagePersonalBoard()):(this.wbStrokes.push(...h),h.forEach(f=>{var y;typeof chrome<"u"&&((y=chrome.runtime)!=null&&y.sendMessage)&&chrome.runtime.sendMessage({type:"WHITEBOARD_STROKE_LOCAL",stroke:f}).catch(()=>{})})),this.wbSelectedStrokeIds=h.map(f=>f.id),this.updateSelectionBar(),this.drawWbCanvas()}}),(b=this.shadow.getElementById("nb-wb-sel-paste"))==null||b.addEventListener("click",()=>{if(this.wbClipboardStrokes.length>0){const s=this.wbClipboardStrokes.map(l=>({...N(l,24,24),id:"stroke-"+Math.random().toString(36).slice(2,10)}));this.wbPrivacyMode==="personal"?(this.wbPersonalStrokes.push(...s),this.saveInPagePersonalBoard()):(this.wbStrokes.push(...s),s.forEach(l=>{var h;typeof chrome<"u"&&((h=chrome.runtime)!=null&&h.sendMessage)&&chrome.runtime.sendMessage({type:"WHITEBOARD_STROKE_LOCAL",stroke:l}).catch(()=>{})})),this.wbSelectedStrokeIds=s.map(l=>l.id),this.updateSelectionBar(),this.drawWbCanvas()}}),(m=this.shadow.getElementById("nb-wb-sel-del"))==null||m.addEventListener("click",()=>{if(this.wbSelectedStrokeIds.length>0){const l=(this.wbPrivacyMode==="personal"?this.wbPersonalStrokes:this.wbStrokes).filter(h=>this.wbSelectedStrokeIds.includes(h.id));this.wbRedoStack.push(...l),this.wbPrivacyMode==="personal"?(this.wbPersonalStrokes=this.wbPersonalStrokes.filter(h=>!this.wbSelectedStrokeIds.includes(h.id)),this.saveInPagePersonalBoard()):(this.wbStrokes=this.wbStrokes.filter(h=>!this.wbSelectedStrokeIds.includes(h.id)),l.forEach(h=>{var f;typeof chrome<"u"&&((f=chrome.runtime)!=null&&f.sendMessage)&&chrome.runtime.sendMessage({type:"WHITEBOARD_UNDO_LOCAL",strokeId:h.id}).catch(()=>{})})),this.wbSelectedStrokeIds=[],this.updateSelectionBar(),this.drawWbCanvas()}}),(_=this.shadow.getElementById("nb-wb-sel-clear"))==null||_.addEventListener("click",()=>{this.wbSelectedStrokeIds=[],this.updateSelectionBar(),this.drawWbCanvas()}),(C=this.shadow.getElementById("nb-wb-undo"))==null||C.addEventListener("click",()=>{var l;const s=this.wbPrivacyMode==="personal"?this.wbPersonalStrokes:this.wbStrokes;if(s.length===0&&this.wbRedoStack.length>0){this.wbPrivacyMode==="personal"?(this.wbPersonalStrokes=[...this.wbRedoStack],this.saveInPagePersonalBoard()):(this.wbStrokes=[...this.wbRedoStack],this.wbStrokes.forEach(h=>{var f;typeof chrome<"u"&&((f=chrome.runtime)!=null&&f.sendMessage)&&chrome.runtime.sendMessage({type:"WHITEBOARD_STROKE_LOCAL",stroke:h}).catch(()=>{})})),this.wbRedoStack=[],this.drawWbCanvas();return}if(s.length>0){const h=s.pop();h&&(this.wbRedoStack.push(h),this.wbPrivacyMode==="personal"?this.saveInPagePersonalBoard():this.wbPrivacyMode==="collaborative"&&typeof chrome<"u"&&((l=chrome.runtime)!=null&&l.sendMessage)&&chrome.runtime.sendMessage({type:"WHITEBOARD_UNDO_LOCAL",strokeId:h.id}).catch(()=>{}),this.drawWbCanvas())}}),(L=this.shadow.getElementById("nb-wb-redo"))==null||L.addEventListener("click",()=>{var s;if(this.wbRedoStack.length>0){const l=this.wbRedoStack.pop();l&&(this.wbPrivacyMode==="personal"?(this.wbPersonalStrokes.push(l),this.saveInPagePersonalBoard()):(this.wbStrokes.push(l),typeof chrome<"u"&&((s=chrome.runtime)!=null&&s.sendMessage)&&chrome.runtime.sendMessage({type:"WHITEBOARD_STROKE_LOCAL",stroke:l}).catch(()=>{})),this.drawWbCanvas())}}),($=this.shadow.getElementById("nb-wb-clear"))==null||$.addEventListener("click",()=>{var l;const s=this.wbPrivacyMode==="personal"?this.wbPersonalStrokes:this.wbStrokes;s.length!==0&&(this.wbRedoStack=[...s],this.wbPrivacyMode==="personal"?(this.wbPersonalStrokes=[],this.saveInPagePersonalBoard()):(this.wbStrokes=[],typeof chrome<"u"&&((l=chrome.runtime)!=null&&l.sendMessage)&&chrome.runtime.sendMessage({type:"WHITEBOARD_CLEAR_LOCAL"}).catch(()=>{})),this.wbSelectedStrokeIds=[],this.updateSelectionBar(),this.drawWbCanvas())}),(p=this.shadow.getElementById("nb-wb-save"))==null||p.addEventListener("click",()=>{const s=i.toDataURL("image/png"),l=document.createElement("a");l.download=`synqto-whiteboard-${Date.now()}.png`,l.href=s,l.click()}),setTimeout(()=>{const s=i.getBoundingClientRect(),l=window.devicePixelRatio||1;i.width=(s.width||380)*l,i.height=(s.height||360)*l;const h=i.getContext("2d");h&&(h.setTransform(1,0,0,1,0,0),h.scale(l,l)),this.drawWbCanvas()},30);const M=s=>{const l=i.getBoundingClientRect();let h=0,f=0;return"touches"in s&&s.touches.length>0?(h=s.touches[0].clientX,f=s.touches[0].clientY):"changedTouches"in s&&s.changedTouches.length>0?(h=s.changedTouches[0].clientX,f=s.changedTouches[0].clientY):"clientX"in s&&(h=s.clientX,f=s.clientY),{x:h-l.left,y:f-l.top}},w=s=>["line","arrow","arrow_bi","rect","rounded_rect","circle","triangle","star","decision_diamond","tree_node","sticky_note","text","code_box","db_cylinder","db_nosql","cloud","cdn_edge","object_storage","auth_jwt","websocket_gw","elasticsearch","load_balancer","message_queue","server_box","cache_mem","dns_router","firewall","user_client","mobile_client","async_arrow","tradeoff_note","array_cells","two_pointers","stack_lifo","queue_fifo","hashmap_table"].includes(s),D=(s,l,h)=>{if(s.geometry){const{x1:f,y1:y,x2:T,y2:I}=s.geometry,A=Math.min(f,T)-h,B=Math.max(f,T)+h,V=Math.min(y,I)-h,X=Math.max(y,I)+h;return l.x>=A&&l.x<=B&&l.y>=V&&l.y<=X}if(s.points&&s.points.length>0){const f=h+s.width/2;return s.points.some(y=>Math.hypot(y.x-l.x,y.y-l.y)<=f)}return!1};i.addEventListener("mousedown",s=>{const l=M(s);if(this.wbTool==="select"){const h=this.wbPrivacyMode==="personal"?this.wbPersonalStrokes:this.wbStrokes;if(this.wbSelectedStrokeIds.length>0&&h.some(y=>{if(!this.wbSelectedStrokeIds.includes(y.id))return!1;const T=Y(y);return l.x>=T.minX-6&&l.x<=T.maxX+6&&l.y>=T.minY-6&&l.y<=T.maxY+6}))this.wbIsMovingSelection=!0,this.wbDragStartCoords=l;else{const y=[...h].reverse().find(T=>{const I=Y(T);return l.x>=I.minX-4&&l.x<=I.maxX+4&&l.y>=I.minY-4&&l.y<=I.maxY+4});y?(this.wbSelectedStrokeIds=[y.id],this.wbIsMovingSelection=!0,this.wbDragStartCoords=l):(this.wbSelectedStrokeIds=[],this.wbIsMarqueeSelecting=!0,this.wbSelectionBox={x1:l.x,y1:l.y,x2:l.x,y2:l.y}),this.updateSelectionBar()}this.drawWbCanvas();return}if(this.wbTool==="eraser"){this.isWbDrawing=!0,this.wbEraserPos=l;const h=(this.wbWidth||4)*3,f=this.wbPrivacyMode==="personal"?this.wbPersonalStrokes:this.wbStrokes,y=f.filter(T=>!D(T,l,h));if(y.length!==f.length){const T=f.filter(I=>D(I,l,h));this.wbRedoStack.push(...T),this.wbPrivacyMode==="personal"?this.wbPersonalStrokes=y:(this.wbStrokes=y,T.forEach(I=>{var A;typeof chrome<"u"&&((A=chrome.runtime)!=null&&A.sendMessage)&&chrome.runtime.sendMessage({type:"WHITEBOARD_UNDO_LOCAL",strokeId:I.id}).catch(()=>{})}))}this.drawWbCanvas();return}if(this.wbTool==="laser"){this.wbLaserTrails.push({x:l.x,y:l.y,alpha:1,timestamp:Date.now()}),this.drawWbCanvas();return}if(this.wbTool==="torch"){this.wbTorchPos=l,this.drawWbCanvas();return}this.isWbDrawing=!0,this.wbStartPoint=l,this.wbCurrentPoints=[l]}),i.addEventListener("mousemove",s=>{const l=M(s);if(this.wbTool==="select"){if(this.wbIsMovingSelection&&this.wbDragStartCoords){const f=l.x-this.wbDragStartCoords.x,y=l.y-this.wbDragStartCoords.y;this.wbDragStartCoords=l,this.wbPrivacyMode==="personal"?this.wbPersonalStrokes=this.wbPersonalStrokes.map(T=>this.wbSelectedStrokeIds.includes(T.id)?N(T,f,y):T):this.wbStrokes=this.wbStrokes.map(T=>this.wbSelectedStrokeIds.includes(T.id)?N(T,f,y):T),this.requestWbRedraw();return}if(this.wbIsMarqueeSelecting&&this.wbSelectionBox){this.wbSelectionBox.x2=l.x,this.wbSelectionBox.y2=l.y;const y=(this.wbPrivacyMode==="personal"?this.wbPersonalStrokes:this.wbStrokes).filter(T=>ae(T,this.wbSelectionBox));this.wbSelectedStrokeIds=y.map(T=>T.id),this.updateSelectionBar(),this.requestWbRedraw();return}}if(this.wbTool==="eraser"){if(this.wbEraserPos=l,this.isWbDrawing){const f=(this.wbWidth||4)*3,y=this.wbPrivacyMode==="personal"?this.wbPersonalStrokes:this.wbStrokes,T=y.filter(I=>!D(I,l,f));if(T.length!==y.length){const I=y.filter(A=>D(A,l,f));this.wbRedoStack.push(...I),this.wbPrivacyMode==="personal"?this.wbPersonalStrokes=T:(this.wbStrokes=T,I.forEach(A=>{var B;typeof chrome<"u"&&((B=chrome.runtime)!=null&&B.sendMessage)&&chrome.runtime.sendMessage({type:"WHITEBOARD_UNDO_LOCAL",strokeId:A.id}).catch(()=>{})}))}}this.requestWbRedraw();return}if(this.wbTool==="laser"){this.wbLaserTrails.push({x:l.x,y:l.y,alpha:1,timestamp:Date.now()}),this.triggerWbAnimationLoop(),this.requestWbRedraw();return}if(this.wbTool==="torch"){this.wbTorchPos=l,this.requestWbRedraw();return}if(!this.isWbDrawing)return;w(this.wbTool)&&this.wbStartPoint?this.requestWbRedraw(void 0,{x1:this.wbStartPoint.x,y1:this.wbStartPoint.y,x2:l.x,y2:l.y}):(this.wbCurrentPoints.push(l),this.requestWbRedraw(this.wbCurrentPoints))});const E=s=>{var T,I;if(this.wbTool==="select"){if(this.wbIsMovingSelection&&(this.wbIsMovingSelection=!1,this.wbDragStartCoords=null,this.wbPrivacyMode==="collaborative"&&typeof chrome<"u"&&((T=chrome.runtime)!=null&&T.sendMessage))){const A=this.wbStrokes.filter(B=>this.wbSelectedStrokeIds.includes(B.id));A.length>0&&chrome.runtime.sendMessage({type:"WHITEBOARD_UPDATE_STROKES_LOCAL",strokes:A}).catch(()=>{})}this.wbIsMarqueeSelecting&&(this.wbIsMarqueeSelecting=!1,this.wbSelectionBox=null),this.updateSelectionBar(),this.drawWbCanvas();return}if(this.wbTool==="eraser"){this.isWbDrawing=!1,this.wbEraserPos=null,this.drawWbCanvas();return}if(this.wbTool==="torch"){this.wbTorchPos=null,this.drawWbCanvas();return}if(!this.isWbDrawing)return;this.isWbDrawing=!1;const l=M(s),h=w(this.wbTool),f=this.wbTool==="highlighter"?16:this.wbWidth,y={id:"stroke-"+Math.random().toString(36).slice(2,10),tool:this.wbTool,color:this.wbColor,width:f,opacity:this.wbTool==="highlighter"?.35:1,points:h?[]:[...this.wbCurrentPoints],geometry:h&&this.wbStartPoint?{x1:this.wbStartPoint.x,y1:this.wbStartPoint.y,x2:l.x,y2:l.y}:void 0};this.wbTool==="temp_pen"?this.tempDisappearingStrokes.push({stroke:y,createdAt:Date.now(),durationMs:3e3}):this.wbPrivacyMode==="personal"?this.wbPersonalStrokes.push(y):(this.wbStrokes.push(y),typeof chrome<"u"&&((I=chrome.runtime)!=null&&I.sendMessage)&&chrome.runtime.sendMessage({type:"WHITEBOARD_STROKE_LOCAL",stroke:y}).catch(()=>{})),this.wbRedoStack=[],this.wbCurrentPoints=[],this.wbStartPoint=null,this.drawWbCanvas()};i.addEventListener("mouseup",E),i.addEventListener("mouseleave",E)}updateSelectionBar(){if(!this.shadow)return;const i=this.shadow.getElementById("nb-wb-selection-floating-bar");if(!i)return;const t=this.wbSelectedStrokeIds.length;if(t>0){i.style.display="flex";const o=i.querySelector("span");o&&(o.textContent=`Selected (${t}):`)}else i.style.display="none"}triggerWbAnimationLoop(){if(this.wbAnimationRafId!==null||this.activeTab!=="whiteboard"||this.wbLaserTrails.length===0&&this.tempDisappearingStrokes.length===0)return;const i=()=>{if(this.activeTab!=="whiteboard"){this.wbAnimationRafId=null;return}let t=!1;const o=Date.now();if(this.wbLaserTrails.length>0&&(this.wbLaserTrails=this.wbLaserTrails.map(e=>({...e,alpha:e.alpha-.05})).filter(e=>e.alpha>0),t=!0),this.tempDisappearingStrokes.length>0){const e=this.tempDisappearingStrokes.length;this.tempDisappearingStrokes=this.tempDisappearingStrokes.filter(a=>o-a.createdAt<a.durationMs),(this.tempDisappearingStrokes.length>0||e>0)&&(t=!0)}t&&this.drawWbCanvas(),this.wbLaserTrails.length>0||this.tempDisappearingStrokes.length>0?this.wbAnimationRafId=requestAnimationFrame(i):this.wbAnimationRafId=null};this.wbAnimationRafId=requestAnimationFrame(i)}requestWbRedraw(i,t){this.latestPreviewPoints=i,this.latestPreviewGeometry=t,!this.wbDrawRafScheduled&&(this.wbDrawRafScheduled=!0,requestAnimationFrame(()=>{this.wbDrawRafScheduled=!1,this.drawWbCanvas(this.latestPreviewPoints,this.latestPreviewGeometry)}))}getOrCreatePattern(i,t,o){const e=`${i}-${t?"light":"dark"}`;if(this.wbPatternCache.has(e))return this.wbPatternCache.get(e);const a=document.createElement("canvas"),d=a.getContext("2d");if(!d)return null;if(i==="dotted")a.width=18,a.height=18,d.fillStyle=t?"rgba(0, 0, 0, 0.15)":"rgba(255, 255, 255, 0.12)",d.beginPath(),d.arc(9,9,1.2,0,Math.PI*2),d.fill();else if(i==="matrix")a.width=24,a.height=24,d.strokeStyle=t?"rgba(0, 0, 0, 0.12)":"rgba(255, 255, 255, 0.08)",d.lineWidth=1,d.strokeRect(0,0,24,24);else if(i==="ruled")a.width=24,a.height=24,d.strokeStyle=t?"rgba(0, 0, 0, 0.09)":"rgba(255, 255, 255, 0.06)",d.lineWidth=1,d.beginPath(),d.moveTo(0,23),d.lineTo(24,23),d.stroke();else if(i==="grid")a.width=20,a.height=20,d.strokeStyle=t?"rgba(0, 0, 0, 0.08)":"rgba(255, 255, 255, 0.04)",d.lineWidth=1,d.strokeRect(0,0,20,20);else if(i==="isometric")a.width=48,a.height=28,d.strokeStyle=t?"rgba(0, 0, 0, 0.08)":"rgba(255, 255, 255, 0.05)",d.lineWidth=1,d.beginPath(),d.moveTo(0,0),d.lineTo(48,28),d.moveTo(0,28),d.lineTo(48,0),d.stroke();else return null;const r=o.createPattern(a,"repeat");return r&&this.wbPatternCache.set(e,r),r}drawWbCanvas(i,t){if(!this.shadow)return;const o=this.shadow.getElementById("nb-whiteboard-canvas");if(!o)return;const e=o.getContext("2d");if(!e)return;const a=window.devicePixelRatio||1,d=o.width/a,r=o.height/a;e.save(),e.setTransform(1,0,0,1,0,0),e.clearRect(0,0,o.width,o.height),e.restore(),e.save();const c=this.wbPrivacyMode==="personal",u=c?this.wbPersonalTheme||"grid":this.wbTheme||"grid",M=c?this.wbPersonalBgColor||"#090d16":this.wbBgColor||"#090d16",w=M==="#ffffff"||M==="#f8fafc"||M==="#fef3c7";if(e.fillStyle=M,e.fillRect(0,0,d,r),u!=="plain"&&u!=="blank"){const n=this.getOrCreatePattern(u,w,e);if(n&&(e.fillStyle=n,e.fillRect(0,0,d,r)),u==="ruled")e.strokeStyle="rgba(244, 63, 94, 0.35)",e.lineWidth=1.5,e.beginPath(),e.moveTo(40,0),e.lineTo(40,r),e.stroke();else if(u==="plot"){const g=d/2,v=r/2;e.strokeStyle=w?"#4f46e5":"#818cf8",e.lineWidth=1.5,e.beginPath(),e.moveTo(0,v),e.lineTo(d,v),e.moveTo(g,0),e.lineTo(g,r),e.stroke()}}if(e.restore(),this.wbTool==="eraser"&&this.wbEraserPos){e.save();const n=(this.wbWidth||4)*2.5;e.strokeStyle=w?"#ef4444":"#f87171",e.lineWidth=1.5,e.setLineDash([3,3]),e.beginPath(),e.arc(this.wbEraserPos.x,this.wbEraserPos.y,n,0,Math.PI*2),e.stroke(),e.fillStyle=w?"rgba(239, 68, 68, 0.08)":"rgba(239, 68, 68, 0.15)",e.fill(),e.restore()}const D=n=>{if(n.tool==="eraser")return;e.save();let g=n.color;if(w&&(g==="#ffffff"||g==="#fff")&&(g="#0f172a"),e.strokeStyle=g,e.fillStyle=g,e.lineWidth=n.width,e.lineCap="round",e.lineJoin="round",e.globalAlpha=n.opacity,n.geometry){const{x1:v,y1:k,x2:x,y2:P}=n.geometry,b=Math.min(v,x),m=Math.min(k,P),_=Math.abs(x-v),C=Math.abs(P-k),L=b+_/2,$=m+C/2;if(n.tool==="line")e.beginPath(),e.moveTo(v,k),e.lineTo(x,P),e.stroke(),n.geometry.label&&(e.fillStyle=w?"#0f172a":"#ffffff",e.font="bold 10px monospace",e.fillText(n.geometry.label,(v+x)/2,(k+P)/2-6));else if(n.tool==="arrow"){e.beginPath(),e.moveTo(v,k),e.lineTo(x,P),e.stroke();const p=Math.atan2(P-k,x-v),s=Math.max(10,n.width*3);e.beginPath(),e.moveTo(x,P),e.lineTo(x-s*Math.cos(p-Math.PI/6),P-s*Math.sin(p-Math.PI/6)),e.moveTo(x,P),e.lineTo(x-s*Math.cos(p+Math.PI/6),P-s*Math.sin(p+Math.PI/6)),e.stroke()}else if(n.tool==="arrow_bi"){e.beginPath(),e.moveTo(v,k),e.lineTo(x,P),e.stroke();const p=Math.atan2(P-k,x-v),s=Math.max(10,n.width*3);e.beginPath(),e.moveTo(x,P),e.lineTo(x-s*Math.cos(p-Math.PI/6),P-s*Math.sin(p-Math.PI/6)),e.moveTo(x,P),e.lineTo(x-s*Math.cos(p+Math.PI/6),P-s*Math.sin(p+Math.PI/6)),e.moveTo(v,k),e.lineTo(v+s*Math.cos(p-Math.PI/6),k+s*Math.sin(p-Math.PI/6)),e.moveTo(v,k),e.lineTo(v+s*Math.cos(p+Math.PI/6),k+s*Math.sin(p+Math.PI/6)),e.stroke()}else if(n.tool==="rect")e.strokeRect(b,m,_,C),n.geometry.label&&(e.fillStyle=w?"#0f172a":"#ffffff",e.font="bold 10px sans-serif",e.textAlign="center",e.textBaseline="middle",e.fillText(n.geometry.label,L,$));else if(n.tool==="rounded_rect")e.beginPath(),e.roundRect(b,m,Math.max(20,_),Math.max(20,C),8),e.stroke(),n.geometry.label&&(e.fillStyle=w?"#0f172a":"#ffffff",e.font="bold 10px sans-serif",e.textAlign="center",e.textBaseline="middle",e.fillText(n.geometry.label,L,$));else if(n.tool==="circle"){const p=_/2,s=C/2;e.beginPath(),e.ellipse(b+p,m+s,p,s,0,0,Math.PI*2),e.stroke(),n.geometry.label&&(e.fillStyle=w?"#0f172a":"#ffffff",e.font="bold 10px sans-serif",e.textAlign="center",e.textBaseline="middle",e.fillText(n.geometry.label,L,$))}else if(n.tool==="triangle")e.beginPath(),e.moveTo(L,m),e.lineTo(b+_,m+C),e.lineTo(b,m+C),e.closePath(),e.stroke();else if(n.tool==="star"){const s=Math.max(12,Math.min(_,C)/2),l=s/2.2;let h=Math.PI/2*3;const f=Math.PI/5;e.beginPath(),e.moveTo(L,$-s);for(let y=0;y<5;y++){let T=L+Math.cos(h)*s,I=$+Math.sin(h)*s;e.lineTo(T,I),h+=f,T=L+Math.cos(h)*l,I=$+Math.sin(h)*l,e.lineTo(T,I),h+=f}e.lineTo(L,$-s),e.closePath(),e.stroke()}else if(n.tool==="decision_diamond")e.beginPath(),e.moveTo(L,m),e.lineTo(b+_,$),e.lineTo(L,m+C),e.lineTo(b,$),e.closePath(),e.stroke(),n.geometry.label&&(e.fillStyle=w?"#0f172a":"#ffffff",e.font="bold 10px sans-serif",e.textAlign="center",e.textBaseline="middle",e.fillText(n.geometry.label,L,$));else if(n.tool==="tree_node"){const p=Math.max(16,n.width*3.5);e.beginPath(),e.arc(v,k,p,0,Math.PI*2),e.fillStyle=w?"rgba(255, 255, 255, 0.95)":"rgba(15, 23, 42, 0.9)",e.fill(),e.stroke(),n.geometry.label&&(e.fillStyle=w?"#0f172a":"#ffffff",e.font="bold 11px monospace",e.textAlign="center",e.textBaseline="middle",e.fillText(n.geometry.label,v,k))}else if(n.tool==="sticky_note"){const p=Math.max(80,_),s=Math.max(60,C);e.fillStyle="#fef3c7",e.strokeStyle="#f59e0b",e.beginPath(),e.roundRect(b,m,p,s,6),e.fill(),e.stroke(),n.geometry.label&&(e.fillStyle="#78350f",e.font="10px sans-serif",e.textAlign="left",e.textBaseline="top",e.fillText(n.geometry.label,b+6,m+6))}else if(n.tool==="text")e.fillStyle=g,e.font="bold 12px sans-serif",e.textAlign="left",e.textBaseline="top",e.fillText(n.geometry.label||"Label",v,k);else if(n.tool==="code_box"){const p=Math.max(80,_),s=Math.max(32,C);e.fillStyle=w?"rgba(240, 249, 255, 0.95)":"rgba(15, 23, 42, 0.95)",e.strokeStyle="#38bdf8",e.lineWidth=1.5,e.beginPath(),e.roundRect(b,m,p,s,4),e.fill(),e.stroke(),n.geometry.label&&(e.fillStyle="#0284c7",e.font="bold 10px monospace",e.textAlign="center",e.textBaseline="middle",e.fillText(n.geometry.label,b+p/2,m+s/2))}else if(n.tool==="array_cells"){const s=Math.max(22,Math.floor(Math.max(100,_)/5)),l=Math.max(24,Math.min(40,C||28));e.fillStyle=w?"rgba(255, 255, 255, 0.95)":"rgba(15, 23, 42, 0.9)";for(let h=0;h<5;h++){const f=b+h*s;e.fillRect(f,m,s,l),e.strokeRect(f,m,s,l),e.fillStyle=w?"#64748b":"#94a3b8",e.font="9px monospace",e.textAlign="center",e.textBaseline="bottom",e.fillText(`[${h}]`,f+s/2,m-2),e.fillStyle=w?"#0f172a":"#ffffff",e.font="bold 11px monospace",e.textBaseline="middle",e.fillText(`${h*2+1}`,f+s/2,m+l/2),e.fillStyle=w?"rgba(255, 255, 255, 0.95)":"rgba(15, 23, 42, 0.9)"}}else if(n.tool==="stack_lifo"){const p=Math.max(45,_),s=Math.max(70,C);e.beginPath(),e.moveTo(b,m),e.lineTo(b,m+s),e.lineTo(b+p,m+s),e.lineTo(b+p,m),e.stroke();const l=3,h=Math.floor((s-8)/l);for(let f=0;f<l;f++){const y=m+s-(f+1)*h;e.fillStyle=w?"rgba(245, 158, 11, 0.15)":"rgba(245, 158, 11, 0.25)",e.fillRect(b+3,y,p-6,h-2),e.strokeRect(b+3,y,p-6,h-2),e.fillStyle=w?"#0f172a":"#ffffff",e.font="bold 9px monospace",e.textAlign="center",e.textBaseline="middle",e.fillText(f===l-1?"TOP":`val_${f+1}`,b+p/2,y+h/2)}}else if(n.tool==="queue_fifo"){const p=Math.max(75,_),s=Math.max(28,C);e.beginPath(),e.moveTo(b,m),e.lineTo(b+p,m),e.moveTo(b,m+s),e.lineTo(b+p,m+s),e.stroke();const l=3,h=Math.floor((p-8)/l);for(let f=0;f<l;f++){const y=b+4+f*h;e.fillStyle=w?"rgba(16, 185, 129, 0.15)":"rgba(16, 185, 129, 0.25)",e.fillRect(y,m+3,h-2,s-6),e.strokeRect(y,m+3,h-2,s-6),e.fillStyle=w?"#0f172a":"#ffffff",e.font="bold 9px monospace",e.textAlign="center",e.textBaseline="middle",e.fillText(`e${f+1}`,y+h/2,m+s/2)}}else if(n.tool==="hashmap_table"){const p=Math.max(75,_),s=Math.max(50,C);e.strokeRect(b,m,p,s);const l=3,h=s/l;for(let f=1;f<l;f++)e.beginPath(),e.moveTo(b,m+f*h),e.lineTo(b+p,m+f*h),e.stroke();e.beginPath(),e.moveTo(b+22,m),e.lineTo(b+22,m+s),e.stroke();for(let f=0;f<l;f++)e.fillStyle=w?"#64748b":"#94a3b8",e.font="9px monospace",e.textAlign="center",e.textBaseline="middle",e.fillText(`${f}`,b+11,m+f*h+h/2),e.fillStyle=w?"#0f172a":"#ffffff",e.fillText(`k${f+1} ➔ v${f+1}`,b+26+(p-26)/2,m+f*h+h/2)}else if(n.tool==="two_pointers"){e.beginPath(),e.moveTo(v,k),e.lineTo(x,P),e.stroke();const p=Math.atan2(P-k,x-v),s=Math.max(8,n.width*2.5);e.beginPath(),e.moveTo(x,P),e.lineTo(x-s*Math.cos(p-Math.PI/6),P-s*Math.sin(p-Math.PI/6)),e.moveTo(x,P),e.lineTo(x-s*Math.cos(p+Math.PI/6),P-s*Math.sin(p+Math.PI/6)),e.stroke(),n.geometry.label&&(e.fillStyle=g,e.font="bold 10px monospace",e.textAlign="center",e.fillText(n.geometry.label,v,k-4))}else if(n.tool==="db_cylinder"||n.tool==="db_nosql"){const p=Math.max(50,_),s=Math.max(55,C),l=Math.min(14,s*.2);e.fillStyle=w?"rgba(255, 255, 255, 0.95)":"rgba(15, 23, 42, 0.95)",e.beginPath(),e.ellipse(b+p/2,m+l,p/2,l,0,Math.PI,0),e.lineTo(b+p,m+s-l),e.ellipse(b+p/2,m+s-l,p/2,l,0,0,Math.PI),e.lineTo(b,m+l),e.fill(),e.stroke(),e.beginPath(),e.ellipse(b+p/2,m+l,p/2,l,0,0,Math.PI*2),e.stroke(),n.geometry.label&&(e.fillStyle=w?"#0f172a":"#ffffff",e.font="bold 10px sans-serif",e.textAlign="center",e.textBaseline="middle",e.fillText(n.geometry.label,b+p/2,m+s/2+4))}else if(n.tool==="cloud"){const p=Math.max(65,_),s=Math.max(40,C);e.fillStyle=w?"rgba(255, 255, 255, 0.95)":"rgba(15, 23, 42, 0.95)",e.beginPath(),e.roundRect(b,m,p,s,14),e.fill(),e.stroke(),n.geometry.label&&(e.fillStyle=w?"#0f172a":"#ffffff",e.font="bold 10px sans-serif",e.textAlign="center",e.textBaseline="middle",e.fillText(n.geometry.label,b+p/2,m+s/2))}else if(n.tool==="load_balancer"){const p=Math.max(55,_),s=Math.max(55,C);e.fillStyle=w?"rgba(255, 255, 255, 0.95)":"rgba(15, 23, 42, 0.95)",e.beginPath(),e.moveTo(b+p/2,m),e.lineTo(b+p,m+s/2),e.lineTo(b+p/2,m+s),e.lineTo(b,m+s/2),e.closePath(),e.fill(),e.stroke(),n.geometry.label&&(e.fillStyle=w?"#0f172a":"#ffffff",e.font="bold 10px sans-serif",e.textAlign="center",e.textBaseline="middle",e.fillText(n.geometry.label,b+p/2,m+s/2))}else if(n.tool==="message_queue"){const p=Math.max(70,_),s=Math.max(34,C);e.fillStyle=w?"rgba(255, 255, 255, 0.95)":"rgba(15, 23, 42, 0.95)",e.beginPath(),e.roundRect(b,m,p,s,6),e.fill(),e.stroke(),n.geometry.label&&(e.fillStyle=w?"#0f172a":"#ffffff",e.font="bold 9px sans-serif",e.textAlign="center",e.textBaseline="middle",e.fillText(n.geometry.label,b+p/2,m+s/2))}else if(n.tool==="server_box"){const p=Math.max(65,_),s=Math.max(40,C);e.fillStyle=w?"rgba(255, 255, 255, 0.95)":"rgba(15, 23, 42, 0.95)",e.beginPath(),e.roundRect(b,m,p,s,6),e.fill(),e.stroke(),e.fillStyle="#10b981",e.beginPath(),e.arc(b+10,m+10,3,0,Math.PI*2),e.fill(),n.geometry.label&&(e.fillStyle=w?"#0f172a":"#ffffff",e.font="bold 9px sans-serif",e.textAlign="center",e.textBaseline="middle",e.fillText(n.geometry.label,b+p/2,m+s/2+2))}else if(n.tool==="cache_mem"){const p=Math.max(65,_),s=Math.max(32,C);e.fillStyle=w?"rgba(244, 63, 94, 0.1)":"rgba(244, 63, 94, 0.2)",e.beginPath(),e.roundRect(b,m,p,s,5),e.fill(),e.stroke(),e.fillStyle=w?"#0f172a":"#ffffff",e.font="bold 9px sans-serif",e.textAlign="center",e.textBaseline="middle",e.fillText(n.geometry.label||"⚡ Redis Cache",b+p/2,m+s/2)}else if(n.tool==="cdn_edge"){const p=Math.max(65,_),s=Math.max(36,C);e.fillStyle=w?"rgba(6, 182, 212, 0.1)":"rgba(6, 182, 212, 0.2)",e.beginPath(),e.roundRect(b,m,p,s,12),e.fill(),e.stroke(),e.fillStyle=w?"#0f172a":"#ffffff",e.font="bold 9px sans-serif",e.textAlign="center",e.textBaseline="middle",e.fillText(n.geometry.label||"🌐 CDN Edge",b+p/2,m+s/2)}else if(n.tool==="object_storage"){const p=Math.max(65,_),s=Math.max(45,C);e.fillStyle=w?"rgba(249, 115, 22, 0.1)":"rgba(249, 115, 22, 0.2)",e.beginPath(),e.roundRect(b,m,p,s,6),e.fill(),e.stroke(),e.fillStyle=w?"#0f172a":"#ffffff",e.font="bold 9px sans-serif",e.textAlign="center",e.textBaseline="middle",e.fillText(n.geometry.label||"📦 S3 Storage",b+p/2,m+s/2)}else if(n.tool==="auth_jwt"){const p=Math.max(60,_),s=Math.max(40,C);e.beginPath(),e.moveTo(b+p/2,m),e.lineTo(b+p,m+s*.3),e.lineTo(b+p/2,m+s),e.lineTo(b,m+s*.3),e.closePath(),e.fillStyle=w?"rgba(234, 179, 8, 0.15)":"rgba(234, 179, 8, 0.25)",e.fill(),e.stroke(),e.fillStyle=w?"#0f172a":"#ffffff",e.font="bold 9px sans-serif",e.textAlign="center",e.textBaseline="middle",e.fillText(n.geometry.label||"🛡️ JWT Auth",b+p/2,m+s/2)}else if(n.tool==="websocket_gw"){const p=Math.max(65,_),s=Math.max(36,C);e.fillStyle=w?"rgba(99, 102, 241, 0.15)":"rgba(99, 102, 241, 0.25)",e.beginPath(),e.roundRect(b,m,p,s,6),e.fill(),e.stroke(),e.fillStyle=w?"#0f172a":"#ffffff",e.font="bold 9px sans-serif",e.textAlign="center",e.textBaseline="middle",e.fillText(n.geometry.label||"⚡ WS Gateway",b+p/2,m+s/2)}else if(n.tool==="elasticsearch"){const p=Math.max(65,_),s=Math.max(36,C);e.fillStyle=w?"rgba(20, 184, 166, 0.15)":"rgba(20, 184, 166, 0.25)",e.beginPath(),e.roundRect(b,m,p,s,6),e.fill(),e.stroke(),e.fillStyle=w?"#0f172a":"#ffffff",e.font="bold 9px sans-serif",e.textAlign="center",e.textBaseline="middle",e.fillText(n.geometry.label||"🔍 Search / ES",b+p/2,m+s/2)}else if(n.tool==="user_client"||n.tool==="mobile_client"){const p=Math.max(50,_),s=Math.max(34,C);e.fillStyle=w?"rgba(59, 130, 246, 0.15)":"rgba(59, 130, 246, 0.25)",e.beginPath(),e.roundRect(b,m,p,s,6),e.fill(),e.stroke(),e.fillStyle=w?"#0f172a":"#ffffff",e.font="bold 9px sans-serif",e.textAlign="center",e.textBaseline="middle",e.fillText(n.geometry.label||(n.tool==="mobile_client"?"📱 Mobile":"💻 Client"),b+p/2,m+s/2)}else if(n.tool==="async_arrow"){e.setLineDash([4,4]),e.beginPath(),e.moveTo(v,k),e.lineTo(x,P),e.stroke(),e.setLineDash([]);const p=Math.atan2(P-k,x-v),s=Math.max(10,n.width*3);e.beginPath(),e.moveTo(x,P),e.lineTo(x-s*Math.cos(p-Math.PI/6),P-s*Math.sin(p-Math.PI/6)),e.moveTo(x,P),e.lineTo(x-s*Math.cos(p+Math.PI/6),P-s*Math.sin(p+Math.PI/6)),e.stroke()}else if(n.tool==="tradeoff_note"){const p=Math.max(90,_),s=Math.max(45,C);e.fillStyle="rgba(250, 204, 21, 0.18)",e.strokeStyle="#facc15",e.beginPath(),e.roundRect(b,m,p,s,4),e.fill(),e.stroke(),e.fillStyle=w?"#78350f":"#fef08a",e.font="bold 9px sans-serif",e.textAlign="center",e.textBaseline="middle",e.fillText(n.geometry.label||"⚖️ Trade-off / CAP Analysis",b+p/2,m+s/2)}}else if(n.points&&n.points.length>0)if(n.points.length===1)e.beginPath(),e.arc(n.points[0].x,n.points[0].y,n.width/2,0,Math.PI*2),e.fill();else{e.beginPath(),e.moveTo(n.points[0].x,n.points[0].y);for(let v=1;v<n.points.length-1;v++){const k=(n.points[v].x+n.points[v+1].x)/2,x=(n.points[v].y+n.points[v+1].y)/2;e.quadraticCurveTo(n.points[v].x,n.points[v].y,k,x)}e.lineTo(n.points[n.points.length-1].x,n.points[n.points.length-1].y),e.stroke()}e.restore()},E=this.wbPrivacyMode==="personal"?this.wbPersonalStrokes:this.wbStrokes;E.forEach(D);const R=Date.now();if(this.tempDisappearingStrokes.forEach(n=>{const g=Math.max(0,1-(R-n.createdAt)/n.durationMs);D({...n.stroke,opacity:g})}),t?D({tool:this.wbTool,color:this.wbColor,width:this.wbTool==="highlighter"?14:this.wbWidth,opacity:this.wbTool==="highlighter"?.35:1,points:[],geometry:t}):i&&i.length>1&&D({tool:this.wbTool,color:this.wbColor,width:this.wbTool==="highlighter"?14:this.wbWidth,opacity:this.wbTool==="highlighter"?.35:1,points:i}),this.wbTool==="torch"&&this.wbTorchPos&&(e.save(),e.fillStyle="rgba(0, 0, 0, 0.75)",e.fillRect(0,0,d,r),e.globalCompositeOperation="destination-out",e.beginPath(),e.arc(this.wbTorchPos.x,this.wbTorchPos.y,55,0,Math.PI*2),e.fill(),e.globalCompositeOperation="source-over",e.strokeStyle="rgba(253, 224, 71, 0.85)",e.lineWidth=2.5,e.shadowColor="#fde047",e.shadowBlur=10,e.beginPath(),e.arc(this.wbTorchPos.x,this.wbTorchPos.y,55,0,Math.PI*2),e.stroke(),e.restore()),this.wbLaserTrails.forEach(n=>{e.save(),e.globalAlpha=n.alpha,e.fillStyle="#ef4444",e.shadowColor="#ef4444",e.shadowBlur=8,e.beginPath(),e.arc(n.x,n.y,4.5*n.alpha,0,Math.PI*2),e.fill(),e.restore()}),this.wbSelectionBox){e.save();const n=Math.min(this.wbSelectionBox.x1,this.wbSelectionBox.x2),g=Math.min(this.wbSelectionBox.y1,this.wbSelectionBox.y2),v=Math.abs(this.wbSelectionBox.x2-this.wbSelectionBox.x1),k=Math.abs(this.wbSelectionBox.y2-this.wbSelectionBox.y1);e.fillStyle=w?"rgba(99, 102, 241, 0.12)":"rgba(99, 102, 241, 0.2)",e.fillRect(n,g,v,k),e.strokeStyle="#6366f1",e.lineWidth=1.5,e.setLineDash([5,4]),e.strokeRect(n,g,v,k),e.restore()}if(this.wbSelectedStrokeIds.length>0){const n=E.filter(g=>this.wbSelectedStrokeIds.includes(g.id));if(n.length>0){let g=1/0,v=1/0,k=-1/0,x=-1/0;n.forEach($=>{const p=Y($);p.minX<g&&(g=p.minX),p.maxX>k&&(k=p.maxX),p.minY<v&&(v=p.minY),p.maxY>x&&(x=p.maxY)});const P=6,b=g-P,m=v-P,_=k-g+P*2,C=x-v+P*2;e.save(),e.strokeStyle="#38bdf8",e.lineWidth=1.5,e.setLineDash([4,4]),e.strokeRect(b,m,_,C),e.setLineDash([]),[{x:b,y:m},{x:b+_,y:m},{x:b,y:m+C},{x:b+_,y:m+C}].forEach($=>{e.fillStyle="#ffffff",e.fillRect($.x-3.5,$.y-3.5,7,7),e.strokeStyle="#0284c7",e.lineWidth=1.5,e.strokeRect($.x-3.5,$.y-3.5,7,7)}),e.restore()}}}listenForRuntimeMessages(){var i;typeof chrome<"u"&&((i=chrome.runtime)!=null&&i.onMessage)&&chrome.runtime.onMessage.addListener(t=>{var o;if(t.type==="FAB_SETTINGS_UPDATED"&&t.payload)this.settings={...U,...t.payload},this.settings.positionMode==="permanent"&&this.settings.savedPosition&&(this.currentPosition={...this.settings.savedPosition}),this.checkVisibilityAndRender(),this.hostElement&&this.render();else if(t.type==="WHITEBOARD_STROKE_LOCAL"&&t.stroke)this.wbStrokes.some(e=>e.id===t.stroke.id)||(this.wbStrokes.push(t.stroke),this.activeTab==="whiteboard"&&this.drawWbCanvas());else if(t.type==="WHITEBOARD_UPDATE_STROKES_LOCAL"&&t.strokes){const e=new Map(t.strokes.map(a=>[a.id,a]));this.wbStrokes=this.wbStrokes.map(a=>e.has(a.id)?e.get(a.id):a),this.activeTab==="whiteboard"&&this.drawWbCanvas()}else if(t.type==="WHITEBOARD_TEMP_STROKE_LOCAL"&&t.stroke)this.tempDisappearingStrokes.push({stroke:t.stroke,createdAt:Date.now(),durationMs:t.durationMs||3e3}),this.activeTab==="whiteboard"&&this.drawWbCanvas();else if(t.type==="WHITEBOARD_CLEAR_LOCAL")this.wbStrokes=[],this.wbRedoStack=[],this.activeTab==="whiteboard"&&this.drawWbCanvas();else if(t.type==="WHITEBOARD_UNDO_LOCAL"&&t.strokeId)this.wbStrokes=this.wbStrokes.filter(e=>e.id!==t.strokeId),this.activeTab==="whiteboard"&&this.drawWbCanvas();else if(t.type==="WHITEBOARD_BG_LOCAL")t.background&&(this.wbTheme=t.background),t.bgColor&&(this.wbBgColor=t.bgColor),this.activeTab==="whiteboard"&&this.drawWbCanvas();else if(t.type==="WHITEBOARD_SNAPSHOT"&&((o=t.notebook)!=null&&o.pages)){const e=t.notebook.pages.find(a=>a.id===t.notebook.activePageId)||t.notebook.pages[0];e&&(this.wbStrokes=e.strokes||[],e.background&&(this.wbTheme=e.background),e.bgColor&&(this.wbBgColor=e.bgColor),this.activeTab==="whiteboard"&&this.drawWbCanvas())}})}escapeHtml(i){return i.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}formatTimestamp(i){return new Date(i).toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"})}renderFormattedText(i,t,o){let e="";o!=null&&o.imageUrl&&(e+=`
        <div style="margin:4px 0;border-radius:6px;overflow:hidden;border:1px solid rgba(255,255,255,0.1);">
          <img src="${o.imageUrl}" alt="Shared image" style="width:100%;max-height:180px;object-fit:cover;display:block;" />
        </div>
      `);const d=i.split(`
`).map((r,c)=>{if(r.startsWith("```")&&r.endsWith("```")&&r.length>6){const u=r.slice(3,-3);return`
          <div style="background:rgba(0,0,0,0.45);padding:6px 8px;border-radius:6px;margin:4px 0;font-family:var(--font-mono);font-size:11px;position:relative;">
            <pre style="margin:0;white-space:pre-wrap;word-break:break-all;">${this.escapeHtml(u)}</pre>
          </div>
        `}return r.includes("||")?`<p style="margin:2px 0;">${r.split(/(\|\|.*?\|\|)/g).map((w,D)=>{if(w.startsWith("||")&&w.endsWith("||")&&w.length>4){const E=w.slice(2,-2),R=`${t}-${c}-${D}`,n=!!this.revealedSpoilers[R];return`
              <span style="display:inline-block;padding:1px 6px;border-radius:4px;background:${n?"rgba(99, 102, 241, 0.25)":"rgba(255, 255, 255, 0.15)"};filter:${n?"none":"blur(4px)"};cursor:pointer;">
                ${this.escapeHtml(E)}
              </span>
            `}return this.renderMentionsHtml(this.escapeHtml(w))}).join("")}</p>`:`<p style="margin:2px 0;">${this.renderMentionsHtml(this.escapeHtml(r))}</p>`}).join("");return e+d}renderMentionsHtml(i){return i.includes("@")?i.replace(/(@everyone|@all)/g,'<span style="background:rgba(245,158,11,0.25);border:1px solid rgba(245,158,11,0.5);color:#fbbf24;padding:1px 4px;border-radius:3px;font-weight:700;font-size:10px;">📣 $1</span>').replace(/(@[a-zA-Z0-9_-]+)/g,'<span style="background:rgba(99,102,241,0.25);border:1px solid rgba(99,102,241,0.4);color:#c7d2fe;padding:1px 4px;border-radius:3px;font-weight:600;font-size:10px;">$1</span>'):i}deduplicateMessages(i){var e,a;const t=new Set,o=[];for(const d of i)!d||!d.id||t.has(d.id)||(t.add(d.id),o.push({...d,isSelf:((e=d.from)==null?void 0:e.peerId)===((a=this.myIdentity)==null?void 0:a.peerId)||d.isSelf}));return o}async sendMessage(i,t){var d,r,c,u;if(!i.trim())return;!this.currentRoomStorageKey&&((d=this.currentProblem)!=null&&d.roomId)&&(this.currentRoomStorageKey=`synqto_chat_${this.currentProblem.roomId}`);const o=i.trim(),e="msg-"+Math.random().toString(36).slice(2,10)+Date.now(),a={id:e,from:this.myIdentity||{nickname:"You",avatar:"⚡",color:"#6366f1",peerId:"self"},text:o,timestamp:Date.now(),replyTo:t==null?void 0:t.id,replyPreview:t==null?void 0:t.preview,status:"sent",isSelf:!0};if(this.messages.push(a),this.messages=this.deduplicateMessages(this.messages),this.render(),this.scrollToBottom(),this.currentRoomStorageKey&&typeof chrome<"u"&&((r=chrome.storage)!=null&&r.local))try{const M=await chrome.storage.local.get([this.currentRoomStorageKey]),w=M[this.currentRoomStorageKey]&&Array.isArray(M[this.currentRoomStorageKey])?M[this.currentRoomStorageKey]:[],D=this.deduplicateMessages([...w,a]).slice(-150);await chrome.storage.local.set({[this.currentRoomStorageKey]:D})}catch{}typeof chrome<"u"&&((c=chrome.runtime)!=null&&c.sendMessage)&&chrome.runtime.sendMessage({type:"SEND_PAGE_CHAT_MESSAGE",messageId:e,text:a.text,replyTo:a.replyTo,replyPreview:a.replyPreview,roomId:(u=this.currentProblem)==null?void 0:u.roomId}).catch(()=>{})}async loadMessages(){var i;if(this.currentRoomStorageKey&&typeof chrome<"u"&&(i=chrome.storage)!=null&&i.local){const t=await chrome.storage.local.get([this.currentRoomStorageKey]);t[this.currentRoomStorageKey]&&Array.isArray(t[this.currentRoomStorageKey])&&(this.messages=this.deduplicateMessages(t[this.currentRoomStorageKey]),this.isOpen&&this.activeTab==="chat"&&(this.render(),this.scrollToBottom()))}}scrollToBottom(){setTimeout(()=>{var t;const i=(t=this.shadow)==null?void 0:t.getElementById("nb-messages");i&&(i.scrollTop=i.scrollHeight)},40)}listenToStorageChanges(){var i;typeof chrome<"u"&&((i=chrome.storage)!=null&&i.onChanged)&&chrome.storage.onChanged.addListener((t,o)=>{var e,a,d,r;if(o==="local"){if(t.nerd_buddy_sidepanel_open&&t.nerd_buddy_sidepanel_open.newValue===!0&&this.isOpen&&(this.isOpen=!1,this.render()),(t.synqto_live_stage||t.nerd_buddy_live_stage)&&(this.liveStage=(t.synqto_live_stage||t.nerd_buddy_live_stage).newValue,this.render()),(t.synqto_identity||t.nerd_buddy_identity)&&(this.myIdentity=(t.synqto_identity||t.nerd_buddy_identity).newValue),t[q]||t[z]){const c=(e=t[q]||t[z])==null?void 0:e.newValue;c&&(this.settings={...U,...c},this.settings.positionMode==="permanent"&&this.settings.savedPosition&&(this.currentPosition={...this.settings.savedPosition}),this.checkVisibilityAndRender(),this.hostElement&&this.render())}if((t.synqto_active_problem||t.nerd_buddy_active_problem)&&(this.currentProblem=(t.synqto_active_problem||t.nerd_buddy_active_problem).newValue,this.currentRoomStorageKey=`synqto_chat_${((a=this.currentProblem)==null?void 0:a.roomId)||""}`,this.loadMessages(),this.checkVisibilityAndRender()),t.nerd_buddy_peer_count&&(this.peerCount=Math.max(1,t.nerd_buddy_peer_count.newValue||1),this.render()),this.currentRoomStorageKey&&t[this.currentRoomStorageKey]){const c=t[this.currentRoomStorageKey].newValue||[];this.messages=this.deduplicateMessages(c),!this.isOpen&&((d=t[this.currentRoomStorageKey].newValue)==null?void 0:d.length)>(((r=t[this.currentRoomStorageKey].oldValue)==null?void 0:r.length)||0)&&this.unreadCount++,this.render(),this.isOpen&&this.activeTab==="chat"&&this.scrollToBottom()}if(t.synqto_server_connected||t.nerd_buddy_server_connected){const c=t.synqto_server_connected||t.nerd_buddy_server_connected,u=!!c.newValue,M=!!c.oldValue;this.isServerConnected=u,u&&!M&&this.showServerConnectedToast("⚡ Connected to Synqto Server"),this.render()}if(t.synqto_theme_settings&&(this.themeSettings=t.synqto_theme_settings.newValue,this.render()),t.synqto_collab_notebook){const c=t.synqto_collab_notebook.newValue;if(c&&Array.isArray(c.pages)){const u=c.pages.find(M=>M.id===c.activePageId)||c.pages[0];u&&(this.wbStrokes=u.strokes||[],u.background&&(this.wbTheme=u.background),u.bgColor&&(this.wbBgColor=u.bgColor),this.activeTab==="whiteboard"&&this.drawWbCanvas())}}if(t.synqto_inpage_personal_board){const c=t.synqto_inpage_personal_board.newValue;c&&(Array.isArray(c.strokes)&&(this.wbPersonalStrokes=c.strokes),c.theme&&(this.wbPersonalTheme=c.theme),c.bgColor&&(this.wbPersonalBgColor=c.bgColor),this.activeTab==="whiteboard"&&this.wbPrivacyMode==="personal"&&this.drawWbCanvas())}if(t[H]){const c=t[H].newValue;c&&(this.timerConfig={...K,...c},this.render())}if(t[O]){const c=t[O].newValue;c&&(this.timerState=c,this.updateTimerDisplay(),this.isOpen&&this.render())}}})}showServerConnectedToast(i){this.serverToastMessage=i,this.render(),setTimeout(()=>{this.serverToastMessage=null,this.render()},3200)}async loadTimerState(){var i;if(typeof chrome<"u"&&((i=chrome.storage)!=null&&i.local))try{const t=await chrome.storage.local.get([H,O]);if(t[H]&&(this.timerConfig={...K,...t[H]}),t[O]){const o=t[O];if(o.isRunning){const e=Math.floor((Date.now()-o.lastUpdated)/1e3);o.mode==="stopwatch"?o.timeLeftSec+=e:(o.timeLeftSec=Math.max(0,o.timeLeftSec-e),o.timeLeftSec===0&&(o.isRunning=!1))}this.timerState=o}}catch{}}saveTimerState(){var i;typeof chrome<"u"&&((i=chrome.storage)!=null&&i.local)&&chrome.storage.local.set({[O]:this.timerState})}startTimerTickLoop(){this.timerInterval&&clearInterval(this.timerInterval),this.timerInterval=setInterval(()=>{this.timerState.isRunning&&(this.timerState.mode==="stopwatch"?(this.timerState.timeLeftSec+=1,this.timerState.lastUpdated=Date.now(),this.updateTimerDisplay()):this.timerState.timeLeftSec>0&&(this.timerState.timeLeftSec-=1,this.timerState.lastUpdated=Date.now(),this.updateTimerDisplay(),this.timerState.timeLeftSec===0?this.handleTimerSessionComplete():this.timerState.timeLeftSec%5===0&&this.saveTimerState()))},1e3)}updateTimerDisplay(){if(!this.shadow)return;const i=this.shadow.getElementById("nb-timer-time");i&&(i.textContent=this.formatTimerTime(this.timerState.timeLeftSec));const t=this.shadow.getElementById("nb-timer-fab-time");t&&(t.textContent=this.formatTimerTime(this.timerState.timeLeftSec));const o=this.shadow.getElementById("nb-timer-fab-fill");if(o){const a=this.getTimerProgressPct();o.style.width=`${a}%`}const e=this.shadow.getElementById("nb-timer-progress-fill");if(e){const a=this.getTimerProgressPct();e.style.width=`${a}%`}}getTimerProgressPct(){if(this.timerState.mode==="stopwatch"||this.timerState.targetDurationSec===0)return 100;const i=1-this.timerState.timeLeftSec/this.timerState.targetDurationSec;return Math.min(100,Math.max(0,i*100))}handleTimerSessionComplete(){if(this.timerState.isRunning=!1,this.timerState.lastUpdated=Date.now(),this.timerConfig.soundAlerts&&this.playTimerChime(),this.timerState.mode==="pomodoro"){this.timerState.sessionsCompleted+=1;const t=this.timerState.sessionsCompleted%4===0?"long_break":"short_break";this.resetTimerToMode(t),this.timerConfig.autoStartBreaks&&(this.timerState.isRunning=!0)}else this.resetTimerToMode("pomodoro");this.saveTimerState(),this.render()}resetTimerToMode(i){this.timerState.mode=i;let t=1500;i==="pomodoro"?t=(this.timerConfig.workDurationMin||25)*60:i==="short_break"?t=(this.timerConfig.shortBreakMin||5)*60:i==="long_break"?t=(this.timerConfig.longBreakMin||15)*60:i==="stopwatch"&&(t=0),this.timerState.timeLeftSec=t,this.timerState.targetDurationSec=t,this.timerState.lastUpdated=Date.now()}toggleTimer(){this.timerState.isRunning=!this.timerState.isRunning,this.timerState.lastUpdated=Date.now(),this.saveTimerState(),this.render()}resetTimer(){this.timerState.isRunning=!1,this.resetTimerToMode(this.timerState.mode),this.saveTimerState(),this.render()}setTimerMode(i){this.timerState.isRunning=!1,this.resetTimerToMode(i),this.saveTimerState(),this.render()}addTimerTime(i){this.timerState.mode!=="stopwatch"?(this.timerState.timeLeftSec=Math.max(0,this.timerState.timeLeftSec+i),this.timerState.targetDurationSec=Math.max(this.timerState.timeLeftSec,this.timerState.targetDurationSec+i)):this.timerState.timeLeftSec=Math.max(0,this.timerState.timeLeftSec+i),this.saveTimerState(),this.render()}formatTimerTime(i){const t=Math.floor(i/60),o=i%60;return`${t.toString().padStart(2,"0")}:${o.toString().padStart(2,"0")}`}playTimerChime(){try{const i=window.AudioContext||window.webkitAudioContext;if(!i)return;const t=new i,o=(e,a,d)=>{const r=t.createOscillator(),c=t.createGain();r.type="sine",r.frequency.setValueAtTime(e,t.currentTime+a),c.gain.setValueAtTime(0,t.currentTime+a),c.gain.linearRampToValueAtTime(.2,t.currentTime+a+.05),c.gain.exponentialRampToValueAtTime(.001,t.currentTime+a+d),r.connect(c),c.connect(t.destination),r.start(t.currentTime+a),r.stop(t.currentTime+a+d)};o(523.25,0,1.2),o(659.25,.15,1.2),o(783.99,.3,1.5),o(1046.5,.45,2)}catch{}}getThemeCSS(){var M,w,D,E,R,n,g,v,k,x;const i=((M=this.themeSettings)==null?void 0:M.mode)||"system",t=i==="day"||i==="light"||i==="leetcode_light"||i==="solarized_light"||i==="sakura"||i==="system"&&typeof window<"u"&&((w=window.matchMedia)==null?void 0:w.call(window,"(prefers-color-scheme: light)").matches);let o="rgba(26, 38, 41, 0.96)",e="rgba(38, 55, 59, 0.95)",a="rgba(45, 212, 191, 0.18)",d="#ecfdf5",r="#a7f3d0",c="#2dd4bf",u="#14b8a6";return(D=this.themeSettings)!=null&&D.customPaletteEnabled?(o=this.themeSettings.customBgSurface||"#1e2b2f",e=this.themeSettings.customBgSurface||"#26373b",c=this.themeSettings.customPrimary||"#2dd4bf",u=this.themeSettings.customPrimary||"#14b8a6",d=this.themeSettings.customTextPrimary||"#ecfdf5",r=this.themeSettings.customTextSecondary||"#94a3b8",a=`${r}33`):i==="nordic_forest"?(o="rgba(26, 38, 41, 0.96)",e="rgba(38, 55, 59, 0.95)",a="rgba(45, 212, 191, 0.22)",d="#ecfdf5",r="#a7f3d0",c="#2dd4bf",u="#14b8a6"):i==="leetcode_dark"?(o="rgba(38, 38, 38, 0.96)",e="rgba(48, 48, 48, 0.95)",a="rgba(255, 161, 22, 0.25)",d="#eff1f6",r="#abb2bf",c="#FFA116",u="#f59e0b"):i==="leetcode_light"?(o="#ffffff",e="#f7f7f8",a="rgba(230, 138, 0, 0.25)",d="#262626",r="#595959",c="#e68a00",u="#cc7a00"):i==="oled"?(o="rgba(10, 10, 10, 0.98)",e="rgba(24, 24, 24, 0.95)",a="rgba(255, 255, 255, 0.18)",d="#ffffff",r="#e2e8f0"):i==="espresso"?(o="rgba(32, 21, 14, 0.96)",e="rgba(48, 32, 22, 0.95)",a="rgba(245, 158, 11, 0.2)",d="#fef3c7",r="#fde68a",c="#f59e0b",u="#d97706"):i==="forest"?(o="rgba(8, 28, 17, 0.96)",e="rgba(14, 42, 27, 0.95)",a="rgba(16, 185, 129, 0.2)",d="#ecfdf5",r="#a7f3d0",c="#10b981",u="#059669"):i==="nord"?(o="rgba(46, 52, 64, 0.96)",e="rgba(59, 66, 82, 0.95)",a="rgba(136, 192, 208, 0.2)",d="#eceff4",r="#e5e9f0",c="#88c0d0",u="#81a1c1"):i==="dracula"?(o="rgba(40, 42, 54, 0.96)",e="rgba(68, 71, 90, 0.95)",a="rgba(189, 147, 249, 0.2)",d="#f8f8f2",r="#bd93f9",c="#bd93f9",u="#a855f7"):i==="synthwave"?(o="rgba(38, 20, 71, 0.96)",e="rgba(54, 28, 102, 0.95)",a="rgba(244, 114, 182, 0.25)",d="#fff0f5",r="#f472b6",c="#f472b6",u="#ec4899"):i==="solarized_dark"?(o="rgba(0, 43, 54, 0.96)",e="rgba(7, 54, 66, 0.95)",a="rgba(42, 161, 152, 0.25)",d="#fdf6e3",r="#eee8d5",c="#2aa198",u="#268bd2"):i==="solarized_light"?(o="#fdf6e3",e="#eee8d5",a="rgba(7, 54, 66, 0.2)",d="#073642",r="#586e75",c="#268bd2",u="#1e6ea8"):i==="sakura"?(o="#ffffff",e="#fff0f3",a="rgba(244, 63, 94, 0.2)",d="#4c0519",r="#881337",c="#f43f5e",u="#e11d48"):t?(o="#ffffff",e="#f6f8fa",a="rgba(31, 35, 40, 0.15)",d="#1f2328",r="#4b5563",c="#4f46e5",u="#4338ca"):i==="night"&&(o="rgba(22, 27, 34, 0.96)",e="rgba(33, 38, 45, 0.95)",a="rgba(255, 255, 255, 0.12)",d="#f0f6fc",r="#c9d1d9",c="#6366f1",u="#4f46e5"),(E=this.themeSettings)!=null&&E.customPaletteEnabled||(((R=this.themeSettings)==null?void 0:R.accent)==="leetcode"?(c="#FFA116",u="#f59e0b"):((n=this.themeSettings)==null?void 0:n.accent)==="emerald"?(c="#10b981",u="#059669"):((g=this.themeSettings)==null?void 0:g.accent)==="cyan"?(c="#06b6d4",u="#0891b2"):((v=this.themeSettings)==null?void 0:v.accent)==="rose"?(c="#f43f5e",u="#e11d48"):((k=this.themeSettings)==null?void 0:k.accent)==="amber"?(c="#f59e0b",u="#d97706"):((x=this.themeSettings)==null?void 0:x.accent)==="purple"&&(c="#a855f7",u="#9333ea")),`
      --primary: ${c};
      --primary-hover: ${u};
      --bg-card: ${o};
      --bg-surface-elevated: ${e};
      --border-subtle: ${a};
      --text-primary: ${d};
      --text-secondary: ${r};
      --text-muted: ${t?"#6b7280":"#8b949e"};
      --text-dim: ${t?"#9ca3af":"#6e7681"};
    `}}class le{constructor(){this.isEnabled=!0,this.showDock=!1,this.dockPosition={top:16,right:90},this.isDragging=!1,this.dragMoved=!1,this.activePeers=new Map,this.containerEl=null,this.lastSentCode="",this.lastSentCursor={line:1,ch:1},this.cleanupInterval=null,this.init()}async init(){var i,t;if(typeof chrome<"u"&&((i=chrome.storage)!=null&&i.local)){const o=await chrome.storage.local.get(["synqto_code_together_enabled","synqto_code_together_dock_visible","synqto_fab_settings","nerd_buddy_fab_settings"]);this.isEnabled=o.synqto_code_together_enabled!==!1;const e=o.synqto_fab_settings||o.nerd_buddy_fab_settings;this.showDock=!!(o.synqto_code_together_dock_visible||e!=null&&e.showCodeTogetherDock),e!=null&&e.savedCodeTogetherPosition&&(this.dockPosition={...e.savedCodeTogetherPosition})}this.injectMainWorldBridge(),this.setupPageMessageListeners(),this.setupRuntimeListeners(),this.setupStorageListeners(),this.showDock&&this.renderFloatingDock(),this.startCursorCleanup(),typeof chrome<"u"&&((t=chrome.runtime)!=null&&t.sendMessage)&&chrome.runtime.sendMessage({type:"CODE_GET_STATE"},o=>{o&&o.code&&this.isEnabled&&this.applyRemoteCodeToPage(o.code,o.language||"python",o.lastEditedBy,1,1)})}setupStorageListeners(){var i;typeof chrome>"u"||!((i=chrome.storage)!=null&&i.onChanged)||chrome.storage.onChanged.addListener((t,o)=>{var a,d;if(o!=="local")return;let e=!1;if(t.synqto_code_together_enabled&&(this.isEnabled=t.synqto_code_together_enabled.newValue!==!1,e=!0),t.synqto_code_together_dock_visible&&(this.showDock=!!t.synqto_code_together_dock_visible.newValue,e=!0),t.synqto_fab_settings||t.nerd_buddy_fab_settings){const r=((a=t.synqto_fab_settings)==null?void 0:a.newValue)||((d=t.nerd_buddy_fab_settings)==null?void 0:d.newValue);r&&(r.showCodeTogetherDock!==void 0&&(this.showDock=!!r.showCodeTogetherDock),r.savedCodeTogetherPosition&&(this.dockPosition={...r.savedCodeTogetherPosition}),e=!0)}e&&(this.showDock?this.renderFloatingDock():this.containerEl&&(this.containerEl.remove(),this.containerEl=null))})}injectMainWorldBridge(){var i,t;if(!(typeof document>"u")&&((i=document.documentElement)==null?void 0:i.getAttribute("data-synqto-bridge"))!=="active"&&!document.getElementById("synqto-inpage-editor-bridge"))try{if(typeof chrome<"u"&&((t=chrome.runtime)!=null&&t.getURL)){const o=document.createElement("script");o.id="synqto-inpage-editor-bridge",o.src=chrome.runtime.getURL("content/in-page-bridge.js"),o.async=!0,(document.head||document.documentElement).appendChild(o)}}catch(o){console.warn("[Synqto] Could not inject in-page editor bridge:",o)}}setupPageMessageListeners(){window.addEventListener("message",i=>{var e,a;if(!i.data||i.data.source!=="SYNQTO_EDITOR_BRIDGE")return;const{type:t,payload:o}=i.data;if(this.isEnabled){if(t==="LOCAL_CODE_CHANGED"){const{code:d,line:r,col:c,language:u}=o;d!==this.lastSentCode&&(this.lastSentCode=d,this.lastSentCursor={line:r,ch:c},typeof chrome<"u"&&((e=chrome.runtime)!=null&&e.sendMessage)&&chrome.runtime.sendMessage({type:"CODE_DELTA_LOCAL",payload:{code:d,cursorLine:r,cursorCol:c,language:u||"python"}}).catch(()=>{}))}else if(t==="LOCAL_CURSOR_MOVED"){const{line:d,ch:r}=o;(d!==this.lastSentCursor.line||r!==this.lastSentCursor.ch)&&(this.lastSentCursor={line:d,ch:r},typeof chrome<"u"&&((a=chrome.runtime)!=null&&a.sendMessage)&&chrome.runtime.sendMessage({type:"CODE_CURSOR_LOCAL",payload:{line:d,ch:r}}).catch(()=>{}))}}})}setupRuntimeListeners(){var i;typeof chrome>"u"||!((i=chrome.runtime)!=null&&i.onMessage)||chrome.runtime.onMessage.addListener(t=>{if(this.isEnabled){if(t.type==="CODE_DELTA_REMOTE"||t.type==="CODE_SYNC_REMOTE"){const{code:o,language:e,cursorLine:a,cursorCol:d,sender:r,lastEditedBy:c}=t.payload;this.applyRemoteCodeToPage(o,e,(r==null?void 0:r.nickname)||c||"Peer",a||1,d||1),r&&(this.activePeers.set(r.peerId,{peerId:r.peerId,nickname:r.nickname,color:r.color||"#3b82f6",line:a||1,ch:d||1,lastActive:Date.now()}),this.updateFloatingDock())}else if(t.type==="CODE_CURSOR_REMOTE"){const{peerId:o,nickname:e,color:a,line:d,ch:r}=t.payload;this.applyRemoteCursorToPage(o,e,a,d,r),this.activePeers.set(o,{peerId:o,nickname:e,color:a||"#3b82f6",line:d,ch:r,lastActive:Date.now()}),this.updateFloatingDock()}}})}applyRemoteCodeToPage(i,t,o,e,a){this.lastSentCode=i,window.postMessage({source:"SYNQTO_CONTENT_SCRIPT",type:"APPLY_REMOTE_CODE",payload:{code:i,language:t,cursorLine:e,cursorCol:a,sender:o}},"*")}applyRemoteCursorToPage(i,t,o,e,a){window.postMessage({source:"SYNQTO_CONTENT_SCRIPT",type:"APPLY_REMOTE_CURSOR",payload:{peerId:i,nickname:t,color:o,line:e,ch:a}},"*")}renderFloatingDock(){var w,D;if(this.containerEl&&this.containerEl.remove(),!this.showDock)return;const i=document.createElement("div");i.id="synqto-code-together-dock";const t=Number.isFinite((w=this.dockPosition)==null?void 0:w.top)?this.dockPosition.top:16,o=Number.isFinite((D=this.dockPosition)==null?void 0:D.right)?this.dockPosition.right:90;i.style.cssText=`
      position: fixed !important;
      top: ${t}px !important;
      right: ${o}px !important;
      z-index: 2147483640 !important;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, monospace !important;
      display: flex !important;
      align-items: center !important;
      gap: 6px !important;
      padding: 5px 10px !important;
      border-radius: 9999px !important;
      background: linear-gradient(135deg, rgba(15, 23, 42, 0.95), rgba(30, 41, 59, 0.95)) !important;
      border: 1px solid ${this.isEnabled?"rgba(99, 102, 241, 0.45)":"rgba(255, 255, 255, 0.12)"} !important;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.4) !important;
      color: #ffffff !important;
      font-size: 11px !important;
      font-weight: 700 !important;
      cursor: grab !important;
      backdrop-filter: blur(16px) !important;
      user-select: none !important;
      touch-action: none !important;
      transition: border-color 0.2s ease, box-shadow 0.2s ease !important;
    `,document.body.appendChild(i),this.containerEl=i;let e=0,a=0,d=o,r=t;const c=E=>{if(!this.isDragging)return;const R="touches"in E?E.touches[0].clientX:E.clientX,n="touches"in E?E.touches[0].clientY:E.clientY,g=R-e,v=n-a;if(Math.hypot(g,v)>4){this.dragMoved=!0;const k=d-g,x=r+v;this.dockPosition={right:Math.max(10,Math.min(window.innerWidth-160,k)),top:Math.max(10,Math.min(window.innerHeight-50,x))},this.containerEl&&(this.containerEl.style.setProperty("right",`${this.dockPosition.right}px`,"important"),this.containerEl.style.setProperty("top",`${this.dockPosition.top}px`,"important"))}},u=()=>{var E;this.isDragging&&(this.isDragging=!1,this.containerEl&&(this.containerEl.style.cursor="grab"),window.removeEventListener("mousemove",c),window.removeEventListener("mouseup",u),window.removeEventListener("touchmove",c),window.removeEventListener("touchend",u),this.dragMoved&&(typeof chrome<"u"&&((E=chrome.storage)!=null&&E.local)&&chrome.storage.local.get(["synqto_fab_settings"],R=>{const n=R.synqto_fab_settings||{};chrome.storage.local.set({synqto_fab_settings:{...n,savedCodeTogetherPosition:{...this.dockPosition}}})}),setTimeout(()=>{this.dragMoved=!1},60)))},M=E=>{this.isDragging=!0,this.dragMoved=!1,this.containerEl&&(this.containerEl.style.cursor="grabbing"),e="touches"in E?E.touches[0].clientX:E.clientX,a="touches"in E?E.touches[0].clientY:E.clientY,d=this.dockPosition.right,r=this.dockPosition.top,window.addEventListener("mousemove",c,{passive:!0}),window.addEventListener("mouseup",u),window.addEventListener("touchmove",c,{passive:!0}),window.addEventListener("touchend",u)};i.addEventListener("mousedown",M),i.addEventListener("touchstart",M,{passive:!0}),i.addEventListener("click",()=>{this.dragMoved||this.toggleCodeTogether()}),this.updateFloatingDock()}updateFloatingDock(){if(!this.containerEl)return;const i=this.activePeers.size;this.containerEl.innerHTML=`
      <span style="font-size: 10px; opacity: 0.5; margin-right: -2px;">⠿</span>
      <span style="font-size: 13px;">${this.isEnabled?"👥":"🔒"}</span>
      <span style="color: ${this.isEnabled?"#818cf8":"#94a3b8"};">Code Together:</span>
      <span style="padding: 1px 6px; border-radius: 10px; font-size: 10px; background: ${this.isEnabled?"rgba(16, 185, 129, 0.2)":"rgba(255, 255, 255, 0.08)"}; color: ${this.isEnabled?"#34d399":"#94a3b8"};">
        ${this.isEnabled?i>0?`Synced (${i+1})`:"Active ⚡":"Solo"}
      </span>
      ${this.isEnabled&&i>0?`
        <div style="display:flex;align-items:center;gap:2px;margin-left:4px;">
          ${Array.from(this.activePeers.values()).map(t=>`
            <span style="display:inline-block;width:7px;height:7px;border-radius:50%;background:${t.color||"#3b82f6"};box-shadow:0 0 6px ${t.color||"#3b82f6"};" title="${t.nickname} (line ${t.line}, col ${t.ch})"></span>
          `).join("")}
        </div>
      `:""}
    `,this.containerEl.style.borderColor=this.isEnabled?"rgba(99, 102, 241, 0.5)":"rgba(255, 255, 255, 0.12)"}toggleCodeTogether(){var i;this.isEnabled=!this.isEnabled,typeof chrome<"u"&&((i=chrome.storage)!=null&&i.local)&&chrome.storage.local.set({synqto_code_together_enabled:this.isEnabled}),this.updateFloatingDock()}startCursorCleanup(){this.cleanupInterval&&clearInterval(this.cleanupInterval),this.cleanupInterval=setInterval(()=>{const i=Date.now();let t=!1;this.activePeers.forEach((o,e)=>{i-o.lastActive>15e3&&(this.activePeers.delete(e),window.postMessage({source:"SYNQTO_CONTENT_SCRIPT",type:"REMOVE_PEER_CURSOR",payload:{peerId:e}},"*"),t=!0)}),t&&this.updateFloatingDock()},4e3)}}console.log("[Synqto] Content script initialized on:",window.location.href),new ie(S=>{var i;try{typeof chrome<"u"&&((i=chrome.runtime)!=null&&i.sendMessage)&&chrome.runtime.sendMessage({type:"PROBLEM_DETECTED",payload:S})}catch{}}),new oe,new ne,new le})();
